import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The backend is served from the same origin under /api.
// During development the dev server proxies /api to the backend on :4000.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:4000',
        changeOrigin: true,
      },
    },
  },
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
});
