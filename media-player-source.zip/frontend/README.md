# My Media Player — Frontend

Fresh from-scratch frontend for the My Media Player web app (personal local media library).

**Stack:** Vite 5 + React 18 + TypeScript + react-router-dom. Hand-rolled CSS (no UI framework).
Dark cinematic theme, Crunchyroll-inspired orange accent (`#f47521`), mobile-first responsive.

## Quick start

```bash
cd frontend-src
npm install

# Development — the dev server proxies /api to the backend on :4000
npm run dev
# open http://localhost:5173

# Type check
npm run typecheck   # tsc --noEmit

# Production build (outputs to dist/)
npm run build

# Preview the production build
npm run preview
```

## Backend contract

All HTTP calls live in `src/api.ts` (types in `src/types.ts`). The app talks to the
backend on the same origin under `/api`; in dev, Vite proxies `/api` to
`http://localhost:4000` (see `vite.config.ts`).

Implemented endpoints:

| Area | Calls |
|---|---|
| Health/config | `GET /api/health`, `GET/PUT /api/config` |
| Library | `POST /api/library/scan`, `GET /api/library` |
| Titles | `GET /api/titles/:id`, `PUT /api/titles/:id`, `POST /api/titles/:id/refresh`, `POST /api/titles/:id/artwork` (multipart) |
| Search | `GET /api/search?q=&kind=&genre=&sort=` |
| Progress | `GET /api/continue-watching`, `PUT /api/progress` |
| Collections | `GET/POST /api/collections`, `PUT/DELETE /api/collections/:id`, `GET /api/collections/:id`, `POST/DELETE /api/collections/:id/items` |
| Metadata | `GET /api/metadata/search?q=&kind=`, `POST /api/metadata/apply` |
| Reviews | `GET /api/reviews/:titleId`, `POST /api/reviews` |
| Providers | `GET/PUT /api/titles/:id/providers` |
| Media | `GET /api/media/episode/:episodeId` (range streaming), `GET /api/media/subtitles/:episodeId` |

## Pages

| Route | Page |
|---|---|
| `/` | Home — hero with rotating muted 12s local preview clips, Continue Watching, Recently Added, collection rows |
| `/shows`, `/movies`, `/music` | Filterable grids (search box + genre/sort filters) |
| `/search` | Global search with kind/genre filters |
| `/saved` | Collections (create/rename/delete) |
| `/collection/:id` | Titles in a collection (remove supported) |
| `/title/:id` | Detail — backdrop hero, Watch Order with season tabs, separately labeled Movies/OVAs/Specials sections, Where-to-watch popup, related titles, reviews at the very bottom, edit modal |
| `/watch/:episodeId` | VLC-style player |
| `/library` | Media folders config, scan with progress, metadata JSON export/import |

## Player features

- Custom controls: orange timeline with buffered display + elapsed/total, play/pause,
  prev/next episode, ±10s, volume slider + mute, brightness (CSS filter), playback
  speed, shuffle, repeat (off/one/all), PiP, fullscreen, sleep timer, playlist drawer,
  subtitle selector (SRT is converted to VTT client-side), settings menu
  (brightness, subtitle size).
- Auto-advance to next episode; progress reported via `PUT /api/progress` throttled to 5s.
- Touch gestures: horizontal swipe = seek, left-half vertical swipe = brightness,
  right-half vertical swipe = volume, double-tap left/right edge = ∓10s, single tap =
  toggle controls. Desktop keyboard: `Space` play/pause, `←/→` ∓10s (`Shift` = 30s),
  `↑/↓` volume, `F` fullscreen, `M` mute, `N`/`P` next/previous.

## Notes / assumptions

- **Artwork upload:** `POST /api/titles/:id/artwork` sends `kind` (and `episodeId` for
  stills) as query params with the file as multipart field `file`. Adjust in
  `src/api.ts` → `uploadArtwork` if the backend expects form fields instead.
- **Metadata export/import** is implemented client-side with the existing endpoints
  (`GET /api/library` + `GET /api/titles/:id` for export; `PUT /api/titles/:id` +
  `PUT /api/titles/:id/providers` for import). There is no dedicated backend
  export/import endpoint in the contract.
- **Scan progress:** the contract's scan endpoint returns a single result object
  (no streaming progress), so the UI shows an indeterminate "scanning" state plus
  the final `titlesAdded`/`episodesAdded`/`filesScanned` summary.
- **No online trailers, YouTube/Dailymotion embeds, or protected-source streaming**
  anywhere — the hero only ever plays the user's own local files.
- The player recovers its episode queue from `sessionStorage` on reload; deep-linking
  to `/watch/:episodeId` without navigation state still streams the episode but has
  no playlist context.
