import { Route, Routes, useLocation } from 'react-router-dom';
import Nav from './components/Nav';
import { Toaster } from './components/Toaster';
import Home from './pages/Home';
import Browse from './pages/Browse';
import SearchPage from './pages/SearchPage';
import Saved from './pages/Saved';
import CollectionPage from './pages/CollectionPage';
import Detail from './pages/Detail';
import Player from './pages/Player';
import Library from './pages/Library';
import NotFound from './pages/NotFound';

export default function App() {
  const location = useLocation();
  // The player is a full-screen overlay page; hide the top nav while watching.
  const isPlayer = location.pathname.startsWith('/watch/');

  return (
    <>
      {!isPlayer && <Nav />}
      <Toaster />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/shows" element={<Browse kind="show" />} />
        <Route path="/movies" element={<Browse kind="movie" />} />
        <Route path="/music" element={<Browse kind="music" />} />
        <Route path="/search" element={<SearchPage />} />
        <Route path="/saved" element={<Saved />} />
        <Route path="/collection/:id" element={<CollectionPage />} />
        <Route path="/title/:id" element={<Detail />} />
        <Route path="/watch/:episodeId" element={<Player />} />
        <Route path="/library" element={<Library />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}
