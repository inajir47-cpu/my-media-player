import { useEffect, useState } from 'react';
import { api } from '../api';
import type { Collection } from '../types';
import Modal from './Modal';
import { toast } from './Toaster';

export default function CollectionPicker({
  titleId,
  titleName,
  onClose,
}: {
  titleId: string;
  titleName: string;
  onClose: () => void;
}) {
  const [collections, setCollections] = useState<Collection[]>([]);
  const [memberOf, setMemberOf] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [newName, setNewName] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const cols = await api.getCollections();
        const membership = new Set<string>();
        // Check membership per collection.
        await Promise.all(
          cols.map(async (c) => {
            try {
              const detail = await api.getCollection(c.id);
              if (detail.titles.some((t) => t.id === titleId)) membership.add(c.id);
            } catch { /* ignore */ }
          }),
        );
        if (!cancelled) {
          setCollections(cols);
          setMemberOf(membership);
        }
      } catch (e) {
        toast(e instanceof Error ? e.message : 'Failed to load collections');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [titleId]);

  const toggle = async (collectionId: string, isMember: boolean) => {
    setBusy(true);
    try {
      if (isMember) {
        await api.removeFromCollection(collectionId, titleId);
        setMemberOf((prev) => { const n = new Set(prev); n.delete(collectionId); return n; });
      } else {
        await api.addToCollection(collectionId, titleId);
        setMemberOf((prev) => new Set(prev).add(collectionId));
      }
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to update collection');
    } finally {
      setBusy(false);
    }
  };

  const create = async () => {
    const name = newName.trim();
    if (!name) return;
    setBusy(true);
    try {
      const created = await api.createCollection(name);
      await api.addToCollection(created.id, titleId);
      setCollections((prev) => [...prev, created]);
      setMemberOf((prev) => new Set(prev).add(created.id));
      setNewName('');
      toast(`Created "${name}" and added this title`);
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to create collection');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title={`Save "${titleName}"`} onClose={onClose}>
      {loading ? (
        <div className="loading-wrap"><div className="spinner" /></div>
      ) : (
        <>
          {collections.length === 0 ? <p className="page-sub">No collections yet — create one below.</p> : null}
          {collections.map((c) => {
            const isMember = memberOf.has(c.id);
            return (
              <label key={c.id} className="check-row">
                <input
                  type="checkbox"
                  checked={isMember}
                  disabled={busy}
                  onChange={() => toggle(c.id, isMember)}
                />
                <span style={{ flex: 1 }}>{c.name}</span>
                {c.titleCount != null ? <span className="page-sub" style={{ margin: 0 }}>{c.titleCount} titles</span> : null}
              </label>
            );
          })}
          <div className="form-row" style={{ marginTop: 16 }}>
            <label htmlFor="new-collection">New collection</label>
            <div className="provider-row">
              <input
                id="new-collection"
                className="form-input"
                style={{ flex: 1 }}
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="Collection name"
                onKeyDown={(e) => { if (e.key === 'Enter') create(); }}
              />
              <button className="btn btn-primary btn-sm" disabled={busy || !newName.trim()} onClick={create}>
                Create
              </button>
            </div>
          </div>
        </>
      )}
    </Modal>
  );
}
