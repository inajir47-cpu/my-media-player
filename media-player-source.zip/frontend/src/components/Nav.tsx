import { Link, NavLink, useNavigate } from 'react-router-dom';

const TABS = [
  { to: '/', label: 'Home', end: true },
  { to: '/shows', label: 'Shows' },
  { to: '/movies', label: 'Movies' },
  { to: '/music', label: 'Music' },
  { to: '/saved', label: 'Saved' },
  { to: '/search', label: 'Search' },
];

export default function Nav() {
  const navigate = useNavigate();
  return (
    <header className="topnav">
      <Link to="/" className="logo" aria-label="My Media Player home">
        <span className="logo-dot" />
        My<em>Media</em>
      </Link>
      <nav className="nav-tabs" aria-label="Primary">
        {TABS.map((t) => (
          <NavLink key={t.to} to={t.to} end={t.end} className={({ isActive }) => `nav-tab${isActive ? ' active' : ''}`}>
            {t.label}
          </NavLink>
        ))}
      </nav>
      <div className="nav-spacer" />
      <button
        className="icon-btn"
        title="Library settings"
        aria-label="Library settings"
        onClick={() => navigate('/library')}
      >
        ⚙
      </button>
    </header>
  );
}
