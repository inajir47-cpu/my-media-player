import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api';
import type { Episode, PlaybackEpisode, TitleSummary } from '../types';
import { episodeLabel, formatRating, kindLabel } from '../utils/format';

const CLIP_SECONDS = 12;
const SKIP_INTRO_SECONDS = 90; // never start inside the first 90s

function storedStart(episodeId: string): number | null {
  try {
    const raw = localStorage.getItem(`mmp_hero_start_${episodeId}`);
    const n = raw == null ? NaN : Number(raw);
    return isFinite(n) && n >= 0 ? n : null;
  } catch {
    return null;
  }
}

function storeStart(episodeId: string, start: number) {
  try {
    localStorage.setItem(`mmp_hero_start_${episodeId}`, String(Math.floor(start)));
  } catch { /* ignore */ }
}

/**
 * Full-width hero that plays rotating MUTED 12-second preview clips taken from
 * random local episodes of a featured title. No online trailers, ever.
 */
export default function Hero({ titles }: { titles: TitleSummary[] }) {
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [featured, setFeatured] = useState<TitleSummary | null>(null);
  const [clips, setClips] = useState<PlaybackEpisode[]>([]);
  const [clipIndex, setClipIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const timerRef = useRef<number | undefined>(undefined);

  // Pick a featured title and gather its playable episodes.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      const candidates = titles.filter((t) => (t.episodeCount ?? 0) > 0);
      const pool = candidates.length > 0 ? candidates : titles;
      if (pool.length === 0) {
        if (!cancelled) { setFeatured(null); setClips([]); setLoading(false); }
        return;
      }
      // Prefer recently added titles so the hero feels fresh.
      const sorted = [...pool].sort((a, b) => String(b.updatedAt ?? '').localeCompare(String(a.updatedAt ?? '')));
      const pick = sorted[Math.floor(Math.random() * Math.min(5, sorted.length))];
      try {
        const detail = await api.getTitle(pick.id);
        const playable: PlaybackEpisode[] = [];
        for (const s of detail.seasons) {
          for (const e of s.episodes) {
            if (e.hasFile) {
              playable.push({
                ...e,
                titleId: pick.id,
                titleName: pick.name,
                titlePoster: pick.poster,
              });
            }
          }
        }
        if (!cancelled) {
          setFeatured(detail.title);
          // Shuffle so clips rotate unpredictably.
          for (let i = playable.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [playable[i], playable[j]] = [playable[j], playable[i]];
          }
          setClips(playable.slice(0, 12));
          setClipIndex(0);
        }
      } catch {
        if (!cancelled) { setFeatured(pick); setClips([]); }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [titles.length]);

  const clip: PlaybackEpisode | undefined = clips[clipIndex];

  // Rotate the clip roughly every 12 seconds.
  useEffect(() => {
    if (clips.length <= 1) return;
    window.clearTimeout(timerRef.current);
    timerRef.current = window.setTimeout(() => {
      setClipIndex((i) => (i + 1) % clips.length);
    }, CLIP_SECONDS * 1000);
    return () => window.clearTimeout(timerRef.current);
  }, [clipIndex, clips.length]);

  // Seek to the remembered (or random) start when a clip loads.
  const onLoadedMetadata = () => {
    const video = videoRef.current;
    if (!video || !clip) return;
    const dur = video.duration;
    let start = storedStart(clip.id);
    if (start == null || !(start < dur * 0.9)) {
      const latestStart = Math.max(0, dur * 0.9);
      const earliest = Math.min(SKIP_INTRO_SECONDS, latestStart * 0.5);
      start = earliest + Math.random() * Math.max(0, latestStart - earliest);
      storeStart(clip.id, start);
    }
    try { video.currentTime = start; } catch { /* ignore */ }
    video.play().catch(() => { /* autoplay may be blocked; hero still shows poster */ });
  };

  // Keep the clip looping inside its 12s window (in case the timer drifts).
  const onTimeUpdate = () => {
    const video = videoRef.current;
    if (!video || !clip) return;
    const start = storedStart(clip.id) ?? 0;
    if (video.currentTime - start >= CLIP_SECONDS) {
      setClipIndex((i) => (i + 1) % clips.length);
    }
  };

  const playFeatured = () => {
    if (!featured || !clip) return;
    navigate(`/watch/${clip.id}`, { state: { episodes: clips, currentId: clip.id } });
  };

  if (loading) {
    return <div className="hero"><div className="loading-wrap"><div className="spinner" /></div></div>;
  }

  if (!featured || clips.length === 0) {
    return (
      <div className="hero">
        <div className="hero-gradient" />
        <div className="hero-empty">
          <h1>Your screen. <em>Your files.</em></h1>
          <p>Add your media folders and scan your library to start watching your own collection.</p>
          <Link to="/library" className="btn btn-primary">Add media</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="hero">
      <video
        key={clip?.id}
        ref={videoRef}
        className="hero-video"
        src={clip ? api.episodeStreamUrl(clip.id) : undefined}
        muted
        playsInline
        preload="auto"
        onLoadedMetadata={onLoadedMetadata}
        onTimeUpdate={onTimeUpdate}
      />
      <div className="hero-gradient" />
      <div className="hero-content">
        <span className="hero-kind">{kindLabel(featured.kind)} · Preview</span>
        <h1 className="hero-title">{featured.name}</h1>
        <div className="hero-meta">
          {featured.year ? <span>{featured.year}</span> : null}
          {featured.rating != null ? <span className="rating">★ {formatRating(featured.rating)}</span> : null}
          {featured.genre ? <span>{featured.genre}</span> : null}
          {clip ? <span>{episodeLabel(clip.seasonNumber, clip.episodeNumber)} · {clip.name}</span> : null}
        </div>
        {featured.description ? <p className="hero-desc">{featured.description}</p> : null}
        <div className="hero-actions">
          <button className="btn btn-primary" onClick={playFeatured}>▶ Play</button>
          <Link to={`/title/${featured.id}`} className="btn btn-ghost">More Info</Link>
        </div>
      </div>
    </div>
  );
}

export type { Episode };
