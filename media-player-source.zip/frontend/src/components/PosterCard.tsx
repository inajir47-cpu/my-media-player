import { Link } from 'react-router-dom';
import type { ContinueWatchingItem, TitleSummary } from '../types';
import { formatDuration, formatRating } from '../utils/format';

/** Clean poster card: poster image, title, year/rating — never filenames, codec or quality badges. */
export function PosterCard({ title }: { title: TitleSummary }) {
  return (
    <Link to={`/title/${title.id}`} className="poster-card">
      <div className="poster-thumb">
        {title.poster ? <img src={title.poster} alt={title.name} loading="lazy" /> : <div className="placeholder">🎬</div>}
      </div>
      <div className="poster-body">
        <p className="poster-name" title={title.name}>{title.name}</p>
        <div className="poster-sub">
          {title.year ? <span>{title.year}</span> : null}
          {title.rating != null ? <span className="rating">★ {formatRating(title.rating)}</span> : null}
        </div>
      </div>
    </Link>
  );
}

/** Landscape card for Continue Watching with a progress bar. */
export function ContinueWatchingCard({ item }: { item: ContinueWatchingItem }) {
  const pct = item.duration > 0 ? Math.min(100, Math.max(0, (item.position / item.duration) * 100)) : 0;
  const sessionKey = `mmp_cw_${item.episodeId}`;
  return (
    <Link
      to={`/watch/${item.episodeId}`}
      className="poster-card cw-card"
      onClick={() => {
        try {
          sessionStorage.setItem(sessionKey, JSON.stringify({ position: item.position }));
        } catch { /* ignore */ }
      }}
    >
      <div className="poster-thumb">
        {item.poster ? <img src={item.poster} alt={item.titleName} loading="lazy" /> : <div className="placeholder">▶</div>}
      </div>
      <div className="poster-body">
        <p className="poster-name" title={item.titleName}>{item.titleName}</p>
        <p className="cw-ep">
          S{item.seasonNumber} E{item.episodeNumber} · {item.episodeName}
          {item.duration ? ` · ${formatDuration(item.duration - item.position)} left` : ''}
        </p>
        <div className="progress-track">
          <div className="progress-fill" style={{ width: `${pct}%` }} />
        </div>
      </div>
    </Link>
  );
}
