import { useEffect, useRef, useState } from 'react';
import { api } from '../api';
import type { MetadataResult, Provider, TitleDetail, TitleKind } from '../types';
import Modal from './Modal';
import { toast } from './Toaster';

export default function EditModal({
  detail,
  onClose,
  onSaved,
}: {
  detail: TitleDetail;
  onClose: () => void;
  onSaved: (updated: TitleDetail) => void;
}) {
  const t = detail.title;
  const [name, setName] = useState(t.name);
  const [description, setDescription] = useState(t.description ?? '');
  const [genre, setGenre] = useState(t.genre ?? '');
  const [year, setYear] = useState(t.year != null ? String(t.year) : '');
  const [language, setLanguage] = useState(t.language ?? '');
  const [rating, setRating] = useState(t.rating != null ? String(t.rating) : '');
  const [providers, setProviders] = useState<Provider[]>(detail.providers ?? []);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState<'poster' | 'backdrop' | null>(null);

  const [metaQuery, setMetaQuery] = useState(t.name);
  const [metaResults, setMetaResults] = useState<MetadataResult[]>([]);
  const [metaSearching, setMetaSearching] = useState(false);
  const [metaApplying, setMetaApplying] = useState<string | null>(null);

  const posterInput = useRef<HTMLInputElement>(null);
  const backdropInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Reset form if a different title is edited.
    setName(t.name);
    setDescription(t.description ?? '');
    setGenre(t.genre ?? '');
    setYear(t.year != null ? String(t.year) : '');
    setLanguage(t.language ?? '');
    setRating(t.rating != null ? String(t.rating) : '');
    setProviders(detail.providers ?? []);
    setMetaQuery(t.name);
    setMetaResults([]);
  }, [t.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const save = async () => {
    setSaving(true);
    try {
      const updated = await api.updateTitle(t.id, {
        name: name.trim() || t.name,
        description: description.trim() || null,
        genre: genre.trim() || null,
        year: year.trim() ? Number(year) : null,
        language: language.trim() || null,
        rating: rating.trim() ? Number(rating) : null,
      });
      await api.updateProviders(t.id, providers.filter((p) => p.name.trim() && p.url.trim()));
      const fresh = await api.getTitle(t.id);
      onSaved({ ...fresh, title: { ...fresh.title, ...updated } });
      toast('Details saved');
      onClose();
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  const upload = async (kind: 'poster' | 'backdrop', file: File | undefined) => {
    if (!file) return;
    setUploading(kind);
    try {
      await api.uploadArtwork(t.id, kind, file);
      const fresh = await api.getTitle(t.id);
      onSaved(fresh);
      toast(`${kind === 'poster' ? 'Poster' : 'Backdrop'} updated`);
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Upload failed');
    } finally {
      setUploading(null);
    }
  };

  const searchMetadata = async () => {
    const q = metaQuery.trim();
    if (!q) return;
    setMetaSearching(true);
    try {
      const results = await api.metadataSearch(q, t.kind as TitleKind);
      setMetaResults(results);
      if (results.length === 0) toast('No matches found');
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Metadata search failed');
    } finally {
      setMetaSearching(false);
    }
  };

  const applyMetadata = async (r: MetadataResult) => {
    setMetaApplying(r.providerId);
    try {
      const updated = await api.applyMetadata(t.id, r.provider, r.providerId);
      onSaved(updated);
      toast(`Applied ${r.provider} metadata`);
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to apply metadata');
    } finally {
      setMetaApplying(null);
    }
  };

  const updateProvider = (i: number, patch: Partial<Provider>) => {
    setProviders((prev) => prev.map((p, idx) => (idx === i ? { ...p, ...patch } : p)));
  };

  return (
    <Modal
      title={`Edit details — ${t.name}`}
      onClose={onClose}
      wide
      footer={
        <>
          <button className="btn btn-outline" onClick={onClose} disabled={saving}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={saving}>
            {saving ? 'Saving…' : 'Save changes'}
          </button>
        </>
      }
    >
      <div className="form-row">
        <label htmlFor="edit-name">Name</label>
        <input id="edit-name" className="form-input" value={name} onChange={(e) => setName(e.target.value)} />
      </div>
      <div className="form-row">
        <label htmlFor="edit-desc">Description</label>
        <textarea id="edit-desc" className="form-textarea" value={description} onChange={(e) => setDescription(e.target.value)} />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <div className="form-row">
          <label htmlFor="edit-genre">Genre</label>
          <input id="edit-genre" className="form-input" value={genre} onChange={(e) => setGenre(e.target.value)} placeholder="Drama, Action…" />
        </div>
        <div className="form-row">
          <label htmlFor="edit-year">Year</label>
          <input id="edit-year" className="form-input" value={year} onChange={(e) => setYear(e.target.value)} inputMode="numeric" placeholder="2024" />
        </div>
        <div className="form-row">
          <label htmlFor="edit-lang">Language</label>
          <input id="edit-lang" className="form-input" value={language} onChange={(e) => setLanguage(e.target.value)} placeholder="Japanese" />
        </div>
        <div className="form-row">
          <label htmlFor="edit-rating">Rating</label>
          <input id="edit-rating" className="form-input" value={rating} onChange={(e) => setRating(e.target.value)} inputMode="decimal" placeholder="8.5" />
        </div>
      </div>

      <div className="section-label"><span className="bar" />Artwork</div>
      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
        <input ref={posterInput} type="file" accept="image/*" hidden onChange={(e) => upload('poster', e.target.files?.[0])} />
        <input ref={backdropInput} type="file" accept="image/*" hidden onChange={(e) => upload('backdrop', e.target.files?.[0])} />
        <button className="btn btn-outline btn-sm" disabled={uploading != null} onClick={() => posterInput.current?.click()}>
          {uploading === 'poster' ? 'Uploading…' : 'Upload poster'}
        </button>
        <button className="btn btn-outline btn-sm" disabled={uploading != null} onClick={() => backdropInput.current?.click()}>
          {uploading === 'backdrop' ? 'Uploading…' : 'Upload backdrop'}
        </button>
      </div>

      <div className="section-label"><span className="bar" />Streaming links</div>
      {providers.map((p, i) => (
        <div className="provider-row" key={i}>
          <input className="form-input" value={p.name} onChange={(e) => updateProvider(i, { name: e.target.value })} placeholder="Service name" />
          <input className="form-input" style={{ flex: 1 }} value={p.url} onChange={(e) => updateProvider(i, { url: e.target.value })} placeholder="https://…" inputMode="url" />
          <button className="mini-btn danger" onClick={() => setProviders((prev) => prev.filter((_, idx) => idx !== i))} title="Remove">✕</button>
        </div>
      ))}
      <button className="btn btn-outline btn-sm" onClick={() => setProviders((prev) => [...prev, { name: '', url: '' }])}>
        + Add link
      </button>

      <div className="section-label"><span className="bar" />Find metadata</div>
      <div className="provider-row">
        <input
          className="form-input"
          style={{ flex: 1 }}
          value={metaQuery}
          onChange={(e) => setMetaQuery(e.target.value)}
          placeholder="Search AniList / TVmaze / Jikan"
          onKeyDown={(e) => { if (e.key === 'Enter') searchMetadata(); }}
        />
        <button className="btn btn-outline btn-sm" disabled={metaSearching || !metaQuery.trim()} onClick={searchMetadata}>
          {metaSearching ? 'Searching…' : 'Search'}
        </button>
      </div>
      {metaResults.map((r) => (
        <div className="meta-result" key={`${r.provider}-${r.providerId}`}>
          {r.poster ? <img src={r.poster} alt="" loading="lazy" /> : null}
          <div className="meta-info">
            <div className="meta-name">{r.name}</div>
            <div className="meta-sub">{r.provider}{r.year ? ` · ${r.year}` : ''}</div>
          </div>
          <button
            className="btn btn-primary btn-sm"
            disabled={metaApplying != null}
            onClick={() => applyMetadata(r)}
          >
            {metaApplying === r.providerId ? 'Applying…' : 'Apply'}
          </button>
        </div>
      ))}
    </Modal>
  );
}
