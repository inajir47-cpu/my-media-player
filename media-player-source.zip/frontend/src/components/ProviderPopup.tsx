import type { Provider } from '../types';
import Modal from './Modal';

export default function ProviderPopup({
  titleName,
  providers,
  onClose,
}: {
  titleName: string;
  providers: Provider[];
  onClose: () => void;
}) {
  return (
    <Modal title={`Where to watch "${titleName}"`} onClose={onClose}>
      {providers.length === 0 ? (
        <p className="page-sub">No streaming links have been added for this title yet. Add them from the Edit details dialog.</p>
      ) : (
        <>
          <p className="page-sub">This title has no local files. Try these links:</p>
          {providers.map((p, i) => (
            <a
              key={`${p.url}-${i}`}
              href={p.url}
              target="_blank"
              rel="noopener noreferrer"
              className="check-row"
              style={{ textDecoration: 'none' }}
            >
              <span style={{ flex: 1, fontWeight: 700 }}>{p.name}</span>
              <span style={{ color: 'var(--accent)' }}>Open →</span>
            </a>
          ))}
        </>
      )}
    </Modal>
  );
}
