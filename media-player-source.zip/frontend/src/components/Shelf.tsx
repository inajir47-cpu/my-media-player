import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';

export default function Shelf({
  title,
  moreTo,
  children,
}: {
  title: string;
  moreTo?: string;
  children: ReactNode;
}) {
  return (
    <section className="shelf">
      <div className="shelf-head">
        <h2 className="shelf-title"><span className="bar" />{title}</h2>
        {moreTo ? <Link to={moreTo} className="shelf-more">See all →</Link> : null}
      </div>
      <div className="shelf-row">{children}</div>
    </section>
  );
}
