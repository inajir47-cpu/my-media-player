// Tiny event-based toast. Render <Toaster /> once near the app root and call
// toast('message') from anywhere.
import { useEffect, useState } from 'react';

type Listener = (msg: string) => void;
const listeners = new Set<Listener>();

export function toast(msg: string) {
  listeners.forEach((l) => l(msg));
}

export function Toaster() {
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    let timer: number | undefined;
    const onToast = (m: string) => {
      setMsg(m);
      window.clearTimeout(timer);
      timer = window.setTimeout(() => setMsg(null), 2600);
    };
    listeners.add(onToast);
    return () => {
      listeners.delete(onToast);
      window.clearTimeout(timer);
    };
  }, []);

  if (!msg) return null;
  return <div className="toast" role="status">{msg}</div>;
}
