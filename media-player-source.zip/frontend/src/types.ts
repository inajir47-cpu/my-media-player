// Shared API + domain types for the My Media Player frontend.

export type TitleKind = 'show' | 'movie' | 'music';

export interface TitleSummary {
  id: string;
  kind: TitleKind;
  name: string;
  year?: number | null;
  poster?: string | null;
  backdrop?: string | null;
  rating?: number | null;
  description?: string | null;
  genre?: string | null;
  episodeCount?: number | null;
  seasonCount?: number | null;
  updatedAt?: string | null;
  language?: string | null;
}

export interface Episode {
  id: string;
  seasonNumber: number;
  episodeNumber: number;
  name: string;
  description?: string | null;
  still?: string | null;
  duration?: number | null; // seconds
  itemKind?: string | null; // 'episode' | 'movie' | 'ova' | 'special' | ...
  hasFile: boolean;
  progress?: EpisodeProgress | null;
}

export interface EpisodeProgress {
  position: number; // seconds
  duration: number; // seconds
}

export interface Season {
  seasonNumber: number;
  year?: number | null;
  episodes: Episode[];
}

export interface Review {
  author: string;
  rating?: number | null;
  text: string;
  source?: string | null;
}

export interface Provider {
  name: string;
  url: string;
}

export interface ContinueFrom {
  episodeId: string;
  position: number;
  duration: number;
}

export interface TitleDetail {
  title: TitleSummary;
  seasons: Season[];
  reviews: Review[];
  providers: Provider[];
  continueFrom: ContinueFrom | null;
}

export interface ContinueWatchingItem {
  titleId: string;
  titleName: string;
  poster?: string | null;
  episodeId: string;
  seasonNumber: number;
  episodeNumber: number;
  episodeName: string;
  position: number;
  duration: number;
  updatedAt?: string | null;
}

export interface Collection {
  id: string;
  name: string;
  titleCount?: number | null;
  updatedAt?: string | null;
}

export interface CollectionDetail extends Collection {
  titles: TitleSummary[];
}

export interface ScanResult {
  titlesAdded: number;
  episodesAdded: number;
  filesScanned: number;
}

export interface AppConfig {
  mediaPaths: string[];
}

export interface SubtitleTrack {
  label: string;
  url: string;
}

export interface MetadataResult {
  provider: string; // e.g. 'anilist' | 'tvmaze' | 'jikan'
  providerId: string;
  name: string;
  year?: number | null;
  poster?: string | null;
  description?: string | null;
}

/** Flat playback context passed to / carried by the player page. */
export interface PlaybackEpisode extends Episode {
  titleId: string;
  titleName: string;
  titlePoster?: string | null;
}

export type RepeatMode = 'off' | 'one' | 'all';
