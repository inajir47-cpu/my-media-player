import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { api } from '../api';
import type { PlaybackEpisode, RepeatMode, SubtitleTrack } from '../types';
import { toast } from '../components/Toaster';
import { episodeLabel, formatDuration } from '../utils/format';

const PLAYBACK_KEY = 'mmp_playback';
const PROGRESS_THROTTLE_MS = 5000;
const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2];
const SLEEP_OPTIONS = [5, 10, 15, 30, 60];

interface NavState {
  episodes?: PlaybackEpisode[];
  currentId?: string;
}

function readPlaybackContext(): NavState | null {
  try {
    const raw = sessionStorage.getItem(PLAYBACK_KEY);
    return raw ? (JSON.parse(raw) as NavState) : null;
  } catch {
    return null;
  }
}

function readResumePosition(episodeId: string): number | null {
  try {
    const raw = sessionStorage.getItem(`mmp_cw_${episodeId}`);
    if (!raw) return null;
    const n = Number(JSON.parse(raw).position);
    return isFinite(n) && n > 0 ? n : null;
  } catch {
    return null;
  }
}

/** Convert SRT subtitle text to WebVTT. */
function srtToVtt(srt: string): string {
  const body = srt
    .replace(/\r/g, '')
    .split('\n\n')
    .map((block) => block.replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, '$1.$2'))
    .join('\n\n');
  return `WEBVTT\n\n${body}`;
}

export default function Player() {
  const { episodeId } = useParams<{ episodeId: string }>();
  const location = useLocation();
  const navigate = useNavigate();
  const navState = (location.state ?? null) as NavState | null;

  const videoRef = useRef<HTMLVideoElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const hideTimer = useRef<number | undefined>(undefined);
  const sleepTimerRef = useRef<number | undefined>(undefined);
  const progressSentAt = useRef(0);
  const gestureRef = useRef({
    startX: 0, startY: 0, startTime: 0, moved: false, mode: null as null | 'seek' | 'bright' | 'vol',
    lastX: 0, baseSeek: 0, baseBright: 1, baseVol: 1, lastTap: 0, lastTapX: 0,
  });
  const hintTimer = useRef<number | undefined>(undefined);

  // ---- playback context -----------------------------------------------------
  const [episodes, setEpisodes] = useState<PlaybackEpisode[]>(() => {
    if (navState?.episodes?.length) return navState.episodes;
    return readPlaybackContext()?.episodes ?? [];
  });
  const [currentId, setCurrentId] = useState<string>(() => {
    if (navState?.currentId) return navState.currentId;
    return readPlaybackContext()?.currentId ?? episodeId ?? '';
  });

  useEffect(() => {
    if (navState?.episodes?.length && navState.currentId) {
      setEpisodes(navState.episodes);
      setCurrentId(navState.currentId);
    }
  }, [location.key]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (episodeId && episodeId !== currentId) setCurrentId(episodeId);
  }, [episodeId]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    try {
      sessionStorage.setItem(PLAYBACK_KEY, JSON.stringify({ episodes, currentId }));
    } catch { /* ignore */ }
  }, [episodes, currentId]);

  const currentIndex = useMemo(
    () => Math.max(0, episodes.findIndex((e) => e.id === currentId)),
    [episodes, currentId],
  );
  const current: PlaybackEpisode | undefined = episodes[currentIndex];

  // ---- player state ----------------------------------------------------------
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [bufferedPct, setBufferedPct] = useState(0);
  const [volume, setVolume] = useState(1);
  const [muted, setMuted] = useState(false);
  const [brightness, setBrightness] = useState(1);
  const [speed, setSpeed] = useState(1);
  const [repeat, setRepeat] = useState<RepeatMode>('off');
  const [shuffle, setShuffle] = useState(false);
  const [order, setOrder] = useState<number[]>([]);
  const [controlsVisible, setControlsVisible] = useState(true);
  const [waiting, setWaiting] = useState(true);
  const [menu, setMenu] = useState<null | 'speed' | 'sleep' | 'subtitles' | 'settings'>(null);
  const [playlistOpen, setPlaylistOpen] = useState(false);
  const [hint, setHint] = useState<string | null>(null);
  const [pip, setPip] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);

  const [subTracks, setSubTracks] = useState<SubtitleTrack[]>([]);
  const [activeSub, setActiveSub] = useState(-1);
  const [subSize, setSubSize] = useState<'S' | 'M' | 'L'>('M');
  const [sleepMinutes, setSleepMinutes] = useState(0);

  // Shuffle play order.
  useEffect(() => {
    setOrder((prev) => {
      const idx = episodes.map((_, i) => i);
      if (!shuffle) return idx;
      if (prev.length === idx.length && new Set(prev).size === idx.length && prev.length > 0) return prev;
      for (let i = idx.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [idx[i], idx[j]] = [idx[j], idx[i]];
      }
      return idx;
    });
  }, [episodes, shuffle]);

  const orderPos = order.indexOf(currentIndex);
  const hasNext = orderPos >= 0 && orderPos < order.length - 1;
  const hasPrev = orderPos > 0;

  const step = useCallback(
    (dir: 1 | -1) => {
      const pos = order.indexOf(currentIndex);
      let nextIdx: number | null = null;
      if (dir === 1) {
        if (pos >= 0 && pos < order.length - 1) nextIdx = order[pos + 1];
        else if (repeat === 'all' && order.length > 0) nextIdx = order[0];
      } else {
        if (pos > 0) nextIdx = order[pos - 1];
        else if (repeat === 'all' && order.length > 0) nextIdx = order[order.length - 1];
      }
      if (nextIdx != null && episodes[nextIdx]) {
        const ep = episodes[nextIdx];
        navigate(`/watch/${ep.id}`, { replace: true, state: { episodes, currentId: ep.id } });
        setCurrentId(ep.id);
      }
    },
    [order, currentIndex, episodes, repeat, navigate],
  );

  const next = useCallback(() => step(1), [step]);
  const prev = useCallback(() => step(-1), [step]);

  // ---- progress reporting (throttled) ----------------------------------------
  const sendProgress = useCallback(
    (force = false) => {
      const video = videoRef.current;
      if (!video || !currentId || !video.duration || !isFinite(video.duration)) return;
      const now = Date.now();
      if (!force && now - progressSentAt.current < PROGRESS_THROTTLE_MS) return;
      progressSentAt.current = now;
      api.updateProgress(currentId, video.currentTime, video.duration).catch(() => { /* best effort */ });
    },
    [currentId],
  );

  // ---- video element wiring ---------------------------------------------------
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const onTime = () => {
      setTime(video.currentTime);
      if (video.buffered.length > 0 && video.duration) {
        setBufferedPct((video.buffered.end(video.buffered.length - 1) / video.duration) * 100);
      }
      sendProgress();
    };
    const onMeta = () => {
      setDuration(video.duration || 0);
      setWaiting(false);
      const resume = readResumePosition(currentId);
      if (resume != null && resume < video.duration - 10) {
        try { video.currentTime = resume; } catch { /* ignore */ }
      }
    };
    const onPlay = () => { setPlaying(true); setWaiting(false); };
    const onPause = () => { setPlaying(false); sendProgress(true); };
    const onWaiting = () => setWaiting(true);
    const onPlaying = () => setWaiting(false);
    const onEnded = () => {
      sendProgress(true);
      if (repeat === 'one') {
        video.currentTime = 0;
        video.play().catch(() => {});
      } else {
        next();
      }
    };
    const onEnterPip = () => setPip(true);
    const onLeavePip = () => setPip(false);

    video.addEventListener('timeupdate', onTime);
    video.addEventListener('loadedmetadata', onMeta);
    video.addEventListener('play', onPlay);
    video.addEventListener('pause', onPause);
    video.addEventListener('waiting', onWaiting);
    video.addEventListener('playing', onPlaying);
    video.addEventListener('ended', onEnded);
    video.addEventListener('enterpictureinpicture', onEnterPip);
    video.addEventListener('leavepictureinpicture', onLeavePip);
    video.playbackRate = speed;
    return () => {
      video.removeEventListener('timeupdate', onTime);
      video.removeEventListener('loadedmetadata', onMeta);
      video.removeEventListener('play', onPlay);
      video.removeEventListener('pause', onPause);
      video.removeEventListener('waiting', onWaiting);
      video.removeEventListener('playing', onPlaying);
      video.removeEventListener('ended', onEnded);
      video.removeEventListener('enterpictureinpicture', onEnterPip);
      video.removeEventListener('leavepictureinpicture', onLeavePip);
      sendProgress(true);
    };
  }, [currentId, speed, repeat, next, sendProgress]);

  // Apply volume/muted/speed/brightness live.
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    video.volume = volume;
    video.muted = muted;
    video.playbackRate = speed;
  }, [volume, muted, speed, currentId]);

  // ---- subtitles ---------------------------------------------------------------
  useEffect(() => {
    let cancelled = false;
    const createdUrls: string[] = [];
    (async () => {
      setSubTracks([]);
      setActiveSub(-1);
      if (!currentId) return;
      try {
        const tracks = await api.getSubtitles(currentId);
        const resolved = await Promise.all(
          tracks.map(async (t) => {
            if (/\.srt($|\?)/i.test(t.url)) {
              try {
                const res = await fetch(t.url);
                const srt = await res.text();
                const url = URL.createObjectURL(new Blob([srtToVtt(srt)], { type: 'text/vtt' }));
                createdUrls.push(url);
                return { ...t, url };
              } catch {
                return t; // fall back to the raw url
              }
            }
            return t;
          }),
        );
        if (!cancelled) setSubTracks(resolved);
      } catch { /* subtitles are optional */ }
    })();
    return () => {
      cancelled = true;
      createdUrls.forEach((u) => URL.revokeObjectURL(u));
    };
  }, [currentId]);

  // Toggle which <track> is showing.
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const list = video.textTracks;
    for (let i = 0; i < list.length; i++) {
      list[i].mode = i === activeSub ? 'showing' : 'disabled';
    }
  }, [activeSub, subTracks, currentId]);

  // ---- controls auto-hide -------------------------------------------------------
  const pokeControls = useCallback(() => {
    setControlsVisible(true);
    window.clearTimeout(hideTimer.current);
    hideTimer.current = window.setTimeout(() => setControlsVisible(false), 3500);
  }, []);

  useEffect(() => {
    pokeControls();
    return () => window.clearTimeout(hideTimer.current);
  }, [pokeControls, currentId]);

  const showHint = useCallback((text: string) => {
    setHint(text);
    window.clearTimeout(hintTimer.current);
    hintTimer.current = window.setTimeout(() => setHint(null), 700);
  }, []);

  // ---- sleep timer ----------------------------------------------------------------
  useEffect(() => {
    window.clearTimeout(sleepTimerRef.current);
    if (sleepMinutes > 0) {
      sleepTimerRef.current = window.setTimeout(() => {
        videoRef.current?.pause();
        setSleepMinutes(0);
        toast('Sleep timer ended — playback paused');
      }, sleepMinutes * 60 * 1000);
    }
    return () => window.clearTimeout(sleepTimerRef.current);
  }, [sleepMinutes, currentId]);

  // ---- fullscreen tracking ----------------------------------------------------------
  useEffect(() => {
    const onFs = () => setFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onFs);
    return () => document.removeEventListener('fullscreenchange', onFs);
  }, []);

  // ---- basic player actions -----------------------------------------------------------
  const togglePlay = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) video.play().catch(() => {});
    else video.pause();
    pokeControls();
  }, [pokeControls]);

  const seekBy = useCallback((delta: number) => {
    const video = videoRef.current;
    if (!video || !isFinite(video.duration)) return;
    video.currentTime = Math.min(Math.max(0, video.currentTime + delta), video.duration);
    showHint(`${delta > 0 ? '+' : '−'}${Math.abs(delta)}s`);
    pokeControls();
  }, [pokeControls, showHint]);

  const seekTo = useCallback((t: number) => {
    const video = videoRef.current;
    if (!video || !isFinite(video.duration)) return;
    video.currentTime = Math.min(Math.max(0, t), video.duration);
  }, []);

  const toggleFullscreen = useCallback(() => {
    const stage = stageRef.current;
    if (!stage) return;
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    else stage.requestFullscreen().catch(() => {});
    pokeControls();
  }, [pokeControls]);

  const togglePip = useCallback(async () => {
    const video = videoRef.current;
    if (!video) return;
    try {
      if (document.pictureInPictureElement) await document.exitPictureInPicture();
      else if (document.pictureInPictureEnabled) await video.requestPictureInPicture();
    } catch { /* ignore */ }
  }, []);

  const cycleRepeat = () => {
    setRepeat((r) => (r === 'off' ? 'one' : r === 'one' ? 'all' : 'off'));
    pokeControls();
  };

  // ---- touch gestures -------------------------------------------------------------------
  const onTouchStart = (e: React.TouchEvent) => {
    const t = e.touches[0];
    const g = gestureRef.current;
    g.startX = t.clientX; g.startY = t.clientY;
    g.lastX = t.clientX; g.startTime = Date.now();
    g.moved = false; g.mode = null;
    g.baseSeek = videoRef.current?.currentTime ?? 0;
    g.baseBright = brightness; g.baseVol = muted ? 0 : volume;
  };

  const onTouchMove = (e: React.TouchEvent) => {
    const t = e.touches[0];
    const g = gestureRef.current;
    const stage = stageRef.current;
    if (!stage) return;
    const rect = stage.getBoundingClientRect();
    const dx = t.clientX - g.startX;
    const dy = t.clientY - g.startY;
    if (!g.moved) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) < 12) return;
      g.moved = true;
      g.mode = Math.abs(dx) > Math.abs(dy) ? 'seek' : (g.startX < rect.width / 2 ? 'bright' : 'vol');
    }
    if (g.mode === 'seek') {
      // Full-width swipe ≈ 3 minutes of seek.
      const delta = ((t.clientX - g.lastX) / rect.width) * 180;
      g.lastX = t.clientX;
      const video = videoRef.current;
      if (video && isFinite(video.duration)) {
        video.currentTime = Math.min(Math.max(0, video.currentTime + delta), video.duration);
        showHint(formatDuration(video.currentTime));
      }
    } else if (g.mode === 'bright') {
      const b = Math.min(2, Math.max(0.2, g.baseBright - (dy / rect.height) * 1.6));
      setBrightness(Number(b.toFixed(2)));
      showHint(`Brightness ${Math.round(b * 100)}%`);
    } else if (g.mode === 'vol') {
      const v = Math.min(1, Math.max(0, g.baseVol - (dy / rect.height) * 1.6));
      setVolume(Number(v.toFixed(2)));
      if (v > 0 && muted) setMuted(false);
      showHint(`Volume ${Math.round(v * 100)}%`);
    }
  };

  const onTouchEnd = (e: React.TouchEvent) => {
    const g = gestureRef.current;
    const stage = stageRef.current;
    if (!stage) return;
    if (!g.moved) {
      const t = e.changedTouches[0];
      const rect = stage.getBoundingClientRect();
      const x = t.clientX - rect.left;
      const now = Date.now();
      // Double-tap on the left/right edges: ∓10s.
      if (now - g.lastTap < 320 && Math.abs(x - g.lastTapX) < 60) {
        if (x < rect.width * 0.28) seekBy(-10);
        else if (x > rect.width * 0.72) seekBy(10);
        else { setControlsVisible((v) => !v); pokeControls(); }
        g.lastTap = 0;
      } else {
        g.lastTap = now;
        g.lastTapX = x;
        // Single tap toggles controls (debounced so a double-tap doesn't flicker).
        window.setTimeout(() => {
          if (gestureRef.current.lastTap === now) {
            setControlsVisible((v) => !v);
            pokeControls();
          }
        }, 330);
      }
    }
  };

  // ---- keyboard (desktop) -------------------------------------------------------------------
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      switch (e.key) {
        case ' ': e.preventDefault(); togglePlay(); break;
        case 'ArrowRight': seekBy(e.shiftKey ? 30 : 10); break;
        case 'ArrowLeft': seekBy(e.shiftKey ? -30 : -10); break;
        case 'ArrowUp': e.preventDefault(); setVolume((v) => Math.min(1, v + 0.1)); break;
        case 'ArrowDown': e.preventDefault(); setVolume((v) => Math.max(0, v - 0.1)); break;
        case 'f': toggleFullscreen(); break;
        case 'm': setMuted((m) => !m); pokeControls(); break;
        case 'n': next(); break;
        case 'p': prev(); break;
        default: break;
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [togglePlay, seekBy, toggleFullscreen, next, prev, pokeControls]);

  const pct = duration > 0 ? (time / duration) * 100 : 0;
  const cueSize = subSize === 'S' ? '0.9rem' : subSize === 'L' ? '1.6rem' : '1.2rem';

  return (
    <div className="player-page">
      <div
        ref={stageRef}
        className="player-stage"
        style={{ ['--cue-size' as string]: cueSize }}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
        onMouseMove={pokeControls}
        onClick={(e) => {
          // Desktop: clicking the bare stage toggles controls.
          if ((e.target as HTMLElement).closest('.player-controls, .player-topbar, .player-menu, .playlist-drawer')) return;
          setControlsVisible((v) => !v);
          pokeControls();
        }}
        onDoubleClick={toggleFullscreen}
      >
        <video
          key={currentId}
          ref={videoRef}
          className="player-video"
          src={currentId ? api.episodeStreamUrl(currentId) : undefined}
          playsInline
          preload="auto"
          style={{ filter: `brightness(${brightness})` }}
        >
          {subTracks.map((t, i) => (
            <track key={`${t.url}-${i}`} kind="subtitles" src={t.url} srcLang="und" label={t.label} />
          ))}
        </video>

        <div className={`gesture-hint${hint ? ' show' : ''}`}>{hint}</div>
        {waiting ? <div className="player-spinner"><div className="spinner" /></div> : null}

        {/* Top bar */}
        <div
          className={`player-topbar${controlsVisible ? '' : ' hidden'}`}
          onTouchStart={(e) => e.stopPropagation()}
        >
          <button className="icon-btn" onClick={() => navigate(-1)} aria-label="Back">←</button>
          <div className="player-title-block">
            <div className="player-title">{current?.titleName ?? 'Episode'}</div>
            {current ? (
              <div className="player-ep">{episodeLabel(current.seasonNumber, current.episodeNumber)} · {current.name}</div>
            ) : null}
          </div>
        </div>

        {/* Controls */}
        <div
          className={`player-controls${controlsVisible ? '' : ' hidden'}`}
          onTouchStart={(e) => e.stopPropagation()}
          onClick={(e) => e.stopPropagation()}
        >
          <Timeline time={time} duration={duration} bufferedPct={bufferedPct} onSeek={seekTo} />
          <div className="player-buttons">
            <button className="pbtn hide-mobile" onClick={() => { setShuffle((s) => !s); pokeControls(); }} title="Shuffle" aria-label="Shuffle">
              <span className={shuffle ? 'active' : ''} style={shuffle ? { color: 'var(--accent)' } : undefined}>⇄</span>
            </button>
            <button className="pbtn" onClick={prev} disabled={!hasPrev && repeat !== 'all'} title="Previous episode" aria-label="Previous episode">⏮</button>
            <button className="pbtn" onClick={() => seekBy(-10)} title="Back 10 seconds" aria-label="Back 10 seconds">↺<span className="pbtn-label">10</span></button>
            <button className="pbtn" onClick={togglePlay} title={playing ? 'Pause' : 'Play'} aria-label={playing ? 'Pause' : 'Play'} style={{ fontSize: '1.8rem' }}>
              {playing ? '⏸' : '▶'}
            </button>
            <button className="pbtn" onClick={() => seekBy(10)} title="Forward 10 seconds" aria-label="Forward 10 seconds">↻<span className="pbtn-label">10</span></button>
            <button className="pbtn" onClick={next} disabled={!hasNext && repeat !== 'all'} title="Next episode" aria-label="Next episode">⏭</button>
            <button className="pbtn hide-mobile" onClick={cycleRepeat} title={`Repeat: ${repeat}`} aria-label={`Repeat ${repeat}`}>
              <span style={repeat !== 'off' ? { color: 'var(--accent)' } : undefined}>⟳{repeat === 'one' ? <span className="pbtn-label">1</span> : null}</span>
            </button>

            <div className="player-time">{formatDuration(time)} / {formatDuration(duration)}</div>
            <div className="player-spacer" />

            <div className="volume-wrap">
              <input
                className="volume-slider"
                type="range" min={0} max={1} step={0.05}
                value={muted ? 0 : volume}
                onChange={(e) => { setVolume(Number(e.target.value)); setMuted(false); }}
                aria-label="Volume"
              />
              <button className="pbtn" onClick={() => { setMuted((m) => !m); pokeControls(); }} title={muted ? 'Unmute' : 'Mute'} aria-label={muted ? 'Unmute' : 'Mute'}>
                {muted || volume === 0 ? '🔇' : volume < 0.5 ? '🔉' : '🔊'}
              </button>
            </div>

            <button className={`pbtn${menu === 'subtitles' ? ' active' : ''}`} onClick={() => { setMenu(menu === 'subtitles' ? null : 'subtitles'); pokeControls(); }} title="Subtitles" aria-label="Subtitles">💬</button>
            <button className={`pbtn${menu === 'speed' ? ' active' : ''}`} onClick={() => { setMenu(menu === 'speed' ? null : 'speed'); pokeControls(); }} title="Playback speed" aria-label="Playback speed">
              <span className="pbtn-label" style={{ fontSize: '0.85rem' }}>{speed}×</span>
            </button>
            <button className="pbtn hide-mobile" onClick={() => { setPlaylistOpen((o) => !o); pokeControls(); }} title="Playlist" aria-label="Playlist">☰</button>
            <button className="pbtn hide-mobile" onClick={togglePip} title="Picture in picture" aria-label="Picture in picture">
              <span style={pip ? { color: 'var(--accent)' } : undefined}>⧉</span>
            </button>
            <button className={`pbtn${menu === 'settings' ? ' active' : ''}`} onClick={() => { setMenu(menu === 'settings' ? null : 'settings'); pokeControls(); }} title="Settings" aria-label="Settings">⚙</button>
            <button className={`pbtn${menu === 'sleep' ? ' active' : ''}`} onClick={() => { setMenu(menu === 'sleep' ? null : 'sleep'); pokeControls(); }} title="Sleep timer" aria-label="Sleep timer">
              <span style={sleepMinutes > 0 ? { color: 'var(--accent)' } : undefined}>⏱{sleepMinutes > 0 ? <span className="pbtn-label">{sleepMinutes}m</span> : null}</span>
            </button>
            <button className="pbtn" onClick={toggleFullscreen} title={fullscreen ? 'Exit fullscreen' : 'Fullscreen'} aria-label={fullscreen ? 'Exit fullscreen' : 'Fullscreen'}>
              {fullscreen ? '⤢' : '⛶'}
            </button>
          </div>
        </div>

        {/* Menus */}
        {menu && controlsVisible ? (
          <div className="player-menu" onTouchStart={(e) => e.stopPropagation()} onClick={(e) => e.stopPropagation()}>
            {menu === 'speed' ? (
              <>
                <h4>Playback speed</h4>
                {SPEEDS.map((s) => (
                  <button key={s} className={`menu-item${s === speed ? ' selected' : ''}`} onClick={() => { setSpeed(s); setMenu(null); pokeControls(); }}>
                    {s}× {s === speed ? <span className="check">✓</span> : null}
                  </button>
                ))}
              </>
            ) : null}
            {menu === 'sleep' ? (
              <>
                <h4>Sleep timer</h4>
                <button className={`menu-item${sleepMinutes === 0 ? ' selected' : ''}`} onClick={() => { setSleepMinutes(0); setMenu(null); }}>
                  Off {sleepMinutes === 0 ? <span className="check">✓</span> : null}
                </button>
                {SLEEP_OPTIONS.map((m) => (
                  <button key={m} className={`menu-item${sleepMinutes === m ? ' selected' : ''}`} onClick={() => { setSleepMinutes(m); setMenu(null); toast(`Sleep timer: ${m} minutes`); }}>
                    {m} minutes {sleepMinutes === m ? <span className="check">✓</span> : null}
                  </button>
                ))}
              </>
            ) : null}
            {menu === 'subtitles' ? (
              <>
                <h4>Subtitles</h4>
                <button className={`menu-item${activeSub === -1 ? ' selected' : ''}`} onClick={() => { setActiveSub(-1); }}>
                  Off {activeSub === -1 ? <span className="check">✓</span> : null}
                </button>
                {subTracks.map((t, i) => (
                  <button key={`${t.url}-${i}`} className={`menu-item${activeSub === i ? ' selected' : ''}`} onClick={() => setActiveSub(i)}>
                    {t.label} {activeSub === i ? <span className="check">✓</span> : null}
                  </button>
                ))}
                {subTracks.length === 0 ? <div className="menu-item" style={{ color: 'var(--text-muted)' }}>No subtitles found</div> : null}
              </>
            ) : null}
            {menu === 'settings' ? (
              <>
                <h4>Settings</h4>
                <div className="menu-slider-row">
                  <label>Brightness — {Math.round(brightness * 100)}%</label>
                  <input type="range" min={0.2} max={2} step={0.05} value={brightness} onChange={(e) => setBrightness(Number(e.target.value))} />
                </div>
                <div className="menu-slider-row">
                  <label>Subtitle size</label>
                  <div style={{ display: 'flex', gap: 8 }}>
                    {(['S', 'M', 'L'] as const).map((s) => (
                      <button key={s} className={`mini-btn${subSize === s ? '' : ''}`} style={subSize === s ? { background: 'var(--accent)', color: '#fff' } : undefined} onClick={() => setSubSize(s)}>{s}</button>
                    ))}
                  </div>
                </div>
                <button className="menu-item" onClick={() => { setBrightness(1); }}>Reset brightness</button>
              </>
            ) : null}
          </div>
        ) : null}

        {/* Playlist drawer */}
        {playlistOpen ? (
          <div className="playlist-drawer" onTouchStart={(e) => e.stopPropagation()} onClick={(e) => e.stopPropagation()}>
            <div className="playlist-head">
              <h3>Up next</h3>
              <button className="icon-btn" onClick={() => setPlaylistOpen(false)} aria-label="Close playlist">✕</button>
            </div>
            <div className="playlist-list">
              {episodes.filter((e) => e.hasFile).map((e) => (
                <button
                  key={e.id}
                  className={`playlist-item${e.id === currentId ? ' current' : ''}`}
                  onClick={() => {
                    navigate(`/watch/${e.id}`, { replace: true, state: { episodes, currentId: e.id } });
                    setCurrentId(e.id);
                    setPlaylistOpen(false);
                  }}
                >
                  {e.still ? <img src={e.still} alt="" loading="lazy" /> : e.titlePoster ? <img src={e.titlePoster} alt="" loading="lazy" /> : null}
                  <div className="pl-info">
                    <div className="pl-name">{e.name}</div>
                    <div className="pl-sub">{episodeLabel(e.seasonNumber, e.episodeNumber)}{e.duration ? ` · ${formatDuration(e.duration)}` : ''}</div>
                  </div>
                </button>
              ))}
              {episodes.filter((e) => e.hasFile).length === 0 ? (
                <p className="page-sub" style={{ padding: 16 }}>No other playable episodes.</p>
              ) : null}
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}

function Timeline({
  time,
  duration,
  bufferedPct,
  onSeek,
}: {
  time: number;
  duration: number;
  bufferedPct: number;
  onSeek: (t: number) => void;
}) {
  const barRef = useRef<HTMLDivElement>(null);
  const [dragging, setDragging] = useState(false);

  const seekFromEvent = (clientX: number) => {
    const bar = barRef.current;
    if (!bar || !duration) return;
    const rect = bar.getBoundingClientRect();
    const ratio = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width));
    onSeek(ratio * duration);
  };

  const pct = duration > 0 ? Math.min(100, (time / duration) * 100) : 0;

  return (
    <div
      ref={barRef}
      className="timeline-wrap"
      role="slider"
      aria-label="Seek"
      aria-valuemin={0}
      aria-valuemax={Math.round(duration)}
      aria-valuenow={Math.round(time)}
      onPointerDown={(e) => {
        (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
        setDragging(true);
        seekFromEvent(e.clientX);
      }}
      onPointerMove={(e) => { if (dragging) seekFromEvent(e.clientX); }}
      onPointerUp={(e) => { setDragging(false); seekFromEvent(e.clientX); }}
      onPointerCancel={() => setDragging(false)}
    >
      <div className="timeline-track">
        <div className="timeline-buffered" style={{ width: `${Math.min(100, bufferedPct)}%` }} />
        <div className="timeline-played" style={{ width: `${pct}%` }} />
        <div className="timeline-knob" style={{ left: `${pct}%` }} />
      </div>
    </div>
  );
}
