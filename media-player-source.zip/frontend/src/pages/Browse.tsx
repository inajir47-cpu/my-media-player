import { useEffect, useMemo, useState } from 'react';
import { api } from '../api';
import type { TitleKind, TitleSummary } from '../types';
import { PosterCard } from '../components/PosterCard';
import { toast } from '../components/Toaster';
import { kindLabel } from '../utils/format';

const KIND_TITLES: Record<TitleKind, string> = {
  show: 'TV Shows',
  movie: 'Movies',
  music: 'Music',
};

const SORTS = [
  { value: 'recent', label: 'Recently added' },
  { value: 'name', label: 'Name A–Z' },
  { value: 'year', label: 'Year' },
  { value: 'rating', label: 'Rating' },
];

export default function Browse({ kind }: { kind: TitleKind }) {
  const [all, setAll] = useState<TitleSummary[]>([]);
  const [results, setResults] = useState<TitleSummary[]>([]);
  const [query, setQuery] = useState('');
  const [genre, setGenre] = useState('');
  const [sort, setSort] = useState('recent');
  const [loading, setLoading] = useState(true);

  // Load the full kind list once to derive filter options.
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    (async () => {
      try {
        const lib = await api.getLibrary();
        if (!cancelled) setAll(lib.titles.filter((t) => t.kind === kind));
      } catch (e) {
        toast(e instanceof Error ? e.message : 'Failed to load');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [kind]);

  const genres = useMemo(() => {
    const set = new Set<string>();
    all.forEach((t) => {
      (t.genre ?? '').split(',').map((g) => g.trim()).filter(Boolean).forEach((g) => set.add(g));
    });
    return [...set].sort((a, b) => a.localeCompare(b));
  }, [all]);

  // Query the server whenever filters change (debounced for the search box).
  useEffect(() => {
    let cancelled = false;
    const timer = window.setTimeout(async () => {
      try {
        const res = await api.search({ q: query.trim(), kind, genre, sort });
        if (!cancelled) setResults(res.titles);
      } catch (e) {
        if (!cancelled) toast(e instanceof Error ? e.message : 'Search failed');
      }
    }, query ? 300 : 0);
    return () => { cancelled = true; window.clearTimeout(timer); };
  }, [query, kind, genre, sort]);

  return (
    <div className="page"><div className="container">
      <h1 className="page-title">{KIND_TITLES[kind]}</h1>
      <p className="page-sub">{kindLabel(kind)} in your library</p>

      <div className="filters">
        <input
          className="filter-input"
          placeholder={`Search ${KIND_TITLES[kind].toLowerCase()}…`}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          aria-label="Search"
        />
        <select className="filter-select" value={genre} onChange={(e) => setGenre(e.target.value)} aria-label="Genre">
          <option value="">All genres</option>
          {genres.map((g) => <option key={g} value={g}>{g}</option>)}
        </select>
        <select className="filter-select" value={sort} onChange={(e) => setSort(e.target.value)} aria-label="Sort">
          {SORTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
      </div>

      {loading ? (
        <div className="loading-wrap"><div className="spinner" /></div>
      ) : results.length === 0 ? (
        <div className="empty-state">
          <div className="big">🔍</div>
          <h2>Nothing found</h2>
          <p>Try a different search or clear the filters.</p>
        </div>
      ) : (
        <div className="grid">
          {results.map((t) => <PosterCard key={t.id} title={t} />)}
        </div>
      )}
    </div></div>
  );
}
