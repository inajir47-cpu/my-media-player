import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';
import type { Collection } from '../types';
import Modal from '../components/Modal';
import { toast } from '../components/Toaster';

export default function Saved() {
  const [collections, setCollections] = useState<Collection[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState('');
  const [renaming, setRenaming] = useState<Collection | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [deleting, setDeleting] = useState<Collection | null>(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try {
      setCollections(await api.getCollections());
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to load collections');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const create = async () => {
    const name = newName.trim();
    if (!name) return;
    setBusy(true);
    try {
      const c = await api.createCollection(name);
      setCollections((prev) => [...prev, c]);
      setNewName('');
      setCreating(false);
      toast(`Created "${name}"`);
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to create collection');
    } finally {
      setBusy(false);
    }
  };

  const rename = async () => {
    if (!renaming) return;
    const name = renameValue.trim();
    if (!name) return;
    setBusy(true);
    try {
      const updated = await api.updateCollection(renaming.id, name);
      setCollections((prev) => prev.map((c) => (c.id === renaming.id ? updated : c)));
      setRenaming(null);
      toast('Collection renamed');
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to rename');
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!deleting) return;
    setBusy(true);
    try {
      await api.deleteCollection(deleting.id);
      setCollections((prev) => prev.filter((c) => c.id !== deleting.id));
      setDeleting(null);
      toast('Collection deleted');
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to delete');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="page"><div className="container">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h1 className="page-title">Saved</h1>
          <p className="page-sub">Your collections</p>
        </div>
        <button className="btn btn-primary btn-sm" onClick={() => setCreating(true)}>+ New collection</button>
      </div>

      {loading ? (
        <div className="loading-wrap"><div className="spinner" /></div>
      ) : collections.length === 0 ? (
        <div className="empty-state">
          <div className="big">📚</div>
          <h2>No collections yet</h2>
          <p>Group titles into collections — favorites, watch later, anime night…</p>
          <button className="btn btn-primary" onClick={() => setCreating(true)}>Create a collection</button>
        </div>
      ) : (
        <div className="grid">
          {collections.map((c) => (
            <div key={c.id} className="collection-card">
              <div className="card-actions">
                <button
                  className="mini-btn"
                  onClick={(e) => { e.stopPropagation(); setRenaming(c); setRenameValue(c.name); }}
                >Rename</button>
                <button
                  className="mini-btn danger"
                  onClick={(e) => { e.stopPropagation(); setDeleting(c); }}
                >Delete</button>
              </div>
              <Link to={`/collection/${c.id}`} style={{ display: 'block' }}>
                <h3>{c.name}</h3>
                <span className="count">{c.titleCount ?? 0} title{(c.titleCount ?? 0) === 1 ? '' : 's'}</span>
              </Link>
            </div>
          ))}
        </div>
      )}

      {creating ? (
        <Modal
          title="New collection"
          onClose={() => setCreating(false)}
          footer={
            <>
              <button className="btn btn-outline" onClick={() => setCreating(false)}>Cancel</button>
              <button className="btn btn-primary" disabled={busy || !newName.trim()} onClick={create}>Create</button>
            </>
          }
        >
          <div className="form-row">
            <label htmlFor="col-name">Name</label>
            <input
              id="col-name"
              className="form-input"
              autoFocus
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="e.g. Weekend watchlist"
              onKeyDown={(e) => { if (e.key === 'Enter') create(); }}
            />
          </div>
        </Modal>
      ) : null}

      {renaming ? (
        <Modal
          title="Rename collection"
          onClose={() => setRenaming(null)}
          footer={
            <>
              <button className="btn btn-outline" onClick={() => setRenaming(null)}>Cancel</button>
              <button className="btn btn-primary" disabled={busy || !renameValue.trim()} onClick={rename}>Save</button>
            </>
          }
        >
          <div className="form-row">
            <label htmlFor="col-rename">Name</label>
            <input
              id="col-rename"
              className="form-input"
              autoFocus
              value={renameValue}
              onChange={(e) => setRenameValue(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') rename(); }}
            />
          </div>
        </Modal>
      ) : null}

      {deleting ? (
        <Modal
          title="Delete collection"
          onClose={() => setDeleting(null)}
          footer={
            <>
              <button className="btn btn-outline" onClick={() => setDeleting(null)}>Cancel</button>
              <button className="btn btn-danger" disabled={busy} onClick={remove}>Delete</button>
            </>
          }
        >
          <p>Delete <strong>"{deleting.name}"</strong>? The titles inside stay in your library.</p>
        </Modal>
      ) : null}
    </div></div>
  );
}
