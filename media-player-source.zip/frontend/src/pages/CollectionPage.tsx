import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '../api';
import type { CollectionDetail } from '../types';
import { PosterCard } from '../components/PosterCard';
import { toast } from '../components/Toaster';

export default function CollectionPage() {
  const { id } = useParams<{ id: string }>();
  const [collection, setCollection] = useState<CollectionDetail | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!id) return;
      try {
        const c = await api.getCollection(id);
        if (!cancelled) setCollection(c);
      } catch (e) {
        if (!cancelled) toast(e instanceof Error ? e.message : 'Failed to load collection');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [id]);

  const removeTitle = async (titleId: string, titleName: string) => {
    if (!id) return;
    try {
      await api.removeFromCollection(id, titleId);
      setCollection((prev) => prev && { ...prev, titles: prev.titles.filter((t) => t.id !== titleId) });
      toast(`Removed "${titleName}"`);
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to remove');
    }
  };

  if (loading) {
    return <div className="page"><div className="loading-wrap"><div className="spinner" /></div></div>;
  }

  if (!collection) {
    return (
      <div className="page"><div className="container">
        <div className="empty-state">
          <div className="big">📚</div>
          <h2>Collection not found</h2>
          <Link to="/saved" className="btn btn-primary">Back to Saved</Link>
        </div>
      </div></div>
    );
  }

  return (
    <div className="page"><div className="container">
      <h1 className="page-title">{collection.name}</h1>
      <p className="page-sub">{collection.titles.length} title{collection.titles.length === 1 ? '' : 's'}</p>

      {collection.titles.length === 0 ? (
        <div className="empty-state">
          <div className="big">📭</div>
          <h2>Nothing here yet</h2>
          <p>Open any title and use "Save" to add it to this collection.</p>
        </div>
      ) : (
        <div className="grid">
          {collection.titles.map((t) => (
            <div key={t.id} style={{ position: 'relative' }}>
              <PosterCard title={t} />
              <button
                className="mini-btn danger"
                style={{ position: 'absolute', top: 8, right: 8 }}
                onClick={() => removeTitle(t.id, t.name)}
                title={`Remove "${t.name}" from this collection`}
              >✕</button>
            </div>
          ))}
        </div>
      )}
    </div></div>
  );
}
