import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div className="page"><div className="container">
      <div className="empty-state">
        <div className="big">🛰</div>
        <h2>Page not found</h2>
        <p>This corner of your library doesn't exist.</p>
        <Link to="/" className="btn btn-primary">Back home</Link>
      </div>
    </div></div>
  );
}
