import { useEffect, useMemo, useState } from 'react';
import { api } from '../api';
import type { TitleKind, TitleSummary } from '../types';
import { PosterCard } from '../components/PosterCard';
import { toast } from '../components/Toaster';

export default function SearchPage() {
  const [query, setQuery] = useState('');
  const [kind, setKind] = useState<TitleKind | ''>('');
  const [genre, setGenre] = useState('');
  const [results, setResults] = useState<TitleSummary[]>([]);
  const [genres, setGenres] = useState<string[]>([]);
  const [searched, setSearched] = useState(false);

  // Derive genre options from the library.
  useEffect(() => {
    (async () => {
      try {
        const lib = await api.getLibrary();
        const set = new Set<string>();
        lib.titles.forEach((t) => {
          (t.genre ?? '').split(',').map((g) => g.trim()).filter(Boolean).forEach((g) => set.add(g));
        });
        setGenres([...set].sort((a, b) => a.localeCompare(b)));
      } catch { /* best effort */ }
    })();
  }, []);

  const debouncedQuery = useDebounce(query, 350);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const q = debouncedQuery.trim();
      if (!q && !kind && !genre) {
        setResults([]);
        setSearched(false);
        return;
      }
      try {
        const res = await api.search({ q, kind, genre, sort: 'recent' });
        if (!cancelled) {
          setResults(res.titles);
          setSearched(true);
        }
      } catch (e) {
        if (!cancelled) toast(e instanceof Error ? e.message : 'Search failed');
      }
    })();
    return () => { cancelled = true; };
  }, [debouncedQuery, kind, genre]);

  return (
    <div className="page"><div className="container">
      <h1 className="page-title">Search</h1>
      <p className="page-sub">Search your whole library</p>

      <div className="filters">
        <input
          className="filter-input"
          placeholder="Titles, genres, years…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          autoFocus
          aria-label="Search query"
        />
        <select className="filter-select" value={kind} onChange={(e) => setKind(e.target.value as TitleKind | '')} aria-label="Kind">
          <option value="">All kinds</option>
          <option value="show">Shows</option>
          <option value="movie">Movies</option>
          <option value="music">Music</option>
        </select>
        <select className="filter-select" value={genre} onChange={(e) => setGenre(e.target.value)} aria-label="Genre">
          <option value="">All genres</option>
          {genres.map((g) => <option key={g} value={g}>{g}</option>)}
        </select>
      </div>

      {!searched ? (
        <div className="empty-state">
          <div className="big">🔎</div>
          <h2>Find something to watch</h2>
          <p>Type above to search across shows, movies and music.</p>
        </div>
      ) : results.length === 0 ? (
        <div className="empty-state">
          <div className="big">🤷</div>
          <h2>No results</h2>
          <p>Nothing matched. Try different keywords or filters.</p>
        </div>
      ) : (
        <>
          <p className="page-sub">{results.length} result{results.length === 1 ? '' : 's'}</p>
          <div className="grid">
            {results.map((t) => <PosterCard key={t.id} title={t} />)}
          </div>
        </>
      )}
    </div></div>
  );
}

function useDebounce(value: string, delay: number): string {
  const [v, setV] = useState(value);
  const memo = useMemo(() => value, [value]);
  useEffect(() => {
    const t = window.setTimeout(() => setV(memo), delay);
    return () => window.clearTimeout(t);
  }, [memo, delay]);
  return v;
}
