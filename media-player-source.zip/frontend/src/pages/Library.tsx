import { useEffect, useRef, useState } from 'react';
import { api } from '../api';
import type { ScanResult, TitleDetail } from '../types';
import { toast } from '../components/Toaster';

export default function Library() {
  const [paths, setPaths] = useState<string[]>([]);
  const [newPath, setNewPath] = useState('');
  const [loading, setLoading] = useState(true);
  const [savingPaths, setSavingPaths] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [scanError, setScanError] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);
  const [importing, setImporting] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const cfg = await api.getConfig();
        if (!cancelled) setPaths(cfg.mediaPaths ?? []);
      } catch (e) {
        toast(e instanceof Error ? e.message : 'Failed to load config');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  const addPath = () => {
    const p = newPath.trim();
    if (!p) return;
    if (paths.includes(p)) {
      toast('That folder is already listed');
      return;
    }
    setPaths((prev) => [...prev, p]);
    setNewPath('');
  };

  const savePaths = async () => {
    setSavingPaths(true);
    try {
      const cfg = await api.updateConfig({ mediaPaths: paths });
      setPaths(cfg.mediaPaths ?? paths);
      toast('Media folders saved');
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to save');
    } finally {
      setSavingPaths(false);
    }
  };

  const scan = async () => {
    setScanning(true);
    setScanResult(null);
    setScanError(null);
    try {
      const res = await api.scan(paths.length > 0 ? paths : undefined);
      setScanResult(res);
    } catch (e) {
      setScanError(e instanceof Error ? e.message : 'Scan failed');
    } finally {
      setScanning(false);
    }
  };

  /** Export title metadata + manual overrides as JSON (download). */
  const exportJson = async () => {
    setExporting(true);
    try {
      const lib = await api.getLibrary();
      const details: TitleDetail[] = [];
      for (const t of lib.titles) {
        try {
          details.push(await api.getTitle(t.id));
        } catch { /* skip titles that fail */ }
      }
      const payload = {
        exportedAt: new Date().toISOString(),
        titles: details.map((d) => ({
          id: d.title.id,
          kind: d.title.kind,
          name: d.title.name,
          year: d.title.year,
          description: d.title.description,
          genre: d.title.genre,
          language: d.title.language,
          rating: d.title.rating,
          poster: d.title.poster,
          backdrop: d.title.backdrop,
          providers: d.providers,
          reviews: d.reviews,
        })),
      };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `my-media-metadata-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      toast(`Exported ${details.length} titles`);
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Export failed');
    } finally {
      setExporting(false);
    }
  };

  /** Import a previously exported JSON file: applies manual fields per title. */
  const importJson = async (file: File | undefined) => {
    if (!file) return;
    setImporting(true);
    try {
      const payload = JSON.parse(await file.text());
      const items: Array<{ id?: string; name?: string } & Record<string, unknown>> = payload.titles ?? [];
      if (!Array.isArray(items) || items.length === 0) {
        toast('No titles found in that file');
        return;
      }
      const lib = await api.getLibrary();
      const byId = new Map(lib.titles.map((t) => [t.id, t]));
      const byName = new Map(lib.titles.map((t) => [t.name.toLowerCase(), t]));
      let applied = 0;
      let skipped = 0;
      for (const item of items) {
        const match = (item.id && byId.get(item.id)) ?? (item.name && byName.get(String(item.name).toLowerCase()));
        if (!match) { skipped++; continue; }
        try {
          await api.updateTitle(match.id, {
            name: typeof item.name === 'string' ? item.name : undefined,
            year: typeof item.year === 'number' ? item.year : null,
            description: typeof item.description === 'string' ? item.description : null,
            genre: typeof item.genre === 'string' ? item.genre : null,
            language: typeof item.language === 'string' ? item.language : null,
            rating: typeof item.rating === 'number' ? item.rating : null,
          });
          if (Array.isArray(item.providers)) {
            await api.updateProviders(match.id, item.providers as { name: string; url: string }[]);
          }
          applied++;
        } catch {
          skipped++;
        }
      }
      toast(`Import done: ${applied} applied, ${skipped} skipped`);
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Import failed — is that a valid export file?');
    } finally {
      setImporting(false);
      if (fileInput.current) fileInput.current.value = '';
    }
  };

  if (loading) {
    return <div className="page"><div className="loading-wrap"><div className="spinner" /></div></div>;
  }

  return (
    <div className="page"><div className="container">
      <h1 className="page-title">Library</h1>
      <p className="page-sub">Media folders, scanning and metadata</p>

      <div className="settings-card">
        <h2>Media folders</h2>
        <p>Folders on your server that contain your shows, movies and music.</p>
        {paths.map((p, i) => (
          <div className="path-row" key={`${p}-${i}`}>
            <input className="form-input" value={p} onChange={(e) => setPaths((prev) => prev.map((x, idx) => (idx === i ? e.target.value : x)))} />
            <button className="mini-btn danger" onClick={() => setPaths((prev) => prev.filter((_, idx) => idx !== i))} title="Remove">✕</button>
          </div>
        ))}
        <div className="path-row">
          <input
            className="form-input"
            value={newPath}
            onChange={(e) => setNewPath(e.target.value)}
            placeholder="/media/shows"
            onKeyDown={(e) => { if (e.key === 'Enter') addPath(); }}
            aria-label="New media folder"
          />
          <button className="btn btn-outline btn-sm" onClick={addPath} disabled={!newPath.trim()}>Add</button>
        </div>
        <button className="btn btn-primary btn-sm" onClick={savePaths} disabled={savingPaths} style={{ marginTop: 8 }}>
          {savingPaths ? 'Saving…' : 'Save folders'}
        </button>
      </div>

      <div className="settings-card">
        <h2>Scan library</h2>
        <p>Scans your media folders for new titles and episodes.</p>
        <button className="btn btn-primary" onClick={scan} disabled={scanning}>
          {scanning ? 'Scanning…' : '🔍 Scan now'}
        </button>
        {scanning ? (
          <div className="scan-status"><div className="spinner" style={{ width: 22, height: 22, display: 'inline-block', verticalAlign: 'middle', marginRight: 10 }} />Scanning your folders… this can take a while.</div>
        ) : null}
        {scanResult ? (
          <div className="scan-status">
            <strong>Scan complete.</strong> {scanResult.filesScanned} files scanned —{' '}
            {scanResult.titlesAdded} titles and {scanResult.episodesAdded} episodes added.
          </div>
        ) : null}
        {scanError ? <div className="error-box">{scanError}</div> : null}
      </div>

      <div className="settings-card">
        <h2>Metadata backup</h2>
        <p>Export your titles' metadata and manual overrides to a JSON file, or import a previous export.</p>
        <div className="export-import-row">
          <button className="btn btn-outline" onClick={exportJson} disabled={exporting}>
            {exporting ? 'Exporting…' : '⬇ Export JSON'}
          </button>
          <input
            ref={fileInput}
            type="file"
            accept="application/json,.json"
            hidden
            onChange={(e) => importJson(e.target.files?.[0])}
          />
          <button className="btn btn-outline" onClick={() => fileInput.current?.click()} disabled={importing}>
            {importing ? 'Importing…' : '⬆ Import JSON'}
          </button>
        </div>
      </div>
    </div></div>
  );
}
