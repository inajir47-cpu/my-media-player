import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';
import type { Collection, ContinueWatchingItem, TitleSummary } from '../types';
import Hero from '../components/Hero';
import Shelf from '../components/Shelf';
import { ContinueWatchingCard, PosterCard } from '../components/PosterCard';

export default function Home() {
  const [titles, setTitles] = useState<TitleSummary[]>([]);
  const [continueWatching, setContinueWatching] = useState<ContinueWatchingItem[]>([]);
  const [collections, setCollections] = useState<Collection[]>([]);
  const [collectionTitles, setCollectionTitles] = useState<Record<string, TitleSummary[]>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [lib, cw, cols] = await Promise.all([
          api.getLibrary(),
          api.continueWatching().catch(() => [] as ContinueWatchingItem[]),
          api.getCollections().catch(() => [] as Collection[]),
        ]);
        if (cancelled) return;
        setTitles(lib.titles);
        setContinueWatching(cw);
        const withTitles = cols.filter((c) => (c.titleCount ?? 0) > 0).slice(0, 6);
        setCollections(withTitles);
        // Load titles for the collection rows (best effort).
        const entries = await Promise.all(
          withTitles.map(async (c) => {
            try {
              const detail = await api.getCollection(c.id);
              return [c.id, detail.titles.slice(0, 12)] as const;
            } catch {
              return [c.id, []] as const;
            }
          }),
        );
        if (!cancelled) setCollectionTitles(Object.fromEntries(entries));
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : 'Failed to load library');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  if (loading) {
    return (
      <div className="page">
        <div className="loading-wrap"><div className="spinner" /><p>Loading your library…</p></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="page"><div className="container">
        <div className="error-box">{error}</div>
        <Link to="/library" className="btn btn-primary">Go to Library settings</Link>
      </div></div>
    );
  }

  const recentlyAdded = [...titles]
    .sort((a, b) => String(b.updatedAt ?? '').localeCompare(String(a.updatedAt ?? '')))
    .slice(0, 12);

  return (
    <div className="page">
      <Hero titles={titles} />
      <div className="container">
        {continueWatching.length > 0 ? (
          <Shelf title="Continue Watching">
            {continueWatching.map((item) => (
              <ContinueWatchingCard key={item.episodeId} item={item} />
            ))}
          </Shelf>
        ) : null}

        {recentlyAdded.length > 0 ? (
          <Shelf title="Recently Added" moreTo="/shows">
            {recentlyAdded.map((t) => <PosterCard key={t.id} title={t} />)}
          </Shelf>
        ) : null}

        {collections.map((c) => {
          const ct = collectionTitles[c.id] ?? [];
          if (ct.length === 0) return null;
          return (
            <Shelf key={c.id} title={c.name} moreTo={`/collection/${c.id}`}>
              {ct.map((t) => <PosterCard key={t.id} title={t} />)}
            </Shelf>
          );
        })}

        {titles.length === 0 && continueWatching.length === 0 ? (
          <div className="empty-state">
            <div className="big">🍿</div>
            <h2>Your library is empty</h2>
            <p>Point the app at your media folders and run a scan to get started.</p>
            <Link to="/library" className="btn btn-primary">Open Library settings</Link>
          </div>
        ) : null}
      </div>
    </div>
  );
}
