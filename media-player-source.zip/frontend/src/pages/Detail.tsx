import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '../api';
import type { Episode, PlaybackEpisode, TitleDetail, TitleSummary } from '../types';
import Shelf from '../components/Shelf';
import { PosterCard } from '../components/PosterCard';
import Modal from '../components/Modal';
import CollectionPicker from '../components/CollectionPicker';
import ProviderPopup from '../components/ProviderPopup';
import EditModal from '../components/EditModal';
import { toast } from '../components/Toaster';
import { episodeLabel, formatDuration, formatRating } from '../utils/format';

interface Section {
  key: string;
  label: string;
  episodes: PlaybackEpisode[];
}

function classifyKind(itemKind?: string | null): 'episode' | 'movie' | 'ova' | 'special' {
  const k = (itemKind ?? 'episode').toLowerCase();
  if (k === 'movie') return 'movie';
  if (k === 'ova') return 'ova';
  if (k === 'special') return 'special';
  return 'episode';
}

export default function Detail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [detail, setDetail] = useState<TitleDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeSeason, setActiveSeason] = useState<number>(1);
  const [progressMap, setProgressMap] = useState<Record<string, { position: number; duration: number }>>({});
  const [related, setRelated] = useState<TitleSummary[]>([]);
  const [showPicker, setShowPicker] = useState(false);
  const [showProviders, setShowProviders] = useState(false);
  const [showEdit, setShowEdit] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  // Reviews live at the very bottom.
  const [reviews, setReviews] = useState(detail?.reviews ?? []);
  const [author, setAuthor] = useState('');
  const [rating, setRating] = useState(0);
  const [text, setText] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    (async () => {
      if (!id) return;
      try {
        const d = await api.getTitle(id);
        if (cancelled) return;
        setDetail(d);
        setReviews(d.reviews ?? []);
        const firstSeason = d.seasons.find((s) => s.seasonNumber >= 1)?.seasonNumber ?? d.seasons[0]?.seasonNumber ?? 1;
        setActiveSeason(firstSeason);
        // Merge per-episode progress from continue-watching.
        try {
          const cw = await api.continueWatching();
          if (!cancelled) {
            const map: Record<string, { position: number; duration: number }> = {};
            cw.forEach((c) => { map[c.episodeId] = { position: c.position, duration: c.duration }; });
            setProgressMap(map);
          }
        } catch { /* best effort */ }
        // Related titles: same kind + genre.
        try {
          const rel = await api.search({
            kind: d.title.kind,
            genre: (d.title.genre ?? '').split(',')[0]?.trim(),
            sort: 'rating',
          });
          if (!cancelled) setRelated(rel.titles.filter((t) => t.id !== d.title.id).slice(0, 12));
        } catch { /* best effort */ }
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : 'Failed to load title');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [id]);

  const playbackEpisodes: PlaybackEpisode[] = useMemo(() => {
    if (!detail) return [];
    const eps: PlaybackEpisode[] = [];
    for (const s of detail.seasons) {
      for (const e of s.episodes) {
        eps.push({
          ...e,
          titleId: detail.title.id,
          titleName: detail.title.name,
          titlePoster: detail.title.poster,
          progress: progressMap[e.id] ?? e.progress ?? null,
        });
      }
    }
    return eps;
  }, [detail, progressMap]);

  const hasAnyFile = useMemo(() => playbackEpisodes.some((e) => e.hasFile), [playbackEpisodes]);

  // One unified "Watch Order" area: regular seasons as tabs; movies/OVAs/specials
  // as separately labeled sections with their own artwork.
  const { seasonTabs, sections } = useMemo(() => {
    const tabs: { seasonNumber: number; year?: number | null; episodes: PlaybackEpisode[] }[] = [];
    const extras: Record<'movie' | 'ova' | 'special', PlaybackEpisode[]> = { movie: [], ova: [], special: [] };
    const bySeason = new Map<number, PlaybackEpisode[]>();
    for (const e of playbackEpisodes) {
      const kind = classifyKind(e.itemKind);
      if (e.seasonNumber >= 1 && kind === 'episode') {
        if (!bySeason.has(e.seasonNumber)) bySeason.set(e.seasonNumber, []);
        bySeason.get(e.seasonNumber)!.push(e);
      } else {
        extras[kind === 'episode' ? 'special' : kind].push(e);
      }
    }
    const seasonYears = new Map<number, number | null | undefined>();
    detail?.seasons.forEach((s) => seasonYears.set(s.seasonNumber, s.year));
    [...bySeason.keys()].sort((a, b) => a - b).forEach((sn) => {
      tabs.push({ seasonNumber: sn, year: seasonYears.get(sn), episodes: bySeason.get(sn)! });
    });
    const sections: Section[] = [];
    if (extras.movie.length) sections.push({ key: 'movies', label: 'Movies', episodes: extras.movie });
    if (extras.ova.length) sections.push({ key: 'ovas', label: 'OVAs', episodes: extras.ova });
    if (extras.special.length) sections.push({ key: 'specials', label: 'Specials', episodes: extras.special });
    return { seasonTabs: tabs, sections };
  }, [playbackEpisodes, detail]);

  const activeTab = seasonTabs.find((t) => t.seasonNumber === activeSeason) ?? seasonTabs[0];

  const goWatch = (episode: PlaybackEpisode) => {
    if (!episode.hasFile) return;
    const playable = playbackEpisodes.filter((e) => e.hasFile);
    navigate(`/watch/${episode.id}`, { state: { episodes: playable, currentId: episode.id } });
  };

  const playResume = () => {
    if (!detail) return;
    if (detail.continueFrom) {
      const ep = playbackEpisodes.find((e) => e.id === detail.continueFrom!.episodeId);
      if (ep) { goWatch(ep); return; }
    }
    const first = playbackEpisodes.find((e) => e.hasFile);
    if (first) goWatch(first);
    else toast('No playable files for this title yet');
  };

  const refresh = async () => {
    if (!id) return;
    setRefreshing(true);
    try {
      const updated = await api.refreshTitle(id);
      setDetail(updated);
      setReviews(updated.reviews ?? []);
      toast('Metadata refreshed');
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Refresh failed');
    } finally {
      setRefreshing(false);
    }
  };

  const submitReview = async () => {
    if (!id || !text.trim()) return;
    setSubmittingReview(true);
    try {
      const r = await api.addReview(id, author.trim() || 'Anonymous', rating || null, text.trim());
      setReviews((prev) => [r, ...prev]);
      setAuthor('');
      setRating(0);
      setText('');
      toast('Review added');
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to add review');
    } finally {
      setSubmittingReview(false);
    }
  };

  if (loading) {
    return <div className="page"><div className="loading-wrap"><div className="spinner" /><p>Loading…</p></div></div>;
  }

  if (error || !detail) {
    return (
      <div className="page"><div className="container">
        <div className="error-box">{error ?? 'Title not found'}</div>
        <Link to="/" className="btn btn-primary">Back home</Link>
      </div></div>
    );
  }

  const t = detail.title;

  return (
    <div className="page">
      {/* Hero */}
      <div className="detail-hero">
        {t.backdrop ? <img className="detail-backdrop" src={t.backdrop} alt="" /> : null}
        <div className="detail-gradient" />
        <div className="detail-head">
          <div className="detail-poster">
            {t.poster ? <img src={t.poster} alt={t.name} /> : <div className="placeholder">🎬</div>}
          </div>
          <div className="detail-info">
            <h1>{t.name}</h1>
            <div className="detail-meta">
              {t.year ? <span>{t.year}</span> : null}
              {t.rating != null ? <span className="rating">★ {formatRating(t.rating)}</span> : null}
              {t.genre ? <span className="pill">{t.genre}</span> : null}
              {t.language ? <span className="pill">{t.language}</span> : null}
              {t.episodeCount ? <span>{t.episodeCount} episodes</span> : null}
            </div>
            {t.description ? <p className="detail-desc">{t.description}</p> : null}
            <div className="detail-actions">
              <button className="btn btn-primary" onClick={playResume}>▶ Play</button>
              <button className="btn btn-ghost" onClick={() => setShowPicker(true)}>＋ Save</button>
              <button className="btn btn-ghost" onClick={refresh} disabled={refreshing}>
                {refreshing ? 'Refreshing…' : '⟳ Refresh'}
              </button>
              <button className="btn btn-ghost" onClick={() => setShowEdit(true)}>✎ Edit</button>
              {!hasAnyFile && detail.providers.length > 0 ? (
                <button className="btn btn-outline" onClick={() => setShowProviders(true)}>Where to watch</button>
              ) : null}
            </div>
          </div>
        </div>
      </div>

      <div className="container">
        {/* Unified Watch Order area */}
        {(seasonTabs.length > 0 || sections.length > 0) ? (
          <>
            <h2 className="section-label"><span className="bar" />Watch Order</h2>
            {seasonTabs.length > 1 || (seasonTabs.length === 1 && sections.length > 0) ? (
              <div className="season-tabs" role="tablist" aria-label="Seasons">
                {seasonTabs.map((s) => (
                  <button
                    key={s.seasonNumber}
                    role="tab"
                    aria-selected={s.seasonNumber === activeTab?.seasonNumber}
                    className={`season-tab${s.seasonNumber === activeTab?.seasonNumber ? ' active' : ''}`}
                    onClick={() => setActiveSeason(s.seasonNumber)}
                  >
                    Season {s.seasonNumber}{s.year ? ` • ${s.year}` : ''}
                  </button>
                ))}
              </div>
            ) : null}
            {activeTab ? <EpisodeGrid episodes={activeTab.episodes} onPlay={goWatch} /> : null}

            {sections.map((sec) => (
              <div key={sec.key}>
                <h3 className="section-label"><span className="bar" />{sec.label} <span className="count">{sec.episodes.length}</span></h3>
                <EpisodeGrid episodes={sec.episodes} onPlay={goWatch} />
              </div>
            ))}
          </>
        ) : (
          <div className="empty-state">
            <div className="big">🎞</div>
            <h2>No episodes found</h2>
            <p>Run a library scan to pick up files for this title.</p>
          </div>
        )}

        {/* Related */}
        {related.length > 0 ? (
          <Shelf title="Related">
            {related.map((r) => <PosterCard key={r.id} title={r} />)}
          </Shelf>
        ) : null}

        {/* Reviews — always at the very bottom */}
        <h2 className="section-label"><span className="bar" />Reviews</h2>
        {reviews.length === 0 ? (
          <p className="page-sub">No reviews yet — be the first.</p>
        ) : (
          reviews.map((r, i) => (
            <div className="review-card" key={`${r.author}-${i}`}>
              <div className="review-head">
                <span className="review-author">{r.author}</span>
                {r.rating != null ? <Stars value={r.rating} /> : null}
                {r.source ? <span className="review-source">via {r.source}</span> : null}
              </div>
              <p className="review-text">{r.text}</p>
            </div>
          ))
        )}
        <div className="review-form">
          <h3>Write a review</h3>
          <div className="form-row">
            <label htmlFor="rev-author">Name</label>
            <input id="rev-author" className="form-input" value={author} onChange={(e) => setAuthor(e.target.value)} placeholder="Anonymous" />
          </div>
          <div className="form-row">
            <label>Rating</label>
            <StarPicker value={rating} onChange={setRating} />
          </div>
          <div className="form-row">
            <label htmlFor="rev-text">Review</label>
            <textarea id="rev-text" className="form-textarea" value={text} onChange={(e) => setText(e.target.value)} placeholder="What did you think?" />
          </div>
          <button className="btn btn-primary" disabled={submittingReview || !text.trim()} onClick={submitReview}>
            {submittingReview ? 'Posting…' : 'Post review'}
          </button>
        </div>
      </div>

      {showPicker ? (
        <CollectionPicker titleId={t.id} titleName={t.name} onClose={() => setShowPicker(false)} />
      ) : null}
      {showProviders ? (
        <ProviderPopup titleName={t.name} providers={detail.providers} onClose={() => setShowProviders(false)} />
      ) : null}
      {showEdit ? (
        <EditModal detail={detail} onClose={() => setShowEdit(false)} onSaved={(d) => { setDetail(d); setReviews(d.reviews ?? []); }} />
      ) : null}
    </div>
  );
}

function EpisodeGrid({ episodes, onPlay }: { episodes: PlaybackEpisode[]; onPlay: (e: PlaybackEpisode) => void }) {
  return (
    <div className="ep-grid">
      {episodes.map((e) => (
        <EpisodeCard key={e.id} episode={e} onPlay={onPlay} />
      ))}
    </div>
  );
}

function EpisodeCard({ episode: e, onPlay }: { episode: PlaybackEpisode; onPlay: (ep: PlaybackEpisode) => void }) {
  const pct = e.progress && e.progress.duration > 0
    ? Math.min(100, Math.max(0, (e.progress.position / e.progress.duration) * 100))
    : 0;
  return (
    <div
      className={`ep-card${e.hasFile ? '' : ' no-file'}`}
      onClick={() => onPlay(e)}
      role={e.hasFile ? 'button' : undefined}
      tabIndex={e.hasFile ? 0 : undefined}
      onKeyDown={(ev) => { if (e.hasFile && (ev.key === 'Enter' || ev.key === ' ')) onPlay(e); }}
      title={e.hasFile ? `Play ${e.name}` : 'No file available'}
    >
      <div className="ep-still">
        {e.still ? <img src={e.still} alt={e.name} loading="lazy" /> : null}
        <span className="ep-num">E{e.episodeNumber}</span>
        {e.hasFile ? <span className="ep-play">▶</span> : null}
      </div>
      <div className="ep-body">
        <p className="ep-name" title={e.name}>{e.name}</p>
        <div className="ep-sub">
          {episodeLabel(e.seasonNumber, e.episodeNumber)}
          {e.duration ? ` · ${formatDuration(e.duration)}` : ''}
        </div>
        {pct > 0 ? (
          <div className="progress-track"><div className="progress-fill" style={{ width: `${pct}%` }} /></div>
        ) : null}
      </div>
    </div>
  );
}

export function Stars({ value }: { value: number }) {
  const full = Math.round(value);
  return (
    <span className="stars" aria-label={`${value} out of 5`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <span key={i} className={i <= full ? 'on' : 'off'}>★</span>
      ))}
    </span>
  );
}

function StarPicker({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  return (
    <div className="star-picker" role="radiogroup" aria-label="Rating">
      {[1, 2, 3, 4, 5].map((i) => (
        <button
          key={i}
          type="button"
          className={i <= value ? 'lit' : ''}
          onClick={() => onChange(i === value ? 0 : i)}
          aria-label={`${i} star${i === 1 ? '' : 's'}`}
        >★</button>
      ))}
    </div>
  );
}

export type { Episode };
