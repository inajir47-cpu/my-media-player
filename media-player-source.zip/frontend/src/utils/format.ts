export function formatDuration(totalSeconds?: number | null): string {
  if (totalSeconds == null || !isFinite(totalSeconds) || totalSeconds < 0) return '';
  const s = Math.floor(totalSeconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
  return `${m}:${String(sec).padStart(2, '0')}`;
}

export function formatRating(r?: number | null): string {
  if (r == null || !isFinite(r)) return '';
  return r.toFixed(1);
}

export function episodeLabel(seasonNumber: number, episodeNumber: number): string {
  return `S${seasonNumber} E${episodeNumber}`;
}

export function kindLabel(kind?: string | null): string {
  switch (kind) {
    case 'show': return 'TV Show';
    case 'movie': return 'Movie';
    case 'music': return 'Music';
    default: return '';
  }
}
