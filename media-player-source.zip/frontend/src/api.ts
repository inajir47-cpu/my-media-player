// Every HTTP call the frontend makes lives here. Nothing else in src/ should
// call fetch directly. All endpoints are relative to the same origin under
// /api (the dev server proxies them to http://localhost:4000).

import type {
  AppConfig,
  Collection,
  CollectionDetail,
  ContinueFrom,
  ContinueWatchingItem,
  MetadataResult,
  Provider,
  Review,
  ScanResult,
  SubtitleTrack,
  TitleDetail,
  TitleKind,
  TitleSummary,
} from './types';

const BASE = '/api';

class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const res = await fetch(BASE + path, {
    ...init,
    headers: {
      ...(init.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
      ...(init.headers ?? {}),
    },
  });
  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const body = await res.json();
      if (body && typeof body.error === 'string') message = body.error;
    } catch {
      /* ignore */
    }
    throw new ApiError(res.status, message);
  }
  if (res.status === 204) return undefined as T;
  const text = await res.text();
  return (text ? JSON.parse(text) : undefined) as T;
}

const get = <T>(path: string) => request<T>(path);
const post = <T>(path: string, body?: unknown) =>
  request<T>(path, { method: 'POST', body: body === undefined ? undefined : JSON.stringify(body) });
const put = <T>(path: string, body?: unknown) =>
  request<T>(path, { method: 'PUT', body: body === undefined ? undefined : JSON.stringify(body) });
const del = <T>(path: string, body?: unknown) =>
  request<T>(path, {
    method: 'DELETE',
    body: body === undefined ? undefined : JSON.stringify(body),
  });

export const api = {
  // --- health / config -------------------------------------------------------
  health: () => get<{ ok: boolean }>('/health'),
  getConfig: () => get<AppConfig>('/config'),
  updateConfig: (config: AppConfig) => put<AppConfig>('/config', config),

  // --- library ---------------------------------------------------------------
  scan: (paths?: string[]) => post<ScanResult>('/library/scan', paths ? { paths } : {}),
  getLibrary: () => get<{ titles: TitleSummary[] }>('/library'),

  // --- titles ----------------------------------------------------------------
  getTitle: (id: string) => get<TitleDetail>(`/titles/${encodeURIComponent(id)}`),
  updateTitle: (id: string, fields: Partial<TitleSummary>) =>
    put<TitleSummary>(`/titles/${encodeURIComponent(id)}`, fields),
  refreshTitle: (id: string) => post<TitleDetail>(`/titles/${encodeURIComponent(id)}/refresh`),

  /** Upload poster / backdrop / still artwork (multipart). `episodeId` is used for stills. */
  uploadArtwork: (titleId: string, kind: 'poster' | 'backdrop' | 'still', file: File, episodeId?: string) => {
    const form = new FormData();
    form.append('file', file);
    const params = new URLSearchParams({ kind });
    if (episodeId) params.set('episodeId', episodeId);
    return fetch(`${BASE}/titles/${encodeURIComponent(titleId)}/artwork?${params}`, {
      method: 'POST',
      body: form,
    }).then(async (res) => {
      if (!res.ok) throw new ApiError(res.status, `Artwork upload failed (${res.status})`);
      return res.json() as Promise<TitleSummary>;
    });
  },

  // --- search ----------------------------------------------------------------
  search: (params: { q?: string; kind?: TitleKind | ''; genre?: string; sort?: string }) => {
    const p = new URLSearchParams();
    if (params.q) p.set('q', params.q);
    if (params.kind) p.set('kind', params.kind);
    if (params.genre) p.set('genre', params.genre);
    if (params.sort) p.set('sort', params.sort);
    const qs = p.toString();
    return get<{ titles: TitleSummary[] }>(`/search${qs ? `?${qs}` : ''}`);
  },

  // --- continue watching / progress ------------------------------------------
  continueWatching: () => get<ContinueWatchingItem[]>('/continue-watching'),
  updateProgress: (episodeId: string, position: number, duration: number) =>
    put<{ ok: boolean }>('/progress', { episodeId, position, duration }),

  // --- collections ------------------------------------------------------------
  getCollections: () => get<Collection[]>('/collections'),
  createCollection: (name: string) => post<Collection>('/collections', { name }),
  updateCollection: (id: string, name: string) => put<Collection>(`/collections/${encodeURIComponent(id)}`, { name }),
  deleteCollection: (id: string) => del<{ ok: boolean }>(`/collections/${encodeURIComponent(id)}`),
  getCollection: (id: string) => get<CollectionDetail>(`/collections/${encodeURIComponent(id)}`),
  addToCollection: (collectionId: string, titleId: string) =>
    post<{ ok: boolean }>(`/collections/${encodeURIComponent(collectionId)}/items`, { titleId }),
  removeFromCollection: (collectionId: string, titleId: string) =>
    del<{ ok: boolean }>(`/collections/${encodeURIComponent(collectionId)}/items`, { titleId }),

  // --- metadata ---------------------------------------------------------------
  metadataSearch: (q: string, kind?: TitleKind | '') => {
    const p = new URLSearchParams({ q });
    if (kind) p.set('kind', kind);
    return get<MetadataResult[]>(`/metadata/search?${p}`);
  },
  applyMetadata: (titleId: string, provider: string, providerId: string) =>
    post<TitleDetail>('/metadata/apply', { titleId, provider, providerId }),

  // --- reviews ----------------------------------------------------------------
  getReviews: (titleId: string) => get<Review[]>(`/reviews/${encodeURIComponent(titleId)}`),
  addReview: (titleId: string, author: string, rating: number | null, text: string) =>
    post<Review>('/reviews', { titleId, author, rating, text }),

  // --- providers --------------------------------------------------------------
  getProviders: (titleId: string) => get<Provider[]>(`/titles/${encodeURIComponent(titleId)}/providers`),
  updateProviders: (titleId: string, providers: Provider[]) =>
    put<Provider[]>(`/titles/${encodeURIComponent(titleId)}/providers`, providers),

  // --- media ------------------------------------------------------------------
  episodeStreamUrl: (episodeId: string) => `${BASE}/media/episode/${encodeURIComponent(episodeId)}`,
  getSubtitles: (episodeId: string) => get<SubtitleTrack[]>(`/media/subtitles/${encodeURIComponent(episodeId)}`),
};

export type { ApiError };

export function continueFromToProgress(cf: ContinueFrom | null): { position: number; duration: number } | null {
  if (!cf || !cf.duration) return null;
  return { position: cf.position, duration: cf.duration };
}
