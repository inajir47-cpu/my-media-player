# QA Checklist — My Media Player source (fresh write-up)

Verified 2026-09-25 in a clean copy at `~/workspace/your_files/media-player-code/`.
This is a faithful fresh re-implementation of the Media Player app, not the
original hosted files (the platform cannot export fullstack app source).

## Backend (`backend/` — Node 24, Express 4, better-sqlite3 12, TypeScript)

- [x] `npm install` — 141 packages, clean (one deprecation warning: multer 1.x;
      see gaps)
- [x] `npm run typecheck` (`tsc --noEmit`) — clean, exit 0
- [x] `npm test` — **9/9 pass** (filename parser: SxxEyy, 1x02, absolute anime
      numbering, movie year, music tracks, dot-cleaning; scanner: grouping,
      idempotency, seasons/tracks)
- [x] `npm run build` (`tsc`) + `npm start` — boots, serves API and frontend
- [x] Live API exercise against fixture media:
  - `GET /api/health` → `{"ok":true}`
  - `GET /` → 200 HTML (frontend `dist/` served by backend, SPA fallback)
  - `POST /api/library/scan` → 4 titles / 8 episodes grouped correctly
        (series w/ seasons, movie w/ year, music album w/ tracks, anime absolute)
  - `GET /api/titles/1` → seasons + episodes + continueFrom shape correct
  - `PUT /api/progress` + `GET /api/continue-watching` → position persisted
  - Collections CRUD + items — OK
  - Reviews POST/GET, providers PUT/GET — OK (verified by builder)
  - Artwork upload (poster + episode still) — OK (verified by builder)
  - Metadata apply from TVmaze; manual title/rating/episode-still edits
    survived refresh — OK (verified by builder)
  - Range streaming returns 206 (416 only for 0-byte fixture — correct)

## Frontend (`frontend/` — Vite 5, React 18, TS, react-router-dom)

- [x] `npm install` — 72 packages, clean
- [x] `npm run typecheck` — clean, exit 0
- [x] `npm run build` — succeeds; `dist/` with hashed JS/CSS + index.html

## Feature coverage vs. spec

- [x] Crunchyroll-style dark UI, orange accent, responsive desktop/phone/tablet
- [x] Home hero with rotating muted 12s local-episode preview clips
      (random start avoiding first 90s + credits; per-episode start in
      localStorage); empty-state hero when no files
- [x] Continue Watching + Recently Added rows; clean poster cards
      (no filenames/codec/quality badges)
- [x] Shows/Movies/Music grids with filters; Search page; Saved/collections
- [x] Detail page: seasons as "Season N • year" tabs, episode grids, movies /
      OVAs / specials in separately labeled sections, related titles, reviews
      at the very bottom, single unified watch-order area (no "Release order"
      label), where-to-watch popup only when no local files
- [x] Edit modal: manual fields, artwork upload, provider-links editor,
      metadata lookup (AniList/TVmaze/Jikan search → apply)
- [x] VLC-style player: orange timeline, elapsed/total, ±10s, prev/next,
      playlist drawer, volume/mute, brightness, speed, shuffle, repeat,
      PiP, fullscreen, sleep timer, SRT/VTT subtitles, progress auto-save
- [x] Touch gestures (swipe seek, vertical swipes, double-tap ±10s, tap
      toggles controls) + keyboard shortcuts
- [x] No online trailers / YouTube / Dailymotion embeds anywhere
- [x] No protected-source fetching; providers are manual links only

## Known gaps / honest limits

1. **Not runtime-tested on a real device or with real media files** — fixtures
   only. Playback, gestures, and picker flows on actual hardware are
   unverified.
2. **AniList was unreachable from the build sandbox** (TLS stall; 8s timeout
   fires and the other providers still return). Should work on a normal
   network; TVmaze + Jikan verified reachable patterns are in code.
3. **TVmaze numbers anime seasons by year** (e.g. S2002); episode auto-fill
   only applies where season/episode numbers match local files.
4. **Music metadata** comes from filenames/folders only (no music DB lookup).
5. **multer 1.x deprecation warning** at install (vulnerabilities patched in
   2.x) — consider upgrading to multer 2.x before exposing beyond localhost.
6. **No auth** — single-user by design; bind to localhost or a trusted
   network.
7. Live metadata APIs are third-party and may change/rate-limit; failures are
   tolerated per-request and cached data keeps working offline.
