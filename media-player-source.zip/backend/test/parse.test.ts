import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { parseFilename } from '../src/parse.js';

describe('parseFilename', () => {
  it('parses SxxEyy patterns', () => {
    assert.deepEqual(parseFilename('My Show S01E02 - Pilot.mkv'), {
      show: 'My Show', season: 1, episode: 2, year: undefined, kind: 'episode',
    });
    assert.deepEqual(parseFilename('Show.Name.S2E10.mkv'), {
      show: 'Show Name', season: 2, episode: 10, year: undefined, kind: 'episode',
    });
    assert.deepEqual(parseFilename('Show s01e05 1080p.mkv'), {
      show: 'Show', season: 1, episode: 5, year: undefined, kind: 'episode',
    });
  });

  it('parses 1x02 patterns', () => {
    const p = parseFilename('Cool Show 1x02 - The Episode.mkv');
    assert.equal(p.show, 'Cool Show');
    assert.equal(p.season, 1);
    assert.equal(p.episode, 2);
    assert.equal(p.kind, 'episode');
  });

  it('parses anime absolute numbering', () => {
    const p = parseFilename('Anime Show - 001.mkv');
    assert.equal(p.show, 'Anime Show');
    assert.equal(p.episode, 1);
    assert.equal(p.absolute, 1);
    assert.equal(p.kind, 'episode');

    const p2 = parseFilename('Another.Show.045.mkv');
    assert.equal(p2.show, 'Another Show');
    assert.equal(p2.absolute, 45);
  });

  it('parses "Show - 01" short episode numbers', () => {
    const p = parseFilename('Daily Vlog - 07.mp4');
    assert.equal(p.show, 'Daily Vlog');
    assert.equal(p.episode, 7);
    assert.equal(p.kind, 'episode');
  });

  it('parses movie name with year', () => {
    const p = parseFilename('Great Movie (2020).mp4');
    assert.equal(p.show, 'Great Movie');
    assert.equal(p.year, 2020);
    assert.equal(p.kind, 'movie');
  });

  it('parses music tracks with album folder', () => {
    const p = parseFilename('Test Artist - Test Album/01 - Opening Track.mp3');
    assert.equal(p.kind, 'music');
    assert.equal(p.episode, 1);
    assert.ok(p.show.length > 0);
  });

  it('cleans dot-separated names', () => {
    const p = parseFilename('Breaking.Bad.S01E01.mkv');
    assert.equal(p.show, 'Breaking Bad');
    assert.equal(p.season, 1);
    assert.equal(p.episode, 1);
  });
});
