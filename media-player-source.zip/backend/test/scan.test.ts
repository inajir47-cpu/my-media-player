import { describe, it, before } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

// Isolate the database for this test run BEFORE scanner/db modules load.
const TEST_DB = path.join(__dirname, 'test-mediaplayer.db');
process.env.DB_PATH = TEST_DB;

const FIX = path.join(__dirname, 'fixtures');

function writeFile(rel: string) {
  const abs = path.join(FIX, rel);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, Buffer.alloc(0));
}

before(async () => {
  if (fs.existsSync(FIX)) fs.rmSync(FIX, { recursive: true, force: true });
  if (fs.existsSync(TEST_DB)) fs.rmSync(TEST_DB, { force: true });
  writeFile('Test Show/Test Show S01E01.mkv');
  writeFile('Test Show/Test Show S01E02.mkv');
  writeFile('Test Show/Test Show S02E01.mkv');
  writeFile('Movies/Test Movie (2020).mp4');
  writeFile('Music/Test Artist - Test Album/01 - Opening Track.mp3');
  writeFile('Music/Test Artist - Test Album/02 - Second Track.mp3');
  writeFile('Anime Show/Anime Show - 001.mkv');
  writeFile('Anime Show/Anime Show - 002.mkv');
});

describe('scanPaths grouping', () => {
  it('groups files into series/movie/music titles and is idempotent', async () => {
    const { scanPaths } = await import('../src/scanner.js');
    const first = scanPaths([FIX]);
    assert.equal(first.filesScanned, 8);
    // Test Show (series, 3 eps) + Test Movie (movie) + Test Artist - Test Album (music, 2 tracks)
    // + Anime Show (series, 2 eps) = 4 titles, 8 media rows
    assert.equal(first.titlesAdded, 4);
    assert.equal(first.episodesAdded, 8);

    const second = scanPaths([FIX]);
    assert.equal(second.titlesAdded, 0);
    assert.equal(second.episodesAdded, 0);
    assert.equal(second.filesScanned, 8);
  });

  it('stores seasons and music tracks correctly', async () => {
    const { getDb } = await import('../src/db.js');
    const db = getDb();
    const show = db.prepare("SELECT id, kind FROM titles WHERE name = 'Test Show'").get() as any;
    assert.equal(show.kind, 'series');
    const eps = db.prepare('SELECT season_number, episode_number FROM episodes WHERE title_id = ? ORDER BY season_number, episode_number').all(show.id) as any[];
    assert.deepEqual(eps.map(e => [e.season_number, e.episode_number]), [[1, 1], [1, 2], [2, 1]]);

    const music = db.prepare("SELECT id FROM titles WHERE kind = 'music'").get() as any;
    const tracks = db.prepare('SELECT episode_number, name FROM episodes WHERE title_id = ? ORDER BY episode_number').all(music.id) as any[];
    assert.equal(tracks.length, 2);
    assert.ok(tracks[0].name?.toLowerCase().includes('opening'));

    const movie = db.prepare("SELECT id, kind, year FROM titles WHERE kind = 'movie'").get() as any;
    assert.equal(movie.year, 2020);

    const anime = db.prepare("SELECT id FROM titles WHERE name = 'Anime Show'").get() as any;
    const abs = db.prepare('SELECT absolute_number FROM episodes WHERE title_id = ? ORDER BY absolute_number').all(anime.id) as any[];
    assert.deepEqual(abs.map(a => a.absolute_number), [1, 2]);
  });
});
