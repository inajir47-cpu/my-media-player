import { Router, Request, Response } from 'express';
import { getDb } from '../db';
import { searchAll, fetchDetails } from '../metadata';
import { applyMetadata } from './library';

const router = Router();

// GET /api/metadata/search?q=&kind=
router.get('/search', async (req: Request, res: Response) => {
  const q = String(req.query.q || '').trim();
  if (!q) return res.status(400).json({ error: 'q is required' });
  try {
    const results = await searchAll(q);
    res.json({ results });
  } catch (e: any) {
    res.status(502).json({ error: e?.message || 'Metadata search failed' });
  }
});

// POST /api/metadata/apply {titleId, provider, providerId}
router.post('/apply', async (req: Request, res: Response) => {
  const { titleId, provider, providerId } = req.body || {};
  const tid = parseInt(titleId, 10);
  if (!tid) return res.status(400).json({ error: 'titleId is required' });
  if (!provider || !providerId) return res.status(400).json({ error: 'provider and providerId are required' });
  const db = getDb();
  const exists = db.prepare('SELECT id FROM titles WHERE id = ?').get(tid) as any;
  if (!exists) return res.status(404).json({ error: 'Title not found' });
  try {
    const details = await fetchDetails(String(provider), String(providerId));
    applyMetadata(db, tid, details);
    res.json({ ok: true });
  } catch (e: any) {
    res.status(502).json({ error: e?.message || 'Metadata apply failed' });
  }
});

export default router;
