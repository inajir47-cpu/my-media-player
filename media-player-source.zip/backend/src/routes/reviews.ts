import { Router, Request, Response } from 'express';
import { getDb, nowIso } from '../db';

const router = Router();

// GET /api/reviews/:titleId -> merged cached + manual, newest first
router.get('/:titleId', (req: Request, res: Response) => {
  const db = getDb();
  const id = parseInt(req.params.titleId, 10);
  const exists = db.prepare('SELECT id FROM titles WHERE id = ?').get(id) as any;
  if (!exists) return res.status(404).json({ error: 'Title not found' });
  const reviews = db.prepare('SELECT id, author, rating, text, source, created_at AS createdAt FROM reviews WHERE title_id = ? ORDER BY created_at DESC').all(id);
  res.json({ reviews });
});

// POST /api/reviews {titleId, author, rating, text}
router.post('/', (req: Request, res: Response) => {
  const { titleId, author, rating, text } = req.body || {};
  const tid = parseInt(titleId, 10);
  if (!tid) return res.status(400).json({ error: 'titleId is required' });
  const db = getDb();
  const exists = db.prepare('SELECT id FROM titles WHERE id = ?').get(tid) as any;
  if (!exists) return res.status(404).json({ error: 'Title not found' });
  if (rating != null && (typeof rating !== 'number' || rating < 0 || rating > 10)) {
    return res.status(400).json({ error: 'rating must be a number between 0 and 10' });
  }
  const r = db.prepare('INSERT INTO reviews (title_id, author, rating, text, source, created_at) VALUES (?, ?, ?, ?, ?, ?)')
    .run(tid, author ?? null, rating ?? null, text ?? null, 'manual', nowIso());
  res.status(201).json({ id: r.lastInsertRowid });
});

export default router;
