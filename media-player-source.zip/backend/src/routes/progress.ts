import { Router, Request, Response } from 'express';
import { getDb, mergeManual, nowIso } from '../db';

const router = Router();

// GET /api/continue-watching
router.get('/continue-watching', (_req: Request, res: Response) => {
  const db = getDb();
  // Latest progress row per episode, only for episodes with files that still exist is checked at read time
  const rows = db.prepare(`
    SELECT h.episode_id, h.position, h.duration, h.watched_at,
           e.title_id, e.season_number, e.episode_number, e.name AS episode_name, e.file_path,
           t.name AS raw_name, t.meta_json, t.manual_json
    FROM watch_history h
    JOIN episodes e ON e.id = h.episode_id
    JOIN titles t ON t.id = e.title_id
    WHERE h.watched_at = (SELECT MAX(watched_at) FROM watch_history WHERE episode_id = h.episode_id)
      AND (h.completed = 0 OR h.completed IS NULL)
    ORDER BY h.watched_at DESC
    LIMIT 50
  `).all() as any[];
  res.json({
    items: rows.map(r => {
      const m = mergeManual({ meta_json: r.meta_json, manual_json: r.manual_json } as any);
      return {
        titleId: r.title_id, titleName: (m as any).name ?? r.raw_name,
        poster: (m as any).poster ?? null,
        episodeId: r.episode_id, seasonNumber: r.season_number,
        episodeNumber: r.episode_number, episodeName: r.episode_name,
        position: r.position, duration: r.duration, updatedAt: r.watched_at,
      };
    }),
  });
});

// PUT /api/progress
router.put('/progress', (req: Request, res: Response) => {
  const { episodeId, position, duration } = req.body || {};
  const eid = parseInt(episodeId, 10);
  if (!eid) return res.status(400).json({ error: 'episodeId is required' });
  if (typeof position !== 'number' || typeof duration !== 'number' || position < 0 || duration < 0) {
    return res.status(400).json({ error: 'position and duration must be non-negative numbers' });
  }
  const db = getDb();
  const ep = db.prepare('SELECT title_id FROM episodes WHERE id = ?').get(eid) as any;
  if (!ep) return res.status(404).json({ error: 'Episode not found' });
  const completed = duration > 0 && position / duration > 0.95 ? 1 : 0;
  const now = nowIso();
  const existing = db.prepare('SELECT id FROM watch_history WHERE episode_id = ?').get(eid) as any;
  if (existing) {
    db.prepare('UPDATE watch_history SET position = ?, duration = ?, watched_at = ?, completed = ? WHERE episode_id = ?')
      .run(position, duration, now, completed, eid);
  } else {
    db.prepare('INSERT INTO watch_history (title_id, episode_id, position, duration, watched_at, completed) VALUES (?, ?, ?, ?, ?, ?)')
      .run(ep.title_id, eid, position, duration, now, completed);
  }
  res.json({ ok: true, completed: !!completed });
});

// GET /api/history?limit=50
router.get('/history', (req: Request, res: Response) => {
  const limit = Math.min(200, Math.max(1, parseInt(String(req.query.limit || '50'), 10) || 50));
  const db = getDb();
  const rows = db.prepare(`
    SELECT h.id, h.position, h.duration, h.watched_at, h.completed,
           e.id AS episode_id, e.season_number, e.episode_number, e.name AS episode_name,
           t.id AS title_id, t.name AS raw_name, t.meta_json, t.manual_json
    FROM watch_history h
    JOIN episodes e ON e.id = h.episode_id
    JOIN titles t ON t.id = e.title_id
    ORDER BY h.watched_at DESC LIMIT ?
  `).all(limit) as any[];
  res.json({
    history: rows.map(r => {
      const m = mergeManual({ meta_json: r.meta_json, manual_json: r.manual_json } as any);
      return {
        id: r.id, titleId: r.title_id, titleName: (m as any).name ?? r.raw_name,
        episodeId: r.episode_id, seasonNumber: r.season_number, episodeNumber: r.episode_number,
        episodeName: r.episode_name, position: r.position, duration: r.duration,
        watchedAt: r.watched_at, completed: !!r.completed,
      };
    }),
  });
});

// GET /api/search?q=&kind=&genre=&sort=recent|rating|name
router.get('/search', (req: Request, res: Response) => {
  const db = getDb();
  const q = String(req.query.q || '').trim();
  const kind = String(req.query.kind || '');
  const genre = String(req.query.genre || '').trim().toLowerCase();
  const sort = String(req.query.sort || 'recent');

  const conditions: string[] = [];
  const params: any[] = [];
  if (kind && ['series', 'movie', 'music'].includes(kind)) { conditions.push('t.kind = ?'); params.push(kind); }
  // Search across base name, meta name and manual name
  if (q) {
    conditions.push(`(t.name LIKE ? OR json_extract(t.meta_json, '$.name') LIKE ? OR json_extract(t.manual_json, '$.name') LIKE ?)`);
    params.push(`%${q}%`, `%${q}%`, `%${q}%`);
  }
  if (genre) {
    conditions.push(`(LOWER(t.genre) LIKE ? OR LOWER(json_extract(t.meta_json, '$.genre')) LIKE ? OR LOWER(json_extract(t.manual_json, '$.genre')) LIKE ?)`);
    params.push(`%${genre}%`, `%${genre}%`, `%${genre}%`);
  }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const order =
    sort === 'rating' ? 'ORDER BY rating_val DESC' :
    sort === 'name' ? 'ORDER BY name ASC' :
    'ORDER BY t.updated_at DESC';

  const rows = db.prepare(`
    SELECT t.*,
      (SELECT COUNT(*) FROM episodes e WHERE e.title_id = t.id) AS episodeCount,
      (SELECT COUNT(DISTINCT e.season_number) FROM episodes e WHERE e.title_id = t.id) AS seasonCount,
      COALESCE(json_extract(t.manual_json, '$.rating'), json_extract(t.meta_json, '$.rating'), t.rating) AS rating_val
    FROM titles t ${where} ${order}
  `).all(...params) as any[];

  res.json({
    titles: rows.map(t => {
      const m = mergeManual(t);
      return {
        id: t.id, kind: t.kind, name: m.name ?? t.name, year: m.year ?? t.year,
        poster: m.poster ?? t.poster, backdrop: m.backdrop ?? t.backdrop,
        rating: m.rating ?? t.rating, description: m.description ?? t.description,
        genre: m.genre ?? t.genre, episodeCount: t.episodeCount, seasonCount: t.seasonCount,
        updatedAt: t.updated_at,
      };
    }),
  });
});

export default router;
