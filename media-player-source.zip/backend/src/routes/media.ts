import { Router, Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import { getDb } from '../db';

const router = Router();

const CONTENT_TYPES: Record<string, string> = {
  '.mp4': 'video/mp4', '.mkv': 'video/x-matroska', '.avi': 'video/x-msvideo',
  '.mov': 'video/quicktime', '.webm': 'video/webm', '.m4v': 'video/x-m4v',
  '.mp3': 'audio/mpeg', '.flac': 'audio/flac', '.m4a': 'audio/mp4',
  '.ogg': 'audio/ogg', '.wav': 'audio/wav', '.aac': 'audio/aac',
  '.srt': 'text/plain; charset=utf-8', '.vtt': 'text/vtt; charset=utf-8',
};

function contentTypeFor(filePath: string): string {
  return CONTENT_TYPES[path.extname(filePath).toLowerCase()] || 'application/octet-stream';
}

// GET /api/media/episode/:episodeId -> Range streaming (206)
router.get('/episode/:episodeId', (req: Request, res: Response) => {
  const db = getDb();
  const eid = parseInt(req.params.episodeId, 10);
  const ep = db.prepare('SELECT file_path FROM episodes WHERE id = ?').get(eid) as any;
  if (!ep?.file_path || !fs.existsSync(ep.file_path)) return res.status(404).json({ error: 'Media file not found' });

  const filePath: string = ep.file_path;
  const stat = fs.statSync(filePath);
  const total = stat.size;
  const type = contentTypeFor(filePath);
  const range = req.headers.range;

  if (!range) {
    res.writeHead(200, { 'Content-Type': type, 'Content-Length': total, 'Accept-Ranges': 'bytes' });
    fs.createReadStream(filePath).pipe(res);
    return;
  }

  const m = range.match(/bytes=(\d*)-(\d*)/);
  if (!m) return res.status(416).json({ error: 'Invalid range' });
  let start = m[1] ? parseInt(m[1], 10) : 0;
  let end = m[2] ? parseInt(m[2], 10) : total - 1;
  if (start >= total || end >= total) {
    res.setHeader('Content-Range', `bytes */${total}`);
    return res.status(416).json({ error: 'Range not satisfiable' });
  }
  if (isNaN(start)) start = Math.max(0, total - (parseInt(m[2], 10) || 0));
  const chunkSize = end - start + 1;
  res.writeHead(206, {
    'Content-Type': type,
    'Content-Length': chunkSize,
    'Content-Range': `bytes ${start}-${end}/${total}`,
    'Accept-Ranges': 'bytes',
  });
  fs.createReadStream(filePath, { start, end }).pipe(res);
});

// GET /api/media/subtitles/:episodeId -> [{label, url}]
router.get('/subtitles/:episodeId', (req: Request, res: Response) => {
  const db = getDb();
  const eid = parseInt(req.params.episodeId, 10);
  const ep = db.prepare('SELECT file_path FROM episodes WHERE id = ?').get(eid) as any;
  if (!ep?.file_path) return res.status(404).json({ error: 'Episode not found' });

  const dir = path.dirname(ep.file_path);
  const base = path.basename(ep.file_path, path.extname(ep.file_path)).toLowerCase();
  const found: { label: string; url: string }[] = [];
  let entries: string[];
  try { entries = fs.readdirSync(dir); } catch { entries = []; }
  for (const f of entries) {
    const ext = path.extname(f).toLowerCase();
    if (ext !== '.srt' && ext !== '.vtt') continue;
    const stem = f.slice(0, -ext.length).toLowerCase();
    const stemNoLang = stem.replace(/\.[a-z]{2,3}$/i, '');
    if (stem === base || stemNoLang === base || base.startsWith(stemNoLang + '.') || stemNoLang.startsWith(base + '.')) {
      const abs = path.join(dir, f);
      found.push({
        label: f.replace(/\.[^.]+$/, '').replace(new RegExp(`^${base.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\.?`, 'i'), '') || f,
        url: `/api/media/subtitle-file?path=${encodeURIComponent(abs)}`,
      });
    }
  }
  res.json({ subtitles: found });
});

// GET /api/media/subtitle-file?path=<enc> -> serves .srt/.vtt as text
router.get('/subtitle-file', (req: Request, res: Response) => {
  const p = String(req.query.path || '');
  if (!p) return res.status(400).json({ error: 'path is required' });
  const ext = path.extname(p).toLowerCase();
  if (ext !== '.srt' && ext !== '.vtt') return res.status(400).json({ error: 'Only .srt/.vtt files are served' });
  // Only serve files that live under a known media path or title path
  const db = getDb();
  const known = (db.prepare('SELECT path FROM titles').all() as any[]).map(r => r.path).filter(Boolean);
  const normalized = path.normalize(p);
  const inside = known.some(k => normalized.startsWith(path.normalize(k) + path.sep));
  if (!inside || !fs.existsSync(normalized)) return res.status(404).json({ error: 'Subtitle file not found' });
  res.setHeader('Content-Type', CONTENT_TYPES[ext]);
  fs.createReadStream(normalized).pipe(res);
});

export default router;
