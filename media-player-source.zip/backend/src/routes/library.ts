import { Router, Request, Response } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { getDb, getConfig, mergeManual, nowIso } from '../db';
import { scanPaths } from '../scanner';
import { fetchDetails } from '../metadata';

const router = Router();

function safeJson(s: string): Record<string, any> {
  try { return JSON.parse(s || '{}'); } catch { return {}; }
}

// ---------- POST /api/library/scan ----------
router.post('/library/scan', (req: Request, res: Response) => {
  let paths: string[] | undefined = req.body?.paths;
  if (!paths) {
    try { paths = JSON.parse(getConfig('mediaPaths', '[]')); } catch { paths = []; }
  }
  if (!Array.isArray(paths)) return res.status(400).json({ error: 'paths must be an array' });
  try {
    const result = scanPaths(paths as string[]);
    res.json(result);
  } catch (e: any) {
    res.status(500).json({ error: e?.message || 'Scan failed' });
  }
});

// ---------- GET /api/library ----------
router.get('/library', (_req: Request, res: Response) => {
  const db = getDb();
  const titles = db.prepare(`
    SELECT t.*,
      (SELECT COUNT(*) FROM episodes e WHERE e.title_id = t.id) AS episodeCount,
      (SELECT COUNT(DISTINCT e.season_number) FROM episodes e WHERE e.title_id = t.id) AS seasonCount
    FROM titles t ORDER BY t.updated_at DESC
  `).all() as any[];
  res.json({
    titles: titles.map(t => {
      const m = mergeManual(t);
      return {
        id: t.id, kind: t.kind, name: m.name ?? t.name, year: m.year ?? t.year,
        poster: m.poster ?? t.poster, backdrop: m.backdrop ?? t.backdrop,
        rating: m.rating ?? t.rating, description: m.description ?? t.description,
        genre: m.genre ?? t.genre, episodeCount: t.episodeCount, seasonCount: t.seasonCount,
        updatedAt: t.updated_at,
      };
    }),
  });
});

// ---------- GET /api/titles/:id ----------
router.get('/titles/:id', (req: Request, res: Response) => {
  const db = getDb();
  const id = parseInt(req.params.id, 10);
  const row = db.prepare('SELECT * FROM titles WHERE id = ?').get(id) as any;
  if (!row) return res.status(404).json({ error: 'Title not found' });
  const m = mergeManual(row);
  const episodes = db.prepare('SELECT * FROM episodes WHERE title_id = ? ORDER BY season_number, episode_number').all(id) as any[];

  // Apply manual episode overrides (name/still) recorded in manual_json.episodes
  const epOverrides: Record<string, any> = m.episode_overrides || {};
  const seasonsMap = new Map<number, any[]>();
  for (const e of episodes) {
    const ov = epOverrides[String(e.id)] || {};
    const ep = {
      id: e.id, seasonNumber: e.season_number, episodeNumber: e.episode_number,
      name: ov.name ?? e.name, description: e.description,
      still: ov.still ?? e.still, duration: e.duration,
      itemKind: e.item_kind, absoluteNumber: e.absolute_number,
      hasFile: !!(e.file_path && fs.existsSync(e.file_path)),
    };
    if (!seasonsMap.has(e.season_number)) seasonsMap.set(e.season_number, []);
    seasonsMap.get(e.season_number)!.push(ep);
  }
  const seasons = [...seasonsMap.entries()]
    .sort((a, b) => a[0] - b[0])
    .map(([seasonNumber, eps]) => ({ seasonNumber, episodes: eps }));

  const reviews = db.prepare('SELECT * FROM reviews WHERE title_id = ? ORDER BY created_at DESC').all(id);
  const providers = db.prepare('SELECT id, name, url FROM watch_providers WHERE title_id = ?').all(id);

  // continueFrom: latest non-completed progress for this title's episodes
  const cont = db.prepare(`
    SELECT h.episode_id, h.position, h.duration, h.watched_at
    FROM watch_history h JOIN episodes e ON e.id = h.episode_id
    WHERE e.title_id = ? AND (h.completed = 0)
    ORDER BY h.watched_at DESC LIMIT 1
  `).get(id) as any;
  const continueFrom = cont ? { episodeId: cont.episode_id, position: cont.position, duration: cont.duration } : null;

  const title = {
    id: row.id, kind: row.kind, name: m.name ?? row.name, year: m.year ?? row.year,
    description: m.description ?? row.description, genre: m.genre ?? row.genre,
    language: m.language ?? row.language, rating: m.rating ?? row.rating,
    poster: m.poster ?? row.poster, backdrop: m.backdrop ?? row.backdrop,
    path: row.path, provider: row.provider, provider_id: row.provider_id,
  };
  res.json({ title, seasons, reviews, providers, continueFrom });
});

// ---------- PUT /api/titles/:id  (manual overrides only) ----------
const MANUAL_FIELDS = ['name', 'description', 'genre', 'year', 'language', 'rating', 'poster', 'backdrop'] as const;

router.put('/titles/:id', (req: Request, res: Response) => {
  const db = getDb();
  const id = parseInt(req.params.id, 10);
  const row = db.prepare('SELECT manual_json FROM titles WHERE id = ?').get(id) as any;
  if (!row) return res.status(404).json({ error: 'Title not found' });
  const manual = safeJson(row.manual_json);
  for (const f of MANUAL_FIELDS) {
    if (req.body[f] !== undefined) manual[f] = req.body[f];
  }
  db.prepare('UPDATE titles SET manual_json = ?, updated_at = ? WHERE id = ?').run(JSON.stringify(manual), nowIso(), id);
  res.json({ ok: true });
});

// ---------- POST /api/titles/:id/artwork ----------
const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, path.join(process.cwd(), 'data', 'artwork')),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname) || '.jpg';
      cb(null, `${Date.now()}-${crypto.randomBytes(6).toString('hex')}${ext}`);
    },
  }),
  limits: { fileSize: 20 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (/^image\//.test(file.mimetype)) cb(null, true);
    else cb(new Error('Only image files are allowed'));
  },
});

router.post('/titles/:id/artwork', upload.single('file'), (req: Request, res: Response) => {
  const db = getDb();
  const id = parseInt(req.params.id, 10);
  const row = db.prepare('SELECT manual_json FROM titles WHERE id = ?').get(id) as any;
  if (!row) return res.status(404).json({ error: 'Title not found' });
  if (!req.file) return res.status(400).json({ error: 'No file uploaded (field "file")' });

  const kind = String(req.query.kind || 'poster');
  if (!['poster', 'backdrop', 'still'].includes(kind)) return res.status(400).json({ error: 'kind must be poster|backdrop|still' });

  const publicPath = `/artwork/${req.file.filename}`;
  const manual = safeJson(row.manual_json);

  if (kind === 'still') {
    const episodeId = parseInt(String(req.query.episodeId || ''), 10);
    if (!episodeId) return res.status(400).json({ error: 'episodeId query param required for still' });
    const ep = db.prepare('SELECT id FROM episodes WHERE id = ? AND title_id = ?').get(episodeId, id) as any;
    if (!ep) return res.status(404).json({ error: 'Episode not found for this title' });
    if (!manual.episodes) manual.episodes = {};
    if (!manual.episodes[String(episodeId)]) manual.episodes[String(episodeId)] = {};
    manual.episodes[String(episodeId)].still = publicPath;
    db.prepare('UPDATE episodes SET still = ? WHERE id = ?').run(publicPath, episodeId);
    db.prepare('UPDATE titles SET manual_json = ?, updated_at = ? WHERE id = ?').run(JSON.stringify(manual), nowIso(), id);
  } else {
    manual[kind] = publicPath;
    db.prepare('UPDATE titles SET manual_json = ?, updated_at = ? WHERE id = ?').run(JSON.stringify(manual), nowIso(), id);
  }
  res.json({ path: publicPath });
});

// ---------- POST /api/titles/:id/refresh ----------
router.post('/titles/:id/refresh', async (req: Request, res: Response) => {
  const db = getDb();
  const id = parseInt(req.params.id, 10);
  const row = db.prepare('SELECT * FROM titles WHERE id = ?').get(id) as any;
  if (!row) return res.status(404).json({ error: 'Title not found' });
  if (!row.provider || !row.provider_id) return res.status(400).json({ error: 'No provider linked to this title' });
  try {
    const details = await fetchDetails(row.provider, row.provider_id);
    applyMetadata(db, id, details, row);
    res.json({ ok: true });
  } catch (e: any) {
    res.status(502).json({ error: e?.message || 'Metadata refresh failed' });
  }
});

/** Write fetched metadata into meta_json + non-manual episode fields. Manual always wins. */
export function applyMetadata(db: any, titleId: number, details: import('../metadata').ProviderDetails, existingRow?: any): void {
  const row = existingRow || db.prepare('SELECT * FROM titles WHERE id = ?').get(titleId);
  const manual = safeJson(row.manual_json);
  const meta: Record<string, any> = {
    name: details.name, year: details.year, description: details.description,
    genre: details.genres?.join(', '), language: details.language, rating: details.rating,
    poster: details.poster, backdrop: details.backdrop,
  };
  for (const k of Object.keys(meta)) if (meta[k] === undefined) delete meta[k];
  db.prepare('UPDATE titles SET meta_json = ?, provider = ?, provider_id = ?, updated_at = ? WHERE id = ?')
    .run(JSON.stringify(meta), details.provider, details.id, nowIso(), titleId);

  // Episode metadata: only fill where NOT manually overridden
  const epOverrides: Record<string, any> = manual.episodes || {};
  if (details.seasons) {
    const episodes = db.prepare('SELECT id, season_number, episode_number FROM episodes WHERE title_id = ?').all(titleId) as any[];
    const upd = db.prepare('UPDATE episodes SET name = COALESCE(NULLIF(TRIM(name), \'\'), ?), description = COALESCE(description, ?), still = COALESCE(still, ?) WHERE id = ?');
    for (const s of details.seasons) {
      for (const se of s.episodes) {
        const local = episodes.find(e => e.season_number === s.seasonNumber && e.episode_number === se.episodeNumber);
        if (!local) continue;
        const ov = epOverrides[String(local.id)] || {};
        if (ov.name) continue; // manual name wins entirely for this episode
        upd.run(se.name ?? null, se.description ?? null, ov.still ?? se.still ?? null, local.id);
      }
    }
  }

  // Cache Jikan reviews
  if (details.reviews?.length) {
    const ins = db.prepare('INSERT INTO reviews (title_id, author, rating, text, source, created_at) VALUES (?, ?, ?, ?, ?, ?)');
    db.prepare('DELETE FROM reviews WHERE title_id = ? AND source = ?').run(titleId, details.provider);
    const now = nowIso();
    for (const r of details.reviews) {
      ins.run(titleId, r.author ?? null, r.rating ?? null, r.text ?? null, details.provider, now);
    }
  }
}

// ---------- providers (manual where-to-watch links) ----------
router.get('/titles/:id/providers', (req: Request, res: Response) => {
  const db = getDb();
  const id = parseInt(req.params.id, 10);
  const exists = db.prepare('SELECT id FROM titles WHERE id = ?').get(id) as any;
  if (!exists) return res.status(404).json({ error: 'Title not found' });
  res.json({ providers: db.prepare('SELECT id, name, url FROM watch_providers WHERE title_id = ?').all(id) });
});

router.put('/titles/:id/providers', (req: Request, res: Response) => {
  const db = getDb();
  const id = parseInt(req.params.id, 10);
  const exists = db.prepare('SELECT id FROM titles WHERE id = ?').get(id) as any;
  if (!exists) return res.status(404).json({ error: 'Title not found' });
  const list = req.body;
  if (!Array.isArray(list)) return res.status(400).json({ error: 'Body must be an array of {name,url}' });
  const tx = db.transaction(() => {
    db.prepare('DELETE FROM watch_providers WHERE title_id = ?').run(id);
    const ins = db.prepare('INSERT INTO watch_providers (title_id, name, url) VALUES (?, ?, ?)');
    for (const p of list) {
      if (!p?.name) continue;
      ins.run(id, String(p.name), p.url ? String(p.url) : null);
    }
  });
  tx();
  res.json({ ok: true });
});

export default router;
