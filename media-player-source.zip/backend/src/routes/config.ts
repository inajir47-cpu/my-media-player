import { Router, Request, Response } from 'express';
import { getConfig, setConfig } from '../db';

const router = Router();

router.get('/config', (_req: Request, res: Response) => {
  let mediaPaths: string[] = [];
  try {
    mediaPaths = JSON.parse(getConfig('mediaPaths', '[]'));
    if (!Array.isArray(mediaPaths)) mediaPaths = [];
  } catch { mediaPaths = []; }
  res.json({ mediaPaths });
});

router.put('/config', (req: Request, res: Response) => {
  const { mediaPaths } = req.body || {};
  if (!Array.isArray(mediaPaths) || mediaPaths.some(p => typeof p !== 'string')) {
    return res.status(400).json({ error: 'mediaPaths must be an array of strings' });
  }
  setConfig('mediaPaths', JSON.stringify(mediaPaths));
  res.json({ mediaPaths });
});

export default router;
