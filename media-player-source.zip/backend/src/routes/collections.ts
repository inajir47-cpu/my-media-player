import { Router, Request, Response } from 'express';
import { getDb, mergeManual, nowIso } from '../db';

const router = Router();

function titlesForCollection(db: any, collectionId: number) {
  const rows = db.prepare(`
    SELECT t.*, ci.position,
      (SELECT COUNT(*) FROM episodes e WHERE e.title_id = t.id) AS episodeCount,
      (SELECT COUNT(DISTINCT e.season_number) FROM episodes e WHERE e.title_id = t.id) AS seasonCount
    FROM collection_items ci JOIN titles t ON t.id = ci.title_id
    WHERE ci.collection_id = ?
    ORDER BY ci.position, t.name
  `).all(collectionId) as any[];
  return rows.map(t => {
    const m = mergeManual(t);
    return {
      id: t.id, kind: t.kind, name: m.name ?? t.name, year: m.year ?? t.year,
      poster: m.poster ?? t.poster, backdrop: m.backdrop ?? t.backdrop,
      rating: m.rating ?? t.rating, description: m.description ?? t.description,
      genre: m.genre ?? t.genre, episodeCount: t.episodeCount, seasonCount: t.seasonCount,
      position: t.position,
    };
  });
}

router.get('/', (_req: Request, res: Response) => {
  const db = getDb();
  const cols = db.prepare('SELECT * FROM collections ORDER BY created_at DESC').all() as any[];
  res.json({
    collections: cols.map(c => ({
      id: c.id, name: c.name, description: c.description, poster: c.poster,
      createdAt: c.created_at,
      count: (db.prepare('SELECT COUNT(*) AS n FROM collection_items WHERE collection_id = ?').get(c.id) as any).n,
    })),
  });
});

router.post('/', (req: Request, res: Response) => {
  const { name, description } = req.body || {};
  if (!name || typeof name !== 'string') return res.status(400).json({ error: 'name is required' });
  const db = getDb();
  const r = db.prepare('INSERT INTO collections (name, description, created_at) VALUES (?, ?, ?)')
    .run(name, description ?? null, nowIso());
  res.status(201).json({ id: r.lastInsertRowid, name, description: description ?? null });
});

router.get('/:id', (req: Request, res: Response) => {
  const db = getDb();
  const id = parseInt(req.params.id, 10);
  const c = db.prepare('SELECT * FROM collections WHERE id = ?').get(id) as any;
  if (!c) return res.status(404).json({ error: 'Collection not found' });
  res.json({
    id: c.id, name: c.name, description: c.description, poster: c.poster, createdAt: c.created_at,
    titles: titlesForCollection(db, id),
  });
});

router.put('/:id', (req: Request, res: Response) => {
  const db = getDb();
  const id = parseInt(req.params.id, 10);
  const c = db.prepare('SELECT id FROM collections WHERE id = ?').get(id) as any;
  if (!c) return res.status(404).json({ error: 'Collection not found' });
  const { name, description, poster } = req.body || {};
  const updates: string[] = [];
  const vals: any[] = [];
  if (name !== undefined) { updates.push('name = ?'); vals.push(name); }
  if (description !== undefined) { updates.push('description = ?'); vals.push(description); }
  if (poster !== undefined) { updates.push('poster = ?'); vals.push(poster); }
  if (!updates.length) return res.status(400).json({ error: 'Nothing to update' });
  db.prepare(`UPDATE collections SET ${updates.join(', ')} WHERE id = ?`).run(...vals, id);
  res.json({ ok: true });
});

router.delete('/:id', (req: Request, res: Response) => {
  const db = getDb();
  const id = parseInt(req.params.id, 10);
  const r = db.prepare('DELETE FROM collections WHERE id = ?').run(id);
  if (!r.changes) return res.status(404).json({ error: 'Collection not found' });
  res.json({ ok: true });
});

router.post('/:id/items', (req: Request, res: Response) => {
  const db = getDb();
  const id = parseInt(req.params.id, 10);
  const c = db.prepare('SELECT id FROM collections WHERE id = ?').get(id) as any;
  if (!c) return res.status(404).json({ error: 'Collection not found' });
  const titleId = parseInt(req.body?.titleId, 10);
  if (!titleId) return res.status(400).json({ error: 'titleId is required' });
  const t = db.prepare('SELECT id FROM titles WHERE id = ?').get(titleId) as any;
  if (!t) return res.status(404).json({ error: 'Title not found' });
  const maxPos = (db.prepare('SELECT MAX(position) AS m FROM collection_items WHERE collection_id = ?').get(id) as any).m ?? -1;
  db.prepare('INSERT INTO collection_items (collection_id, title_id, position) VALUES (?, ?, ?) ON CONFLICT(collection_id, title_id) DO NOTHING')
    .run(id, titleId, maxPos + 1);
  res.status(201).json({ ok: true });
});

router.delete('/:id/items/:titleId', (req: Request, res: Response) => {
  const db = getDb();
  const id = parseInt(req.params.id, 10);
  const titleId = parseInt(req.params.titleId, 10);
  const r = db.prepare('DELETE FROM collection_items WHERE collection_id = ? AND title_id = ?').run(id, titleId);
  if (!r.changes) return res.status(404).json({ error: 'Item not found in collection' });
  res.json({ ok: true });
});

export default router;
