// Metadata providers: AniList GraphQL, TVmaze REST, Jikan REST.
// All calls are direct provider APIs (no scraping, no embeds).

export interface ProviderResult {
  provider: string;
  id: string;
  name: string;
  year?: number;
  poster?: string;
  description?: string;
}

export interface ProviderDetails extends ProviderResult {
  backdrop?: string;
  rating?: number;
  genres?: string[];
  language?: string;
  seasons?: {
    seasonNumber: number;
    year?: number;
    episodes: {
      seasonNumber: number;
      episodeNumber: number;
      absoluteNumber?: number;
      name?: string;
      description?: string;
      still?: string;
      itemKind?: 'episode' | 'movie' | 'ova' | 'special';
    }[];
  }[];
  reviews?: { author?: string; rating?: number; text?: string }[];
  relations?: { kind: string; name: string; provider: string; id: string }[];
}

const TIMEOUT_MS = 8000;

async function fetchJson(url: string, opts?: RequestInit): Promise<any> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, { ...opts, signal: ctrl.signal, headers: { 'User-Agent': 'my-media-player/1.0', ...(opts?.headers || {}) } });
    if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

function stripHtml(s?: string | null): string | undefined {
  if (!s) return undefined;
  return s.replace(/<[^>]*>/g, '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").trim() || undefined;
}

// ---------------- AniList ----------------
const ANILIST_URL = 'https://graphql.anilist.io';

async function anilistQuery(query: string, variables: Record<string, any>): Promise<any> {
  return fetchJson(ANILIST_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables }),
  });
}

export async function anilistSearch(q: string): Promise<ProviderResult[]> {
  const data = await anilistQuery(
    `query ($q: String) { Page(perPage: 8) { media(search: $q, type: ANIME) {
       id title { english romaji native } startDate { year } description
       coverImage { large } averageScore } } }`,
    { q }
  );
  const media = data?.data?.Page?.media || [];
  return media.map((m: any) => ({
    provider: 'anilist',
    id: String(m.id),
    name: m.title?.english || m.title?.romaji || m.title?.native || 'Unknown',
    year: m.startDate?.year,
    poster: m.coverImage?.large,
    description: stripHtml(m.description)?.slice(0, 400),
  }));
}

export async function anilistDetails(id: string): Promise<ProviderDetails> {
  const data = await anilistQuery(
    `query ($id: Int) { Media(id: $id, type: ANIME) {
       id title { english romaji native } startDate { year } description
       coverImage { large extraLarge } bannerImage averageScore genres
       relations { edges { relationType(version: 2) node { id title { english romaji native } format } } }
    } }`,
    { id: parseInt(id, 10) }
  );
  const m = data?.data?.Media;
  if (!m) throw new Error('AniList: not found');
  const relations = (m.relations?.edges || [])
    .map((e: any) => {
      const rel = String(e.relationType || '').toLowerCase();
      const kind = rel.includes('movie') ? 'movie' : rel.includes('ova') || rel.includes('side') ? 'ova' : rel.includes('special') ? 'special' : 'related';
      return { kind, name: e.node?.title?.english || e.node?.title?.romaji || 'Related', provider: 'anilist', id: String(e.node?.id) };
    })
    .filter((r: any) => r.kind !== 'related');
  return {
    provider: 'anilist',
    id: String(m.id),
    name: m.title?.english || m.title?.romaji || m.title?.native || 'Unknown',
    year: m.startDate?.year,
    poster: m.coverImage?.extraLarge || m.coverImage?.large,
    backdrop: m.bannerImage || undefined,
    description: stripHtml(m.description),
    rating: m.averageScore != null ? Math.round((m.averageScore / 10) * 10) / 10 : undefined,
    genres: m.genres,
    relations,
  };
}

// ---------------- TVmaze ----------------
export async function tvmazeSearch(q: string): Promise<ProviderResult[]> {
  const data = await fetchJson(`https://api.tvmaze.com/search/shows?q=${encodeURIComponent(q)}`);
  return (data || []).slice(0, 8).map((r: any) => ({
    provider: 'tvmaze',
    id: String(r.show?.id),
    name: r.show?.name || 'Unknown',
    year: r.show?.premiered ? parseInt(r.show.premiered.slice(0, 4), 10) : undefined,
    poster: r.show?.image?.medium || r.show?.image?.original,
    description: stripHtml(r.show?.summary)?.slice(0, 400),
  }));
}

export async function tvmazeDetails(id: string): Promise<ProviderDetails> {
  const show = await fetchJson(`https://api.tvmaze.com/shows/${encodeURIComponent(id)}?embed=episodes`);
  if (!show?.id) throw new Error('TVmaze: not found');
  const eps = show._embedded?.episodes || [];
  const seasonsMap = new Map<number, any[]>();
  for (const e of eps) {
    const s = e.season ?? 1;
    if (!seasonsMap.has(s)) seasonsMap.set(s, []);
    seasonsMap.get(s)!.push({
      seasonNumber: s,
      episodeNumber: e.number ?? 0,
      name: e.name,
      description: stripHtml(e.summary),
      still: e.image?.medium || e.image?.original,
      itemKind: 'episode' as const,
    });
  }
  const seasons = [...seasonsMap.entries()]
    .sort((a, b) => a[0] - b[0])
    .map(([seasonNumber, episodes]) => ({
      seasonNumber,
      year: show.premiered ? parseInt(show.premiered.slice(0, 4), 10) : undefined,
      episodes: episodes.sort((a, b) => a.episodeNumber - b.episodeNumber),
    }));
  return {
    provider: 'tvmaze',
    id: String(show.id),
    name: show.name,
    year: show.premiered ? parseInt(show.premiered.slice(0, 4), 10) : undefined,
    poster: show.image?.original || show.image?.medium,
    backdrop: show.image?.original,
    description: stripHtml(show.summary),
    rating: show.rating?.average ?? undefined,
    genres: show.genres,
    language: show.language,
    seasons,
  };
}

// ---------------- Jikan ----------------
export async function jikanSearch(q: string): Promise<ProviderResult[]> {
  const data = await fetchJson(`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(q)}&limit=8`);
  return (data?.data || []).map((a: any) => ({
    provider: 'jikan',
    id: String(a.mal_id),
    name: a.title_english || a.title || 'Unknown',
    year: a.year,
    poster: a.images?.jpg?.large_image_url || a.images?.jpg?.image_url,
    description: a.synopsis?.slice(0, 400),
  }));
}

export async function jikanDetails(id: string): Promise<ProviderDetails> {
  const a = (await fetchJson(`https://api.jikan.moe/v4/anime/${encodeURIComponent(id)}`))?.data;
  if (!a) throw new Error('Jikan: not found');
  let reviews: ProviderDetails['reviews'] = [];
  try {
    const r = await fetchJson(`https://api.jikan.moe/v4/anime/${encodeURIComponent(id)}/reviews?sort=desc`);
    reviews = (r?.data || []).slice(0, 10).map((rev: any) => ({
      author: rev.user?.username,
      rating: rev.score,
      text: rev.review,
    }));
  } catch { /* reviews optional */ }
  return {
    provider: 'jikan',
    id: String(a.mal_id),
    name: a.title_english || a.title || 'Unknown',
    year: a.year,
    poster: a.images?.jpg?.large_image_url || a.images?.jpg?.image_url,
    description: a.synopsis,
    rating: a.score,
    genres: (a.genres || []).map((g: any) => g.name),
    reviews,
  };
}

// ---------------- Orchestration ----------------
export async function searchAll(q: string): Promise<ProviderResult[]> {
  const results = await Promise.allSettled([anilistSearch(q), tvmazeSearch(q), jikanSearch(q)]);
  const out: ProviderResult[] = [];
  for (const r of results) {
    if (r.status === 'fulfilled') out.push(...r.value);
    // failures tolerated
  }
  return out;
}

export async function fetchDetails(provider: string, id: string): Promise<ProviderDetails> {
  switch (provider) {
    case 'anilist': return anilistDetails(id);
    case 'tvmaze': return tvmazeDetails(id);
    case 'jikan': return jikanDetails(id);
    default: throw new Error(`Unknown provider: ${provider}`);
  }
}
