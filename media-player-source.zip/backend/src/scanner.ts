// Library scanner: walks media dirs, groups files into series/movie/music titles.

import fs from 'fs';
import path from 'path';
import { getDb, nowIso } from './db';
import { parseFilename } from './parse';

export const VIDEO_EXTS = new Set(['.mp4', '.mkv', '.avi', '.mov', '.webm', '.m4v']);
export const AUDIO_EXTS = new Set(['.mp3', '.flac', '.m4a', '.ogg', '.wav', '.aac']);
export const SUB_EXTS = new Set(['.srt', '.vtt']);

export interface ScanResult {
  titlesAdded: number;
  episodesAdded: number;
  filesScanned: number;
}

export interface FoundFile {
  absPath: string;
  relPath: string;
  dir: string;       // parent dir (absolute)
  dirName: string;   // parent dir name
  fileName: string;
  ext: string;
  kind: 'video' | 'audio' | 'sub';
}

function walkFiles(root: string): FoundFile[] {
  const out: FoundFile[] = [];
  const stack = [root];
  while (stack.length) {
    const dir = stack.pop()!;
    let entries: fs.Dirent[];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch { continue; }
    for (const e of entries) {
      const abs = path.join(dir, e.name);
      if (e.isDirectory()) {
        if (e.name.startsWith('.')) continue;
        stack.push(abs);
      } else if (e.isFile()) {
        const ext = path.extname(e.name).toLowerCase();
        const kind = VIDEO_EXTS.has(ext) ? 'video' : AUDIO_EXTS.has(ext) ? 'audio' : SUB_EXTS.has(ext) ? 'sub' : null;
        if (!kind) continue;
        out.push({ absPath: abs, relPath: path.relative(root, abs), dir, dirName: path.basename(dir), fileName: e.name, ext, kind });
      }
    }
  }
  return out;
}

/** Find subtitle files whose base name matches the video base name (sibling-matched). */
function matchSubtitles(files: FoundFile[]): Map<string, FoundFile[]> {
  const byDir = new Map<string, FoundFile[]>();
  for (const f of files) {
    if (f.kind !== 'sub') continue;
    const key = f.dir + '/' + stripSubLang(f.fileName);
    if (!byDir.has(key)) byDir.set(key, []);
    byDir.get(key)!.push(f);
  }
  const result = new Map<string, FoundFile[]>();
  for (const f of files) {
    if (f.kind !== 'video') continue;
    const videoBase = f.fileName.replace(/\.[^.]+$/, '').toLowerCase();
    const dirSubs = byDir.get(f.dir + '/' + videoBase);
    if (dirSubs) result.set(f.absPath, dirSubs);
  }
  return result;
}

/** Strip ".en"/".eng" style language suffixes and extension from subtitle file names. */
function stripSubLang(name: string): string {
  return name.replace(/\.[^.]+$/, '').replace(/\.[a-z]{2,3}$/i, '').toLowerCase();
}

interface GroupedEpisode {
  file: FoundFile;
  parsed: ReturnType<typeof parseFilename>;
  itemKind: 'episode' | 'movie' | 'ova' | 'special';
}

export function scanPaths(roots: string[]): ScanResult {
  const db = getDb();
  let titlesAdded = 0, episodesAdded = 0, filesScanned = 0;

  const allFiles: FoundFile[] = [];
  for (const root of roots) {
    if (!fs.existsSync(root)) continue;
    allFiles.push(...walkFiles(root));
  }
  filesScanned = allFiles.length;

  const knownPaths = new Set(
    (db.prepare('SELECT file_path FROM episodes').all() as { file_path: string }[]).map(r => r.file_path)
  );
  const freshFiles = allFiles.filter(f => f.kind === 'sub' || !knownPaths.has(f.absPath));
  if (!freshFiles.length) return { titlesAdded, episodesAdded, filesScanned };

  // Subtitle files are sibling-matched per video at serve time (see subtitles route).

  const videos = freshFiles.filter(f => f.kind === 'video');
  const audios = freshFiles.filter(f => f.kind === 'audio');

  // --- Group videos: by show folder or show name from filename
  // Key: normalized show name for episodic content; folder key for movies/lone files.
  interface SeriesGroup { showName: string; items: GroupedEpisode[]; kind: 'series' | 'movie'; dir: string; year?: number }
  const groups = new Map<string, SeriesGroup>();

  for (const v of videos) {
    const parsed = parseFilename(v.fileName);
    // A video is "episodic" if it parsed with season+episode/absolute, or shares a show
    // name with other videos in the same folder.
    const hasEpInfo = parsed.episode != null;
    const key = `series|${parsed.show.toLowerCase()}`;
    const loneKey = `file|${v.absPath}`;
    if (hasEpInfo) {
      if (!groups.has(key)) groups.set(key, { showName: parsed.show, items: [], kind: 'series', dir: v.dir, year: parsed.year });
      groups.get(key)!.items.push({ file: v, parsed, itemKind: 'episode' });
    } else {
      // Lone video (movie or single-episode): check if the folder has other videos with the same show.
      const siblings = videos.filter(s => s !== v && s.dir === v.dir && parseFilename(s.fileName).show.toLowerCase() === parsed.show.toLowerCase() && parseFilename(s.fileName).episode != null);
      if (siblings.length) {
        if (!groups.has(key)) groups.set(key, { showName: parsed.show, items: [], kind: 'series', dir: v.dir, year: parsed.year });
        groups.get(key)!.items.push({ file: v, parsed: { ...parsed, episode: (groups.get(key)!.items.length + 1) }, itemKind: 'episode' });
      } else {
        // Lone video (movie): a video with no episode info and no episodic siblings.
        if (!groups.has(loneKey)) groups.set(loneKey, { showName: parsed.show, items: [], kind: 'movie', dir: v.dir, year: parsed.year });
        groups.get(loneKey)!.items.push({ file: v, parsed, itemKind: 'movie' });
      }
    }
  }

  // --- Group audio: parent folder => music title, files => tracks
  const audioGroups = new Map<string, FoundFile[]>();
  for (const a of audios) {
    if (!audioGroups.has(a.dir)) audioGroups.set(a.dir, []);
    audioGroups.get(a.dir)!.push(a);
  }

  const now = nowIso();
  const insertTitle = db.prepare(
    `INSERT INTO titles (kind, name, year, path, provider, provider_id, meta_json, manual_json, created_at, updated_at)
     VALUES (?, ?, ?, ?, NULL, NULL, '{}', '{}', ?, ?)`
  );
  const insertEpisode = db.prepare(
    `INSERT INTO episodes (title_id, season_number, episode_number, name, description, file_path, duration, item_kind, absolute_number)
     VALUES (?, ?, ?, ?, NULL, ?, NULL, ?, ?)`
  );

  const insertAll = db.transaction(() => {
    for (const g of groups.values()) {
      let titleId: number | undefined;
      if (g.kind === 'movie') {
        // Reuse existing movie title in the same path if one exists
        const existing = db.prepare('SELECT id FROM titles WHERE kind = ? AND name = ? AND path = ?')
          .get('movie', g.showName, g.dir) as { id: number } | undefined;
        titleId = existing?.id;
      } else {
        const existing = db.prepare('SELECT id FROM titles WHERE kind = ? AND name = ?')
          .get('series', g.showName) as { id: number } | undefined;
        titleId = existing?.id;
      }
      if (!titleId) {
        const r = insertTitle.run(g.kind, g.showName, g.year ?? null, g.dir, now, now);
        titleId = r.lastInsertRowid as number;
        titlesAdded++;
      }
      const usedNums = new Set(
        (db.prepare('SELECT season_number, episode_number FROM episodes WHERE title_id = ?').all(titleId) as any[])
          .map(r => `${r.season_number}:${r.episode_number}`)
      );
      for (const item of g.items) {
        const season = item.parsed.season ?? 1;
        let ep = item.parsed.episode ?? 1;
        while (usedNums.has(`${season}:${ep}`)) ep++;
        usedNums.add(`${season}:${ep}`);
        const epName = item.itemKind === 'movie' ? item.parsed.show : undefined;
        insertEpisode.run(titleId, season, ep, epName ?? null, item.file.absPath, item.itemKind, item.parsed.absolute ?? null);
        episodesAdded++;
      }
    }
    // Music titles
    for (const [dir, tracks] of audioGroups) {
      const dirName = tracks[0].dirName;
      const existing = db.prepare('SELECT id FROM titles WHERE kind = ? AND name = ? AND path = ?')
        .get('music', dirName, dir) as { id: number } | undefined;
      let titleId = existing?.id;
      if (!titleId) {
        const r = insertTitle.run('music', dirName, null, dir, now, now);
        titleId = r.lastInsertRowid as number;
        titlesAdded++;
      }
      const usedNums = new Set(
        (db.prepare('SELECT episode_number FROM episodes WHERE title_id = ?').all(titleId) as any[])
          .map(r => r.episode_number)
      );
      const sorted = [...tracks].sort((a, b) => a.fileName.localeCompare(b.fileName));
      for (const t of sorted) {
        const parsed = parseFilename(t.relPath);
        let ep = parsed.episode ?? 1;
        while (usedNums.has(ep)) ep++;
        usedNums.add(ep);
        const name = cleanTrackName(t.fileName);
        insertEpisode.run(titleId, 1, ep, name, t.absPath, 'episode', null);
        episodesAdded++;
      }
    }
  });
  insertAll();

  return { titlesAdded, episodesAdded, filesScanned };
}

function cleanTrackName(fileName: string): string | null {
  const bare = fileName.replace(/\.[^.]+$/, '');
  const m = bare.match(/^\s*\d{1,3}\s*[-._\s]+(.+)$/);
  const name = m ? m[1] : bare;
  const cleaned = name.replace(/[._]+/g, ' ').replace(/\s{2,}/g, ' ').trim();
  return cleaned || null;
}

export { matchSubtitles };
