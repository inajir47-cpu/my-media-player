import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { getDb } from './db';
import configRouter from './routes/config';
import libraryRouter from './routes/library';
import collectionsRouter from './routes/collections';
import progressRouter from './routes/progress';
import metadataRouter from './routes/metadata';
import reviewsRouter from './routes/reviews';
import mediaRouter from './routes/media';

const PORT = parseInt(process.env.PORT || '4000', 10);

const app = express();
app.use(cors());
app.use(express.json({ limit: '4mb' }));

// Ensure data dirs exist
getDb();
for (const d of ['data/artwork']) {
  const p = path.join(process.cwd(), d);
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
}
app.use('/artwork', express.static(path.join(process.cwd(), 'data', 'artwork')));

app.get('/api/health', (_req, res) => res.json({ ok: true }));

app.use('/api', configRouter);
app.use('/api', libraryRouter);
app.use('/api/collections', collectionsRouter);
app.use('/api/metadata', metadataRouter);
app.use('/api/reviews', reviewsRouter);
app.use('/api/media', mediaRouter);
// continue-watching / progress / history / search mounted at /api root
app.use('/api', progressRouter);

// Frontend static (production): ../frontend/dist
const frontendDir = path.join(__dirname, '..', '..', 'frontend', 'dist');
if (fs.existsSync(frontendDir)) {
  app.use(express.static(frontendDir));
  app.get('*', (_req, res) => res.sendFile(path.join(frontendDir, 'index.html')));
}

// 404 for unknown API routes
app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found' }));

// Error handler
// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('API error:', err?.message || err);
  res.status(err?.status || 500).json({ error: err?.message || 'Internal server error' });
});

app.listen(PORT, () => {
  console.log(`My Media Player backend listening on :${PORT}`);
});
