import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';

const DB_PATH = process.env.DB_PATH || path.join(process.cwd(), 'data', 'mediaplayer.db');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS titles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL CHECK(kind IN ('series','movie','music')),
  name TEXT NOT NULL,
  year INTEGER,
  description TEXT,
  genre TEXT,
  language TEXT,
  rating REAL,
  poster TEXT,
  backdrop TEXT,
  path TEXT,
  provider TEXT,
  provider_id TEXT,
  meta_json TEXT DEFAULT '{}',
  manual_json TEXT DEFAULT '{}',
  created_at TEXT,
  updated_at TEXT
);
CREATE TABLE IF NOT EXISTS episodes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title_id INTEGER NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
  season_number INTEGER DEFAULT 1,
  episode_number INTEGER DEFAULT 1,
  name TEXT,
  description TEXT,
  still TEXT,
  file_path TEXT,
  duration REAL,
  item_kind TEXT DEFAULT 'episode' CHECK(item_kind IN ('episode','movie','ova','special')),
  absolute_number INTEGER
);
CREATE INDEX IF NOT EXISTS idx_episodes_title ON episodes(title_id);
CREATE INDEX IF NOT EXISTS idx_episodes_filepath ON episodes(file_path);
CREATE TABLE IF NOT EXISTS collections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  poster TEXT,
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS collection_items (
  collection_id INTEGER NOT NULL REFERENCES collections(id) ON DELETE CASCADE,
  title_id INTEGER NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
  position INTEGER DEFAULT 0,
  PRIMARY KEY (collection_id, title_id)
);
CREATE TABLE IF NOT EXISTS watch_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title_id INTEGER REFERENCES titles(id) ON DELETE CASCADE,
  episode_id INTEGER REFERENCES episodes(id) ON DELETE CASCADE,
  position REAL DEFAULT 0,
  duration REAL DEFAULT 0,
  watched_at TEXT,
  completed INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_history_episode ON watch_history(episode_id);
CREATE INDEX IF NOT EXISTS idx_history_watched ON watch_history(watched_at DESC);
CREATE TABLE IF NOT EXISTS reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title_id INTEGER NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
  author TEXT,
  rating REAL,
  text TEXT,
  source TEXT DEFAULT 'manual',
  created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_reviews_title ON reviews(title_id);
CREATE TABLE IF NOT EXISTS watch_providers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title_id INTEGER NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  url TEXT
);
CREATE INDEX IF NOT EXISTS idx_providers_title ON watch_providers(title_id);
CREATE TABLE IF NOT EXISTS config (
  key TEXT PRIMARY KEY,
  value TEXT
);
`;

let db: Database;

export function getDb(): Database {
  if (!db) {
    const dir = path.dirname(DB_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    db = new Database(DB_PATH);
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');
    db.exec(SCHEMA);
  }
  return db;
}

export function nowIso(): string {
  return new Date().toISOString();
}

/** Merge meta_json and manual_json: manual wins on title fields, plus manual episode overrides. */
export function mergeManual<T extends Record<string, any>>(row: {
  meta_json: string;
  manual_json: string;
} & T): T & { manual_overrides: Record<string, any>; episode_overrides: Record<string, any> } {
  const meta = safeJson(row.meta_json);
  const manual = safeJson(row.manual_json);
  const { episodes: epOverrides = {}, ...manualFields } = manual;
  const merged = { ...row, ...meta, ...manualFields } as any;
  delete merged.meta_json;
  delete merged.manual_json;
  merged.manual_overrides = manualFields;
  merged.episode_overrides = epOverrides;
  return merged;
}

function safeJson(s: string): Record<string, any> {
  try {
    const v = JSON.parse(s || '{}');
    return v && typeof v === 'object' ? v : {};
  } catch {
    return {};
  }
}

export function getConfig(key: string, fallback: string): string {
  const row = getDb().prepare('SELECT value FROM config WHERE key = ?').get(key) as { value: string } | undefined;
  return row ? row.value : fallback;
}

export function setConfig(key: string, value: string): void {
  getDb().prepare('INSERT INTO config (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(key, value);
}
