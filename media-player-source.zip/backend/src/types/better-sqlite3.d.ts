// Minimal local typings for better-sqlite3 (no @types package exists for v12).
declare module 'better-sqlite3' {
  namespace BetterSqlite3 {
    interface RunResult {
      changes: number | bigint;
      lastInsertRowid: number | bigint;
    }
    interface Statement {
      run(...params: any[]): RunResult;
      get(...params: any[]): any;
      all(...params: any[]): any[];
      iterate(...params: any[]): IterableIterator<any>;
    }
    type TransactionFn = (...params: any[]) => any;
  }
  class Database {
    constructor(filename: string, options?: { readonly?: boolean; fileMustExist?: boolean; timeout?: number; verbose?: (...args: any[]) => void });
    prepare(source: string): BetterSqlite3.Statement;
    exec(source: string): void;
    pragma(source: string, options?: { simple?: boolean }): any;
    transaction(fn: (...params: any[]) => any): BetterSqlite3.TransactionFn;
    close(): void;
    readonly open: boolean;
    readonly inTransaction: boolean;
  }
  export = Database;
}
