// Filename parser for media files.
// Supports:
//   Show Name S01E02 ...        -> { show, season: 1, episode: 2 }
//   Show.Name.1x02              -> { show, season: 1, episode: 2 }
//   Show - 01                   -> { show, episode: 1 }
//   Anime Show - 001            -> { show, absolute: 1 }
//   Movie Name (2020).mp4       -> { show: "Movie Name", year: 2020, kind: "movie" }
//   Artist - Album/01 - Track   -> { show: "Artist - Album", track: 1, kind: "music" }

export interface ParsedName {
  show: string;        // cleaned show / movie / album name
  season?: number;
  episode?: number;
  absolute?: number;   // anime absolute numbering
  year?: number;
  kind: 'episode' | 'movie' | 'music';
}

const VIDEO_STRIP = /\.(mp4|mkv|avi|mov|webm|m4v)$/i;
const AUDIO_STRIP = /\.(mp3|flac|m4a|ogg|wav|aac)$/i;
const SUB_STRIP = /\.(srt|vtt|ass|ssa)$/i;

export function stripExt(name: string): string {
  return name.replace(VIDEO_STRIP, '').replace(AUDIO_STRIP, '').replace(SUB_STRIP, '');
}

function cleanName(s: string): string {
  return s
    .replace(/[._]+/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim()
    .replace(/[\s\-_.]+$/, '')
    .trim();
}

/** Extract (year) or [2020] style year from the end of a name. Returns { name, year }. */
function extractYear(name: string): { name: string; year?: number } {
  const m = name.match(/[\(\[](\d{4})[\)\]]\s*$/);
  if (m) {
    const year = parseInt(m[1], 10);
    if (year >= 1900 && year <= 2100) {
      return { name: name.slice(0, m.index).trim(), year };
    }
  }
  // bare year at the end separated by space/dot
  const m2 = name.match(/[.\s](19|20)\d{2}\s*$/);
  if (m2) {
    const year = parseInt(m2[0].replace(/[.\s]/g, ''), 10);
    return { name: name.slice(0, m2.index).trim(), year };
  }
  return { name };
}

/**
 * Parse a media filename (or a "parentDir/filename" string for music) into its components.
 * `relPath` may include parent folders; for music we pass the full relative path so the
 * parent folder contributes the Artist/Album context.
 */
export function parseFilename(input: string): ParsedName {
  const base = input.split(/[\\/]/).pop() || input;
  const bare = stripExt(base);

  // --- Music first: audio extension => track-based parse
  if (AUDIO_STRIP.test(base)) {
    const parts = input.split(/[\\/]/);
    const file = stripExt(parts.pop() || '');
    const parent = parts.length ? cleanName(parts[parts.length - 1]) : '';
    // "01 - Track Name" / "01.Track Name" / "Track 01 - Name"
    let track: number | undefined;
    let trackName = file;
    let m = file.match(/^\s*(\d{1,3})\s*[-._\s]+(.+)$/);
    if (m) {
      track = parseInt(m[1], 10);
      trackName = cleanName(m[2]);
    } else {
      m = file.match(/(.+?)[\s\-._]+(?:track\s*)?(\d{1,3})\s*$/i);
      if (m && m[2].length <= 3) {
        track = parseInt(m[2], 10);
        trackName = cleanName(m[1]);
      }
    }
    const show = parent ? `${parent}` : cleanName(file);
    return { show, episode: track, kind: 'music' };
  }

  // --- S01E02 / S1E2 / s01e02 patterns
  let m = bare.match(/^(.*?)[.\s_\-]+[Ss](\d{1,2})[.\s_\-]*[Ee](\d{1,3})(?:[.\s_\-]+(.*))?$/);
  if (m) {
    const show = cleanName(m[1] || '');
    const epName = m[4] ? cleanName(m[4]) : undefined;
    const { name, year } = extractYear(show);
    return { show: name || show, season: parseInt(m[2], 10), episode: parseInt(m[3], 10), year, kind: 'episode', };
  }

  // --- 1x02 / 01x02 pattern
  m = bare.match(/^(.*?)[.\s_\-]+(\d{1,2})[xX](\d{1,3})(?:[.\s_\-]+(.*))?$/);
  if (m) {
    const show = cleanName(m[1] || '');
    const { name, year } = extractYear(show);
    return { show: name || show, season: parseInt(m[2], 10), episode: parseInt(m[3], 10), year, kind: 'episode' };
  }

  // --- "Show - 001" / "Show 001" anime absolute numbering (3 digits at end)
  m = bare.match(/^(.*?)[\s._\-–—]+(?:e|ep|episode\s*)?(\d{2,4})(?:[\s._\-–—]+(v\d+|part\s*\d+|ova|special))?[\s._\-–—]*(.*?)$/i);
  if (m && !bare.match(/\d{4}$/)) {
    const num = parseInt(m[2], 10);
    if (num >= 1 && num <= 9999) {
      const show = cleanName(m[1] || '');
      if (show) {
        const { name, year } = extractYear(show);
        const extra = cleanName((m[3] ? m[3] + ' ' : '') + (m[4] || ''));
        return { show: name || show, episode: num, absolute: num, year, kind: 'episode' };
      }
    }
  }

  // --- "Show Name - 01 - Episode Title" short number (2 digits)
  m = bare.match(/^(.*?)[\s._\-–—]+(\d{1,2})(?:[\s._\-–—]+(.+))?$/);
  if (m) {
    const num = parseInt(m[2], 10);
    const show = cleanName(m[1] || '');
    if (show && num <= 99) {
      const { name, year } = extractYear(show);
      return { show: name || show, episode: num, kind: 'episode' };
    }
  }

  // --- Movie with year
  {
    const { name, year } = extractYear(bare);
    if (year) {
      return { show: cleanName(name), year, kind: 'movie' };
    }
  }

  // --- Fallback: whole name as show, single episode 1 (used when grouped under a folder)
  return { show: cleanName(bare), kind: 'episode' };
}

/** Split a title name into show title and episode name for "Show - Episode" style strings. */
export function splitShowEpisode(name: string): { show: string; episodeName?: string } {
  const m = name.match(/^(.*?)\s*[-–—]\s*(.+)$/);
  if (m) return { show: cleanName(m[1]), episodeName: cleanName(m[2]) };
  return { show: cleanName(name) };
}
