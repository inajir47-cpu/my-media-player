# My Media Player — Backend

Node.js + Express 4 + better-sqlite3 + TypeScript backend for a personal media-player web app.
Single-user, no auth. Serves media files with HTTP Range streaming.

## Requirements

- Node.js 18+

## Install

```sh
npm install
```

## Develop

```sh
npm run dev      # tsx watch src/index.ts — auto-reload on change
```

## Build & run (production)

```sh
npm run build    # tsc -> dist/
npm start        # node dist/index.js
```

The server serves the frontend static build from `../frontend/dist` when it exists
(express.static + SPA fallback); otherwise it runs API-only.

## Typecheck & tests

```sh
npx tsc --noEmit        # typecheck (also: npm run typecheck)
npm test                # node:test unit tests (parse.ts + scan grouping)
```

## Configuration

| Env var   | Default                    | Description              |
|-----------|----------------------------|--------------------------|
| `PORT`    | `4000`                     | HTTP port                |
| `DB_PATH` | `./data/mediaplayer.db`    | SQLite file location     |

`PUT /api/config` with `{ "mediaPaths": ["/media/Movies", "/media/Shows"] }` sets the
directories scanned by `POST /api/library/scan` (paths may also be passed in the body).

## API (base `/api`)

| Method | Route | Description |
|---|---|---|
| GET | `/health` | `{ok:true}` |
| GET/PUT | `/config` | media paths config |
| POST | `/library/scan` | scan dirs → `{titlesAdded, episodesAdded, filesScanned}` |
| GET | `/library` | all titles (summary) |
| GET | `/titles/:id` | title + seasons/episodes + reviews + providers + continueFrom |
| PUT | `/titles/:id` | manual field overrides (writes **only** `manual_json`) |
| POST | `/titles/:id/artwork` | multipart `file`, `?kind=poster\|backdrop\|still&episodeId=` → `{path}` |
| POST | `/titles/:id/refresh` | re-fetch metadata; manual overrides survive |
| GET/PUT/DELETE | `/collections`, `/collections/:id` | collections CRUD |
| GET | `/collections/:id` | collection with titles |
| POST/DELETE | `/collections/:id/items`, `.../items/:titleId` | manage items |
| GET | `/search?q=&kind=&genre=&sort=recent\|rating\|name` | search titles |
| GET | `/continue-watching` | resume list |
| PUT | `/progress` | `{episodeId, position, duration}` upsert (completed when >95%) |
| GET | `/history?limit=50` | watch history |
| GET | `/metadata/search?q=&kind=` | AniList + TVmaze + Jikan search |
| POST | `/metadata/apply` | `{titleId, provider, providerId}` → fills meta + episodes + Jikan reviews |
| GET | `/reviews/:titleId` | cached + manual reviews |
| POST | `/reviews` | `{titleId, author, rating, text}` |
| GET/PUT | `/titles/:id/providers` | manual where-to-watch links |
| GET | `/media/episode/:episodeId` | file stream with HTTP Range (206) |
| GET | `/media/subtitles/:episodeId` | sibling-matched `.srt`/`.vtt` list |
| GET | `/media/subtitle-file?path=` | serves subtitle text |

Errors are `{error: string}`.

## Metadata providers

- **AniList** — GraphQL `https://graphql.anilist.io` (anime search/details, relations for OVA/movie/special)
- **TVmaze** — `https://api.tvmaze.com` (show + embedded episodes)
- **Jikan** — `https://api.jikan.moe/v4` (anime details + reviews)

All direct provider APIs with 8s timeouts; failures are tolerated. No YouTube/Dailymotion
embeds, no scraping of protected sources — watch providers are manual links only.

## Manual-override model

- Fetched data → `titles.meta_json`; user edits → `titles.manual_json` (merged with manual winning).
- Episode-level manual name/still overrides live in `manual_json.episodes = { <episodeId>: { name, still } }`.
- `POST /titles/:id/refresh` and `POST /api/metadata/apply` never overwrite `manual_json`
  or episode names/stills recorded there.
