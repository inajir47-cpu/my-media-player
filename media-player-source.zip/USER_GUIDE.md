# My Media Player — User Guide

A personal, self-hosted media library. It organizes the movies, shows, and music
stored on your own computer, fetches posters, ratings, reviews, and episode lists
from public internet databases, and plays everything back in a cinema-style
interface — with no accounts, no subscriptions, and no uploads. Your files never
leave your machine.

---

## 1. How it works (the big picture)

```
  Your video/music files          Public databases            Your browser
  (stay on your computer)         (AniList, TVmaze, Jikan)
         │                                │
         │  1. App scans folders,         │  2. App looks up each title
         │     groups episodes            │     and downloads posters,
         ▼                                ▼     ratings, reviews, episodes
┌─────────────────────┐        ┌──────────────────────┐
│  Node.js server     │◄──────►│  SQLite database     │
│  (backend/)         │        │  (one file on disk)  │
│  - scans & serves   │        │  - library, metadata │
│    your files       │        │  - watch history     │
│  - fetches metadata │        │  - your edits        │
└────────┬────────────┘        └──────────────────────┘
         │  3. Serves the web app + streams video
         ▼
┌─────────────────────┐
│  React web app      │
│  (frontend/)        │
│  Home, Shows, Movies, Music, Player… │
└─────────────────────┘
```

- **Backend** (`backend/`): a Node.js + Express server. It scans your media
  folders, figures out which files belong to which show/season/episode from
  their filenames, asks public databases for artwork and details, stores
  everything in a local SQLite database, and streams video to the player.
- **Frontend** (`frontend/`): a React web app (built with Vite) that talks to
  the backend over a local REST API. In production the backend serves the
  built frontend itself, so you only run one thing.
- **Database**: a single SQLite file (`backend/data/mediaplayer.db`). It holds
  your library, cached metadata, watch history, playback positions, your manual
  edits, reviews, and collections. One file = easy backup.

---

## 2. Install and run

You need **Node.js 18 or newer** installed.

```bash
cd my-media-player-code/backend
npm install

cd ../frontend
npm install
npm run build        # builds the web app into frontend/dist/
```

### Run it (production)

```bash
cd ../backend
npm run build        # compile TypeScript -> dist/
npm start            # serves API + web app on http://localhost:4000
```

Open **http://localhost:4000** in your browser. The backend automatically
serves the built frontend, so one command runs everything.

| Command (backend/) | What it does                              |
|--------------------|-------------------------------------------|
| `npm run dev`      | Development server with auto-reload (tsx) |
| `npm run build`    | Compile TypeScript to `dist/`             |
| `npm start`        | Run the compiled production server        |
| `npm run typecheck`| Type-check without emitting (`tsc`)       |
| `npm test`         | Run unit tests (filename parser, scan)    |

| Command (frontend/) | What it does                              |
|---------------------|-------------------------------------------|
| `npm run dev`       | Dev server on :5173 (proxies API to :4000)|
| `npm run build`     | Production build into `dist/`             |
| `npm run typecheck` | Type-check without emitting               |

Environment variables (optional): `PORT` (default 4000), `DB_PATH` (default
`./data/mediaplayer.db`).

---

## 3. Adding your media

1. Open **Library** (gear icon) → add one or more media folders → **Scan**.
2. The scanner reads filenames and groups them automatically:
   - `Show Name S01E02 …`, `Show - 1x02`, anime `Show - 001` → series,
     seasons, episodes
   - `Movie Name (2020).mp4` → movie
   - `Artist - Album/01 - Track.mp3` → music album with tracks
   - `.srt` / `.vtt` files sitting next to a video are picked up as subtitles.
3. Scanning is idempotent — re-scanning never creates duplicates.

Your files are only **read**. Nothing is renamed, moved, or uploaded.

---

## 4. How metadata fetching works

When a title is added it has just a name from the filename. To get posters,
synopsis, ratings, reviews, season/episode names and artwork:

1. Open the title → **Edit details** → **Find metadata**.
2. Search, pick the correct result (AniList, TVmaze, or Jikan), and **Apply**.
3. The server downloads everything and caches it in the database.

Sources used (all free, no API keys needed):

- **AniList** (GraphQL) — anime posters, descriptions, ratings, relations
  (sequels, OVAs, specials).
- **TVmaze** (REST) — show/season/episode lists, episode names and stills.
- **Jikan** (MyAnimeList REST) — community reviews.

**Your edits always win.** Anything you change manually — title, description,
genre, year, rating, poster/backdrop artwork, episode names or stills, your own
reviews — is stored separately and is **never overwritten** by a later
metadata refresh. Refresh only fills in blanks.

---

## 5. How the database is organized

One SQLite file: `backend/data/mediaplayer.db`. Tables:

| Table             | Holds                                                        |
|-------------------|--------------------------------------------------------------|
| `titles`          | Movies / series / music; fetched metadata (`meta_json`) kept separate from your edits (`manual_json`) |
| `episodes`        | Episodes, tracks, movies, OVAs, specials (with `item_kind`)  |
| `collections`     | Your named collections (e.g. "Ghibli", "Watchlist")          |
| `collection_items`| Which titles are in which collection                         |
| `watch_history`   | What you watched, playback position, completion               |
| `reviews`         | Your reviews plus cached community reviews                   |
| `watch_providers` | Manually entered "where to watch" links per title            |
| `config`          | Settings such as your media folder paths                     |

Uploaded artwork lives in `backend/data/artwork/`.

---

## 6. How previews work

There are no online trailers in this app (by design). Instead:

- **Home hero**: plays a muted **12-second clip from a random episode of your
  own files**, rotating to a different episode about every 12 seconds.
- **Episode hover**: hovering an episode card plays a 12-second clip from that
  exact episode.
- Clips start at a random point that avoids the first ~90 seconds and the
  ending-credit region. The chosen start time is remembered per episode so it
  is consistent.
- Previews only work for files the app can reach; with nothing added yet, the
  hero shows an empty state instead.

---

## 7. Player features

- Orange timeline with buffered display, elapsed / total time
- Play/pause, previous/next episode, playlist drawer
- ±10 second skip buttons, playback speed, shuffle, repeat (off/one/all)
- Volume + mute, brightness control, picture-in-picture, fullscreen
- Subtitle selector (SRT/VTT, incl. external files next to the video)
- Sleep timer
- **Touch gestures**: horizontal swipe = seek · left-side vertical swipe =
  brightness · right-side vertical swipe = volume · double-tap edges = ±10s ·
  single tap = show/hide controls
- **Keyboard**: space = play/pause · ←/→ = ±10s · ↑/↓ = volume · F =
  fullscreen · M = mute · N/P = next/previous episode
- Playback position is saved automatically; **Continue Watching** on Home
  resumes where you left off.

---

## 8. Backing up your data

Copy two things and you have everything:

1. `backend/data/mediaplayer.db` — library, metadata cache, history,
   reviews, collections, edits.
2. `backend/data/artwork/` — uploaded posters/backdrops/stills.

Your actual video/music files are untouched and live wherever you keep them —
back those up however you normally do. To restore, put the database file and
artwork folder back and start the server. (If file paths changed, re-scan and
use metadata refresh to re-link.)

You can also export any title's metadata to JSON from its Edit dialog, and
re-import it later.

---

## 9. Honest limits

- **Internet is needed the first time** a title's metadata is looked up. After
  that everything is cached and works fully offline.
- **Matching depends on filenames.** Clean names (`Show S01E02`) match
  automatically; messy ones may need you to pick the right result manually.
- **Music metadata** comes from your files (filenames/folders); there is no
  dedicated music database lookup.
- **No automatic streaming sources.** "Where to watch" links are entered
  manually per title. The app never fetches episodes from protected online
  sources.
- **Single user, no login.** Anyone who can reach the server address can use
  it — keep it on your local network / computer.
- **Previews and playback need your files present.** Network drives that go
  offline will show empty states until reconnected.
