import { describe, expect, it } from 'vitest';
import { hash01, previewCoordinator, selectPreviewClip } from './engine';

const TWELVE_S = 12_000;

describe('hash01', () => {
  it('is deterministic and bounded', () => {
    expect(hash01('preview:abc')).toBe(hash01('preview:abc'));
    expect(hash01('preview:abc')).toBeGreaterThanOrEqual(0);
    expect(hash01('preview:abc')).toBeLessThan(1);
    expect(hash01('preview:abc')).not.toBe(hash01('preview:abd'));
  });
});

describe('selectPreviewClip', () => {
  it('picks a deterministic 12 s clip inside the 25–75% window', () => {
    const duration = 3_600_000;
    const a = selectPreviewClip(duration, TWELVE_S, 'item-1');
    const b = selectPreviewClip(duration, TWELVE_S, 'item-1');
    expect(a).toEqual(b);
    expect(a.lengthMs).toBe(TWELVE_S);
    expect(a.startMs).toBeGreaterThanOrEqual(duration * 0.1);
    expect(a.startMs + a.lengthMs).toBeLessThanOrEqual(duration * 0.9);
    expect(a.startMs).toBeGreaterThanOrEqual(duration * 0.25 - 1);
    // Different files get (almost surely) different clips.
    expect(selectPreviewClip(duration, TWELVE_S, 'item-2').startMs).not.toBe(a.startMs);
  });

  it('never uses the first or last 10% for long files', () => {
    for (const seed of ['a', 'b', 'c', 'd', 'e']) {
      const clip = selectPreviewClip(600_000, TWELVE_S, seed);
      expect(clip.startMs).toBeGreaterThanOrEqual(60_000 * 0.999);
      expect(clip.startMs + clip.lengthMs).toBeLessThanOrEqual(600_000 - 60_000 + 1);
    }
  });

  it('adapts to short files: middle of the file, never longer than it', () => {
    const clip = selectPreviewClip(10_000, TWELVE_S, 'short');
    expect(clip.lengthMs).toBeLessThanOrEqual(10_000);
    expect(clip.lengthMs).toBeGreaterThan(0);
    expect(clip.startMs).toBeGreaterThanOrEqual(0);
    expect(clip.startMs + clip.lengthMs).toBeLessThanOrEqual(10_000);
  });

  it('returns an empty clip for invalid durations', () => {
    expect(selectPreviewClip(0, TWELVE_S, 'x')).toEqual({ startMs: 0, lengthMs: 0 });
    expect(selectPreviewClip(-5, TWELVE_S, 'x')).toEqual({ startMs: 0, lengthMs: 0 });
    expect(selectPreviewClip(Number.NaN, TWELVE_S, 'x')).toEqual({ startMs: 0, lengthMs: 0 });
  });

  it('honors a manual start offset, clamped to the file', () => {
    const clip = selectPreviewClip(600_000, TWELVE_S, 'x', 120_000);
    expect(clip.startMs).toBe(120_000);
    const clamped = selectPreviewClip(600_000, TWELVE_S, 'x', 999_999_999);
    expect(clamped.startMs + clamped.lengthMs).toBeLessThanOrEqual(600_000);
  });
});

describe('previewCoordinator', () => {
  it('keeps a single active preview and pauses the previous holder', () => {
    const paused: string[] = [];
    const releaseA = previewCoordinator.acquire('a', () => {
      paused.push('a');
    });
    expect(previewCoordinator.activeId()).toBe('a');
    const releaseB = previewCoordinator.acquire('b', () => {
      paused.push('b');
    });
    expect(paused).toEqual(['a']);
    expect(previewCoordinator.activeId()).toBe('b');
    releaseA();
    expect(previewCoordinator.activeId()).toBe('b');
    releaseB();
    expect(previewCoordinator.activeId()).toBeNull();
  });

  it('pauseAll clears the slot', () => {
    let paused = false;
    previewCoordinator.acquire('z', () => {
      paused = true;
    });
    previewCoordinator.pauseAll();
    expect(paused).toBe(true);
    expect(previewCoordinator.activeId()).toBeNull();
  });

  it('suspending pauses everything (background / battery saver)', () => {
    let paused = false;
    previewCoordinator.acquire('s', () => {
      paused = true;
    });
    previewCoordinator.setSuspended(true);
    expect(paused).toBe(true);
    expect(previewCoordinator.isSuspended()).toBe(true);
    previewCoordinator.setSuspended(false);
    expect(previewCoordinator.isSuspended()).toBe(false);
  });
});
