// ---------------------------------------------------------------------------
// PreviewVideo: a muted, looping local clip that participates in the single-
// instance preview coordinator. Pauses when it leaves the viewport, when the
// app is backgrounded, or when previews are suspended.
// ---------------------------------------------------------------------------

import { useEffect, useRef, useState } from 'react';
import type { MediaItem } from '../storage/types';
import { previewCoordinator, ensurePreviewClip } from './engine';
import { resolvePlayableUrl } from '../library/playable';
import { getSettings } from '../settings/store';
import { logger } from '../shared/logger';

interface Props {
  item: MediaItem;
  /** Unique slot id, e.g. `hero`, `card-<id>`. */
  slotId: string;
  className?: string;
  /** Start playing immediately when mounted and visible. */
  autoplay?: boolean;
  onReady?: (durationMs: number) => void;
}

export function PreviewVideo({ item, slotId, className, autoplay = true, onReady }: Props): React.ReactNode {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [src, setSrc] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);
  const releaseRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    if (item.previewDisabled) {
      setFailed(true);
      return;
    }
    let cancelled = false;
    void (async () => {
      const url = await resolvePlayableUrl(item);
      if (cancelled) return;
      if (!url) {
        setFailed(true);
        return;
      }
      setSrc(url);
    })();
    return () => {
      cancelled = true;
    };
  }, [item]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video || !src) return;
    let release: (() => void) | null = null;
    let observer: IntersectionObserver | null = null;

    const pause = (): void => {
      video.pause();
    };

    const tryPlay = async (): Promise<void> => {
      if (previewCoordinator.isSuspended()) return;
      const settings = getSettings();
      if (!settings.previewEnabled || settings.reduceMotion) return;
      try {
        const durationMs = (video.duration || 0) * 1000;
        if (durationMs > 0) {
          const clip = await ensurePreviewClip(item, durationMs, settings.previewLengthSec * 1000);
          if (clip.lengthMs > 0) {
            try {
              video.currentTime = clip.startMs / 1000;
            } catch {
              /* some sources reject early seeks */
            }
            const stopAt = (clip.startMs + clip.lengthMs) / 1000;
            const onTime = (): void => {
              if (video.currentTime >= stopAt) {
                try {
                  video.currentTime = clip.startMs / 1000;
                } catch {
                  /* noop */
                }
              }
            };
            video.addEventListener('timeupdate', onTime);
            // Remove the looping helper when the slot is released.
            const prevRelease = release;
            release = () => {
              video.removeEventListener('timeupdate', onTime);
              prevRelease?.();
            };
          }
          onReady?.(durationMs);
        }
        release = previewCoordinator.acquire(slotId, pause);
        releaseRef.current = release;
        video.muted = true;
        await video.play().catch(() => {
          // Autoplay policies or missing decoders: fall back to poster.
          setFailed(true);
        });
      } catch {
        logger.debug('preview', 'preview play failed', { id: item.id });
        setFailed(true);
      }
    };

    if (autoplay && 'IntersectionObserver' in window) {
      observer = new IntersectionObserver(
        (entries) => {
          const entry = entries[0];
          if (entry?.isIntersecting) void tryPlay();
          else pause();
        },
        { threshold: 0.35 },
      );
      observer.observe(video);
    } else if (autoplay) {
      void tryPlay();
    }

    const onVis = (): void => {
      if (document.hidden) pause();
    };
    document.addEventListener('visibilitychange', onVis);

    return () => {
      observer?.disconnect();
      document.removeEventListener('visibilitychange', onVis);
      release?.();
      releaseRef.current = null;
      pause();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [src]);

  if (failed || !src) return null;
  return (
    <video
      ref={videoRef}
      className={className}
      src={src}
      muted
      playsInline
      disablePictureInPicture
      aria-hidden="true"
      tabIndex={-1}
      preload="metadata"
      style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
    />
  );
}
