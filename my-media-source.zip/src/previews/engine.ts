// ---------------------------------------------------------------------------
// Preview engine: deterministic local clip selection + a single-instance
// coordinator so only ONE muted preview decoder runs at a time.
//
// Clip rules:
//  - default 12 s (configurable), never the first/last 10% of the file,
//    preferring the 25%-75% range;
//  - deterministic start per file (hash of the item id) so the clip is stable
//    across restarts until the user regenerates it;
//  - short files adapt the clip length safely;
//  - timing is stored as local metadata; no duplicate video is ever created.
// ---------------------------------------------------------------------------

import type { MediaItem } from '../storage/types';
import { repository } from '../storage/repository';
import { logger } from '../shared/logger';

export interface PreviewClip {
  startMs: number;
  lengthMs: number;
}

/** Deterministic 0..1 value from a string (stable across restarts). */
export function hash01(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) / 4294967295;
}

/**
 * Pick a preview clip for a file of `durationMs`.
 * `seed` makes the choice deterministic per file; pass a fresh random seed
 * (or a manual offset) to regenerate.
 */
export function selectPreviewClip(
  durationMs: number,
  desiredLengthMs: number,
  seed: string,
  manualStartMs?: number,
): PreviewClip {
  if (!Number.isFinite(durationMs) || durationMs <= 0) {
    return { startMs: 0, lengthMs: 0 };
  }
  const minMargin = durationMs * 0.1;
  // Short file: take the middle, never longer than the file itself.
  if (durationMs <= desiredLengthMs + 2 * minMargin) {
    const lengthMs = Math.max(1000, Math.floor(durationMs * 0.6));
    return { startMs: Math.floor((durationMs - lengthMs) / 2), lengthMs };
  }
  const lengthMs = Math.min(desiredLengthMs, Math.floor(durationMs * 0.5));
  if (manualStartMs !== undefined) {
    const startMs = Math.min(Math.max(0, Math.floor(manualStartMs)), Math.floor(durationMs - lengthMs));
    return { startMs, lengthMs };
  }
  // Prefer the 25%-75% window; deterministic offset from the seed.
  const windowStart = durationMs * 0.25;
  const windowEnd = durationMs * 0.75 - lengthMs;
  const startMs = Math.floor(windowStart + hash01(`preview:${seed}`) * Math.max(0, windowEnd - windowStart));
  return { startMs, lengthMs };
}

/** Compute (and persist) the preview clip for an item. */
export async function ensurePreviewClip(
  item: MediaItem,
  durationMs: number,
  desiredLengthMs: number,
): Promise<PreviewClip> {
  if (item.previewStartMs !== undefined && item.previewLengthMs !== undefined && item.previewLengthMs > 0) {
    return { startMs: item.previewStartMs, lengthMs: item.previewLengthMs };
  }
  const clip = selectPreviewClip(durationMs, desiredLengthMs, item.id);
  if (clip.lengthMs > 0) {
    await repository.updateItem(item.id, { previewStartMs: clip.startMs, previewLengthMs: clip.lengthMs });
  }
  return clip;
}

/** Regenerate: pick a new deterministic clip from a fresh seed. */
export async function regeneratePreviewClip(
  item: MediaItem,
  durationMs: number,
  desiredLengthMs: number,
): Promise<PreviewClip> {
  const clip = selectPreviewClip(durationMs, desiredLengthMs, `${item.id}:${Date.now()}`);
  await repository.updateItem(item.id, {
    previewStartMs: clip.startMs,
    previewLengthMs: clip.lengthMs,
    previewDisabled: false,
  });
  return clip;
}

// -- single-instance coordinator --------------------------------------------------
// Only one preview may decode at a time. Components request/release slots;
// the coordinator pauses the previous holder and notifies via callbacks.

type SlotId = string;

interface Slot {
  onPause: () => void;
}

class PreviewCoordinator {
  private active: { id: SlotId; slot: Slot } | null = null;
  private suspended = false; // app backgrounded / battery saver / reduced motion

  /** Request the single preview slot. Pauses whoever holds it. Returns release fn. */
  acquire(id: SlotId, onPause: () => void): () => void {
    if (this.active && this.active.id !== id) {
      try {
        this.active.slot.onPause();
      } catch {
        logger.warn('preview', 'previous slot pause failed');
      }
    }
    this.active = { id, slot: { onPause } };
    return () => {
      this.release(id);
    };
  }

  release(id: SlotId): void {
    if (this.active?.id === id) this.active = null;
  }

  pauseAll(): void {
    if (this.active) {
      try {
        this.active.slot.onPause();
      } catch {
        /* noop */
      }
      this.active = null;
    }
  }

  setSuspended(suspended: boolean): void {
    this.suspended = suspended;
    if (suspended) this.pauseAll();
  }

  isSuspended(): boolean {
    return this.suspended;
  }

  activeId(): SlotId | null {
    return this.active?.id ?? null;
  }
}

export const previewCoordinator = new PreviewCoordinator();
