// ---------------------------------------------------------------------------
// Local sidecar metadata: NFO (Kodi-style XML) and JSON files next to media.
// Local sidecars always win over internet metadata.
// ---------------------------------------------------------------------------

import { cleanText } from '../shared/sanitize';

export interface SidecarMetadata {
  title?: string;
  year?: number;
  synopsis?: string;
  genres: string[];
  maturity?: string;
  cast: { name: string; role: string }[];
  rating?: number; // 0..10 local scale, e.g. from NFO
  season?: number;
  episode?: number;
}

/** Parse a Kodi-style .nfo file (movie or episode). Never throws. */
export function parseNfo(xml: string): SidecarMetadata {
  const out: SidecarMetadata = { genres: [], cast: [] };
  const tag = (name: string): string | undefined => {
    const m = xml.match(new RegExp(`<${name}>([\\s\\S]*?)</${name}>`, 'i'));
    return m?.[1] ? cleanText(m[1], 4000) : undefined;
  };
  const tags = (name: string): string[] => {
    const matches = [...xml.matchAll(new RegExp(`<${name}>([\\s\\S]*?)</${name}>`, 'gi'))];
    return matches.map((m) => cleanText(m[1] ?? '', 120)).filter(Boolean);
  };

  const title = tag('title') ?? tag('showtitle');
  if (title) out.title = title;
  const year = tag('year') ?? tag('premiered')?.slice(0, 4);
  if (year && /^\d{4}$/.test(year)) out.year = parseInt(year, 10);
  const plot = tag('plot');
  if (plot) out.synopsis = plot;
  out.genres = tags('genre');
  const mpaa = tag('mpaa');
  if (mpaa) out.maturity = mpaa;

  const actorBlocks = [...xml.matchAll(/<actor>([\s\S]*?)<\/actor>/gi)];
  for (const block of actorBlocks) {
    const name = /<name>([\s\S]*?)<\/name>/i.exec(block[1] ?? '')?.[1];
    const role = /<role>([\s\S]*?)<\/role>/i.exec(block[1] ?? '')?.[1];
    if (name) out.cast.push({ name: cleanText(name, 120), role: role ? cleanText(role, 120) : 'Actor' });
  }
  const rating = tag('rating');
  if (rating && !Number.isNaN(parseFloat(rating))) out.rating = parseFloat(rating);
  const season = tag('season');
  if (season && /^\d+$/.test(season)) out.season = parseInt(season, 10);
  const episode = tag('episode');
  if (episode && /^\d+$/.test(episode)) out.episode = parseInt(episode, 10);
  return out;
}

/** Parse a .json sidecar with the same shape (field names are case-insensitive). */
export function parseJsonSidecar(json: string): SidecarMetadata {
  const out: SidecarMetadata = { genres: [], cast: [] };
  let data: Record<string, unknown>;
  try {
    data = JSON.parse(json) as Record<string, unknown>;
  } catch {
    return out;
  }
  const lower: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(data)) lower[k.toLowerCase()] = v;
  const str = (v: unknown, max = 4000): string | undefined =>
    typeof v === 'string' && v.trim() ? cleanText(v, max) : undefined;

  const title = str(lower['title']);
  if (title) out.title = title;
  const year = lower['year'];
  if (typeof year === 'number' && year >= 1900 && year <= 2100) out.year = year;
  const synopsis = str(lower['plot'] ?? lower['synopsis'] ?? lower['overview']);
  if (synopsis) out.synopsis = synopsis;
  const genres = lower['genres'] ?? lower['genre'];
  if (Array.isArray(genres))
    out.genres = genres.filter((g): g is string => typeof g === 'string').map((g) => cleanText(g, 60));
  const maturity = str(lower['mpaa'] ?? lower['maturity'] ?? lower['certification'], 40);
  if (maturity) out.maturity = maturity;
  const cast = lower['cast'] ?? lower['actors'];
  if (Array.isArray(cast)) {
    for (const c of cast) {
      if (typeof c === 'string') out.cast.push({ name: cleanText(c, 120), role: 'Actor' });
      else if (c && typeof c === 'object') {
        const rec = c as Record<string, unknown>;
        const name = str(rec['name'], 120);
        if (name) out.cast.push({ name, role: str(rec['role'] ?? rec['character'], 120) ?? 'Actor' });
      }
    }
  }
  const rating = lower['rating'];
  if (typeof rating === 'number') out.rating = rating;
  return out;
}

/** Merge sidecar metadata into an item patch (manual edits win: only fill blanks). */
export function applySidecar(
  current: { title: string; year?: number; synopsis?: string; genres: string[]; maturity?: string },
  sidecar: SidecarMetadata,
): { title?: string; year?: number; synopsis?: string; genres?: string[]; maturity?: string } {
  const patch: { title?: string; year?: number; synopsis?: string; genres?: string[]; maturity?: string } =
    {};
  if (sidecar.title && current.title !== sidecar.title) patch.title = sidecar.title;
  if (sidecar.year && !current.year) patch.year = sidecar.year;
  if (sidecar.synopsis && !current.synopsis) patch.synopsis = sidecar.synopsis;
  if (sidecar.genres.length > 0 && current.genres.length === 0) patch.genres = sidecar.genres;
  if (sidecar.maturity && !current.maturity) patch.maturity = sidecar.maturity;
  return patch;
}
