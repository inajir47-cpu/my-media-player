// ---------------------------------------------------------------------------
// Metadata match review: before bulk internet-metadata changes are applied,
// the user reviews candidates with a confidence score and can undo the whole
// batch afterwards. Nothing from a provider is ever applied silently.
// ---------------------------------------------------------------------------

import type { MediaItem, ShowGroup } from '../storage/types';
import type { MetadataCandidate } from './providers';
import { sortKey } from '../library/parser';
import { repository } from '../storage/repository';

export interface MatchProposal {
  itemId: string;
  currentTitle: string;
  currentYear?: number;
  candidate: MetadataCandidate;
  /** Fields that would change, for the review screen. */
  changes: string[];
}

/** Token-overlap similarity between two titles (0..1). */
export function titleSimilarity(a: string, b: string): number {
  const ta = new Set(sortKey(a).split(' ').filter(Boolean));
  const tb = new Set(sortKey(b).split(' ').filter(Boolean));
  if (ta.size === 0 || tb.size === 0) return 0;
  let overlap = 0;
  for (const t of ta) if (tb.has(t)) overlap += 1;
  return (2 * overlap) / (ta.size + tb.size);
}

/** Confidence that a provider candidate matches the local item. */
export function matchConfidence(
  item: { title: string; year?: number },
  candidate: MetadataCandidate,
): number {
  const titleScore = titleSimilarity(item.title, candidate.title);
  let yearScore = 0.5; // unknown year neither helps nor hurts much
  if (item.year && candidate.year) {
    yearScore =
      item.year === candidate.year
        ? 1
        : item.year === candidate.year + 1 || item.year === candidate.year - 1
          ? 0.6
          : 0.1;
  }
  return Math.round((titleScore * 0.7 + yearScore * 0.3 + candidate.confidence * 0.2) * 100) / 100;
}

/** Build review proposals for a batch of items and their chosen candidates. */
export function buildProposals(items: MediaItem[], picks: Map<string, MetadataCandidate>): MatchProposal[] {
  const proposals: MatchProposal[] = [];
  for (const item of items) {
    const candidate = picks.get(item.id);
    if (!candidate) continue;
    const changes: string[] = [];
    if (candidate.title && candidate.title !== item.title) changes.push('title');
    if (candidate.year && candidate.year !== item.year) changes.push('year');
    if (candidate.synopsis && candidate.synopsis !== item.synopsis) changes.push('synopsis');
    if (candidate.genres.length > 0) changes.push('genres');
    if (candidate.cast.length > 0) changes.push('cast');
    proposals.push({
      itemId: item.id,
      currentTitle: item.title,
      currentYear: item.year,
      candidate: { ...candidate, confidence: matchConfidence(item, candidate) },
      changes,
    });
  }
  return proposals.sort((a, b) => a.candidate.confidence - b.candidate.confidence);
}

/** Snapshot of fields a bulk edit touches, so the whole batch can be undone. */
export interface MetadataUndoFrame {
  at: number;
  entries: { itemId: string; before: Partial<MediaItem> }[];
  showEntries: { showId: string; before: Partial<ShowGroup> }[];
}

const UNDO_FIELDS = [
  'title',
  'sortTitle',
  'year',
  'synopsis',
  'genres',
  'cast',
  'maturity',
  'providerName',
  'providerId',
  'matchSource',
  'matchConfidence',
  'poster',
  'backdrop',
] as const;

function snapshot<T extends object>(obj: T): Partial<T> {
  const out: Partial<T> = {};
  for (const key of UNDO_FIELDS) {
    const v: unknown = (obj as Record<string, unknown>)[key];
    let copy: unknown = v;
    if (Array.isArray(v)) copy = [...(v as unknown[])];
    else if (v !== null && typeof v === 'object') copy = { ...(v as Record<string, unknown>) };
    (out as Record<string, unknown>)[key] = copy;
  }
  return out;
}

export function captureUndoFrame(items: MediaItem[], shows: ShowGroup[] = []): MetadataUndoFrame {
  return {
    at: Date.now(),
    entries: items.map((it) => ({ itemId: it.id, before: snapshot(it) })),
    showEntries: shows.map((s) => ({ showId: s.id, before: snapshot(s) })),
  };
}

const undoStack: MetadataUndoFrame[] = [];
const MAX_UNDO = 10;

export function pushUndoFrame(frame: MetadataUndoFrame): void {
  undoStack.push(frame);
  if (undoStack.length > MAX_UNDO) undoStack.shift();
}

export function popUndoFrame(): MetadataUndoFrame | undefined {
  return undoStack.pop();
}

export function undoDepth(): number {
  return undoStack.length;
}

/** True when at least one undo frame is available. */
export function hasUndo(): boolean {
  return undoStack.length > 0;
}

/** Restore the most recent frame's before-snapshots. */
export async function undoLastFrame(): Promise<boolean> {
  const frame = popUndoFrame();
  if (!frame) return false;
  for (const e of frame.entries) {
    await repository.updateItem(e.itemId, e.before);
  }
  for (const e of frame.showEntries) {
    const current = await repository.getShow(e.showId);
    if (current) {
      await repository.upsertShow({ ...current, ...e.before, updatedAt: Date.now() });
    }
  }
  return true;
}
