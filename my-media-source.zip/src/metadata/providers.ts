// ---------------------------------------------------------------------------
// Metadata provider adapter interface. Internet metadata is OPTIONAL and never
// required for playback. Providers are configured by the user with their own
// API key (Settings > Metadata); keys are stored in secure storage and never
// leave the device except in the provider's own search request, which carries
// only the minimum title/year query.
// ---------------------------------------------------------------------------

import { secureStorage } from '../storage/adapters';
import { cleanText } from '../shared/sanitize';

export interface MetadataCandidate {
  providerId: string;
  title: string;
  year?: number;
  synopsis?: string;
  genres: string[];
  cast: string[];
  posterUrl?: string;
  backdropUrl?: string;
  publicRating?: { value: number; scale: number; votes?: number };
  confidence: number; // 0..1 — shown on the match-review screen
}

export interface MetadataProvider {
  readonly id: string;
  readonly displayName: string;
  /** True when the user configured a key for this provider. */
  isConfigured(): Promise<boolean>;
  /** Store the user's own API key (secure storage on Android). */
  setApiKey(key: string): Promise<void>;
  clearApiKey(): Promise<void>;
  search(title: string, year?: number): Promise<MetadataCandidate[]>;
  details(providerId: string): Promise<MetadataCandidate | null>;
  publicReviews(
    providerId: string,
  ): Promise<{ author: string; body: string; stars?: number; url?: string }[]>;
}

/** Base class handling key storage; providers implement the HTTP calls. */
export abstract class BaseProvider implements MetadataProvider {
  abstract readonly id: string;
  abstract readonly displayName: string;

  protected keyName(): string {
    return `metadata.${this.id}.key`;
  }

  async isConfigured(): Promise<boolean> {
    return (await secureStorage.get(this.keyName())) != null;
  }

  async setApiKey(key: string): Promise<void> {
    const trimmed = key.trim();
    if (!trimmed) throw new Error('API key is empty.');
    await secureStorage.set(this.keyName(), trimmed);
  }

  async clearApiKey(): Promise<void> {
    await secureStorage.remove(this.keyName());
  }

  protected async apiKey(): Promise<string | null> {
    return secureStorage.get(this.keyName());
  }

  abstract search(title: string, year?: number): Promise<MetadataCandidate[]>;
  abstract details(providerId: string): Promise<MetadataCandidate | null>;
  abstract publicReviews(
    providerId: string,
  ): Promise<{ author: string; body: string; stars?: number; url?: string }[]>;
}

/**
 * Example TMDB-shaped provider. The user pastes their own TMDB API key in
 * Settings; without it the provider reports unconfigured and the app falls
 * back to local metadata + manual editing.
 */
export class TmdbProvider extends BaseProvider {
  readonly id = 'tmdb';
  readonly displayName = 'TMDB';

  private async call<T>(path: string, params: Record<string, string>): Promise<T> {
    const key = await this.apiKey();
    if (!key) throw new Error('TMDB API key is not configured.');
    const url = new URL(`https://api.themoviedb.org/3${path}`);
    url.searchParams.set('api_key', key);
    for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
    const res = await fetch(url.toString());
    if (!res.ok) throw new Error(`TMDB request failed (${res.status}).`);
    return (await res.json()) as T;
  }

  async search(title: string, year?: number): Promise<MetadataCandidate[]> {
    const data = await this.call<{ results: Record<string, unknown>[] }>('/search/multi', {
      query: title,
      ...(year ? { year: String(year) } : {}),
    });
    return data.results.slice(0, 8).map((r, i) => toCandidate(r, i));
  }

  async details(providerId: string): Promise<MetadataCandidate | null> {
    const [mediaType, id] = providerId.split(':');
    if (!mediaType || !id) return null;
    const data = await this.call<Record<string, unknown>>(`/${mediaType}/${id}`, {});
    return toCandidate({ ...data, media_type: mediaType }, 0);
  }

  async publicReviews(
    providerId: string,
  ): Promise<{ author: string; body: string; stars?: number; url?: string }[]> {
    const [mediaType, id] = providerId.split(':');
    if (!mediaType || !id) return [];
    const data = await this.call<{ results: Record<string, unknown>[] }>(`/${mediaType}/${id}/reviews`, {});
    return data.results.map((r) => ({
      author: cleanText(str(r['author']) || 'Unknown', 80),
      body: cleanText(str(r['content']), 2000),
      stars:
        typeof r['author_details'] === 'object' && r['author_details'] !== null
          ? ratingToStars((r['author_details'] as Record<string, unknown>)['rating'])
          : undefined,
      url: typeof r['url'] === 'string' ? r['url'] : undefined,
    }));
  }
}

function ratingToStars(rating: unknown): number | undefined {
  if (typeof rating !== 'number' || rating <= 0) return undefined;
  return Math.round((rating / 2) * 2) / 2; // TMDB 0..10 -> 0..5 stars
}

/** Safely stringify a JSON value (objects/arrays become ''). */
function str(v: unknown): string {
  if (typeof v === 'string') return v;
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  return '';
}

function toCandidate(r: Record<string, unknown>, index: number): MetadataCandidate {
  const mediaType = r['media_type'] === 'tv' ? 'tv' : 'movie';
  const title = str(r['title']) || str(r['name']) || 'Unknown';
  const dateStr = str(r['release_date']) || str(r['first_air_date']);
  const year = /^\d{4}/.test(dateStr) ? parseInt(dateStr.slice(0, 4), 10) : undefined;
  const vote = typeof r['vote_average'] === 'number' ? r['vote_average'] : undefined;
  return {
    providerId: `${mediaType}:${str(r['id'])}`,
    title: cleanText(title, 200),
    year,
    synopsis: r['overview'] ? cleanText(str(r['overview']), 2000) : undefined,
    genres: [],
    cast: [],
    posterUrl: r['poster_path'] ? `https://image.tmdb.org/t/p/w500${str(r['poster_path'])}` : undefined,
    backdropUrl: r['backdrop_path']
      ? `https://image.tmdb.org/t/p/w1280${str(r['backdrop_path'])}`
      : undefined,
    publicRating: vote
      ? { value: vote, scale: 10, votes: typeof r['vote_count'] === 'number' ? r['vote_count'] : undefined }
      : undefined,
    confidence: Math.max(0.2, 0.95 - index * 0.08),
  };
}

/** Registry of available providers. Add new ones here. */
export const metadataProviders: MetadataProvider[] = [new TmdbProvider()];

export function getProvider(id: string | undefined): MetadataProvider | undefined {
  return metadataProviders.find((p) => p.id === id);
}
