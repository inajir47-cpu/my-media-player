import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './app/App';
import './app/theme.css';

const el = document.getElementById('root');
if (!el) throw new Error('Missing #root element');
createRoot(el).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
