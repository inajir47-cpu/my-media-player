// ---------------------------------------------------------------------------
// Manual metadata correction sheet: title, type, year, season, episode,
// synopsis, genres, rating, artwork, sort title. Changes are undoable via the
// matcher's undo stack.
// ---------------------------------------------------------------------------

import { useState, type ReactNode } from 'react';
import type { MediaItem } from '../storage/types';
import { repository } from '../storage/repository';
import { BottomSheet, Button, Field, Stars } from '../shared/ui';
import { t } from '../shared/i18n';
import { sortKey, showGroupKey, stableId } from '../library/parser';
import { captureUndoFrame, pushUndoFrame } from '../metadata/matcher';
import { cleanText } from '../shared/sanitize';

export function EditMetadataSheet({
  item,
  onClose,
  onSaved,
}: {
  item: MediaItem;
  onClose: () => void;
  onSaved: (i: MediaItem) => void;
}): ReactNode {
  const [title, setTitle] = useState(item.title);
  const [sortTitleInput, setSortTitleInput] = useState(item.sortTitle);
  const [year, setYear] = useState(item.year ? String(item.year) : '');
  const [season, setSeason] = useState(item.season !== undefined ? String(item.season) : '');
  const [episode, setEpisode] = useState(item.episode !== undefined ? String(item.episode) : '');
  const [synopsis, setSynopsis] = useState(item.synopsis ?? '');
  const [genres, setGenres] = useState(item.genres.join(', '));
  const [maturity, setMaturity] = useState(item.maturity ?? '');
  const [stars, setStars] = useState(item.localRating?.stars ?? 0);
  const [kind, setKind] = useState(item.kind);
  const [error, setError] = useState('');

  const save = async (): Promise<void> => {
    const trimmed = title.trim();
    if (!trimmed) {
      setError('Title cannot be empty.');
      return;
    }
    pushUndoFrame(captureUndoFrame([item]));
    const patch: Partial<MediaItem> = {
      title: cleanText(trimmed, 200),
      sortTitle: sortTitleInput.trim() ? cleanText(sortTitleInput, 200) : sortKey(trimmed),
      kind,
      synopsis: cleanText(synopsis, 4000) || undefined,
      genres: genres
        .split(',')
        .map((g) => cleanText(g, 60))
        .filter(Boolean),
      maturity: cleanText(maturity, 40) || undefined,
      localRating: stars > 0 ? { stars, updatedAt: Date.now() } : undefined,
    };
    const y = parseInt(year, 10);
    if (year.trim() && (Number.isNaN(y) || y < 1900 || y > 2100)) {
      setError('Year must be between 1900 and 2100.');
      return;
    }
    patch.year = year.trim() ? y : undefined;
    const s = parseInt(season, 10);
    patch.season = season.trim() && !Number.isNaN(s) ? s : undefined;
    const e = parseInt(episode, 10);
    patch.episode = episode.trim() && !Number.isNaN(e) ? e : undefined;
    if (patch.kind === 'episode' && patch.season !== undefined) {
      patch.groupId = stableId(`show:${showGroupKey(patch.title ?? item.title, patch.year)}`);
    }
    patch.matchSource = 'manual';
    await repository.updateItem(item.id, patch);
    const updated = (await repository.getItem(item.id)) ?? { ...item, ...patch };
    onSaved(updated);
  };

  return (
    <BottomSheet title={t('detail.editMetadata')} onClose={onClose}>
      {error && (
        <p role="alert" style={{ color: 'var(--danger)' }}>
          {error}
        </p>
      )}
      <Field label="Title">
        <input
          className="mm-input"
          value={title}
          onChange={(e) => {
            setTitle(e.target.value);
          }}
          aria-label="Title"
        />
      </Field>
      <Field label="Sort title">
        <input
          className="mm-input"
          value={sortTitleInput}
          onChange={(e) => {
            setSortTitleInput(e.target.value);
          }}
          aria-label="Sort title"
        />
      </Field>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
        <Field label="Year">
          <input
            className="mm-input"
            inputMode="numeric"
            value={year}
            onChange={(e) => {
              setYear(e.target.value);
            }}
            aria-label="Year"
          />
        </Field>
        <Field label="Season">
          <input
            className="mm-input"
            inputMode="numeric"
            value={season}
            onChange={(e) => {
              setSeason(e.target.value);
            }}
            aria-label="Season"
          />
        </Field>
        <Field label="Episode">
          <input
            className="mm-input"
            inputMode="numeric"
            value={episode}
            onChange={(e) => {
              setEpisode(e.target.value);
            }}
            aria-label="Episode"
          />
        </Field>
      </div>
      <Field label="Type">
        <select
          className="mm-select"
          value={kind}
          onChange={(e) => {
            setKind(e.target.value as MediaItem['kind']);
          }}
          aria-label="Type"
        >
          <option value="movie">Movie</option>
          <option value="episode">Episode</option>
          <option value="audio">Audio</option>
        </select>
      </Field>
      <Field label="Synopsis">
        <textarea
          className="mm-textarea"
          value={synopsis}
          onChange={(e) => {
            setSynopsis(e.target.value);
          }}
          aria-label="Synopsis"
        />
      </Field>
      <Field label="Genres (comma separated)">
        <input
          className="mm-input"
          value={genres}
          onChange={(e) => {
            setGenres(e.target.value);
          }}
          aria-label="Genres"
        />
      </Field>
      <Field label="Maturity label">
        <input
          className="mm-input"
          value={maturity}
          onChange={(e) => {
            setMaturity(e.target.value);
          }}
          aria-label="Maturity label"
        />
      </Field>
      <Field label="My rating">
        <Stars value={stars} onChange={setStars} label="My rating" />
      </Field>
      <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end', marginTop: 8 }}>
        <Button label={t('common.cancel')} onClick={onClose}>
          {t('common.cancel')}
        </Button>
        <Button variant="primary" label={t('common.save')} onClick={() => void save()}>
          {t('common.save')}
        </Button>
      </div>
    </BottomSheet>
  );
}
