// ---------------------------------------------------------------------------
// Show detail page: seasons, episode rows with correct-episode local previews,
// watched progress, review at the END (always the last section).
// Selected season and scroll position survive navigation via sessionStorage.
// ---------------------------------------------------------------------------

import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { repository } from '../storage/repository';
import type { MediaItem, ShowGroup } from '../storage/types';
import { PreviewVideo } from '../previews/PreviewVideo';
import { ReviewsSection } from './ReviewsSection';
import { Button, EmptyState, ErrorState, IconButton, Segmented } from '../shared/ui';
import { previewsAllowed, useSettings } from '../settings/store';
import { formatDuration } from '../shared/format';
import { t } from '../shared/i18n';
import { AddToCollectionSheet } from '../collections/AddToCollectionSheet';

interface EpisodeRowProps {
  ep: MediaItem;
  onChanged: (i: MediaItem) => void;
}

function EpisodeRow({ ep, onChanged }: EpisodeRowProps): ReactNode {
  const navigate = useNavigate();
  const settings = useSettings();
  const [preview, setPreview] = useState(false);
  const [longPress, setLongPress] = useState(false);
  const holdTimer = useRef<number | null>(null);
  const dur = ep.durationMs ?? 0;
  const frac = dur > 0 ? ep.progressMs / dur : 0;

  const startHold = (): void => {
    holdTimer.current = window.setTimeout(() => {
      setLongPress(true);
    }, 500);
  };
  const endHold = (): void => {
    if (holdTimer.current) window.clearTimeout(holdTimer.current);
    if (!longPress) void navigate(`/play/${ep.id}`);
    setLongPress(false);
  };

  const toggleWatched = async (e: React.MouseEvent): Promise<void> => {
    e.stopPropagation();
    await repository.updateItem(ep.id, {
      watched: !ep.watched,
      watchedAt: !ep.watched ? Date.now() : undefined,
    });
    onChanged({ ...ep, watched: !ep.watched });
  };

  return (
    <div
      className="mm-ep-row"
      onClick={() => navigate(`/play/${ep.id}`)}
      onMouseEnter={() => {
        if (settings.cardPreviewMode === 'hover' && previewsAllowed(settings)) setPreview(true);
      }}
      onMouseLeave={() => {
        setPreview(false);
      }}
      onFocus={() => {
        if (settings.cardPreviewMode === 'hover' && previewsAllowed(settings)) setPreview(true);
      }}
      onBlur={() => {
        setPreview(false);
      }}
      onTouchStart={startHold}
      onTouchEnd={endHold}
      tabIndex={0}
      role="button"
      aria-label={`Play S${ep.season ?? 0}E${ep.episode ?? 0}: ${ep.title}${ep.watched ? ', watched' : ''}`}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          void navigate(`/play/${ep.id}`);
        }
      }}
    >
      <div className="mm-ep-thumb">
        {preview && previewsAllowed(settings) && !ep.previewDisabled ? (
          <PreviewVideo item={ep} slotId={`ep-${ep.id}`} />
        ) : ep.poster.uri ? (
          <img
            src={ep.poster.uri}
            alt=""
            loading="lazy"
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
        ) : (
          <span className="mm-chip" aria-hidden="true">
            E{ep.episode ?? '?'}
          </span>
        )}
        {frac > 0 && frac < 0.95 && (
          <div className="mm-progress" style={{ position: 'absolute', bottom: 0, left: 0, right: 0 }}>
            <div style={{ width: `${frac * 100}%` }} />
          </div>
        )}
        {ep.watched && (
          <span
            style={{
              position: 'absolute',
              top: 4,
              right: 4,
              color: 'var(--ok)',
              background: 'rgba(0,0,0,0.6)',
              borderRadius: 10,
              width: 22,
              height: 22,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
            aria-label="Watched"
          >
            ✓
          </span>
        )}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{ margin: '0 0 4px', fontSize: 14 }}>
          <strong>{ep.episode !== undefined ? `E${ep.episode}` : ''}</strong>{' '}
          <span style={{ color: 'var(--text2)' }}>{ep.title}</span>
        </p>
        <p style={{ margin: 0, fontSize: 12, color: 'var(--text3)' }}>
          {ep.durationMs ? formatDuration(ep.durationMs) : ''}
          {ep.year ? ` · ${ep.year}` : ''}
        </p>
      </div>
      <button
        type="button"
        className="mm-chip"
        aria-pressed={ep.watched}
        aria-label={ep.watched ? t('detail.markUnwatched') : t('detail.markWatched')}
        onClick={(e) => void toggleWatched(e)}
      >
        {ep.watched ? '✓' : '○'}
      </button>
    </div>
  );
}

export function ShowDetailPage(): ReactNode {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const settings = useSettings();
  const [show, setShow] = useState<ShowGroup | null>(null);
  const [episodes, setEpisodes] = useState<MediaItem[]>([]);
  const [notFound, setNotFound] = useState(false);
  const seasonKey = `mymedia-season-${id}`;
  const scrollKey = `mymedia-scroll-${id}`;
  const [season, setSeason] = useState<number | null>(null);
  const [collectOpen, setCollectOpen] = useState(false);
  const [collectNote, setCollectNote] = useState('');
  const restored = useRef(false);

  const load = useCallback(async (): Promise<void> => {
    if (!id) return;
    const [g, eps] = await Promise.all([repository.getShow(id), repository.episodesForShow(id)]);
    if (!g) {
      setNotFound(true);
      return;
    }
    setShow(g);
    setEpisodes(eps);
    if (!restored.current) {
      restored.current = true;
      const savedSeason = sessionStorage.getItem(seasonKey);
      const seasons = [...new Set(eps.map((e) => e.season ?? 0))].sort((a, b) => a - b);
      setSeason(savedSeason !== null ? parseInt(savedSeason, 10) : (seasons[0] ?? 0));
      const y = parseInt(sessionStorage.getItem(scrollKey) ?? '', 10);
      if (!Number.isNaN(y))
        requestAnimationFrame(() => {
          window.scrollTo(0, y);
        });
    }
  }, [id, seasonKey, scrollKey]);

  useEffect(() => {
    void load();
    const onScroll = (): void => {
      sessionStorage.setItem(scrollKey, String(window.scrollY));
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
    };
  }, [load, scrollKey]);

  useEffect(() => {
    if (season !== null) sessionStorage.setItem(seasonKey, String(season));
  }, [season, seasonKey]);

  const seasons = useMemo(
    () => [...new Set(episodes.map((e) => e.season ?? 0))].sort((a, b) => a - b),
    [episodes],
  );
  const seasonEpisodes = useMemo(
    () =>
      episodes
        .filter((e) => (e.season ?? 0) === (season ?? -1))
        .sort((a, b) => (a.episode ?? 0) - (b.episode ?? 0)),
    [episodes, season],
  );
  const watchedCount = useMemo(() => seasonEpisodes.filter((e) => e.watched).length, [seasonEpisodes]);

  if (notFound)
    return (
      <ErrorState
        title="Not found"
        body="This show is no longer in your library."
        onRetry={() => navigate('/')}
      />
    );
  if (!show) return <EmptyState title={t('common.loading')} body="" />;

  const firstUnwatched = seasonEpisodes.find((e) => !e.watched);

  return (
    <div style={{ paddingBottom: 40 }}>
      <div
        style={{
          position: 'relative',
          aspectRatio: '16 / 9',
          maxHeight: '44dvh',
          overflow: 'hidden',
          background: 'var(--bg1)',
        }}
      >
        {/* Local clip from the season's first episode file */}
        {seasonEpisodes[0] && previewsAllowed(settings) && !show.previewDisabled ? (
          <PreviewVideo item={seasonEpisodes[0]} slotId={`detail-${show.id}`} />
        ) : show.backdrop.uri ? (
          <img src={show.backdrop.uri} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        ) : null}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            background: 'linear-gradient(180deg, rgba(5,5,8,0.35), rgba(5,5,8,0.02) 40%, var(--bg0) 98%)',
          }}
          aria-hidden="true"
        />
        <div style={{ position: 'absolute', top: 'calc(12px + env(safe-area-inset-top))', left: 12 }}>
          <IconButton label="Back" onClick={() => navigate(-1)}>
            ←
          </IconButton>
        </div>
      </div>

      <div
        style={{ padding: '0 16px', maxWidth: 1000, margin: '0 auto', marginTop: -64, position: 'relative' }}
      >
        <h1 style={{ margin: '56px 0 6px', fontSize: 'clamp(22px, 4vw, 32px)', letterSpacing: '-0.02em' }}>
          {show.title}
        </h1>
        <p style={{ margin: 0, color: 'var(--text2)', fontSize: 14 }}>
          {[
            show.years.from ?? show.years.to,
            `${episodes.length} episodes`,
            show.maturity ?? t('detail.maturity.unknown'),
            show.genres.join(' · '),
          ]
            .filter(Boolean)
            .join(' · ')}
        </p>

        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', margin: '16px 0' }}>
          {firstUnwatched ? (
            <Button
              variant="primary"
              label={`Play next episode: ${firstUnwatched.title}`}
              onClick={() => navigate(`/play/${firstUnwatched.id}`)}
            >
              ▶ Play S{firstUnwatched.season ?? 0}E{firstUnwatched.episode ?? 0}
            </Button>
          ) : (
            <Button
              variant="ghost"
              label={t('detail.restart')}
              onClick={() => seasonEpisodes[0] && navigate(`/play/${seasonEpisodes[0].id}`)}
            >
              {t('detail.restart')}
            </Button>
          )}
          <IconButton
            label={show.favorite ? t('detail.unfavorite') : t('detail.favorite')}
            onClick={() =>
              void repository
                .upsertShow({ ...show, favorite: !show.favorite, updatedAt: Date.now() })
                .then(() => {
                  setShow({ ...show, favorite: !show.favorite });
                })
            }
          >
            <span style={{ color: show.favorite ? 'var(--accent)' : undefined }}>
              {show.favorite ? '★' : '☆'}
            </span>
          </IconButton>
          <IconButton
            label={show.watchlist ? t('detail.unwatchlist') : t('detail.watchlist')}
            onClick={() =>
              void repository
                .upsertShow({ ...show, watchlist: !show.watchlist, updatedAt: Date.now() })
                .then(() => {
                  setShow({ ...show, watchlist: !show.watchlist });
                })
            }
          >
            <span style={{ color: show.watchlist ? 'var(--accent)' : undefined }}>
              {show.watchlist ? '🔖' : '📑'}
            </span>
          </IconButton>
          {seasonEpisodes.length > 0 && (
            <Button
              variant="ghost"
              label={`Mark season ${season} watched`}
              onClick={() => {
                void repository
                  .bulkMarkWatched(
                    seasonEpisodes.map((e) => e.id),
                    true,
                  )
                  .then(() => void load());
              }}
            >
              Mark S{season} watched
            </Button>
          )}
          <Button
            variant="ghost"
            label={t('collections.addSeasonToCollection')}
            onClick={() => setCollectOpen(true)}
            disabled={seasonEpisodes.length === 0}
          >
            🗂 {t('collections.addSeasonToCollection')}
          </Button>
        </div>
        {collectNote !== '' && (
          <p role="status" style={{ color: 'var(--accent)', fontSize: 14, margin: '4px 0' }}>
            {collectNote}
          </p>
        )}
        {collectOpen && (
          <AddToCollectionSheet
            itemIds={seasonEpisodes.map((e) => e.id)}
            onClose={() => setCollectOpen(false)}
            onAdded={(name) => setCollectNote(t('collections.added', { name }))}
          />
        )}

        <p style={{ lineHeight: 1.6, color: 'var(--text2)' }}>{show.synopsis || t('detail.noSynopsis')}</p>

        {seasons.length > 1 && (
          <div style={{ margin: '16px 0' }}>
            <Segmented
              label="Season"
              value={String(season ?? seasons[0] ?? 0)}
              onChange={(v) => {
                setSeason(parseInt(v, 10));
              }}
              options={seasons.map((s) => ({ id: String(s), label: `Season ${s}` }))}
            />
          </div>
        )}

        <p style={{ fontSize: 13, color: 'var(--text3)' }} role="status">
          {watchedCount} / {seasonEpisodes.length} watched in season {season}
        </p>

        <div style={{ display: 'grid', gap: 4 }}>
          {seasonEpisodes.map((ep) => (
            <EpisodeRow
              key={ep.id}
              ep={ep}
              onChanged={(updated) => {
                setEpisodes((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
              }}
            />
          ))}
        </div>

        <p style={{ marginTop: 16 }}>
          <Link to={`/identify/${show.id}`} style={{ color: 'var(--accent)' }}>
            Fix metadata with a provider match
          </Link>
        </p>

        {/* Reviews is ALWAYS the last section. Do not add sections below this line. */}
        <ReviewsSection
          target={show}
          onChanged={(tgt) => {
            setShow(tgt as ShowGroup);
          }}
        />
      </div>
    </div>
  );
}
