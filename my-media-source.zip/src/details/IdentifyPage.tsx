// ---------------------------------------------------------------------------
// Metadata match review: pick a provider result for a movie or show, apply
// it, or undo the last application. Nothing is fabricated — only data the
// provider returned is applied. Requires the user to configure their own key
// in Settings → Metadata first. Remote artwork URLs are shown but never
// downloaded automatically.
// ---------------------------------------------------------------------------

import { useEffect, useState, type ReactNode } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { repository } from '../storage/repository';
import type { MediaItem, ProviderReview, ShowGroup } from '../storage/types';
import { getProvider, type MetadataCandidate } from '../metadata/providers';
import { captureUndoFrame, pushUndoFrame, undoLastFrame, hasUndo } from '../metadata/matcher';
import { useSettings } from '../settings/store';
import { Button, EmptyState, ErrorState, Stars } from '../shared/ui';
import { t } from '../shared/i18n';

function applyCandidate(
  candidate: MetadataCandidate,
  providerId: string,
  item?: MediaItem,
  show?: ShowGroup,
): { items: MediaItem[]; shows: ShowGroup[] } {
  const patch = {
    title: candidate.title,
    year: candidate.year,
    synopsis: candidate.synopsis,
    genres: candidate.genres,
    cast: candidate.cast,
    providerName: providerId,
    providerId: candidate.providerId,
    matchSource: 'provider' as const,
    matchConfidence: candidate.confidence,
    updatedAt: Date.now(),
  };
  const items: MediaItem[] = [];
  const shows: ShowGroup[] = [];
  if (item) items.push({ ...item, ...patch });
  if (show) shows.push({ ...show, ...patch });
  return { items, shows };
}

export function IdentifyPage(): ReactNode {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const settings = useSettings();
  const [item, setItem] = useState<MediaItem | null>(null);
  const [show, setShow] = useState<ShowGroup | null>(null);
  const [candidates, setCandidates] = useState<MetadataCandidate[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [canUndo, setCanUndo] = useState(false);
  const [applied, setApplied] = useState(false);
  const [publicReviews, setPublicReviews] = useState<ProviderReview[]>([]);
  const [reviewsLoading, setReviewsLoading] = useState(false);

  useEffect(() => {
    if (!id) return;
    void (async () => {
      const [it, g] = await Promise.all([repository.getItem(id), repository.getShow(id)]);
      setItem(it ?? null);
      setShow(g ?? null);
      setCanUndo(hasUndo());
    })();
  }, [id]);

  const providerId = settings.metadataProvider ?? 'none';
  const provider = providerId === 'none' ? undefined : getProvider(providerId);

  const search = async (): Promise<void> => {
    if (!provider) {
      setError(t('identify.noKey'));
      return;
    }
    setLoading(true);
    setError('');
    try {
      const configured = await provider.isConfigured().catch(() => false);
      if (!configured) {
        setError(t('identify.noKey'));
        return;
      }
      const target = item ?? show;
      if (!target) return;
      const year = item?.year ?? show?.years.from;
      const results = await provider.search(target.title, year);
      setCandidates(results);
      if (results.length === 0) setError(t('identify.noResults'));
    } catch {
      setError(t('identify.failed'));
    } finally {
      setLoading(false);
    }
  };

  const apply = async (candidate: MetadataCandidate): Promise<void> => {
    pushUndoFrame(captureUndoFrame(item ? [item] : [], show ? [show] : []));
    const { items, shows } = applyCandidate(candidate, provider!.id, item ?? undefined, show ?? undefined);
    for (const i of items) await repository.updateItem(i.id, i);
    for (const g of shows) await repository.upsertShow(g);
    setItem(items[0] ?? item);
    setShow(shows[0] ?? show);
    setApplied(true);
    setCanUndo(true);
  };

  const undo = async (): Promise<void> => {
    await undoLastFrame();
    setApplied(false);
    setCanUndo(hasUndo());
    if (id) {
      const [it, g] = await Promise.all([repository.getItem(id), repository.getShow(id)]);
      setItem(it ?? null);
      setShow(g ?? null);
    }
  };

  const loadPublicReviews = async (): Promise<void> => {
    const target = item ?? show;
    if (!provider || !target?.providerId) return;
    setReviewsLoading(true);
    try {
      const reviews = await provider.publicReviews(target.providerId).catch(() => []);
      const mapped: ProviderReview[] = reviews.map((r) => ({ ...r, source: provider.displayName }));
      setPublicReviews(mapped);
      if (item) {
        await repository.updateItem(item.id, { providerReviews: mapped });
        setItem({ ...item, providerReviews: mapped });
      } else if (show) {
        await repository.upsertShow({ ...show, providerReviews: mapped });
        setShow({ ...show, providerReviews: mapped });
      }
    } finally {
      setReviewsLoading(false);
    }
  };

  if (!item && !show) return <EmptyState title={t('common.loading')} body="" />;
  const target = (item ?? show)!;

  return (
    <div style={{ padding: '16px 12px 24px', maxWidth: 800, margin: '0 auto' }}>
      <h1 style={{ fontSize: 22 }}>
        {t('identify.title')}: {target.title}
      </h1>
      <p style={{ color: 'var(--text2)', fontSize: 14 }}>
        {t('identify.current', {
          source: target.matchSource ?? 'filename',
          pct: Math.round((target.matchConfidence ?? 0.5) * 100),
        })}
        {' · '}Provider: {provider?.displayName ?? 'none'}
      </p>
      <p style={{ color: 'var(--text3)', fontSize: 13 }}>{t('identify.hint')}</p>

      <div style={{ display: 'flex', gap: 10, margin: '12px 0 20px', flexWrap: 'wrap' }}>
        <Button
          variant="primary"
          label={t('identify.search')}
          onClick={() => void search()}
          disabled={loading}
        >
          {loading ? t('common.loading') : t('identify.search')}
        </Button>
        {canUndo && (
          <Button variant="ghost" label={t('identify.undo')} onClick={() => void undo()}>
            {t('identify.undo')}
          </Button>
        )}
        <Button variant="ghost" label={t('identify.back')} onClick={() => navigate(-1)}>
          {t('identify.back')}
        </Button>
      </div>

      {applied && (
        <p role="status" style={{ color: 'var(--ok)' }}>
          {t('identify.applied')}
        </p>
      )}
      {error && <ErrorState title="Search" body={error} onRetry={() => void search()} />}

      <div style={{ display: 'grid', gap: 12 }}>
        {candidates.map((c) => (
          <div key={c.providerId} className="mm-card" style={{ padding: 16 }}>
            <h3 style={{ margin: 0 }}>
              {c.title} {c.year ? `(${c.year})` : ''}
            </h3>
            <p style={{ margin: '4px 0', fontSize: 13, color: 'var(--text3)' }}>
              {t('identify.confidence', { pct: Math.round(c.confidence * 100) })}
              {c.publicRating
                ? ` · ★ ${((c.publicRating.value / c.publicRating.scale) * 5).toFixed(1)}/5 (${c.publicRating.votes ?? '?'} votes)`
                : ''}
            </p>
            {c.synopsis && (
              <p style={{ margin: '6px 0 0', fontSize: 13.5, color: 'var(--text2)', lineHeight: 1.5 }}>
                {c.synopsis}
              </p>
            )}
            {c.genres.length > 0 && (
              <p style={{ margin: '6px 0 0', fontSize: 12, color: 'var(--text3)' }}>{c.genres.join(' · ')}</p>
            )}
            {c.cast.length > 0 && (
              <p style={{ margin: '6px 0 0', fontSize: 12, color: 'var(--text3)' }}>
                {c.cast.slice(0, 5).join(', ')}
              </p>
            )}
            <div style={{ marginTop: 10 }}>
              <Button
                variant="primary"
                label={`${t('identify.apply')}: ${c.title}`}
                onClick={() => void apply(c)}
              >
                {t('identify.apply')}
              </Button>
            </div>
          </div>
        ))}
      </div>

      {target.providerId && (
        <div style={{ marginTop: 24 }}>
          <Button
            variant="ghost"
            label={t('identify.loadReviews')}
            onClick={() => void loadPublicReviews()}
            disabled={reviewsLoading}
          >
            {reviewsLoading ? t('common.loading') : t('identify.loadReviews')}
          </Button>
          {publicReviews.length > 0 && (
            <div style={{ display: 'grid', gap: 8, marginTop: 12 }}>
              {publicReviews.map((r, i) => (
                <article key={i} className="mm-card" style={{ padding: 14 }}>
                  <div className="mm-row" style={{ justifyContent: 'space-between' }}>
                    <strong>{r.author}</strong>
                    {r.stars !== undefined && <Stars value={r.stars} readOnly label="Public rating" />}
                  </div>
                  <p style={{ margin: '8px 0 0', color: 'var(--text2)', lineHeight: 1.5 }}>{r.body}</p>
                  <p style={{ margin: '6px 0 0', fontSize: 12, color: 'var(--text3)' }}>
                    {t('reviews.public.source', { provider: r.source })}
                  </p>
                </article>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
