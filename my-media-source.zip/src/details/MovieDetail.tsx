// ---------------------------------------------------------------------------
// Movie detail page. Section order is contractual: ReviewsSection is ALWAYS
// the final section (see the comment at the bottom).
// ---------------------------------------------------------------------------

import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { repository } from '../storage/repository';
import type { MediaItem } from '../storage/types';
import { PreviewVideo } from '../previews/PreviewVideo';
import { ReviewsSection } from './ReviewsSection';
import { EditMetadataSheet } from './EditMetadata';
import { Button, EmptyState, ErrorState, IconButton, Stars } from '../shared/ui';
import { previewsAllowed, useSettings } from '../settings/store';
import { decideResume, progressFraction } from '../player/persistence';
import { formatDuration, formatDateTime, formatBytes } from '../shared/format';
import { resolvePlayableUrl } from '../library/playable';
import { saveOfflineCopy, getOfflineCopy } from '../storage/offline';
import { isNative } from '../storage/adapters';
import { t } from '../shared/i18n';
import { regeneratePreviewClip } from '../previews/engine';
import { logger } from '../shared/logger';
import { AddToCollectionSheet } from '../collections/AddToCollectionSheet';

function ActionBar({ item, onChanged }: { item: MediaItem; onChanged: (i: MediaItem) => void }): ReactNode {
  const navigate = useNavigate();
  const settings = useSettings();
  const [hasOffline, setHasOffline] = useState(false);
  const [collectOpen, setCollectOpen] = useState(false);
  const [collectNote, setCollectNote] = useState('');
  const resume = decideResume(item.progressMs, item.durationMs);

  useEffect(() => {
    if (!isNative)
      void getOfflineCopy(item.id).then((b) => {
        setHasOffline(!!b);
      });
  }, [item.id]);

  const toggle = async (patch: Partial<MediaItem>): Promise<void> => {
    await repository.updateItem(item.id, patch);
    onChanged({ ...item, ...patch });
  };

  const saveOffline = async (): Promise<void> => {
    const url = await resolvePlayableUrl(item);
    if (!url) return;
    try {
      const blob = await (await fetch(url)).blob();
      await saveOfflineCopy(item.id, blob);
      setHasOffline(true);
    } catch {
      logger.warn('detail', 'offline copy failed', { id: item.id });
    }
  };

  return (
    <>
      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', margin: '16px 0' }}>
        {resume.action === 'resume' && settings.resumeBehavior !== 'never' ? (
          <>
            <Button
              variant="primary"
              label={`${t('detail.resume')} ${item.title}`}
              onClick={() => navigate(`/play/${item.id}`)}
            >
              ▶ {t('detail.resume')} · {formatDuration(item.progressMs)}
            </Button>
            <Button
              variant="ghost"
              label={t('detail.restart')}
              onClick={() => navigate(`/play/${item.id}?from=0`)}
            >
              {t('detail.restart')}
            </Button>
          </>
        ) : (
          <Button
            variant="primary"
            label={`${t('detail.play')} ${item.title}`}
            onClick={() => navigate(`/play/${item.id}`)}
          >
            ▶ {t('detail.play')}
          </Button>
        )}
        <IconButton
          label={item.favorite ? t('detail.unfavorite') : t('detail.favorite')}
          onClick={() => void toggle({ favorite: !item.favorite })}
        >
          <span style={{ color: item.favorite ? 'var(--accent)' : undefined }}>
            {item.favorite ? '★' : '☆'}
          </span>
        </IconButton>
        <IconButton
          label={item.watchlist ? t('detail.unwatchlist') : t('detail.watchlist')}
          onClick={() => void toggle({ watchlist: !item.watchlist })}
        >
          <span style={{ color: item.watchlist ? 'var(--accent)' : undefined }}>
            {item.watchlist ? '🔖' : '📑'}
          </span>
        </IconButton>
        <Button
          variant="ghost"
          label={item.watched ? t('detail.markUnwatched') : t('detail.markWatched')}
          onClick={() =>
            void toggle({ watched: !item.watched, watchedAt: !item.watched ? Date.now() : undefined })
          }
        >
          {item.watched ? '✓ ' : ''}
          {item.watched ? t('detail.markUnwatched') : t('detail.markWatched')}
        </Button>
        {!isNative && (
          <Button
            variant="ghost"
            label="Save offline copy"
            onClick={() => void saveOffline()}
            disabled={hasOffline}
          >
            {hasOffline ? '✓ Offline copy saved' : '⬇ Save offline copy'}
          </Button>
        )}
        <Button variant="ghost" label={t('collections.addToCollection')} onClick={() => setCollectOpen(true)}>
          🗂 {t('collections.addToCollection')}
        </Button>
      </div>
      {collectNote !== '' && (
        <p role="status" style={{ color: 'var(--accent)', fontSize: 14, margin: '4px 0' }}>
          {collectNote}
        </p>
      )}
      {collectOpen && (
        <AddToCollectionSheet
          itemIds={[item.id]}
          onClose={() => setCollectOpen(false)}
          onAdded={(name) => setCollectNote(t('collections.added', { name }))}
        />
      )}
    </>
  );
}

export function MovieDetailPage(): ReactNode {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const settings = useSettings();
  const [item, setItem] = useState<MediaItem | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [editing, setEditing] = useState(false);
  const [related, setRelated] = useState<MediaItem[]>([]);
  const [history, setHistory] = useState<{ startedAt: number; toMs: number }[]>([]);
  const [previewKey, setPreviewKey] = useState(0);

  useEffect(() => {
    if (!id) return;
    void (async () => {
      const found = await repository.getItem(id);
      if (!found) {
        setNotFound(true);
        return;
      }
      setItem(found);
      const all = await repository.allItems();
      setRelated(
        all
          .filter((i) => i.id !== found.id && !i.missing && i.genres.some((g) => found.genres.includes(g)))
          .slice(0, 12),
      );
      setHistory(await repository.eventsForItem(found.id, 10));
    })();
  }, [id]);

  const missing = item?.missing;
  const unsupported = item?.technical.unsupportedReason;

  const metaLine = useMemo(() => {
    if (!item) return '';
    return [
      item.year,
      item.durationMs ? formatDuration(item.durationMs) : '',
      item.maturity ?? t('detail.maturity.unknown'),
      item.genres.join(' · '),
    ]
      .filter(Boolean)
      .join(' · ');
  }, [item]);

  if (notFound) {
    return (
      <ErrorState
        title="Not found"
        body="This title is no longer in your library."
        onRetry={() => navigate('/')}
      />
    );
  }
  if (!item) return <EmptyState title={t('common.loading')} body="" />;

  const frac = progressFraction(item.progressMs, item.durationMs);

  return (
    <div style={{ paddingBottom: 40 }}>
      {/* Backdrop: local clip from this exact movie */}
      <div
        style={{
          position: 'relative',
          aspectRatio: '16 / 9',
          maxHeight: '52dvh',
          overflow: 'hidden',
          background: 'var(--bg1)',
        }}
      >
        {previewsAllowed(settings) && !item.previewDisabled ? (
          <PreviewVideo key={previewKey} item={item} slotId={`detail-${item.id}`} />
        ) : item.backdrop.uri || item.poster.uri ? (
          <img
            src={item.backdrop.uri ?? item.poster.uri}
            alt=""
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
        ) : null}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            background: 'linear-gradient(180deg, rgba(5,5,8,0.35), rgba(5,5,8,0.02) 40%, var(--bg0) 98%)',
          }}
          aria-hidden="true"
        />
        <div style={{ position: 'absolute', top: 'calc(12px + env(safe-area-inset-top))', left: 12 }}>
          <IconButton label="Back" onClick={() => navigate(-1)}>
            ←
          </IconButton>
        </div>
        <div
          style={{
            position: 'absolute',
            top: 'calc(12px + env(safe-area-inset-top))',
            right: 12,
            display: 'flex',
            gap: 8,
          }}
        >
          <IconButton
            label={t('detail.editMetadata')}
            onClick={() => {
              setEditing(true);
            }}
          >
            ✎
          </IconButton>
          <IconButton
            label={t('settings.previews.regenerate')}
            onClick={() => {
              void (async () => {
                const url = await resolvePlayableUrl(item);
                if (!url) return;
                // Probe duration via a throwaway element; no full playback.
                const probe = document.createElement('video');
                probe.preload = 'metadata';
                probe.src = url;
                await new Promise<void>((res) => {
                  probe.onloadedmetadata = () => {
                    res();
                  };
                  probe.onerror = () => {
                    res();
                  };
                  setTimeout(res, 4000);
                });
                const dur = (probe.duration || 0) * 1000;
                probe.src = '';
                if (dur > 0) {
                  await regeneratePreviewClip(item, dur, settings.previewLengthSec * 1000);
                  setItem({ ...item, previewDisabled: false });
                  setPreviewKey((k) => k + 1);
                }
              })();
            }}
          >
            🎬
          </IconButton>
        </div>
      </div>

      <div
        style={{ padding: '0 16px', maxWidth: 1000, margin: '0 auto', marginTop: -64, position: 'relative' }}
      >
        <div style={{ display: 'flex', gap: 16 }}>
          {item.poster.uri && (
            <img
              src={item.poster.uri}
              alt={`${item.title} poster`}
              style={{
                width: 120,
                borderRadius: 'var(--r-lg)',
                boxShadow: 'var(--shadow-card)',
                alignSelf: 'flex-start',
              }}
            />
          )}
          <div style={{ minWidth: 0 }}>
            <h1
              style={{ margin: '56px 0 6px', fontSize: 'clamp(22px, 4vw, 32px)', letterSpacing: '-0.02em' }}
            >
              {item.title}
            </h1>
            <p style={{ margin: 0, color: 'var(--text2)', fontSize: 14 }}>{metaLine}</p>
            <div className="mm-row" style={{ gap: 16, marginTop: 6 }}>
              {item.localRating && (
                <span aria-label={`Your rating: ${item.localRating.stars} of 5`}>
                  <Stars value={item.localRating.stars} readOnly label="Your rating" />{' '}
                  <span style={{ fontSize: 12, color: 'var(--text3)' }}>yours</span>
                </span>
              )}
            </div>
          </div>
        </div>

        {missing && (
          <div
            className="mm-card"
            style={{ padding: 16, marginTop: 16, borderColor: 'var(--danger)' }}
            role="alert"
          >
            <h3 style={{ margin: '0 0 6px' }}>{t('library.missingFile.title')}</h3>
            <p style={{ margin: 0, color: 'var(--text2)', fontSize: 14 }}>
              {t('library.missingFile.body', { title: item.title })}
            </p>
          </div>
        )}
        {unsupported && (
          <div
            className="mm-card"
            style={{ padding: 16, marginTop: 16, borderColor: 'var(--danger)' }}
            role="alert"
          >
            <h3 style={{ margin: '0 0 6px' }}>{t('scan.unsupported.title')}</h3>
            <p style={{ margin: 0, color: 'var(--text2)', fontSize: 14 }}>
              {t('scan.unsupported.body', { name: item.fileName, detail: unsupported })}
            </p>
          </div>
        )}

        {!missing && !unsupported && <ActionBar item={item} onChanged={setItem} />}
        {frac > 0 && (
          <div style={{ margin: '4px 0 12px' }}>
            <div className="mm-progress">
              <div style={{ width: `${frac * 100}%` }} />
            </div>
          </div>
        )}

        <p style={{ lineHeight: 1.6, color: 'var(--text2)' }}>{item.synopsis || t('detail.noSynopsis')}</p>

        {item.cast.length > 0 && (
          <section aria-label={t('detail.cast')} style={{ marginTop: 24 }}>
            <h2 style={{ fontSize: 18 }}>{t('detail.cast')}</h2>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {item.cast.map((c) => (
                <span key={c} className="mm-chip">
                  {c}
                </span>
              ))}
            </div>
          </section>
        )}

        {related.length > 0 && (
          <section aria-label={t('detail.related')} style={{ marginTop: 24 }}>
            <h2 style={{ fontSize: 18 }}>{t('detail.related')}</h2>
            <div style={{ display: 'flex', gap: 12, overflowX: 'auto', paddingBottom: 8 }}>
              {related.map((r) => (
                <Link
                  key={r.id}
                  to={`/movie/${r.id}`}
                  style={{ flex: '0 0 110px', textDecoration: 'none', color: 'inherit' }}
                >
                  {r.poster.uri ? (
                    <img
                      src={r.poster.uri}
                      alt=""
                      loading="lazy"
                      className="mm-poster"
                      style={{ borderRadius: 'var(--r-md)' }}
                    />
                  ) : (
                    <div className="mm-poster" style={{ borderRadius: 'var(--r-md)' }} />
                  )}
                  <p style={{ fontSize: 12, margin: '6px 0 0' }}>{r.title}</p>
                </Link>
              ))}
            </div>
          </section>
        )}

        <section aria-label={t('detail.technical')} style={{ marginTop: 24 }}>
          <h2 style={{ fontSize: 18 }}>{t('detail.technical')}</h2>
          <dl
            style={{
              display: 'grid',
              gridTemplateColumns: 'auto 1fr',
              gap: '6px 16px',
              fontSize: 13.5,
              color: 'var(--text2)',
            }}
          >
            <dt>File</dt>
            <dd style={{ margin: 0, wordBreak: 'break-all' }}>{item.fileName}</dd>
            <dt>Container</dt>
            <dd style={{ margin: 0 }}>{item.technical.container ?? '—'}</dd>
            <dt>Size</dt>
            <dd style={{ margin: 0 }}>{formatBytes(item.sizeBytes)}</dd>
            <dt>Duration</dt>
            <dd style={{ margin: 0 }}>{item.durationMs ? formatDuration(item.durationMs) : '—'}</dd>
            {item.playCount > 0 && (
              <>
                <dt>Plays</dt>
                <dd style={{ margin: 0 }}>{item.playCount}</dd>
              </>
            )}
          </dl>
        </section>

        {history.length > 0 && (
          <section aria-label={t('detail.history')} style={{ marginTop: 24 }}>
            <h2 style={{ fontSize: 18 }}>{t('detail.history')}</h2>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, fontSize: 13.5, color: 'var(--text2)' }}>
              {history.map((h) => (
                <li
                  key={`${h.startedAt}`}
                  style={{ padding: '6px 0', borderBottom: '1px solid var(--line)' }}
                >
                  {formatDateTime(h.startedAt)} · watched to {formatDuration(h.toMs)}
                </li>
              ))}
            </ul>
          </section>
        )}

        {/* Reviews is ALWAYS the last section. Do not add sections below this line. */}
        <ReviewsSection
          target={item}
          onChanged={(tgt) => {
            setItem(tgt as MediaItem);
          }}
        />
      </div>

      {editing && (
        <EditMetadataSheet
          item={item}
          onClose={() => {
            setEditing(false);
          }}
          onSaved={(updated) => {
            setItem(updated);
            setEditing(false);
          }}
        />
      )}
    </div>
  );
}
