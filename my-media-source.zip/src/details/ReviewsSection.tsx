// ---------------------------------------------------------------------------
// Reviews section — MUST always be the last content section on every detail
// page (after seasons, episodes, cast, related, technical details). Private
// local reviews are stored on-device and editable offline; public reviews
// appear only when a configured provider genuinely returns them, labeled
// with their source.
// ---------------------------------------------------------------------------

import { useEffect, useState, type ReactNode } from 'react';
import type { LocalReview, MediaItem, ProviderReview, ShowGroup } from '../storage/types';
import { repository } from '../storage/repository';
import { Button, BottomSheet, Field, IconButton, Stars, EmptyState } from '../shared/ui';
import { t } from '../shared/i18n';
import { formatDateTime } from '../shared/format';
import { cleanText } from '../shared/sanitize';
import { getProvider } from '../metadata/providers';

type Target = MediaItem | ShowGroup;

function isItem(target: Target): target is MediaItem {
  return 'uri' in target;
}

function ReviewForm({
  initial,
  onSave,
  onCancel,
}: {
  initial?: LocalReview;
  onSave: (r: LocalReview) => void;
  onCancel: () => void;
}): ReactNode {
  const [stars, setStars] = useState(initial?.stars ?? 4);
  const [title, setTitle] = useState(initial?.title ?? '');
  const [body, setBody] = useState(initial?.body ?? '');
  const [spoiler, setSpoiler] = useState(initial?.spoiler ?? false);
  const [error, setError] = useState('');

  const save = (): void => {
    if (stars < 0.5 || stars > 5) {
      setError('Pick a rating between 0.5 and 5 stars.');
      return;
    }
    const now = Date.now();
    onSave({
      id: initial?.id ?? `rev_${now.toString(36)}`,
      title: cleanText(title, 140),
      body: cleanText(body, 4000),
      stars,
      spoiler,
      createdAt: initial?.createdAt ?? now,
      updatedAt: now,
    });
  };

  return (
    <div>
      <Field label={t('reviews.rating.label')}>
        <Stars value={stars} onChange={setStars} label={t('reviews.rating.label')} />
      </Field>
      <Field label={t('reviews.title.label')}>
        <input
          className="mm-input"
          value={title}
          onChange={(e) => {
            setTitle(e.target.value);
          }}
          maxLength={140}
          aria-label={t('reviews.title.label')}
        />
      </Field>
      <Field label={t('reviews.body.label')}>
        <textarea
          className="mm-textarea"
          value={body}
          onChange={(e) => {
            setBody(e.target.value);
          }}
          aria-label={t('reviews.body.label')}
        />
      </Field>
      <label className="mm-row" style={{ gap: 10, cursor: 'pointer' }}>
        <input
          type="checkbox"
          checked={spoiler}
          onChange={(e) => {
            setSpoiler(e.target.checked);
          }}
          style={{ width: 22, height: 22, accentColor: 'var(--accent)' }}
          aria-label={t('reviews.spoiler.label')}
        />
        <span>{t('reviews.spoiler.label')}</span>
      </label>
      {error && (
        <p role="alert" style={{ color: 'var(--danger)' }}>
          {error}
        </p>
      )}
      <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end', marginTop: 12 }}>
        <Button label={t('reviews.cancel')} onClick={onCancel}>
          {t('reviews.cancel')}
        </Button>
        <Button variant="primary" label={t('reviews.save')} onClick={save}>
          {t('reviews.save')}
        </Button>
      </div>
    </div>
  );
}

function SpoilerBody({ body }: { body: string }): ReactNode {
  const [revealed, setRevealed] = useState(false);
  if (!revealed) {
    return (
      <button
        type="button"
        onClick={() => {
          setRevealed(true);
        }}
        className="mm-chip"
        aria-label={t('reviews.spoiler.hidden')}
      >
        {t('reviews.spoiler.hidden')}
      </button>
    );
  }
  return <p style={{ margin: '8px 0 0', lineHeight: 1.55 }}>{body}</p>;
}

export function ReviewsSection({
  target,
  onChanged,
}: {
  target: Target;
  onChanged: (t: Target) => void;
}): ReactNode {
  const [editing, setEditing] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [publicReviews, setPublicReviews] = useState<ProviderReview[]>(target.providerReviews ?? []);
  const [publicLoading, setPublicLoading] = useState(false);
  const review = target.localReview;

  useEffect(() => {
    setPublicReviews(target.providerReviews ?? []);
  }, [target]);

  const persist = async (patch: Partial<MediaItem> | Partial<ShowGroup>): Promise<void> => {
    if (isItem(target)) {
      await repository.updateItem(target.id, patch as Partial<MediaItem>);
      onChanged({ ...target, ...(patch as Partial<MediaItem>) });
    } else {
      await repository.upsertShow({ ...target, ...(patch as Partial<ShowGroup>), updatedAt: Date.now() });
      onChanged({ ...target, ...(patch as Partial<ShowGroup>) });
    }
  };

  const loadPublic = async (): Promise<void> => {
    const provider = getProvider(target.providerName);
    if (!provider || !target.providerName) return;
    setPublicLoading(true);
    try {
      const configured = await provider.isConfigured().catch(() => false);
      if (!configured) return;
      // Public reviews are cached on the item/show for offline use.
      const reviews = await provider.publicReviews(target.providerName).catch(() => []);
      const mapped: ProviderReview[] = reviews.map((r) => ({ ...r, source: provider.displayName }));
      setPublicReviews(mapped);
      await persist({ providerReviews: mapped });
    } finally {
      setPublicLoading(false);
    }
  };

  return (
    <section aria-label={t('detail.reviews')} data-testid="reviews-section" style={{ marginTop: 32 }}>
      <div className="mm-section-title">
        <h2>{t('detail.reviews')}</h2>
        {!review && (
          <Button
            variant="ghost"
            label={t('reviews.write')}
            onClick={() => {
              setEditing(true);
            }}
          >
            {t('reviews.write')}
          </Button>
        )}
      </div>

      {review ? (
        <article className="mm-card" style={{ padding: 16 }} aria-label={t('reviews.mine')}>
          <div className="mm-row" style={{ justifyContent: 'space-between' }}>
            <div>
              <Stars value={review.stars} readOnly label={t('reviews.rating.label')} />
              {review.title && <h3 style={{ margin: '6px 0 0' }}>{review.title}</h3>}
              <p style={{ margin: '4px 0 0', fontSize: 12, color: 'var(--text3)' }}>
                {formatDateTime(review.updatedAt)}
                {review.spoiler ? ' · spoiler' : ''}
              </p>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <IconButton
                label={t('reviews.edit')}
                onClick={() => {
                  setEditing(true);
                }}
              >
                ✎
              </IconButton>
              <IconButton
                label={t('reviews.delete')}
                onClick={() => {
                  setConfirmDelete(true);
                }}
              >
                🗑
              </IconButton>
            </div>
          </div>
          {review.spoiler ? (
            <SpoilerBody body={review.body} />
          ) : (
            <p style={{ margin: '8px 0 0', lineHeight: 1.55 }}>{review.body}</p>
          )}
        </article>
      ) : (
        !editing && <EmptyState title={t('reviews.empty.title')} body={t('reviews.empty.body')} />
      )}

      {publicReviews.length > 0 && (
        <div style={{ marginTop: 16 }}>
          <h3 style={{ fontSize: 15, color: 'var(--text2)' }}>
            {t('reviews.public')} · {t('reviews.public.source', { provider: publicReviews[0]?.source ?? '' })}
          </h3>
          <div style={{ display: 'grid', gap: 8 }}>
            {publicReviews.map((r, i) => (
              <article key={i} className="mm-card" style={{ padding: 14 }}>
                <div className="mm-row" style={{ justifyContent: 'space-between' }}>
                  <strong>{r.author}</strong>
                  {r.stars !== undefined && <Stars value={r.stars} readOnly label="Public rating" />}
                </div>
                <p style={{ margin: '8px 0 0', color: 'var(--text2)', lineHeight: 1.5 }}>{r.body}</p>
              </article>
            ))}
          </div>
        </div>
      )}

      {target.providerName && publicReviews.length === 0 && (
        <Button
          variant="ghost"
          label="Load public reviews"
          onClick={() => void loadPublic()}
          disabled={publicLoading}
        >
          {publicLoading ? t('common.loading') : 'Load public reviews'}
        </Button>
      )}

      {editing && (
        <BottomSheet
          title={review ? t('reviews.edit') : t('reviews.write')}
          onClose={() => {
            setEditing(false);
          }}
        >
          <ReviewForm
            initial={review}
            onCancel={() => {
              setEditing(false);
            }}
            onSave={(r) => {
              void persist({ localReview: r }).then(() => {
                setEditing(false);
              });
            }}
          />
        </BottomSheet>
      )}
      {confirmDelete && (
        <BottomSheet
          title={t('reviews.delete')}
          onClose={() => {
            setConfirmDelete(false);
          }}
        >
          <p>{t('reviews.delete.confirm')}</p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
            <Button
              label={t('common.cancel')}
              onClick={() => {
                setConfirmDelete(false);
              }}
            >
              {t('common.cancel')}
            </Button>
            <Button
              variant="danger"
              label={t('common.delete')}
              onClick={() => {
                void persist({ localReview: undefined }).then(() => {
                  setConfirmDelete(false);
                });
              }}
            >
              {t('common.delete')}
            </Button>
          </div>
        </BottomSheet>
      )}
    </section>
  );
}
