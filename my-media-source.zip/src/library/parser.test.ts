import { describe, expect, it } from 'vitest';
import { dedupeKey, parseFileName, showGroupKey, sortKey, stableId } from './parser';

describe('parseFileName — movies', () => {
  it('parses a movie name with year and quality tags', () => {
    const p = parseFileName('Dune.Part.Two.2024.1080p.BluRay.x264.mkv');
    expect(p.kind).toBe('movie');
    expect(p.title).toBe('Dune Part Two');
    expect(p.year).toBe(2024);
    expect(p.season).toBeUndefined();
    expect(p.episode).toBeUndefined();
    expect(p.tags).toContain('1080P');
  });

  it('parses a plain movie name without a year', () => {
    const p = parseFileName('Spirited Away.mkv');
    expect(p.kind).toBe('movie');
    expect(p.title).toBe('Spirited Away');
    expect(p.year).toBeUndefined();
  });

  it('takes the last year-like token as the release year', () => {
    const p = parseFileName('1975.Movie.2020.REMUX.1080p.mkv');
    expect(p.year).toBe(2020);
  });
});

describe('parseFileName — episodes', () => {
  it('parses S02E05 notation', () => {
    const p = parseFileName('Show.Name.S02E05.1080p.WEB-DL.mkv');
    expect(p.kind).toBe('episode');
    expect(p.title).toBe('Show Name');
    expect(p.season).toBe(2);
    expect(p.episode).toBe(5);
  });

  it('parses 2x05 notation', () => {
    const p = parseFileName('Show.Name.2x05.HDTV.mkv');
    expect(p.kind).toBe('episode');
    expect(p.season).toBe(2);
    expect(p.episode).toBe(5);
  });

  it('takes the season from a "Season 2" parent folder', () => {
    const p = parseFileName('Episode 7 - The Return.mkv', ['My Show', 'Season 2']);
    expect(p.kind).toBe('episode');
    expect(p.season).toBe(2);
    expect(p.episode).toBe(7);
  });

  it('takes the season from an "S02" parent folder', () => {
    const p = parseFileName('My Show - 03.mkv', ['My Show', 'S02']);
    expect(p.season).toBe(2);
  });

  it('detects episode-only names without a season', () => {
    const p = parseFileName('My Show E04 1080p.mkv');
    expect(p.kind).toBe('episode');
    expect(p.episode).toBe(4);
  });
});

describe('dedupeKey / stableId', () => {
  it('produces a stable identity from uri + size + mtime', () => {
    const a = dedupeKey('file:///a/b.mkv', 1234, 999);
    const b = dedupeKey('file:///a/b.mkv', 1234, 999);
    expect(a).toBe(b);
  });

  it('changes when size or mtime change (rescan updates instead of duplicating)', () => {
    const a = dedupeKey('file:///a/b.mkv', 1234, 999);
    expect(dedupeKey('file:///a/b.mkv', 1235, 999)).not.toBe(a);
    expect(dedupeKey('file:///a/b.mkv', 1234, 1000)).not.toBe(a);
    expect(dedupeKey('file:///a/c.mkv', 1234, 999)).not.toBe(a);
  });

  it('stableId is deterministic and collision-shaped', () => {
    const k = dedupeKey('file:///a/b.mkv', 1234, 999);
    expect(stableId(k)).toBe(stableId(k));
    expect(stableId(k)).toMatch(/^[0-9a-f]{16}$/);
    expect(stableId(k + 'x')).not.toBe(stableId(k));
  });
});

describe('showGroupKey / sortKey', () => {
  it('normalizes titles for grouping', () => {
    expect(showGroupKey('The Office', 2005)).toBe(showGroupKey('the office', 2005));
  });

  it('distinguishes same-name shows by year', () => {
    expect(showGroupKey('Battlestar Galactica', 1978)).not.toBe(showGroupKey('Battlestar Galactica', 2004));
  });

  it('sortKey strips leading articles', () => {
    expect(sortKey('The Matrix')).toBe('matrix');
    expect(sortKey('A Quiet Place')).toBe('quiet place');
  });
});
