// ---------------------------------------------------------------------------
// Indexer: groups episodes into shows, maintains ShowGroup aggregates
// (episode counts, watched progress, year ranges), and guarantees no
// duplicates after rescans.
// ---------------------------------------------------------------------------

import { repository } from '../storage/repository';
import type { MediaItem, ShowGroup } from '../storage/types';
import { showGroupKey, sortKey, stableId } from './parser';
import { logger } from '../shared/logger';

export interface ShowSummary extends ShowGroup {
  episodeCount: number;
  watchedCount: number;
  seasons: number[];
  lastPlayedAt?: number;
}

/** Rebuild show groups from the current episode items. Idempotent. */
export async function rebuildShowGroups(): Promise<ShowSummary[]> {
  const items = await repository.allItems();
  const episodes = items.filter((it) => it.kind === 'episode' && it.groupId && !it.missing);

  const byGroup = new Map<string, MediaItem[]>();
  for (const ep of episodes) {
    const list = byGroup.get(ep.groupId!) ?? [];
    list.push(ep);
    byGroup.set(ep.groupId!, list);
  }

  const existing = await repository.allShows();
  const existingById = new Map(existing.map((s) => [s.id, s]));
  const seen = new Set<string>();
  const summaries: ShowSummary[] = [];

  for (const [groupId, eps] of byGroup) {
    seen.add(groupId);
    const first = eps[0]!;
    const prev = existingById.get(groupId);
    const seasons = [...new Set(eps.map((e) => e.season ?? 1))].sort((a, b) => a - b);
    const years = eps.map((e) => e.year).filter((y): y is number => y !== undefined);
    const watchedCount = eps.filter((e) => e.watched).length;
    const lastPlayedAt = eps.reduce<number | undefined>(
      (acc, e) => Math.max(acc ?? 0, e.lastPlayedAt ?? 0) || undefined,
      undefined,
    );
    // Prefer real artwork found on any episode; fall back to previous choice.
    const withPoster = eps.find((e) => e.poster.uri);
    const withBackdrop = eps.find((e) => e.backdrop.uri);
    const allGenres = [...new Set(eps.flatMap((e) => e.genres))];
    const allCast = [...new Set(eps.flatMap((e) => e.cast))].slice(0, 20);

    const show: ShowGroup = {
      id: groupId,
      title: prev?.title ?? first.title,
      sortTitle: prev?.sortTitle ?? sortKey(first.title),
      section: 'show',
      years: {
        from: prev?.years.from ?? (years.length ? Math.min(...years) : undefined),
        to: prev?.years.to ?? (years.length ? Math.max(...years) : undefined),
      },
      synopsis: prev?.synopsis,
      genres: prev?.genres?.length ? prev.genres : allGenres,
      maturity: prev?.maturity,
      cast: prev?.cast?.length ? prev.cast : allCast,
      poster: withPoster?.poster ?? prev?.poster ?? {},
      backdrop: withBackdrop?.backdrop ?? prev?.backdrop ?? {},
      favorite: prev?.favorite ?? false,
      watchlist: prev?.watchlist ?? false,
      localRating: prev?.localRating,
      localReview: prev?.localReview,
      providerReviews: prev?.providerReviews ?? [],
      providerName: prev?.providerName,
      addedAt: prev?.addedAt ?? Math.min(...eps.map((e) => e.addedAt)),
      updatedAt: Date.now(),
    };
    await repository.upsertShow(show);
    summaries.push({ ...show, episodeCount: eps.length, watchedCount, seasons, lastPlayedAt });
  }

  // Drop groups whose episodes all vanished (but never during a partial scan).
  for (const prev of existing) {
    if (!seen.has(prev.id)) {
      await repository.deleteShow(prev.id);
      logger.info('indexer', 'removed empty show group', { id: prev.id });
    }
  }

  return summaries.sort((a, b) => a.sortTitle.localeCompare(b.sortTitle));
}

/** Episodes of a show, ordered by season then episode. */
export function orderEpisodes(episodes: MediaItem[]): MediaItem[] {
  return [...episodes].sort((a, b) => {
    const sa = a.season ?? 1;
    const sb = b.season ?? 1;
    if (sa !== sb) return sa - sb;
    const ea = a.episode ?? a.absoluteEpisode ?? 0;
    const eb = b.episode ?? b.absoluteEpisode ?? 0;
    return ea - eb;
  });
}

/** Next unwatched episode, or the first episode when all are watched. */
export function nextEpisode(episodes: MediaItem[]): MediaItem | undefined {
  const ordered = orderEpisodes(episodes);
  return ordered.find((e) => !e.watched) ?? ordered[0];
}

/** Fraction of episodes watched (0..1). */
export function showProgress(episodes: MediaItem[]): number {
  if (episodes.length === 0) return 0;
  return episodes.filter((e) => e.watched).length / episodes.length;
}

/** Preview the would-be groups for a batch of parsed titles (used by tests/UI). */
export function groupEpisodes(items: MediaItem[]): Map<string, MediaItem[]> {
  const byGroup = new Map<string, MediaItem[]>();
  for (const it of items) {
    if (it.kind !== 'episode') continue;
    const key = it.groupId ?? stableId(`show:${showGroupKey(it.title, it.year)}`);
    const list = byGroup.get(key) ?? [];
    list.push(it);
    byGroup.set(key, list);
  }
  return byGroup;
}
