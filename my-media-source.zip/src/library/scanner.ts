// ---------------------------------------------------------------------------
// Library scanner: recursive, incremental, cancellable. Never freezes the UI:
// enumeration yields to the event loop in chunks, and progress is reported
// after every batch.
// ---------------------------------------------------------------------------

import {
  LIKELY_UNSUPPORTED_VIDEO_EXTENSIONS,
  SIDECAR_EXTENSIONS,
  SUPPORTED_ARTWORK_EXTENSIONS,
  SUPPORTED_MEDIA_EXTENSIONS,
  SUPPORTED_SUBTITLE_EXTENSIONS,
  SUPPORTED_VIDEO_EXTENSIONS,
} from '../config';
import { logger } from '../shared/logger';
import { dedupeKey, parseFileName, showGroupKey, sortKey, stableId } from './parser';
import { repository } from '../storage/repository';
import type { MediaItem, SubtitleTrack } from '../storage/types';
import type { ScanCallbacks, ScanStats, ScannedFile } from './types';

export interface FileWalker {
  /** Recursively enumerate files under a folder reference. */
  list(
    folderRef: string,
    onBatch: (files: ScannedFile[]) => Promise<void> | void,
    isCancelled: () => boolean,
  ): Promise<{ errors: number }>;
}

function classify(fileName: string): ScannedFile['kind'] {
  const ext = fileName.split('.').pop()?.toLowerCase() ?? '';
  if (SUPPORTED_MEDIA_EXTENSIONS.has(ext)) {
    return (SUPPORTED_VIDEO_EXTENSIONS as readonly string[]).includes(ext) ? 'video' : 'audio';
  }
  if ((SUPPORTED_SUBTITLE_EXTENSIONS as readonly string[]).includes(ext)) return 'subtitle';
  if ((SUPPORTED_ARTWORK_EXTENSIONS as readonly string[]).includes(ext)) return 'artwork';
  if (SIDECAR_EXTENSIONS.has(ext)) return 'sidecar';
  return 'other';
}

export function classifyFile(fileName: string): ScannedFile['kind'] {
  return classify(fileName);
}

function parentDirsOf(relativePath: string): string[] {
  const parts = relativePath.split('/').slice(0, -1);
  return parts.slice(-2); // innermost two folders are the useful ones
}

interface PendingArtwork {
  uri: string;
  base: string; // basename without extension, lowercased
  dir: string;
}

export async function scanFolder(
  folderId: string,
  folderRef: string,
  folderName: string,
  walker: FileWalker,
  cb: ScanCallbacks,
): Promise<ScanStats> {
  const stats: ScanStats = {
    total: 0,
    done: 0,
    added: 0,
    updated: 0,
    skipped: 0,
    errors: 0,
    currentPath: folderName,
  };
  const emit = (): void => {
    cb.onProgress({ ...stats });
  };

  // Snapshot of existing items for this folder, keyed by dedupe key.
  const existing = await repository.itemsByFolder(folderId);
  const existingByKey = new Map(existing.map((it) => [dedupeKey(it.uri, it.sizeBytes, it.mtimeMs), it]));
  const seenKeys = new Set<string>();

  const mediaBatch: ScannedFile[] = [];
  const subtitles: ScannedFile[] = [];
  const artworks: PendingArtwork[] = [];
  const sidecars: ScannedFile[] = [];

  const flushMedia = async (): Promise<void> => {
    if (mediaBatch.length === 0) return;
    const batch = mediaBatch.splice(0, mediaBatch.length);
    await ingestBatch(batch);
  };

  const ingestBatch = async (files: ScannedFile[]): Promise<void> => {
    const toUpsert: MediaItem[] = [];
    for (const file of files) {
      if (cb.isCancelled()) return;
      stats.done += 1;
      stats.currentPath = file.relativePath || file.fileName;
      const key = dedupeKey(file.uri, file.sizeBytes, file.mtimeMs);
      seenKeys.add(key);
      const prev = existingByKey.get(key);
      if (prev && !prev.missing) {
        stats.skipped += 1;
        continue;
      }
      try {
        const item = buildItem(file, folderId, folderName, prev);
        toUpsert.push(item);
        if (prev) stats.updated += 1;
        else stats.added += 1;
      } catch {
        stats.errors += 1;
        logger.warn('scanner', 'ingest failed for one file', { folderId });
      }
      if (stats.done % 25 === 0) emit();
      // Yield so the UI stays responsive during huge scans.
      await new Promise((r) => setTimeout(r, 0));
    }
    await repository.upsertItems(toUpsert);
    emit();
  };

  await walker.list(
    folderRef,
    async (files) => {
      for (const f of files) {
        const kind = classify(f.fileName);
        const entry: ScannedFile = {
          ...f,
          kind,
          extension: f.fileName.split('.').pop()?.toLowerCase() ?? '',
        };
        stats.total += 1;
        if (kind === 'video' || kind === 'audio') mediaBatch.push(entry);
        else if (kind === 'subtitle') subtitles.push(entry);
        else if (kind === 'artwork') {
          const base = entry.fileName.replace(/\.[a-z0-9]{2,5}$/i, '').toLowerCase();
          artworks.push({ uri: entry.uri, base, dir: entry.relativePath.split('/').slice(0, -1).join('/') });
        } else if (kind === 'sidecar') sidecars.push(entry);
      }
      if (mediaBatch.length >= 50) await flushMedia();
    },
    () => cb.isCancelled(),
  );
  await flushMedia();

  // Attach subtitles / artwork / sidecars to the ingested items (same folder run).
  if (!cb.isCancelled()) {
    await attachAuxiliary(folderId, subtitles, artworks, sidecars);
  }

  // Mark missing: previously known files in this folder that were not seen.
  // Never mark missing when the scan was cancelled mid-run.
  if (!cb.isCancelled()) {
    const missingIds: string[] = [];
    for (const it of existing) {
      const key = dedupeKey(it.uri, it.sizeBytes, it.mtimeMs);
      if (!seenKeys.has(key) && !it.missing) missingIds.push(it.id);
    }
    for (const id of missingIds) {
      await repository.updateItem(id, { missing: true });
    }
    if (missingIds.length > 0)
      logger.info('scanner', 'marked missing', { count: missingIds.length, folderId });
  }

  emit();
  return stats;
}

function buildItem(
  file: ScannedFile,
  folderId: string,
  _folderName: string,
  prev: MediaItem | undefined,
): MediaItem {
  const parsed = parseFileName(file.fileName, parentDirsOf(file.relativePath));
  const key = dedupeKey(file.uri, file.sizeBytes, file.mtimeMs);
  const id = stableId(key);
  const now = Date.now();
  const isVideo = file.kind === 'video';
  const ext = file.extension;
  const unsupported =
    isVideo && LIKELY_UNSUPPORTED_VIDEO_EXTENSIONS.has(ext)
      ? `Container .${ext} is not decodable by this device's built-in player.`
      : undefined;

  const base: MediaItem = {
    id,
    uri: file.uri,
    fileName: file.fileName,
    sizeBytes: file.sizeBytes,
    mtimeMs: file.mtimeMs,
    folderId,
    kind: parsed.kind === 'audio' ? 'audio' : parsed.kind === 'episode' ? 'episode' : 'movie',
    title: parsed.title,
    sortTitle: sortKey(parsed.title),
    year: parsed.year,
    season: parsed.season,
    episode: parsed.episode,
    absoluteEpisode: parsed.absoluteEpisode,
    genres: [],
    cast: [],
    crew: [],
    poster: {},
    backdrop: {},
    thumbnail: {},
    subtitleTracks: [],
    progressMs: 0,
    progressUpdatedAt: 0,
    watched: false,
    playCount: 0,
    favorite: false,
    watchlist: false,
    providerReviews: [],
    groupId:
      parsed.kind === 'episode' ? stableId(`show:${showGroupKey(parsed.title, parsed.year)}`) : undefined,
    addedAt: prev?.addedAt ?? now,
    updatedAt: now,
    missing: false,
    technical: unsupported ? { container: ext, unsupportedReason: unsupported } : { container: ext },
  };
  // Preserve user data across rescans of the same file.
  if (prev) {
    base.progressMs = prev.progressMs;
    base.progressUpdatedAt = prev.progressUpdatedAt;
    base.watched = prev.watched;
    base.watchedAt = prev.watchedAt;
    base.playCount = prev.playCount;
    base.lastPlayedAt = prev.lastPlayedAt;
    base.favorite = prev.favorite;
    base.watchlist = prev.watchlist;
    base.localRating = prev.localRating;
    base.localReview = prev.localReview;
    base.previewStartMs = prev.previewStartMs;
    base.previewLengthMs = prev.previewLengthMs;
    base.previewDisabled = prev.previewDisabled;
    base.durationMs = prev.durationMs;
    base.subtitleTracks = prev.subtitleTracks ?? [];
  }
  return base;
}

async function attachAuxiliary(
  folderId: string,
  subtitles: ScannedFile[],
  artworks: PendingArtwork[],
  _sidecars: ScannedFile[],
): Promise<void> {
  const items = await repository.itemsByFolder(folderId);
  // Keys must use the folder-relative directory. Item URIs carry a scheme
  // prefix while auxiliary entries carry plain relpaths:
  //   fsa:<folderId>/<relpath>  -> <relpath>
  //   input:<relpath>           -> <relpath>
  //   native:<opaque>           -> (no relpath; sidecar matching N/A)
  const relDirOf = (uri: string): string => {
    let rel = uri;
    const fsaPrefix = `fsa:${folderId}/`;
    if (rel.startsWith(fsaPrefix)) rel = rel.slice(fsaPrefix.length);
    else if (rel.startsWith('input:')) rel = rel.slice('input:'.length);
    const idx = rel.lastIndexOf('/');
    return idx >= 0 ? rel.slice(0, idx) : '';
  };
  const byBase = new Map<string, MediaItem[]>();
  const byDir = new Map<string, MediaItem[]>();
  for (const it of items) {
    const base = it.fileName.replace(/\.[a-z0-9]{2,5}$/i, '').toLowerCase();
    const dir = relDirOf(it.uri);
    const bList = byBase.get(`${dir}::${base}`) ?? [];
    bList.push(it);
    byBase.set(`${dir}::${base}`, bList);
    const dList = byDir.get(dir) ?? [];
    dList.push(it);
    byDir.set(dir, dList);
  }

  const seasonArt = new Map<string, PendingArtwork[]>();
  const dirArt = new Map<string, PendingArtwork[]>();

  for (const art of artworks) {
    const exact = byBase.get(`${art.dir}::${art.base}`);
    if (exact) {
      const patch = pickArtworkPatch(art.base, { uri: art.uri, cachedAt: Date.now() });
      for (const t of exact) await repository.updateItem(t.id, patch);
      continue;
    }
    const seasonMatch = art.base.match(/season[ ._-]*(\d{1,2})/);
    if (seasonMatch) {
      const list = seasonArt.get(art.dir) ?? [];
      list.push(art);
      seasonArt.set(art.dir, list);
      continue;
    }
    const list = dirArt.get(art.dir) ?? [];
    list.push(art);
    dirArt.set(art.dir, list);
  }

  for (const [dir, arts] of dirArt) {
    const targets = byDir.get(dir) ?? [];
    for (const art of arts) {
      const patch = pickArtworkPatch(art.base, { uri: art.uri, cachedAt: Date.now() });
      for (const t of targets) {
        const has = patch.poster ? t.poster.uri : t.backdrop.uri;
        if (!has) await repository.updateItem(t.id, patch);
      }
    }
  }
  for (const [dir, arts] of seasonArt) {
    const targets = byDir.get(dir) ?? [];
    for (const art of arts) {
      const seasonNum = parseInt(art.base.match(/season[ ._-]*(\d{1,2})/)![1]!, 10);
      const patch = pickArtworkPatch(art.base, { uri: art.uri, cachedAt: Date.now() });
      for (const t of targets) {
        if (t.season === seasonNum && !t.poster.uri) await repository.updateItem(t.id, patch);
      }
    }
  }

  // Attach sidecar subtitles: "movie.en.srt" -> movie, lang "en";
  // "movie.srt" -> movie, no language. Matched by folder-relative base name.
  const pendingTracks = new Map<string, SubtitleTrack[]>();
  for (const sub of subtitles) {
    const noExt = sub.fileName.replace(/\.[a-z0-9]{2,5}$/i, '');
    const langMatch = /\.([a-z]{2,3}(?:-[a-z0-9]{2,8})?)$/i.exec(noExt);
    const lang = langMatch?.[1]?.toLowerCase();
    const baseName =
      lang && langMatch ? noExt.slice(0, -langMatch[0].length).toLowerCase() : noExt.toLowerCase();
    const dir = sub.relativePath.split('/').slice(0, -1).join('/');
    const targets = byBase.get(`${dir}::${baseName}`) ?? [];
    for (const t of targets) {
      const track: SubtitleTrack = {
        uri: sub.uri,
        label: lang ? subtitleLangLabel(lang) : 'External',
        ...(lang ? { lang } : {}),
      };
      const list = pendingTracks.get(t.id) ?? [];
      list.push(track);
      pendingTracks.set(t.id, list);
    }
  }
  for (const [id, tracks] of pendingTracks) {
    const current = items.find((i) => i.id === id)?.subtitleTracks ?? [];
    const fresh = tracks.filter((tr) => !current.some((c) => c.uri === tr.uri));
    if (fresh.length > 0) {
      await repository.updateItem(id, { subtitleTracks: [...current, ...fresh] });
    }
  }
}

const SUBTITLE_LANG_LABELS: Record<string, string> = {
  en: 'English',
  es: 'Spanish',
  fr: 'French',
  de: 'German',
  it: 'Italian',
  pt: 'Portuguese',
  ar: 'Arabic',
  hi: 'Hindi',
  ur: 'Urdu',
  ru: 'Russian',
  zh: 'Chinese',
  ja: 'Japanese',
  ko: 'Korean',
  tr: 'Turkish',
  nl: 'Dutch',
  pl: 'Polish',
};

function subtitleLangLabel(lang: string): string {
  return SUBTITLE_LANG_LABELS[lang] ?? lang.toUpperCase();
}

/** Map an artwork file's basename hint to a poster or backdrop patch. */
export function pickArtworkPatch(
  baseName: string,
  ref: { uri: string; cachedAt: number },
): Partial<MediaItem> {
  const lower = baseName.toLowerCase();
  if (lower.includes('fanart') || lower.includes('backdrop') || lower.includes('banner')) {
    return { backdrop: ref };
  }
  return { poster: ref };
}
