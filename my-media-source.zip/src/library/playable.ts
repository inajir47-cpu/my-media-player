// ---------------------------------------------------------------------------
// Playable URL resolution: turn a stored MediaItem into something the
// <video>/<audio> element can play, on each platform. Object URLs are cached
// per item and revoked when the library changes or the app shuts down.
// Media bytes are NEVER uploaded anywhere; every URL here is local.
// ---------------------------------------------------------------------------

import { isNative, nativePlayableUrl } from '../storage/adapters';
import type { MediaItem } from '../storage/types';
import { getDirectoryHandle, getFallbackBlob } from './walkers';
import { logger } from '../shared/logger';

const urlCache = new Map<string, string>();

function trackUrl(itemId: string, url: string): string {
  const prev = urlCache.get(itemId);
  if (prev && prev !== url && prev.startsWith('blob:')) {
    URL.revokeObjectURL(prev);
  }
  urlCache.set(itemId, url);
  return url;
}

/** Resolve a playable URL for an item. Returns null when access is lost. */
export async function resolvePlayableUrl(item: MediaItem): Promise<string | null> {
  if (isNative) {
    const url = await nativePlayableUrl(item.uri);
    if (url) return url;
    logger.warn('playable', 'native URL resolution failed', { id: item.id });
    return null;
  }

  const cached = urlCache.get(item.id);
  if (cached) return cached;

  if (item.uri.startsWith('fsa:')) {
    const url = await resolveFsaUrl(item.uri);
    if (url) return trackUrl(item.id, url);
    return null;
  }

  if (item.uri.startsWith('input:')) {
    const blob = await getFallbackBlob(item.id);
    if (!blob) return null;
    return trackUrl(item.id, URL.createObjectURL(blob));
  }

  // Plain http(s)/blob/data URL stored directly (tests, sidecars).
  if (/^(https?:|blob:|data:)/.test(item.uri)) return item.uri;
  return null;
}

/** Resolve an fsa:<folderId>/<relpath> URI to a blob URL. */
async function resolveFsaUrl(uri: string): Promise<string | null> {
  const rest = uri.slice(4);
  const slash = rest.indexOf('/');
  const folderId = rest.slice(0, slash);
  const relPath = rest.slice(slash + 1);
  const handle = await getDirectoryHandle(folderId);
  if (!handle) return null;
  const file = await findFile(handle as unknown as FSDirLike, relPath.split('/')).catch(() => null);
  if (!file) return null;
  return URL.createObjectURL(file);
}

/**
 * Resolve a sidecar subtitle track to a WebVTT blob URL for a <track>
 * element. SRT files are converted to VTT on the fly. Returns null when
 * the subtitle file is unreachable. The caller must revoke the URL.
 */
export async function resolveSubtitleTrackUrl(item: MediaItem, index: number): Promise<string | null> {
  const track = item.subtitleTracks[index];
  if (!track) return null;
  const uri = track.uri;
  let blob: Blob | null = null;
  if (isNative) {
    const url = await nativePlayableUrl(uri);
    if (!url) return null;
    // Native serves the file over the local media server; fetch it so we
    // can normalize SRT -> VTT the same way as every other platform.
    try {
      const res = await fetch(url);
      if (!res.ok) return null;
      blob = await res.blob();
    } catch {
      return null;
    }
  } else if (uri.startsWith('fsa:')) {
    const url = await resolveFsaUrl(uri);
    if (!url) return null;
    try {
      const res = await fetch(url);
      URL.revokeObjectURL(url);
      if (!res.ok) return null;
      blob = await res.blob();
    } catch {
      return null;
    }
  } else if (uri.startsWith('input:')) {
    const stored = await getFallbackBlob(`sub:${item.id}:${index}`);
    if (!stored) return null;
    blob = stored;
  } else if (/^(https?:|blob:|data:)/.test(uri)) {
    try {
      const res = await fetch(uri);
      if (!res.ok) return null;
      blob = await res.blob();
    } catch {
      return null;
    }
  } else {
    return null;
  }
  const text = await blob.text().catch(() => null);
  if (!text || !text.trim()) return null; // malformed/empty subtitle: expose nothing
  const vtt = uri.toLowerCase().endsWith('.srt') || looksLikeSrt(text) ? srtToVtt(text) : toVtt(text);
  return URL.createObjectURL(new Blob([vtt], { type: 'text/vtt' }));
}

function looksLikeSrt(text: string): boolean {
  return /^\d+\s*\r?\n\d{2}:\d{2}:\d{2},\d{3}\s*-->/m.test(text);
}

/** Minimal SRT -> WebVTT conversion (timestamps + header). */
export function srtToVtt(srt: string): string {
  const body = srt
    .replace(/\r\n/g, '\n')
    .replace(/^\uFEFF/, '')
    .split('\n')
    .filter((line, i, arr) => {
      // Drop numeric cue identifiers: a line that is only digits followed by a timestamp line.
      if (!/^\d+$/.test(line.trim())) return true;
      const next = arr[i + 1] ?? '';
      return !/^\d{2}:\d{2}:\d{2}[,.]\d{3}\s*-->/.test(next);
    })
    .join('\n')
    .replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, '$1.$2');
  return `WEBVTT\n\n${body.trim()}\n`;
}

/** Ensure a VTT payload has the required header. */
function toVtt(text: string): string {
  const clean = text.replace(/^\uFEFF/, '');
  return clean.startsWith('WEBVTT') ? clean : `WEBVTT\n\n${clean}`;
}

interface FSDirLike {
  values(): AsyncIterableIterator<{ kind: string; name: string; getFile(): Promise<File> }>;
}

async function findFile(dir: FSDirLike, parts: string[]): Promise<File | null> {
  const [head, ...tail] = parts;
  if (!head) return null;
  for await (const entry of dir.values()) {
    if (entry.name !== head) continue;
    if (tail.length === 0 && entry.kind === 'file') return entry.getFile();
    if (tail.length > 0 && entry.kind === 'directory') {
      return findFile(entry as unknown as FSDirLike, tail);
    }
  }
  return null;
}

/** Forget cached object URLs (call after library resets or folder removal). */
export function revokePlayableUrls(itemIds?: string[]): void {
  const ids = itemIds ?? [...urlCache.keys()];
  for (const id of ids) {
    const url = urlCache.get(id);
    if (url?.startsWith('blob:')) URL.revokeObjectURL(url);
    urlCache.delete(id);
  }
}

/** Release everything (app shutdown). */
export function revokeAllPlayableUrls(): void {
  revokePlayableUrls();
}
