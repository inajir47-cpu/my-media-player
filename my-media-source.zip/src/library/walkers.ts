// ---------------------------------------------------------------------------
// File walkers: enumerate media files under a user-chosen folder on each
// platform. The scanner consumes the uniform FileWalker interface.
// ---------------------------------------------------------------------------

import { nativeListFiles } from '../storage/adapters';
import type { NativeFileEntry } from '../storage/adapters';
import type { FileWalker } from './scanner';
import type { ScannedFile } from './types';
import { logger } from '../shared/logger';

// -- raw IndexedDB helpers (handles and fallback blobs) ------------------------
// Kept outside Dexie: FileSystemHandles and File blobs are stored via
// structured clone in a dedicated database.

const HANDLES_DB = 'my-media-handles';
const HANDLES_STORE = 'handles';

function openHandlesDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(HANDLES_DB, 1);
    req.onupgradeneeded = () => {
      req.result.createObjectStore(HANDLES_STORE);
    };
    req.onsuccess = () => {
      resolve(req.result);
    };
    req.onerror = () => {
      reject(req.error ?? new Error('IndexedDB request failed'));
    };
  });
}

async function idbPut(key: string, value: unknown): Promise<void> {
  const db = await openHandlesDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(HANDLES_STORE, 'readwrite');
    tx.objectStore(HANDLES_STORE).put(value, key);
    tx.oncomplete = () => {
      resolve();
    };
    tx.onerror = () => {
      reject(tx.error ?? new Error('IndexedDB transaction failed'));
    };
  });
  db.close();
}

async function idbGet<T>(key: string): Promise<T | undefined> {
  const db = await openHandlesDb();
  const value = await new Promise<T | undefined>((resolve, reject) => {
    const tx = db.transaction(HANDLES_STORE, 'readonly');
    const req = tx.objectStore(HANDLES_STORE).get(key);
    req.onsuccess = () => {
      resolve(req.result as T | undefined);
    };
    req.onerror = () => {
      reject(req.error ?? new Error('IndexedDB request failed'));
    };
  });
  db.close();
  return value;
}

async function idbDelete(key: string): Promise<void> {
  const db = await openHandlesDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(HANDLES_STORE, 'readwrite');
    tx.objectStore(HANDLES_STORE).delete(key);
    tx.oncomplete = () => {
      resolve();
    };
    tx.onerror = () => {
      reject(tx.error ?? new Error('IndexedDB transaction failed'));
    };
  });
  db.close();
}

// -- File System Access API -------------------------------------------------------

interface FSHandle {
  kind: 'file' | 'directory';
  name: string;
}
interface FSFileHandle extends FSHandle {
  kind: 'file';
  getFile(): Promise<File>;
}
interface FSDirHandle extends FSHandle {
  kind: 'directory';
  values(): AsyncIterableIterator<FSHandle>;
  queryPermission(opts?: { mode: 'read' }): Promise<PermissionState>;
  requestPermission(opts?: { mode: 'read' }): Promise<PermissionState>;
}

declare global {
  interface Window {
    showDirectoryPicker?: (opts?: { mode: 'read' }) => Promise<FSDirHandle>;
  }
}

export function supportsFileSystemAccess(): boolean {
  return typeof window !== 'undefined' && typeof window.showDirectoryPicker === 'function';
}

export async function pickDirectoryHandle(): Promise<{ handle: FSDirHandle; name: string } | null> {
  if (!window.showDirectoryPicker) return null;
  try {
    const handle = await window.showDirectoryPicker({ mode: 'read' });
    return { handle, name: handle.name };
  } catch {
    // User cancelled the picker — not an error.
    logger.debug('walker', 'directory picker cancelled');
    return null;
  }
}

export async function storeDirectoryHandle(folderId: string, handle: FSDirHandle): Promise<void> {
  await idbPut(`dir:${folderId}`, handle);
}

export async function getDirectoryHandle(folderId: string): Promise<FSDirHandle | undefined> {
  return idbGet<FSDirHandle>(`dir:${folderId}`);
}

export async function forgetDirectoryHandle(folderId: string): Promise<void> {
  await idbDelete(`dir:${folderId}`);
}

/** True when the stored handle still grants read access without prompting. */
export async function hasDirectoryPermission(folderId: string): Promise<boolean> {
  const handle = await getDirectoryHandle(folderId);
  if (!handle) return false;
  try {
    return (await handle.queryPermission({ mode: 'read' })) === 'granted';
  } catch {
    return false;
  }
}

async function* walkDir(
  dir: FSDirHandle,
  base: string,
): AsyncGenerator<{ handle: FSFileHandle; path: string }> {
  for await (const entry of dir.values()) {
    const path = base ? `${base}/${entry.name}` : entry.name;
    if (entry.kind === 'file') {
      yield { handle: entry as FSFileHandle, path };
    } else {
      yield* walkDir(entry as unknown as FSDirHandle, path);
    }
  }
}

/** FileWalker over a persisted File System Access directory handle. */
export function fsaWalker(folderId: string): FileWalker {
  return {
    async list(folderRef, onBatch, isCancelled) {
      void folderRef;
      const handle = await getDirectoryHandle(folderId);
      if (!handle) return { errors: 0 };
      const perm = await handle.queryPermission({ mode: 'read' }).catch(() => 'denied' as PermissionState);
      if (perm !== 'granted') return { errors: 0 };
      let batch: ScannedFile[] = [];
      let errors = 0;
      const flush = async (): Promise<void> => {
        if (batch.length === 0) return;
        await onBatch(batch);
        batch = [];
      };
      for await (const { handle: fileHandle, path } of walkDir(handle, '')) {
        if (isCancelled()) break;
        try {
          const file = await fileHandle.getFile();
          batch.push({
            uri: `fsa:${folderId}/${path}`,
            fileName: fileHandle.name,
            relativePath: path,
            sizeBytes: file.size,
            mtimeMs: file.lastModified,
            kind: 'video',
            extension: '',
          });
        } catch {
          errors += 1;
        }
        if (batch.length >= 100) await flush();
      }
      await flush();
      return { errors };
    },
  };
}

/** Re-request read permission for a stored handle (one-tap reselect flow). */
export async function requestDirectoryPermission(folderId: string): Promise<boolean> {
  const handle = await getDirectoryHandle(folderId);
  if (!handle) return false;
  try {
    return (await handle.requestPermission({ mode: 'read' })) === 'granted';
  } catch {
    return false;
  }
}

// -- multi-file input fallback (no File System Access API) ---------------------------
// File objects are persisted as blobs in IndexedDB so playback and rescans
// keep working until the user clears site data.

export async function storeFallbackBlobs(files: File[]): Promise<Map<string, string>> {
  // Returns map of webkitRelativePath -> blob key.
  const map = new Map<string, string>();
  for (const file of files) {
    const rel = (file as File & { webkitRelativePath?: string }).webkitRelativePath || file.name;
    const key = `blob:${rel}`;
    await idbPut(key, file);
    map.set(rel, key);
  }
  return map;
}

export async function getFallbackBlob(itemId: string): Promise<Blob | undefined> {
  return idbGet<Blob>(`itemblob:${itemId}`);
}

export async function storeItemBlob(itemId: string, blob: Blob): Promise<void> {
  await idbPut(`itemblob:${itemId}`, blob);
}

/** FileWalker over a static FileList from <input type=file webkitdirectory>. */
export function inputFileWalker(files: File[]): FileWalker {
  return {
    async list(_folderRef, onBatch, isCancelled) {
      void _folderRef;
      let batch: ScannedFile[] = [];
      for (const file of files) {
        if (isCancelled()) break;
        const rel = (file as File & { webkitRelativePath?: string }).webkitRelativePath || file.name;
        batch.push({
          uri: `input:${rel}`,
          fileName: file.name,
          relativePath: rel,
          sizeBytes: file.size,
          mtimeMs: file.lastModified,
          kind: 'video',
          extension: '',
        });
        if (batch.length >= 100) {
          await onBatch(batch);
          batch = [];
        }
      }
      if (batch.length > 0) await onBatch(batch);
      return { errors: 0 };
    },
  };
}

// -- Android SAF walker -------------------------------------------------------------

export function nativeWalker(): FileWalker {
  return {
    async list(folderRef, onBatch, isCancelled) {
      const entries: NativeFileEntry[] = await nativeListFiles(folderRef);
      let batch: ScannedFile[] = [];
      for (const e of entries) {
        if (isCancelled()) break;
        batch.push({
          uri: e.uri,
          fileName: e.name,
          relativePath: e.relativePath,
          sizeBytes: e.size,
          mtimeMs: e.mtimeMs,
          kind: 'video',
          extension: '',
        });
        if (batch.length >= 100) {
          await onBatch(batch);
          batch = [];
        }
      }
      if (batch.length > 0) await onBatch(batch);
      return { errors: 0 };
    },
  };
}
