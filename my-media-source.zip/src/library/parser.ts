// ---------------------------------------------------------------------------
// Filename parser: turns "Show.Name.S02E05.1080p.WEB-DL.mkv" into structured
// metadata. Handles S02E05, 2x05, "Season 2" folders, years, and movie names.
// Pure functions — fully unit tested.
// ---------------------------------------------------------------------------

import type { ParsedName } from './types';

const SEASON_EPISODE =
  /[Ss](\d{1,2})[ ._-]*[Ee](\d{1,3})|(\d{1,2})[xX](\d{1,3})|season[ ._-]*(\d{1,2})[ ._-]*episode[ ._-]*(\d{1,3})/;
const EPISODE_ONLY = /(?:^|[ ._-])(?:ep|e|episode)[ ._-]*(\d{1,3})(?:[ ._-]|$)/i;
const ABSOLUTE_EP = /(?:^|[ ._-])(\d{2,3})(?:[ ._-](?:v\d+)?[ ._-]|$)/;
const TAG_SPLIT = /[.\-_ ]+/;

function cleanTitle(raw: string): string {
  return raw
    .split(TAG_SPLIT)
    .filter(Boolean)
    .map((w) => (w.length > 1 ? w[0]!.toUpperCase() + w.slice(1) : w.toUpperCase()))
    .join(' ');
}

/**
 * Parse a media file name (without requiring the full path).
 * `parentDirs` lets "Season 2" folder names supply the season number.
 */
export function parseFileName(fileName: string, parentDirs: string[] = []): ParsedName {
  const withoutExt = fileName.replace(/\.[a-z0-9]{2,5}$/i, '');
  const tags: string[] = [];
  let working = withoutExt;

  // Year: capture the LAST 4-digit year-like token (release year usually trails).
  let year: number | undefined;
  const yearMatches = [...working.matchAll(/(?:^|[ .(_[-])((?:19|20)\d{2})(?=[ .)\]_-]|$)/g)];
  if (yearMatches.length > 0) {
    const last = yearMatches[yearMatches.length - 1]!;
    year = parseInt(last[1]!, 10);
    working = working.slice(0, last.index) + ' ' + working.slice(last.index + last[0].length);
  }

  // Season/episode patterns.
  let season: number | undefined;
  let episode: number | undefined;
  const se = working.match(SEASON_EPISODE);
  if (se) {
    season = parseInt(se[1] ?? se[3] ?? se[5] ?? '1', 10);
    episode = parseInt(se[2] ?? se[4] ?? se[6] ?? '1', 10);
    working = working.replace(se[0], ' ');
  } else {
    const eo = working.match(EPISODE_ONLY);
    if (eo) {
      episode = parseInt(eo[1]!, 10);
      working = working.replace(eo[0], ' ');
    }
  }

  // Season from parent folder ("Season 2", "S02", "Series 3").
  if (season === undefined) {
    for (const dir of parentDirs) {
      const m = dir.match(/(?:season|s|series)[ ._-]*(\d{1,2})/i);
      if (m) {
        season = parseInt(m[1]!, 10);
        break;
      }
    }
  }

  // Absolute episode number fallback ("Show - 042.mkv").
  let absoluteEpisode: number | undefined;
  if (episode === undefined && season !== undefined) {
    const m = working.match(ABSOLUTE_EP);
    if (m) absoluteEpisode = parseInt(m[1]!, 10);
  }

  // Quality/source tags: strip from the title but remember them.
  // Keep hyphenated source tags intact so "WEB-DL" is a tag, not a title word.
  working = working
    .replace(/\bweb-dl\b/gi, 'WEBDL')
    .replace(/\bweb-rip\b/gi, 'WEBRIP')
    .replace(/\bblu-ray\b/gi, 'BLURAY');
  const words = working.split(TAG_SPLIT).filter(Boolean);
  const titleWords: string[] = [];
  for (const w of words) {
    const lower = w.toLowerCase();
    if (
      /^(2160p|1080p|720p|480p|4k|uhd|hdr|hdr10|dolby|bluray|blu-ray|bdrip|brrip|webdl|web-dl|webrip|web|hdtv|dvdrip|dvd|x264|x265|h264|h265|hevc|aac|ac3|dts|atmos|truehd|flac|extended|remux|proper|repack|v\d+)$/i.test(
        lower,
      )
    ) {
      tags.push(w.toUpperCase());
    } else {
      titleWords.push(w);
    }
  }

  const title = cleanTitle(titleWords.join(' ')) || cleanTitle(withoutExt);
  const kind: ParsedName['kind'] =
    season !== undefined || episode !== undefined || absoluteEpisode !== undefined ? 'episode' : 'movie';

  return { title, year, season, episode, absoluteEpisode, kind, tags };
}

/** "Dune.Part.Two.2024.1080p" -> sort key "dune part two". */
export function sortKey(title: string): string {
  return title
    .toLowerCase()
    .replace(/^(the|a|an)\s+/i, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

/**
 * Stable file identity: uri + size + mtime. Two entries with the same key are
 * the same file — rescans update instead of duplicating.
 */
export function dedupeKey(uri: string, sizeBytes: number, mtimeMs: number): string {
  return `${uri}|${sizeBytes}|${mtimeMs}`;
}

/** Deterministic id from the dedupe key (FNV-1a 64-bit hex). */
export function stableId(key: string): string {
  let h1 = 0xcbf29ce4;
  let h2 = 0xcbf29ce4;
  for (let i = 0; i < key.length; i++) {
    const c = key.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0;
    h2 = Math.imul(h2 ^ (c + 31), 0x01000193) >>> 0;
  }
  return `${h1.toString(16).padStart(8, '0')}${h2.toString(16).padStart(8, '0')}`;
}

/** Group key for episodes: normalized show title (+year when known). */
export function showGroupKey(title: string, year?: number): string {
  return year ? `${sortKey(title)}::${year}` : sortKey(title);
}
