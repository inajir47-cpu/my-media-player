// ---------------------------------------------------------------------------
// Library domain types: parse results from file names, scan progress events.
// ---------------------------------------------------------------------------

export interface ParsedName {
  title: string;
  year?: number;
  season?: number;
  episode?: number;
  absoluteEpisode?: number;
  /** 'episode' when SxxEyy / NxNN pattern matched, 'movie' otherwise. */
  kind: 'episode' | 'movie' | 'audio';
  /** Extra quality/source tags found (kept for display, not identity). */
  tags: string[];
}

export interface ScannedFile {
  uri: string;
  fileName: string;
  relativePath: string;
  sizeBytes: number;
  mtimeMs: number;
  kind: 'video' | 'audio' | 'subtitle' | 'artwork' | 'sidecar' | 'other';
  extension: string;
}

export interface ScanStats {
  total: number;
  done: number;
  added: number;
  updated: number;
  skipped: number;
  errors: number;
  currentPath: string;
}

export interface ScanCallbacks {
  onProgress(stats: ScanStats): void;
  isCancelled(): boolean;
}

export const QUALITY_TAGS = [
  '2160p',
  '1080p',
  '720p',
  '480p',
  '4k',
  'uhd',
  'hdr',
  'bluray',
  'web-dl',
  'webrip',
  'hdtv',
  'dvdrip',
  'x264',
  'x265',
  'hevc',
  'aac',
  'dts',
  'atmos',
] as const;
