import { describe, expect, it } from 'vitest';
import { srtToVtt } from './playable';

const SRT = `1
00:00:01,000 --> 00:00:04,000
Hello world

2
00:00:05,500 --> 00:00:07,000
Second line
`;

describe('srtToVtt', () => {
  it('adds the WEBVTT header and converts comma decimals', () => {
    const vtt = srtToVtt(SRT);
    expect(vtt.startsWith('WEBVTT')).toBe(true);
    expect(vtt).toContain('00:00:01.000 --> 00:00:04.000');
    expect(vtt).not.toContain('00:00:01,000');
  });

  it('drops numeric cue identifiers', () => {
    const vtt = srtToVtt(SRT);
    expect(vtt).not.toMatch(/^1$/m);
    expect(vtt).toContain('Hello world');
  });

  it('is idempotent-safe on empty input', () => {
    expect(srtToVtt('').startsWith('WEBVTT')).toBe(true);
  });
});
