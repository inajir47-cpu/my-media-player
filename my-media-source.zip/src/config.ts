// ---------------------------------------------------------------------------
// My Media - single source of truth for app identity and global constants.
// The app name lives ONLY here. UI, manifest and native shells read from it.
// ---------------------------------------------------------------------------

export const APP_NAME = 'My Media';

export const APP_ID = 'app.mymedia.library';
export const APP_VERSION = '1.0.0';

export const SUPPORTED_VIDEO_EXTENSIONS = ['mp4', 'm4v', 'webm', 'mkv', 'mov'] as const;
export const SUPPORTED_AUDIO_EXTENSIONS = ['mp3', 'aac', 'm4a', 'flac', 'ogg', 'oga', 'wav'] as const;
export const SUPPORTED_SUBTITLE_EXTENSIONS = ['srt', 'vtt'] as const;
export const SUPPORTED_ARTWORK_EXTENSIONS = ['jpg', 'jpeg', 'png', 'webp', 'avif', 'gif', 'bmp'] as const;

export const SUPPORTED_MEDIA_EXTENSIONS: ReadonlySet<string> = new Set([
  ...SUPPORTED_VIDEO_EXTENSIONS,
  ...SUPPORTED_AUDIO_EXTENSIONS,
]);

/** Container extensions the HTML <video> element cannot decode on its own. */
export const LIKELY_UNSUPPORTED_VIDEO_EXTENSIONS: ReadonlySet<string> = new Set(['mkv', 'mov']);

/** Sidecar metadata files we read next to media files. */
export const SIDECAR_EXTENSIONS: ReadonlySet<string> = new Set(['nfo', 'json']);

export const DB_NAME = 'my-media-db';
export const DB_VERSION = 4;

/** Artwork cache budget (bytes) before LRU eviction kicks in. */
export const ARTWORK_CACHE_BUDGET_BYTES = 256 * 1024 * 1024;

/** Maximum items the virtualized grids are designed for. */
export const LIBRARY_SCALE_TARGET = 10_000;

/** Playback speeds offered in the player (0.25x - 4x). */
export const PLAYBACK_SPEEDS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 3, 4] as const;

/** Home screen section ids, in default order. */
export const DEFAULT_HOME_SECTIONS = [
  'continue-watching',
  'recently-added',
  'favorites',
  'watchlist',
  'movies',
  'shows',
  'recently-played',
  'collections',
  'hero',
] as const;
