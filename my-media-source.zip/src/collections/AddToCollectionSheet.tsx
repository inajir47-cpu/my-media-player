// ---------------------------------------------------------------------------
// AddToCollectionSheet: pick a collection (or create one) to add an item to.
// ---------------------------------------------------------------------------

import { useState, type ReactNode } from 'react';
import { BottomSheet, Button, Field } from '../shared/ui';
import { t } from '../shared/i18n';
import { useLibrary } from '../app/libraryContext';
import { addToCollection, createCollection } from './store';
import { logger } from '../shared/logger';

export function AddToCollectionSheet({
  itemIds,
  onClose,
  onAdded,
}: {
  itemIds: string[];
  onClose: () => void;
  onAdded: (collectionName: string) => void;
}): ReactNode {
  const { collections, refresh } = useLibrary();
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const add = async (collectionId: string, collectionName: string): Promise<void> => {
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      for (const itemId of itemIds) {
        await addToCollection(collectionId, itemId);
      }
      await refresh();
      onAdded(collectionName);
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      logger.warn('collections', 'add to collection failed', { collectionId });
    } finally {
      setBusy(false);
    }
  };

  const create = async (): Promise<void> => {
    const trimmed = name.trim();
    if (!trimmed || busy) return;
    setBusy(true);
    setError('');
    try {
      const col = await createCollection(trimmed);
      for (const itemId of itemIds) {
        await addToCollection(col.id, itemId);
      }
      await refresh();
      onAdded(col.name);
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      logger.warn('collections', 'create collection failed', {});
    } finally {
      setBusy(false);
    }
  };

  return (
    <BottomSheet title={t('collections.addToCollection')} onClose={onClose}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4, padding: '8px 0' }}>
        {collections.map((c) => (
          <Button
            key={c.id}
            variant="ghost"
            label={`${t('collections.addToCollection')}: ${c.name}`}
            onClick={() => void add(c.id, c.name)}
            disabled={busy}
          >
            ＋ {c.name} · {t('collections.count', { n: c.itemIds.length })}
          </Button>
        ))}
        {collections.length === 0 && !creating && (
          <p style={{ color: 'var(--text3)', fontSize: 14 }}>{t('collections.empty')}</p>
        )}
        {creating ? (
          <Field label={t('collections.nameLabel')}>
            <div style={{ display: 'flex', gap: 8 }}>
              <input
                className="mm-input"
                value={name}
                onChange={(e) => setName(e.target.value)}
                maxLength={80}
                placeholder={t('collections.nameLabel')}
                aria-label={t('collections.nameLabel')}
              />
              <Button
                variant="primary"
                label={t('collections.create')}
                onClick={() => void create()}
                disabled={busy || name.trim().length === 0}
              >
                {t('collections.create')}
              </Button>
            </div>
          </Field>
        ) : (
          <Button
            variant="ghost"
            label={t('collections.newCollection')}
            onClick={() => setCreating(true)}
            disabled={busy}
          >
            {t('collections.newCollection')}
          </Button>
        )}
        {error !== '' && (
          <p role="alert" style={{ color: 'var(--danger)', fontSize: 14 }}>
            {error}
          </p>
        )}
      </div>
    </BottomSheet>
  );
}
