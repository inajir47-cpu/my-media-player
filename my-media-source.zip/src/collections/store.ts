// ---------------------------------------------------------------------------
// Collections domain: favorites, watchlist, user collections, history and the
// Continue Watching / Recently Added / Recently Played selectors.
// ---------------------------------------------------------------------------

import { repository } from '../storage/repository';
import type { MediaItem, UserCollection } from '../storage/types';
import { logger } from '../shared/logger';

function uid(prefix: string): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

/** Trim, collapse inner whitespace, cap length. Throws on empty. */
function normalizeName(name: string): string {
  const normalized = name.trim().replace(/\s+/g, ' ').slice(0, 80);
  if (!normalized) throw new Error('Collection name is empty.');
  return normalized;
}

/** Toggle favorite on an item. Returns the new state. */
export async function toggleFavorite(item: MediaItem): Promise<boolean> {
  const next = !item.favorite;
  await repository.updateItem(item.id, { favorite: next });
  return next;
}

export async function toggleWatchlist(item: MediaItem): Promise<boolean> {
  const next = !item.watchlist;
  await repository.updateItem(item.id, { watchlist: next });
  return next;
}

export async function createCollection(name: string): Promise<UserCollection> {
  const collection: UserCollection = {
    id: uid('col'),
    name: normalizeName(name),
    itemIds: [],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  await repository.upsertCollection(collection);
  return collection;
}

export async function addToCollection(collectionId: string, itemId: string): Promise<void> {
  const collections = await repository.allCollections();
  const col = collections.find((c) => c.id === collectionId);
  if (!col) throw new Error('Collection not found.');
  if (!col.itemIds.includes(itemId)) {
    col.itemIds.push(itemId);
    col.updatedAt = Date.now();
    await repository.upsertCollection(col);
  }
}

export async function removeFromCollection(collectionId: string, itemId: string): Promise<void> {
  const collections = await repository.allCollections();
  const col = collections.find((c) => c.id === collectionId);
  if (!col) return;
  col.itemIds = col.itemIds.filter((id) => id !== itemId);
  col.updatedAt = Date.now();
  await repository.upsertCollection(col);
}

export async function reorderCollection(collectionId: string, itemIds: string[]): Promise<void> {
  const collections = await repository.allCollections();
  const col = collections.find((c) => c.id === collectionId);
  if (!col) throw new Error('Collection not found.');
  const valid = new Set(col.itemIds);
  const seen = new Set<string>();
  // Given order wins; unknown ids are dropped, duplicates collapsed.
  const ordered: string[] = [];
  for (const id of itemIds) {
    if (valid.has(id) && !seen.has(id)) {
      seen.add(id);
      ordered.push(id);
    }
  }
  // Items not mentioned keep their original relative order at the end.
  for (const id of col.itemIds) {
    if (!seen.has(id)) {
      ordered.push(id);
      seen.add(id);
    }
  }
  col.itemIds = ordered;
  col.updatedAt = Date.now();
  await repository.upsertCollection(col);
}

export async function renameCollection(collectionId: string, name: string): Promise<void> {
  const collections = await repository.allCollections();
  const col = collections.find((c) => c.id === collectionId);
  if (!col) throw new Error('Collection not found.');
  col.name = normalizeName(name);
  col.updatedAt = Date.now();
  await repository.upsertCollection(col);
}

// -- selectors -------------------------------------------------------------------

/** Items with meaningful progress that are not finished. */
export function continueWatching(items: MediaItem[]): MediaItem[] {
  return items
    .filter((it) => !it.missing && !it.watched && it.progressMs > 5000 && it.progressUpdatedAt > 0)
    .sort((a, b) => b.progressUpdatedAt - a.progressUpdatedAt);
}

/** Newest additions first. */
export function recentlyAdded(items: MediaItem[], limit = 30): MediaItem[] {
  return [...items]
    .filter((it) => !it.missing)
    .sort((a, b) => b.addedAt - a.addedAt)
    .slice(0, limit);
}

/** Items played most recently. */
export function recentlyPlayed(items: MediaItem[], limit = 30): MediaItem[] {
  return [...items]
    .filter((it) => !it.missing && it.lastPlayedAt)
    .sort((a, b) => (b.lastPlayedAt ?? 0) - (a.lastPlayedAt ?? 0))
    .slice(0, limit);
}

export async function removeFromContinueWatching(item: MediaItem): Promise<void> {
  await repository.updateItem(item.id, { progressMs: 0, progressUpdatedAt: 0 });
  logger.info('collections', 'removed from continue watching', { id: item.id });
}
