// Collections domain tests: create/add/remove/reorder/rename/delete
// semantics against an in-memory stand-in for the repository.

import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { UserCollection } from '../storage/types';

const db = new Map<string, UserCollection>();

vi.mock('../storage/repository', () => ({
  repository: {
    allCollections: async (): Promise<UserCollection[]> =>
      [...db.values()].map((c) => ({ ...c, itemIds: [...c.itemIds] })),
    upsertCollection: async (c: UserCollection): Promise<void> => {
      db.set(c.id, { ...c, itemIds: [...c.itemIds] });
    },
    deleteCollection: async (id: string): Promise<void> => {
      db.delete(id);
    },
  },
}));

import {
  addToCollection,
  createCollection,
  removeFromCollection,
  renameCollection,
  reorderCollection,
} from './store';
import { repository } from '../storage/repository';

beforeEach(() => {
  db.clear();
});

describe('createCollection', () => {
  it('creates a collection with a trimmed name', async () => {
    const col = await createCollection('  My List  ');
    expect(col.name).toBe('My List');
    expect(col.itemIds).toEqual([]);
    expect((await repository.allCollections()).map((c) => c.id)).toContain(col.id);
  });

  it('rejects an empty name', async () => {
    await expect(createCollection('   ')).rejects.toThrow('Collection name is empty.');
  });
});

describe('addToCollection', () => {
  it('adds an item and ignores duplicates', async () => {
    const col = await createCollection('A');
    await addToCollection(col.id, 'item-1');
    await addToCollection(col.id, 'item-1');
    await addToCollection(col.id, 'item-2');
    const found = (await repository.allCollections()).find((c) => c.id === col.id);
    expect(found?.itemIds).toEqual(['item-1', 'item-2']);
  });

  it('throws for an unknown collection', async () => {
    await expect(addToCollection('nope', 'item-1')).rejects.toThrow('Collection not found.');
  });
});

describe('removeFromCollection', () => {
  it('removes only the given item', async () => {
    const col = await createCollection('A');
    await addToCollection(col.id, 'item-1');
    await addToCollection(col.id, 'item-2');
    await removeFromCollection(col.id, 'item-1');
    const found = (await repository.allCollections()).find((c) => c.id === col.id);
    expect(found?.itemIds).toEqual(['item-2']);
  });
});

describe('reorderCollection', () => {
  it('keeps the given order and drops unknown ids', async () => {
    const col = await createCollection('A');
    await addToCollection(col.id, 'a');
    await addToCollection(col.id, 'b');
    await addToCollection(col.id, 'c');
    await reorderCollection(col.id, ['c', 'a', 'ghost']);
    const found = (await repository.allCollections()).find((c) => c.id === col.id);
    expect(found?.itemIds).toEqual(['c', 'a', 'b']);
  });

  it('dedupes the given order', async () => {
    const col = await createCollection('A');
    await addToCollection(col.id, 'a');
    await addToCollection(col.id, 'b');
    await reorderCollection(col.id, ['b', 'b', 'a']);
    const found = (await repository.allCollections()).find((c) => c.id === col.id);
    expect(found?.itemIds).toEqual(['b', 'a']);
  });
});

describe('renameCollection', () => {
  it('renames and normalizes whitespace', async () => {
    const col = await createCollection('Old');
    await renameCollection(col.id, '  New   Name  ');
    const found = (await repository.allCollections()).find((c) => c.id === col.id);
    expect(found?.name).toBe('New Name');
  });

  it('rejects an empty name', async () => {
    const col = await createCollection('Old');
    await expect(renameCollection(col.id, '  ')).rejects.toThrow('Collection name is empty.');
  });
});
