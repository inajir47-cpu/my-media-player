// ---------------------------------------------------------------------------
// Offline copies: app-managed file copies stored in this app's private
// storage. Genuinely useful on web, where folder permissions don't survive
// restarts — a saved copy keeps a title playable. On Android the original
// files are already on the device, so copies are unnecessary and the UI says
// so instead of pretending.
// ---------------------------------------------------------------------------

import { isNative } from './adapters';
import { logger } from '../shared/logger';

const DB = 'my-media-offline';
const STORE = 'copies';

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => {
      resolve(req.result);
    };
    req.onerror = () => {
      reject(req.error ?? new Error('IndexedDB request failed'));
    };
  });
}

async function tx<T>(
  mode: IDBTransactionMode,
  fn: (store: IDBObjectStore) => IDBRequest<T> | void,
): Promise<T | void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE, mode);
    const store = transaction.objectStore(STORE);
    let result: T | undefined;
    const req = fn(store);
    if (req)
      req.onsuccess = () => {
        result = req.result;
      };
    transaction.oncomplete = () => {
      db.close();
      resolve(result);
    };
    transaction.onerror = () => {
      db.close();
      reject(transaction.error ?? new Error('IndexedDB transaction failed'));
    };
  });
}

export interface OfflineCopy {
  itemId: string;
  bytes: number;
  savedAt: number;
}

/** Save an app-managed offline copy (web only; Android files are already local). */
export async function saveOfflineCopy(itemId: string, blob: Blob): Promise<void> {
  if (isNative)
    throw new Error('Offline copies are unnecessary on Android — files are already on the device.');
  await tx('readwrite', (store) =>
    store.put({ itemId, bytes: blob.size, savedAt: Date.now(), blob }, itemId),
  );
  logger.info('offline', 'saved offline copy', { id: itemId, bytes: blob.size });
}

export async function getOfflineCopy(itemId: string): Promise<Blob | null> {
  const rec = (await tx('readonly', (store) => store.get(itemId))) as { blob: Blob } | undefined;
  return rec?.blob ?? null;
}

export async function removeOfflineCopy(itemId: string): Promise<void> {
  await tx('readwrite', (store) => store.delete(itemId));
}

export async function listOfflineCopies(): Promise<OfflineCopy[]> {
  const db = await openDb();
  const all = await new Promise<{ itemId: string; bytes: number; savedAt: number }[]>((resolve, reject) => {
    const transaction = db.transaction(STORE, 'readonly');
    const req = transaction.objectStore(STORE).getAll();
    req.onsuccess = () => {
      resolve(
        (req.result as { itemId: string; bytes: number; savedAt: number; blob: Blob }[]).map(
          ({ itemId, bytes, savedAt }) => ({ itemId, bytes, savedAt }),
        ),
      );
    };
    req.onerror = () => {
      reject(req.error ?? new Error('IndexedDB request failed'));
    };
  });
  db.close();
  return all;
}

export async function offlineBytesTotal(): Promise<number> {
  const copies = await listOfflineCopies();
  return copies.reduce((acc, c) => acc + c.bytes, 0);
}

/** Resolve a playable URL, preferring the app-managed offline copy. */
export async function offlineCopyUrl(itemId: string): Promise<string | null> {
  const blob = await getOfflineCopy(itemId);
  return blob ? URL.createObjectURL(blob) : null;
}
