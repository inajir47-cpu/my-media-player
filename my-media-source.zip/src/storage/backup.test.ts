import { describe, expect, it } from 'vitest';
import { summarizeBackup, validateBackup, type BackupPayload } from './backup';

function validPayload(): BackupPayload {
  return {
    app: 'my-media',
    backupVersion: 4,
    exportedAt: 1727200000000,
    items: [
      { id: 'a', uri: 'file:///a.mkv', title: 'A' },
      { id: 'b', uri: 'file:///b.mkv', title: 'B', localReview: { stars: 4 } },
    ],
    shows: [{ id: 's1', title: 'Show' }],
    collections: [],
    folders: [],
    settings: { theme: 'dark' },
  };
}

describe('validateBackup', () => {
  it('accepts a well-formed payload', () => {
    expect(validateBackup(validPayload())).toEqual([]);
  });

  it('rejects non-objects and wrong apps', () => {
    expect(validateBackup(null)).toHaveLength(1);
    expect(validateBackup('nope')).toHaveLength(1);
    expect(validateBackup({ ...validPayload(), app: 'other-app' })).toContain(
      'This backup was not created by My Media.',
    );
  });

  it('requires all top-level sections', () => {
    const { items, ...rest } = validPayload();
    void items;
    const problems = validateBackup(rest);
    expect(problems.some((p) => p.includes('"items"'))).toBe(true);
  });

  it('rejects wrong types for sections', () => {
    const p = { ...validPayload(), items: 'not-an-array', settings: 42 };
    const problems = validateBackup(p);
    expect(problems.some((m) => m.includes('"items" must be an array'))).toBe(true);
    expect(problems.some((m) => m.includes('"settings" must be an object'))).toBe(true);
  });

  it('flags library items missing id or uri', () => {
    const p = validPayload();
    p.items = [{ id: 'ok', uri: 'file:///x' }, { title: 'no id' }, { id: 'no-uri' }];
    const problems = validateBackup(p);
    expect(problems.some((m) => m.includes('2 library item(s)'))).toBe(true);
  });

  it('rejects backups that smuggle a PIN hash', () => {
    const p = validPayload();
    p.settings = { theme: 'dark', pinHash: 'deadbeef' } as never;
    expect(validateBackup(p).some((m) => m.includes('PIN hash'))).toBe(true);
  });

  it('requires a numeric backupVersion', () => {
    const p = { ...validPayload(), backupVersion: 'four' };
    expect(validateBackup(p).some((m) => m.includes('backupVersion'))).toBe(true);
  });
});

describe('summarizeBackup', () => {
  it('counts items and shows for the restore preview', () => {
    const s = summarizeBackup(validPayload());
    expect(s).toEqual({ items: 2, shows: 1, exportedAt: 1727200000000 });
  });
});
