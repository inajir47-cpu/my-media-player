// ---------------------------------------------------------------------------
// Repository abstraction over the versioned database. All library reads and
// writes go through here so platform stores can be swapped without touching
// feature code. Writes are debounced where the UI calls them at high
// frequency (progress updates).
// ---------------------------------------------------------------------------

import { getDb, transactionAll } from './db';
import type {
  AppSettings,
  LibraryFolder,
  MediaItem,
  PlaybackEvent,
  ShowGroup,
  UserCollection,
} from './types';
import { DEFAULT_SETTINGS } from './types';
import { logger } from '../shared/logger';

function debounce<T extends (...args: never[]) => void>(fn: T, ms: number): T {
  let timer: ReturnType<typeof setTimeout> | null = null;
  return ((...args: never[]) => {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      timer = null;
      fn(...args);
    }, ms);
  }) as T;
}

export const repository = {
  // -- items ---------------------------------------------------------------
  async getItem(id: string): Promise<MediaItem | undefined> {
    return getDb().items.get(id);
  },
  async getItems(ids: string[]): Promise<MediaItem[]> {
    return getDb().items.where('id').anyOf(ids).toArray();
  },
  async allItems(): Promise<MediaItem[]> {
    return getDb().items.toArray();
  },
  async itemsByFolder(folderId: string): Promise<MediaItem[]> {
    return getDb().items.where('folderId').equals(folderId).toArray();
  },
  async itemsByGroup(groupId: string): Promise<MediaItem[]> {
    return getDb().items.where('groupId').equals(groupId).toArray();
  },
  async upsertItems(items: MediaItem[]): Promise<void> {
    if (items.length === 0) return;
    await getDb().items.bulkPut(items);
  },
  async deleteItems(ids: string[]): Promise<void> {
    if (ids.length === 0) return;
    await getDb().items.bulkDelete(ids);
  },
  async countItems(): Promise<number> {
    return getDb().items.count();
  },

  /** Debounced progress writer: called on every timeupdate; flushed at most 1/s. */
  saveProgress: debounce((id: string, progressMs: number, durationMs?: number) => {
    void getDb()
      .items.update(id, {
        progressMs: Math.floor(progressMs),
        progressUpdatedAt: Date.now(),
        ...(durationMs ? { durationMs: Math.floor(durationMs) } : {}),
      })
      .catch(() => {
        logger.error('repo', 'progress write failed', { id });
      });
  }, 1000),

  async updateItem(id: string, patch: Partial<MediaItem>): Promise<void> {
    await getDb().items.update(id, { ...patch, updatedAt: Date.now() });
  },

  /** Bulk watched-state change (library page, season actions). */
  async bulkMarkWatched(ids: string[], watched: boolean): Promise<void> {
    if (ids.length === 0) return;
    const patch = watched
      ? { watched: true as const, watchedAt: Date.now() }
      : { watched: false as const, watchedAt: undefined };
    await getDb()
      .items.where('id')
      .anyOf(ids)
      .modify({ ...patch, updatedAt: Date.now() });
  },

  /** Factory reset: clears all library data, progress, settings and metadata. */
  async clearAll(): Promise<void> {
    await transactionAll(async () => {
      const db = getDb();
      await db.items.clear();
      await db.shows.clear();
      await db.folders.clear();
      await db.collections.clear();
      await db.playbackEvents.clear();
      await db.settings.clear();
      await db.meta.clear();
    });
    logger.info('repository', 'cleared all data');
  },

  // -- shows ----------------------------------------------------------------
  async getShow(id: string): Promise<ShowGroup | undefined> {
    return getDb().shows.get(id);
  },
  async allShows(): Promise<ShowGroup[]> {
    return getDb().shows.toArray();
  },
  /** All episode items belonging to a show, in season/episode order. */
  async episodesForShow(showId: string): Promise<MediaItem[]> {
    const eps = await getDb().items.where('groupId').equals(showId).toArray();
    return eps
      .filter((e) => e.kind === 'episode')
      .sort((a, b) => (a.season ?? 0) - (b.season ?? 0) || (a.episode ?? 0) - (b.episode ?? 0));
  },
  async upsertShow(show: ShowGroup): Promise<void> {
    await getDb().shows.put(show);
  },
  async deleteShow(id: string): Promise<void> {
    await getDb().shows.delete(id);
  },

  // -- folders ---------------------------------------------------------------
  async allFolders(): Promise<LibraryFolder[]> {
    return getDb().folders.toArray();
  },
  async upsertFolder(folder: LibraryFolder): Promise<void> {
    await getDb().folders.put(folder);
  },
  async deleteFolder(id: string): Promise<void> {
    const db = getDb();
    await db.transaction('rw', db.folders, db.items, async () => {
      await db.folders.delete(id);
      await db.items.where('folderId').equals(id).delete();
    });
  },

  // -- collections ------------------------------------------------------------
  async allCollections(): Promise<UserCollection[]> {
    return getDb().collections.orderBy('updatedAt').reverse().toArray();
  },
  async upsertCollection(collection: UserCollection): Promise<void> {
    await getDb().collections.put(collection);
  },
  async deleteCollection(id: string): Promise<void> {
    await getDb().collections.delete(id);
  },

  // -- playback history --------------------------------------------------------
  async addPlaybackEvent(event: PlaybackEvent): Promise<void> {
    await getDb().playbackEvents.add(event);
    // Keep the history bounded.
    const count = await getDb().playbackEvents.count();
    if (count > 2000) {
      const oldest = await getDb()
        .playbackEvents.orderBy('startedAt')
        .limit(count - 2000)
        .primaryKeys();
      await getDb().playbackEvents.bulkDelete(oldest);
    }
  },
  async eventsForItem(itemId: string, limit = 20): Promise<PlaybackEvent[]> {
    return getDb().playbackEvents.where('itemId').equals(itemId).reverse().limit(limit).toArray();
  },
  async recentPlayed(limit = 50): Promise<PlaybackEvent[]> {
    return getDb().playbackEvents.orderBy('startedAt').reverse().limit(limit).toArray();
  },

  // -- settings ------------------------------------------------------------------
  async getSettings(): Promise<AppSettings> {
    const row = await getDb().settings.get('app');
    return { ...DEFAULT_SETTINGS, ...(row?.value ?? {}) };
  },
  async saveSettings(patch: Partial<AppSettings>): Promise<void> {
    const current = await repository.getSettings();
    await getDb().settings.put({ id: 'app', value: { ...current, ...patch } });
  },

  // -- meta -----------------------------------------------------------------------
  async getMeta(id: string): Promise<string | number | undefined> {
    return (await getDb().meta.get(id))?.value;
  },
  async setMeta(id: string, value: string | number): Promise<void> {
    await getDb().meta.put({ id, value });
  },
};
