// ---------------------------------------------------------------------------
// Platform adapters. ALL platform-specific behavior (secure storage, haptics,
// brightness, volume, orientation, folder access, playable URLs) lives behind
// these typed interfaces. Feature code never touches Capacitor or DOM APIs
// directly.
// ---------------------------------------------------------------------------

import { Capacitor, registerPlugin } from '@capacitor/core';
import { Haptics as CapHaptics, ImpactStyle } from '@capacitor/haptics';
import { Preferences } from '@capacitor/preferences';
import { ScreenOrientation } from '@capacitor/screen-orientation';
import { logger } from '../shared/logger';

export const isNative = Capacitor.isNativePlatform();
export const platformName: 'android' | 'web' = isNative ? 'android' : 'web';

// -- secure storage -----------------------------------------------------------
// On Android, provider API keys are kept in EncryptedSharedPreferences via the
// native MediaBridge plugin. On web they stay in localStorage on the device.

interface MediaBridgePlugin {
  pickFolder(): Promise<{ treeUri: string; displayName: string }>;
  releaseFolder(options: { treeUri: string }): Promise<void>;
  hasPermission(options: { treeUri: string }): Promise<{ granted: boolean }>;
  /** Start the localhost media server; returns base URL like http://127.0.0.1:PORT */
  startMediaServer(): Promise<{ baseUrl: string }>;
  /** Map a content:// URI to a playable localhost URL served from this device. */
  playableUrl(options: { uri: string }): Promise<{ url: string }>;
  listFiles(options: { treeUri: string }): Promise<{ files: NativeFileEntry[] }>;
  setSecureValue(options: { key: string; value: string }): Promise<void>;
  getSecureValue(options: { key: string }): Promise<{ value: string | null }>;
  removeSecureValue(options: { key: string }): Promise<void>;
  setWindowBrightness(options: { value: number }): Promise<void>;
  getWindowBrightness(): Promise<{ value: number }>;
  setVolume(options: { value: number }): Promise<void>;
  getVolume(): Promise<{ value: number }>;
  /** Hand a playable URL to another app (Android intent). The native plugin
   *  must implement this; when it rejects, the UI reports unavailability. */
  openExternal(options: { url: string }): Promise<void>;
}

export interface NativeFileEntry {
  uri: string;
  name: string;
  size: number;
  mtimeMs: number;
  relativePath: string;
}

const MediaBridge = isNative ? registerPlugin<MediaBridgePlugin>('MediaBridge') : null;

export const secureStorage = {
  async set(key: string, value: string): Promise<void> {
    if (MediaBridge) {
      await MediaBridge.setSecureValue({ key, value });
      return;
    }
    localStorage.setItem(`mm.secure.${key}`, value);
  },
  async get(key: string): Promise<string | null> {
    if (MediaBridge) {
      return (await MediaBridge.getSecureValue({ key })).value;
    }
    return localStorage.getItem(`mm.secure.${key}`);
  },
  async remove(key: string): Promise<void> {
    if (MediaBridge) {
      await MediaBridge.removeSecureValue({ key });
      return;
    }
    localStorage.removeItem(`mm.secure.${key}`);
  },
};

// -- haptics --------------------------------------------------------------------

export const haptics = {
  async impact(): Promise<void> {
    if (!isNative) {
      if ('vibrate' in navigator) navigator.vibrate(12);
      return;
    }
    try {
      await CapHaptics.impact({ style: ImpactStyle.Light });
    } catch {
      logger.debug('haptics', 'impact unavailable');
    }
  },
  async selection(): Promise<void> {
    if (!isNative) {
      if ('vibrate' in navigator) navigator.vibrate(8);
      return;
    }
    try {
      await CapHaptics.selectionStart();
      await CapHaptics.selectionEnd();
    } catch {
      logger.debug('haptics', 'selection unavailable');
    }
  },
};

// -- brightness -------------------------------------------------------------------
// Android: adjusts the current app window only (never system settings).
// Web/PWA: browsers expose no display-brightness API, so the player applies a
// visual filter overlay and labels it honestly.

export const brightness = {
  mode: isNative ? 'window' : 'simulated',
  async get(): Promise<number> {
    if (MediaBridge) {
      try {
        return (await MediaBridge.getWindowBrightness()).value;
      } catch {
        return 1;
      }
    }
    return 1;
  },
  async set(value: number): Promise<void> {
    const v = Math.min(1, Math.max(0.05, value));
    if (MediaBridge) {
      await MediaBridge.setWindowBrightness({ value: v }).catch(() => {
        logger.warn('brightness', 'window brightness unavailable');
      });
    }
    // Web: the player reads brightness.current and renders a filter overlay.
    brightness.current = v;
  },
  current: 1,
};

// -- volume ------------------------------------------------------------------------

export const volume = {
  async get(): Promise<number> {
    if (MediaBridge) {
      try {
        return (await MediaBridge.getVolume()).value;
      } catch {
        return 1;
      }
    }
    return 1;
  },
  async set(value: number): Promise<void> {
    const v = Math.min(1, Math.max(0, value));
    if (MediaBridge) {
      await MediaBridge.setVolume({ value: v }).catch(() => {
        logger.warn('volume', 'native volume unavailable');
      });
    }
    // Web: the player element's own volume is the only thing we can change.
    volume.current = v;
  },
  current: 1,
};

// -- orientation ----------------------------------------------------------------------

export const orientation = {
  async lock(mode: 'portrait' | 'landscape'): Promise<void> {
    if (!isNative) return; // PWA: orientation comes from the manifest/device
    try {
      await ScreenOrientation.lock({ orientation: mode });
    } catch {
      logger.debug('orientation', 'lock unavailable');
    }
  },
  async unlock(): Promise<void> {
    if (!isNative) return;
    try {
      await ScreenOrientation.unlock();
    } catch {
      logger.debug('orientation', 'unlock unavailable');
    }
  },
};

// -- lightweight preferences ----------------------------------------------------------

export const prefs = {
  async get(key: string): Promise<string | null> {
    const r = await Preferences.get({ key });
    return r.value;
  },
  async set(key: string, value: string): Promise<void> {
    await Preferences.set({ key, value });
  },
  async remove(key: string): Promise<void> {
    await Preferences.remove({ key });
  },
};

// -- media server (Android localhost streaming of SAF content URIs) ---------------------

let mediaServerBase: string | null = null;

export async function ensureMediaServer(): Promise<string | null> {
  if (!MediaBridge) return null;
  if (mediaServerBase) return mediaServerBase;
  try {
    const { baseUrl } = await MediaBridge.startMediaServer();
    mediaServerBase = baseUrl;
    return baseUrl;
  } catch {
    logger.error('media-server', 'failed to start localhost server');
    return null;
  }
}

export async function nativePlayableUrl(uri: string): Promise<string | null> {
  if (!MediaBridge) return null;
  try {
    const { url } = await MediaBridge.playableUrl({ uri });
    return url;
  } catch {
    return null;
  }
}

export async function nativePickFolder(): Promise<{ treeUri: string; displayName: string } | null> {
  if (!MediaBridge) return null;
  // Safety net: the native picker must always settle. If the result is ever
  // lost (e.g. an unregistered request code), fail loudly instead of hanging.
  return withNativeTimeout(
    MediaBridge.pickFolder(),
    120_000,
    'The folder picker did not respond. Please try again.',
  );
}

export async function nativeListFiles(treeUri: string): Promise<NativeFileEntry[]> {
  if (!MediaBridge) return [];
  return withNativeTimeout(
    MediaBridge.listFiles({ treeUri }).then((r) => r.files),
    180_000,
    'Listing that folder took too long. Try a smaller folder.',
  );
}

/** Reject if a native bridge call never settles, so the UI can never hang forever. */
function withNativeTimeout<T>(promise: Promise<T>, ms: number, message: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new Error(message)), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

export async function nativeHasPermission(treeUri: string): Promise<boolean> {
  if (!MediaBridge) return false;
  try {
    return (await MediaBridge.hasPermission({ treeUri })).granted;
  } catch {
    return false;
  }
}

export async function nativeReleaseFolder(treeUri: string): Promise<void> {
  if (!MediaBridge) return;
  await MediaBridge.releaseFolder({ treeUri }).catch(() => undefined);
}

// -- app PIN (explicitly NOT encryption) -------------------------------------------
// Optional lock that keeps casual viewers out of the app. The PIN itself is
// never stored — only a salted SHA-256 hash in app preferences. This is an
// honesty lock, not encryption: it does not protect the files or database.

const PIN_KEY = 'app.pinHash';

async function sha256Hex(input: string): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(input));
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

/** Store a new PIN (4-8 digits). */
export async function setPin(pin: string): Promise<void> {
  if (!/^\d{4,8}$/.test(pin)) throw new Error('PIN must be 4–8 digits.');
  const salt = crypto
    .getRandomValues(new Uint8Array(16))
    .reduce((s, b) => s + b.toString(16).padStart(2, '0'), '');
  const hash = await sha256Hex(`${salt}:${pin}`);
  await prefs.set(PIN_KEY, `${salt}:${hash}`);
}

/** True when a PIN is currently set. */
export async function hasPin(): Promise<boolean> {
  return (await prefs.get(PIN_KEY)) != null;
}

/** Verify a PIN attempt against the stored hash. */
export async function verifyPin(pin: string): Promise<boolean> {
  const stored = await prefs.get(PIN_KEY);
  if (!stored) return false;
  const [salt, hash] = stored.split(':');
  if (!salt || !hash) return false;
  return (await sha256Hex(`${salt}:${pin}`)) === hash;
}

/** Remove the PIN. */
export async function clearPin(): Promise<void> {
  await prefs.remove(PIN_KEY);
}

// -- confirm dialog ----------------------------------------------------------------

/**
 * Confirmation dialog. On Android this will use the native dialog once the
 * MediaBridge exposes one; today it falls back to window.confirm honestly.
 */
export function confirmNative(message: string): Promise<boolean> {
  if (typeof window !== 'undefined' && typeof window.confirm === 'function') {
    return Promise.resolve(window.confirm(message));
  }
  return Promise.resolve(false);
}

// -- external player ---------------------------------------------------------------

/**
 * Hand a playable URL to another app on the device (Android intent).
 * Returns false when there is no native bridge or it refuses — the player
 * then hides the option instead of pretending it worked.
 */
export async function openExternalPlayer(url: string): Promise<boolean> {
  if (!MediaBridge) return false;
  try {
    await MediaBridge.openExternal({ url });
    return true;
  } catch {
    logger.warn('external-player', 'bridge openExternal unavailable');
    return false;
  }
}
