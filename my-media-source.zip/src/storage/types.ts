// ---------------------------------------------------------------------------
// Storage types shared by the database, repositories and backup files.
// ---------------------------------------------------------------------------

export type ItemKind = 'movie' | 'episode' | 'audio';
export type LibrarySection = 'movie' | 'show' | 'audio';

export interface ArtworkRef {
  /** Local blob/object URL, content:// URI or cached file path. Never remote by default. */
  uri?: string;
  /** When the artwork was cached (ms epoch). Used for LRU eviction. */
  cachedAt?: number;
}

export interface LocalRating {
  stars: number; // 0.5 .. 5 in 0.5 steps
  updatedAt: number;
}

export interface LocalReview {
  id: string;
  title: string;
  body: string;
  stars: number; // 0.5 .. 5
  spoiler: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface ProviderReview {
  author: string;
  body: string;
  stars?: number;
  source: string; // provider name, e.g. "TMDB"
  url?: string;
}

export interface TechnicalInfo {
  container?: string;
  videoCodec?: string;
  audioCodec?: string;
  width?: number;
  height?: number;
  fps?: number;
  bitrateKbps?: number;
  unsupportedReason?: string;
}

/** A sidecar subtitle file attached to an item at scan time. */
export interface SubtitleTrack {
  /** Same URI scheme as MediaItem.uri (fsa:, input:, native:, …). */
  uri: string;
  /** Display label, e.g. "English" or "External". */
  label: string;
  /** BCP-47-ish language code when the filename carries one. */
  lang?: string;
}

export interface MediaItem {
  id: string; // stable: hash of dedupe key
  /** Stable file identity: uri + size + mtime. */
  uri: string;
  fileName: string;
  sizeBytes: number;
  mtimeMs: number;
  folderId: string;
  kind: ItemKind;
  title: string;
  sortTitle: string;
  year?: number;
  season?: number;
  episode?: number;
  absoluteEpisode?: number;
  synopsis?: string;
  genres: string[];
  maturity?: string;
  cast: string[];
  crew: { name: string; role: string }[];
  durationMs?: number;
  poster: ArtworkRef;
  backdrop: ArtworkRef;
  thumbnail: ArtworkRef;
  /** Sidecar subtitle files matched by filename at scan time. */
  subtitleTracks: SubtitleTrack[];
  // Playback state
  progressMs: number;
  progressUpdatedAt: number;
  watched: boolean;
  watchedAt?: number;
  playCount: number;
  lastPlayedAt?: number;
  // User state
  favorite: boolean;
  watchlist: boolean;
  localRating?: LocalRating;
  localReview?: LocalReview;
  providerReviews: ProviderReview[];
  providerName?: string; // which metadata provider supplied enriched data
  providerId?: string; // provider's own id for this title (for public reviews)
  matchSource?: 'filename' | 'nfo' | 'provider' | 'manual';
  matchConfidence?: number; // 0..1, shown on match-review screen
  // Preview engine
  previewStartMs?: number;
  previewLengthMs?: number;
  previewDisabled?: boolean;
  // Grouping
  groupId?: string; // show id for episodes; movie id for movies
  addedAt: number;
  updatedAt: number;
  missing: boolean; // file unreachable but metadata kept
  technical: TechnicalInfo;
}

export interface ShowGroup {
  id: string;
  title: string;
  sortTitle: string;
  section: LibrarySection;
  years: { from?: number; to?: number };
  synopsis?: string;
  genres: string[];
  maturity?: string;
  cast: string[];
  poster: ArtworkRef;
  backdrop: ArtworkRef;
  favorite: boolean;
  watchlist: boolean;
  localRating?: LocalRating;
  localReview?: LocalReview;
  providerReviews: ProviderReview[];
  providerName?: string;
  providerId?: string;
  matchSource?: 'filename' | 'nfo' | 'provider' | 'manual';
  matchConfidence?: number;
  previewDisabled?: boolean;
  addedAt: number;
  updatedAt: number;
}

export interface LibraryFolder {
  id: string;
  /** Display name (never the raw URI in logs). */
  name: string;
  /** Platform-specific stable reference: content tree URI (Android), opaque id (web). */
  ref: string;
  platform: 'android' | 'web';
  addedAt: number;
  lastScannedAt?: number;
}

export interface UserCollection {
  id: string;
  name: string;
  itemIds: string[]; // ordered
  createdAt: number;
  updatedAt: number;
}

export interface PlaybackEvent {
  id: string;
  itemId: string;
  startedAt: number;
  endedAt?: number;
  fromMs: number;
  toMs: number;
}

export interface AppSettings {
  theme: 'dark' | 'light';
  density: 'comfortable' | 'compact';
  reduceMotion: boolean;
  reduceTransparency: boolean;
  highContrast: boolean;
  haptics: boolean;
  autoplayNext: boolean;
  resumeBehavior: 'ask' | 'always' | 'never';
  seekIntervalSec: number;
  defaultSpeed: number;
  previewEnabled: boolean;
  previewLengthSec: number;
  heroRotationSec: number;
  watchedThreshold: number; // 0..1, default 0.9
  wifiOnlyMetadata: boolean;
  defaultAudioLang: string;
  defaultSubtitleLang: string;
  subtitleStyle: { size: number; color: string; background: string; position: 'bottom' | 'top' };
  subtitleDelayMs: number;
  audioDelayMs: number;
  orientation: 'auto' | 'portrait' | 'landscape';
  pinHash?: string; // salted hash, never the PIN
  gestures: Record<string, GestureBinding>;
  metadataProvider?: string;
  diagnosticsOptIn: boolean;
  // Extended preferences (added as the UI grew; all optional for old rows).
  homeSections: string[];
  cardPreviewMode: 'hover' | 'longpress' | 'off';
  autoplayDelaySec: number;
  sleepTimerMin: number;
  skipIntroAuto: boolean;
  startMuted: boolean;
  fontScale: number;
  locale: 'en' | 'ar';
  dpadHints: boolean;
  autoScanOnLaunch: boolean;
  generateThumbnails: boolean;
  preferLocalMetadata: boolean;
  cacheProviderResponses: boolean;
  tabletDensity: 'comfortable' | 'compact';
  shareCrashReports: boolean;
  includeFullPathsInDiagnostics: boolean;
}

export type GestureId =
  | 'tap'
  | 'doubleTapLeft'
  | 'doubleTapRight'
  | 'doubleTapCenter'
  | 'swipeHorizontal'
  | 'swipeVerticalLeft'
  | 'swipeVerticalRight'
  | 'pinch'
  | 'twoFingerTap'
  | 'longPress';

export interface GestureBinding {
  enabled: boolean;
  /** Action identifier the player executes; 'none' disables. */
  action: string;
}

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'dark',
  density: 'comfortable',
  reduceMotion: false,
  reduceTransparency: false,
  highContrast: false,
  haptics: true,
  autoplayNext: true,
  resumeBehavior: 'ask',
  seekIntervalSec: 10,
  defaultSpeed: 1,
  previewEnabled: true,
  previewLengthSec: 12,
  heroRotationSec: 20,
  watchedThreshold: 0.9,
  wifiOnlyMetadata: true,
  defaultAudioLang: '',
  defaultSubtitleLang: '',
  subtitleStyle: { size: 100, color: '#ffffff', background: 'rgba(0,0,0,0.6)', position: 'bottom' },
  subtitleDelayMs: 0,
  audioDelayMs: 0,
  orientation: 'auto',
  diagnosticsOptIn: false,
  homeSections: [
    'continue-watching',
    'recently-added',
    'favorites',
    'watchlist',
    'movies',
    'shows',
    'recently-played',
    'collections',
    'hero',
  ],
  cardPreviewMode: 'hover',
  autoplayDelaySec: 10,
  sleepTimerMin: 0,
  skipIntroAuto: true,
  startMuted: false,
  fontScale: 1,
  locale: 'en',
  dpadHints: true,
  autoScanOnLaunch: true,
  generateThumbnails: true,
  preferLocalMetadata: true,
  cacheProviderResponses: true,
  tabletDensity: 'comfortable',
  shareCrashReports: false,
  includeFullPathsInDiagnostics: false,
  gestures: {
    tap: { enabled: true, action: 'toggleControls' },
    doubleTapLeft: { enabled: true, action: 'rewind' },
    doubleTapRight: { enabled: true, action: 'forward' },
    doubleTapCenter: { enabled: true, action: 'togglePlay' },
    swipeHorizontal: { enabled: true, action: 'scrub' },
    swipeVerticalLeft: { enabled: true, action: 'brightness' },
    swipeVerticalRight: { enabled: true, action: 'volume' },
    pinch: { enabled: true, action: 'zoom' },
    twoFingerTap: { enabled: true, action: 'togglePlay' },
    longPress: { enabled: true, action: 'temp2x' },
  },
};
