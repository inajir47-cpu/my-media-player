import { describe, expect, it } from 'vitest';
import { DEFAULT_SETTINGS } from './types';

describe('DEFAULT_SETTINGS', () => {
  it('defaults to the dark cinematic theme', () => {
    expect(DEFAULT_SETTINGS.theme).toBe('dark');
  });

  it('matches the documented playback defaults', () => {
    expect(DEFAULT_SETTINGS.seekIntervalSec).toBe(10);
    expect(DEFAULT_SETTINGS.defaultSpeed).toBe(1);
    expect(DEFAULT_SETTINGS.watchedThreshold).toBe(0.9);
    expect(DEFAULT_SETTINGS.resumeBehavior).toBe('ask');
    expect(DEFAULT_SETTINGS.autoplayNext).toBe(true);
    expect(DEFAULT_SETTINGS.autoplayDelaySec).toBe(10);
  });

  it('matches the documented preview defaults', () => {
    expect(DEFAULT_SETTINGS.previewEnabled).toBe(true);
    expect(DEFAULT_SETTINGS.previewLengthSec).toBe(12);
  });

  it('keeps privacy-sensitive options off by default', () => {
    expect(DEFAULT_SETTINGS.diagnosticsOptIn).toBe(false);
    expect(DEFAULT_SETTINGS.wifiOnlyMetadata).toBe(true);
    expect(DEFAULT_SETTINGS.pinHash).toBeUndefined();
  });

  it('exposes the required settings groups', () => {
    const keys = Object.keys(DEFAULT_SETTINGS);
    for (const k of [
      'theme',
      'subtitleStyle',
      'subtitleDelayMs',
      'audioDelayMs',
      'gestures',
      'homeSections',
      'locale',
      'fontScale',
    ]) {
      expect(keys).toContain(k);
    }
  });
});
