// ---------------------------------------------------------------------------
// Human-readable JSON backup: export/import of the app database.
// Video files are never included. Secrets (provider API keys, PIN hash) are
// never included in backups or exported settings.
// ---------------------------------------------------------------------------

import { DB_VERSION } from '../config';
import { getDb, transactionAll } from './db';
import { DEFAULT_SETTINGS, type AppSettings } from './types';
import { logger } from '../shared/logger';

export interface BackupPayload {
  app: 'my-media';
  backupVersion: number;
  exportedAt: number;
  items: unknown[];
  shows: unknown[];
  collections: unknown[];
  folders: unknown[];
  settings: Partial<AppSettings>;
}

const REQUIRED_TOP_LEVEL = [
  'app',
  'backupVersion',
  'exportedAt',
  'items',
  'shows',
  'collections',
  'settings',
] as const;

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}

/**
 * Validate an imported backup payload. Returns a list of human-readable
 * problems; empty means the payload is safe to preview/apply.
 */
export function validateBackup(payload: unknown): string[] {
  const problems: string[] = [];
  if (!isRecord(payload)) return ['Backup file is not a JSON object.'];
  for (const key of REQUIRED_TOP_LEVEL) {
    if (!(key in payload)) problems.push(`Missing required section: "${key}".`);
  }
  if (payload['app'] !== 'my-media') problems.push('This backup was not created by My Media.');
  if (typeof payload['backupVersion'] !== 'number') problems.push('"backupVersion" must be a number.');
  for (const key of ['items', 'shows', 'collections'] as const) {
    if (key in payload && !Array.isArray(payload[key])) problems.push(`"${key}" must be an array.`);
  }
  if ('settings' in payload && !isRecord(payload['settings'])) problems.push('"settings" must be an object.');
  // Item-level sanity: every item needs an id and a uri.
  if (Array.isArray(payload['items'])) {
    const bad = (payload['items'] as unknown[]).filter(
      (it) => !isRecord(it) || typeof it['id'] !== 'string' || typeof it['uri'] !== 'string',
    ).length;
    if (bad > 0) problems.push(`${bad} library item(s) are missing an id or file reference.`);
  }
  // Secrets must never ride along in a backup.
  if (isRecord(payload['settings'])) {
    const s = payload['settings'];
    if ('pinHash' in s) problems.push('Backup contains a PIN hash and will be rejected for safety.');
  }
  return problems;
}

/** Build an export payload from the live database (secrets stripped). */
export async function exportBackup(): Promise<BackupPayload> {
  const db = getDb();
  const [items, shows, collections, folders, settingsRow] = await Promise.all([
    db.items.toArray(),
    db.shows.toArray(),
    db.collections.toArray(),
    db.folders.toArray(),
    db.settings.get('app'),
  ]);
  const settings: Partial<AppSettings> = { ...(settingsRow?.value ?? DEFAULT_SETTINGS) };
  delete settings.pinHash; // never export the lock secret
  // Strip volatile blob: URLs — they cannot survive a restore.
  const scrubbedItems = items.map((item) => ({
    ...item,
    poster: { cachedAt: item.poster.cachedAt },
    backdrop: { cachedAt: item.backdrop.cachedAt },
    thumbnail: { cachedAt: item.thumbnail.cachedAt },
  }));
  logger.info('backup', 'exported backup', { items: items.length, shows: shows.length });
  return {
    app: 'my-media',
    backupVersion: DB_VERSION,
    exportedAt: Date.now(),
    items: scrubbedItems,
    shows,
    collections,
    folders: folders.map((f) => ({ ...f })),
    settings,
  };
}

/** Summarize a validated payload for the restore-preview screen. */
export function summarizeBackup(payload: BackupPayload): {
  items: number;
  shows: number;
  exportedAt: number;
} {
  return {
    items: Array.isArray(payload.items) ? payload.items.length : 0,
    shows: Array.isArray(payload.shows) ? payload.shows.length : 0,
    exportedAt: payload.exportedAt,
  };
}

export interface ImportReport {
  exportedAt: number;
  counts: { items: number; shows: number; collections: number; reviews: number; invalid: number };
  problems: string[];
}

function countReviews(payload: BackupPayload): number {
  let n = 0;
  for (const list of [payload.items, payload.shows]) {
    if (Array.isArray(list)) {
      for (const rec of list) {
        if (rec && typeof rec === 'object' && (rec as Record<string, unknown>)['localReview']) n += 1;
      }
    }
  }
  return n;
}

/**
 * Import a backup from its JSON text. With dryRun=true only validates and
 * reports; with dryRun=false replaces current library data.
 */
export async function importBackupFile(text: string, dryRun: boolean): Promise<ImportReport> {
  let parsed: unknown;
  try {
    parsed = JSON.parse(text) as unknown;
  } catch {
    throw new Error('Backup file is not valid JSON.');
  }
  const problems = validateBackup(parsed);
  const payload = parsed as BackupPayload;
  const report: ImportReport = {
    exportedAt: typeof payload?.exportedAt === 'number' ? payload.exportedAt : 0,
    counts: {
      items: Array.isArray(payload?.items) ? payload.items.length : 0,
      shows: Array.isArray(payload?.shows) ? payload.shows.length : 0,
      collections: Array.isArray(payload?.collections) ? payload.collections.length : 0,
      reviews: countReviews(payload),
      invalid: problems.length,
    },
    problems,
  };
  if (!dryRun) {
    await importBackup(payload);
  }
  return report;
}

/** Download the current database as a JSON backup file. */
export async function exportBackupFile(): Promise<void> {
  const payload = await exportBackup();
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const date = new Date(payload.exportedAt).toISOString().slice(0, 10);
  a.href = url;
  a.download = `my-media-backup-${date}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => {
    URL.revokeObjectURL(url);
  }, 5000);
  logger.info('backup', 'exported backup file', { items: payload.items.length });
}

/** Replace current library data with a validated backup payload. */
export async function importBackup(payload: BackupPayload): Promise<void> {
  const problems = validateBackup(payload);
  if (problems.length > 0) {
    throw new Error(`Backup validation failed: ${problems.join(' ')}`);
  }
  const db = getDb();
  await transactionAll(async () => {
    await db.items.clear();
    await db.shows.clear();
    await db.collections.clear();
    await db.folders.clear();
    // Types are validated structurally above; cast narrowly for Dexie.
    await db.items.bulkAdd(payload.items as never[]);
    await db.shows.bulkAdd(payload.shows as never[]);
    await db.collections.bulkAdd(payload.collections as never[]);
    if (Array.isArray(payload.folders)) await db.folders.bulkAdd(payload.folders as never[]);
    const current = (await db.settings.get('app'))?.value ?? DEFAULT_SETTINGS;
    await db.settings.put({ id: 'app', value: { ...current, ...payload.settings } });
  });
  logger.info('backup', 'imported backup', summarizeBackup(payload));
}
