// ---------------------------------------------------------------------------
// Versioned local database (IndexedDB via Dexie on web; the same schema is
// used inside the Android WebView, so one codebase covers both platforms).
// Migrations are deterministic and additive; v4 is current.
// ---------------------------------------------------------------------------

import Dexie, { type Table } from 'dexie';
import { DB_NAME, DB_VERSION } from '../config';
import type {
  AppSettings,
  LibraryFolder,
  MediaItem,
  PlaybackEvent,
  ShowGroup,
  UserCollection,
} from './types';

export interface SettingsRow {
  id: 'app';
  value: AppSettings;
}

export interface MetaRow {
  id: string;
  value: string | number;
}

export class MediaDatabase extends Dexie {
  items!: Table<MediaItem, string>;
  shows!: Table<ShowGroup, string>;
  folders!: Table<LibraryFolder, string>;
  collections!: Table<UserCollection, string>;
  playbackEvents!: Table<PlaybackEvent, string>;
  settings!: Table<SettingsRow, string>;
  meta!: Table<MetaRow, string>;

  constructor() {
    super(DB_NAME);

    // v1: initial schema
    this.version(1).stores({
      items:
        'id, folderId, groupId, kind, sortTitle, addedAt, lastPlayedAt, favorite, watchlist, watched, missing',
      shows: 'id, sortTitle, favorite, watchlist',
      folders: 'id, addedAt',
      collections: 'id, updatedAt',
      playbackEvents: 'id, itemId, startedAt',
      settings: 'id',
      meta: 'id',
    });

    // v2: search index support — compound index for title prefix queries
    this.version(2).stores({
      items:
        'id, folderId, groupId, kind, sortTitle, title, addedAt, lastPlayedAt, favorite, watchlist, watched, missing',
      shows: 'id, sortTitle, title, favorite, watchlist',
    });

    // v3: preview timing persistence + technical info index
    this.version(3).stores({
      items:
        'id, folderId, groupId, kind, sortTitle, title, addedAt, lastPlayedAt, favorite, watchlist, watched, missing, updatedAt',
    });

    // v4: sidecar subtitle tracks attached at scan time (backfilled empty)
    this.version(4)
      .stores({
        items:
          'id, folderId, groupId, kind, sortTitle, title, addedAt, lastPlayedAt, favorite, watchlist, watched, missing, updatedAt',
      })
      .upgrade((tx) =>
        tx
          .table<MediaItem>('items')
          .toCollection()
          .modify((item) => {
            if (!Array.isArray(item.subtitleTracks)) item.subtitleTracks = [];
          }),
      );
  }
}

let dbInstance: MediaDatabase | null = null;

/**
 * Run a read/write transaction across ALL tables. Dexie's typed
 * `transaction()` overloads cap the number of tables, so this uses the
 * dynamic form with an explicit cast for full-database operations
 * (factory reset, backup import).
 */
export async function transactionAll(scope: () => Promise<void>): Promise<void> {
  const db = getDb();
  // eslint-disable-next-line @typescript-eslint/unbound-method -- rebound via .call(db, …) below
  const tx = db.transaction as unknown as (mode: string, ...args: unknown[]) => Promise<void>;
  await tx.call(
    db,
    'rw',
    db.items,
    db.shows,
    db.folders,
    db.collections,
    db.playbackEvents,
    db.settings,
    db.meta,
    scope,
  );
}

/** Singleton database handle. */
export function getDb(): MediaDatabase {
  if (!dbInstance) {
    dbInstance = new MediaDatabase();
  }
  return dbInstance;
}

/**
 * Open the database, running migrations. On corruption, attempt a
 * non-destructive recovery: back up what is readable into a JSON dump kept in
 * memory, delete the broken database, recreate it, and return the dump so the
 * UI can offer a restore.
 */
export async function openDatabase(): Promise<{ recovered: boolean; dump?: string }> {
  const db = getDb();
  try {
    await db.open();
    return { recovered: false };
  } catch {
    // Corruption recovery path: salvage readable tables.
    try {
      const dump: Record<string, unknown[]> = {};
      for (const table of ['items', 'shows', 'folders', 'collections', 'settings'] as const) {
        try {
          dump[table] = await (db.table(table) as Dexie.Table<Record<string, unknown>, string>)
            .toArray()
            .catch(() => []);
        } catch {
          dump[table] = [];
        }
      }
      await db.delete();
      dbInstance = new MediaDatabase();
      await dbInstance.open();
      return { recovered: true, dump: JSON.stringify({ version: DB_VERSION, salvagedAt: Date.now(), dump }) };
    } catch {
      // Last resort: start empty rather than crash the app.
      await db.delete().catch(() => undefined);
      dbInstance = new MediaDatabase();
      await dbInstance.open();
      return { recovered: true };
    }
  }
}

/** Non-destructive full reindex: clears derived grouping, keeps user data. */
export async function rebuildIndex(): Promise<void> {
  const db = getDb();
  await db.transaction('rw', db.items, db.shows, async () => {
    await db.shows.clear();
    await db.items.toCollection().modify((item) => {
      item.groupId = undefined;
    });
  });
}

export { DB_VERSION };
