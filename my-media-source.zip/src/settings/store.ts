// ---------------------------------------------------------------------------
// Settings store: typed preferences with subscription. Persisted via the
// repository; defaults come from DEFAULT_SETTINGS in storage/types.ts.
// ---------------------------------------------------------------------------

import { useSyncExternalStore } from 'react';
import { repository } from '../storage/repository';
import { DEFAULT_SETTINGS, type AppSettings } from '../storage/types';

let settings: AppSettings = { ...DEFAULT_SETTINGS };
let loaded = false;
const listeners = new Set<() => void>();

function emit(): void {
  for (const l of listeners) l();
}

export async function loadSettings(): Promise<AppSettings> {
  settings = await repository.getSettings();
  loaded = true;
  emit();
  return settings;
}

export function getSettings(): AppSettings {
  return settings;
}

export function isSettingsLoaded(): boolean {
  return loaded;
}

/** Update settings (persisted). */
export async function updateSettings(patch: Partial<AppSettings>): Promise<void> {
  settings = { ...settings, ...patch };
  emit();
  await repository.saveSettings(patch);
}

export function subscribeSettings(listener: () => void): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

/** React hook for settings access. */
export function useSettings(): AppSettings {
  return useSyncExternalStore(subscribeSettings, () => settings);
}

/** Partial update of a single gesture binding. */
export async function updateGesture(
  id: keyof AppSettings['gestures'],
  patch: Partial<AppSettings['gestures'][keyof AppSettings['gestures']]>,
): Promise<void> {
  await updateSettings({
    gestures: { ...settings.gestures, [id]: { ...settings.gestures[id]!, ...patch } },
  });
}

/** System preference probes (reduced motion/transparency, contrast). */
export function systemPreferences(): {
  reduceMotion: boolean;
  reduceTransparency: boolean;
  highContrast: boolean;
} {
  if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') {
    return { reduceMotion: false, reduceTransparency: false, highContrast: false };
  }
  return {
    reduceMotion: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    reduceTransparency: window.matchMedia('(prefers-reduced-transparency: reduce)').matches,
    highContrast: window.matchMedia('(prefers-contrast: more)').matches,
  };
}

/** Effective preview permission: setting AND system prefs AND battery saver. */
export function previewsAllowed(s: AppSettings): boolean {
  if (!s.previewEnabled) return false;
  const sys = systemPreferences();
  if (sys.reduceMotion || s.reduceMotion) return false;
  return true;
}
