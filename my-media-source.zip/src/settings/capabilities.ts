// ---------------------------------------------------------------------------
// Capability detection: what the current device/browser can actually do.
// The UI disables or explains features instead of showing fake controls.
// ---------------------------------------------------------------------------

import { isNative } from '../storage/adapters';

export interface Capabilities {
  pictureInPicture: boolean;
  fullscreen: boolean;
  orientationLock: boolean;
  systemBrightness: boolean; // native window brightness
  systemVolume: boolean; // native media-stream volume
  haptics: boolean;
  wakeLock: boolean;
  fileSystemAccess: boolean;
  share: boolean;
  dpad: boolean; // coarse: TV/remote-ish environment
}

let cached: Capabilities | null = null;

export function getCapabilities(): Capabilities {
  if (cached) return cached;
  const video = typeof document !== 'undefined' ? document.createElement('video') : null;
  cached = {
    pictureInPicture:
      !!video &&
      typeof (video as HTMLVideoElement & { requestPictureInPicture?: unknown }).requestPictureInPicture ===
        'function' &&
      !isNative,
    fullscreen: typeof document !== 'undefined' && !!document.documentElement.requestFullscreen,
    orientationLock: isNative,
    systemBrightness: isNative,
    systemVolume: isNative,
    haptics: isNative || (typeof navigator !== 'undefined' && 'vibrate' in navigator),
    wakeLock: typeof navigator !== 'undefined' && 'wakeLock' in navigator,
    fileSystemAccess:
      typeof window !== 'undefined' &&
      typeof (window as unknown as { showDirectoryPicker?: unknown }).showDirectoryPicker === 'function',
    share: typeof navigator !== 'undefined' && typeof navigator.share === 'function',
    dpad: typeof window !== 'undefined' && !window.matchMedia?.('(pointer: coarse)')?.matches && isNative,
  };
  return cached;
}

/** Container formats the built-in player is expected to decode. */
export function isFormatSupported(extension: string): { supported: boolean; reason?: string } {
  const ext = extension.toLowerCase();
  if (isNative) {
    // Android's platform decoders handle these in the WebView media pipeline.
    if (
      ['mp4', 'm4v', 'webm', 'mkv', 'mov', 'mp3', 'aac', 'm4a', 'flac', 'ogg', 'oga', 'wav'].includes(ext)
    ) {
      return { supported: true };
    }
  } else {
    const video = document.createElement('video');
    const audio = document.createElement('audio');
    const mime: Record<string, string> = {
      mp4: 'video/mp4',
      m4v: 'video/mp4',
      webm: 'video/webm',
      mov: 'video/quicktime',
      mp3: 'audio/mpeg',
      aac: 'audio/aac',
      m4a: 'audio/mp4',
      flac: 'audio/flac',
      ogg: 'audio/ogg',
      oga: 'audio/ogg',
      wav: 'audio/wav',
    };
    const m = mime[ext];
    if (m) {
      const probe = m.startsWith('video') ? video.canPlayType(m) : audio.canPlayType(m);
      if (probe === 'probably' || probe === 'maybe') return { supported: true };
      return { supported: false, reason: `This browser reports it cannot decode .${ext} files.` };
    }
  }
  return { supported: false, reason: `The .${ext} format is not supported on this device.` };
}
