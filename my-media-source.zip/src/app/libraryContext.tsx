// ---------------------------------------------------------------------------
// Library context: the single source of truth for library UI state.
// Wraps the repository + scanner + indexer; exposes refresh/scan actions.
// ---------------------------------------------------------------------------

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { repository } from '../storage/repository';
import type { LibraryFolder, MediaItem, UserCollection } from '../storage/types';
import { rebuildShowGroups, type ShowSummary } from '../library/indexer';
import { scanFolder, type FileWalker } from '../library/scanner';
import type { ScanStats } from '../library/types';
import {
  fsaWalker,
  inputFileWalker,
  nativeWalker,
  storeDirectoryHandle,
  storeFallbackBlobs,
  storeItemBlob,
  supportsFileSystemAccess,
  getDirectoryHandle,
} from '../library/walkers';
import { isNative, nativePickFolder, nativeHasPermission } from '../storage/adapters';
import { logger } from '../shared/logger';

export interface ScanState {
  running: boolean;
  folderId?: string;
  stats?: ScanStats;
}

interface LibraryContextValue {
  ready: boolean;
  recovered: boolean;
  items: MediaItem[];
  shows: ShowSummary[];
  folders: LibraryFolder[];
  collections: UserCollection[];
  scan: ScanState;
  refresh: () => Promise<void>;
  startScan: (folderId: string) => Promise<void>;
  cancelScan: () => void;
  addFolder: () => Promise<{ ok: boolean; reason?: string }>;
  addFilesFallback: (files: File[]) => Promise<void>;
  removeFolder: (folderId: string) => Promise<void>;
}

const LibraryContext = createContext<LibraryContextValue | null>(null);

function uid(prefix: string): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export function LibraryProvider({ children }: { children: ReactNode }): ReactNode {
  const [ready, setReady] = useState(false);
  const [recovered, setRecovered] = useState(false);
  const [items, setItems] = useState<MediaItem[]>([]);
  const [shows, setShows] = useState<ShowSummary[]>([]);
  const [folders, setFolders] = useState<LibraryFolder[]>([]);
  const [collections, setCollections] = useState<UserCollection[]>([]);
  const [scan, setScan] = useState<ScanState>({ running: false });
  const cancelRef = useRef(false);

  const refresh = useCallback(async () => {
    const [allItems, allFolders, allCollections] = await Promise.all([
      repository.allItems(),
      repository.allFolders(),
      repository.allCollections(),
    ]);
    const summaries = await rebuildShowGroups();
    setItems(allItems);
    setShows(summaries);
    setFolders(allFolders);
    setCollections(allCollections);
  }, []);

  useEffect(() => {
    void (async () => {
      const { openDatabase } = await import('../storage/db');
      const { recovered: rec } = await openDatabase();
      setRecovered(rec);
      await refresh();
      setReady(true);
    })();
  }, [refresh]);

  const startScan = useCallback(
    async (folderId: string) => {
      const folder = (await repository.allFolders()).find((f) => f.id === folderId);
      if (!folder || scan.running) return;
      cancelRef.current = false;
      setScan({ running: true, folderId });
      let walker: FileWalker;
      if (isNative) {
        const granted = await nativeHasPermission(folder.ref);
        if (!granted) {
          setScan({ running: false });
          logger.warn('library', 'scan aborted: permission lost', { folderId });
          return;
        }
        walker = nativeWalker();
      } else if (folder.platform === 'web' && folder.ref.startsWith('fsa:')) {
        walker = fsaWalker(folder.ref.slice(4));
      } else {
        // Fallback folders store blobs; rescan re-lists stored files.
        walker = inputFileWalker([]);
      }
      try {
        await scanFolder(folderId, folder.ref, folder.name, walker, {
          onProgress: (stats) => {
            setScan({ running: true, folderId, stats });
          },
          isCancelled: () => cancelRef.current,
        });
        await repository.upsertFolder({ ...folder, lastScannedAt: Date.now() });
      } finally {
        setScan({ running: false });
        await refresh();
      }
    },
    [refresh, scan.running],
  );

  const cancelScan = useCallback(() => {
    cancelRef.current = true;
  }, []);

  const addFolder = useCallback(async (): Promise<{ ok: boolean; reason?: string }> => {
    if (isNative) {
      let picked: { treeUri: string; displayName: string } | null;
      try {
        picked = await nativePickFolder();
      } catch (e) {
        return { ok: false, reason: e instanceof Error ? e.message : 'Folder picker failed.' };
      }
      if (!picked) return { ok: false, reason: 'cancelled' };
      const folder: LibraryFolder = {
        id: uid('folder'),
        name: picked.displayName || 'Media folder',
        ref: picked.treeUri,
        platform: 'android',
        addedAt: Date.now(),
      };
      await repository.upsertFolder(folder);
      await refresh();
      try {
        await startScan(folder.id);
      } catch (e) {
        return { ok: false, reason: e instanceof Error ? e.message : 'Scan failed.' };
      }
      return { ok: true };
    }
    if (supportsFileSystemAccess()) {
      const { pickDirectoryHandle } = await import('../library/walkers');
      const picked = await pickDirectoryHandle();
      if (!picked) return { ok: false, reason: 'cancelled' };
      const folder: LibraryFolder = {
        id: uid('folder'),
        name: picked.name,
        ref: `fsa:${uid('fsa')}`,
        platform: 'web',
        addedAt: Date.now(),
      };
      const folderId = folder.id;
      await storeDirectoryHandle(folderId, picked.handle);
      folder.ref = `fsa:${folderId}`;
      await repository.upsertFolder(folder);
      await refresh();
      await startScan(folder.id);
      return { ok: true };
    }
    return { ok: false, reason: 'needs-file-input' };
  }, [refresh, startScan]);

  const addFilesFallback = useCallback(
    async (files: File[]) => {
      if (files.length === 0) return;
      const folder: LibraryFolder = {
        id: uid('folder'),
        name: `Selected files (${files.length})`,
        ref: `input:${uid('input')}`,
        platform: 'web',
        addedAt: Date.now(),
      };
      await repository.upsertFolder(folder);
      await storeFallbackBlobs(files);
      cancelRef.current = false;
      setScan({ running: true, folderId: folder.id });
      try {
        await scanFolder(folder.id, folder.ref, folder.name, inputFileWalker(files), {
          onProgress: (stats) => {
            setScan({ running: true, folderId: folder.id, stats });
          },
          isCancelled: () => cancelRef.current,
        });
        // Persist blobs per item for playback after reload.
        const scanned = await repository.itemsByFolder(folder.id);
        const fileByRel = new Map<string, File>();
        for (const f of files) {
          fileByRel.set((f as File & { webkitRelativePath?: string }).webkitRelativePath || f.name, f);
        }
        for (const item of scanned) {
          const rel = item.uri.slice('input:'.length);
          const file = fileByRel.get(rel);
          if (file) await storeItemBlob(item.id, file);
          // Persist sidecar subtitle blobs so <track> elements keep working.
          for (let i = 0; i < item.subtitleTracks.length; i++) {
            const subRel = item.subtitleTracks[i]?.uri.slice('input:'.length);
            const subFile = subRel ? fileByRel.get(subRel) : undefined;
            if (subFile) await storeItemBlob(`sub:${item.id}:${i}`, subFile);
          }
        }
        await repository.upsertFolder({ ...folder, lastScannedAt: Date.now() });
      } finally {
        setScan({ running: false });
        await refresh();
      }
    },
    [refresh],
  );

  const removeFolder = useCallback(
    async (folderId: string) => {
      const folder = folders.find((f) => f.id === folderId);
      await repository.deleteFolder(folderId);
      if (folder && !isNative && folder.ref.startsWith('fsa:')) {
        const { forgetDirectoryHandle } = await import('../library/walkers');
        await forgetDirectoryHandle(folder.id);
      }
      await refresh();
    },
    [folders, refresh],
  );

  const value = useMemo<LibraryContextValue>(
    () => ({
      ready,
      recovered,
      items,
      shows,
      folders,
      collections,
      scan,
      refresh,
      startScan,
      cancelScan,
      addFolder,
      addFilesFallback,
      removeFolder,
    }),
    [
      ready,
      recovered,
      items,
      shows,
      folders,
      collections,
      scan,
      refresh,
      startScan,
      cancelScan,
      addFolder,
      addFilesFallback,
      removeFolder,
    ],
  );
  return <LibraryContext.Provider value={value}>{children}</LibraryContext.Provider>;
}

export function useLibrary(): LibraryContextValue {
  const ctx = useContext(LibraryContext);
  if (!ctx) throw new Error('useLibrary must be used inside LibraryProvider');
  return ctx;
}

/** Find the persisted folder for an item (used for permission-loss recovery). */
export async function folderForItem(item: MediaItem): Promise<LibraryFolder | undefined> {
  return repository.allFolders().then((folders) => folders.find((f) => f.id === item.folderId));
}

export { getDirectoryHandle };
