// ---------------------------------------------------------------------------
// Responsive app layout: bottom navigation on phones, navigation rail on
// tablets, collapsible sidebar on desktop. Purpose-built, not scaled.
// ---------------------------------------------------------------------------

import { type ReactNode } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { APP_NAME } from '../config';
import { t } from '../shared/i18n';
import { useViewport } from './hooks';

const TABS = [
  { to: '/', labelKey: 'nav.home' as const, icon: '⌂', end: true },
  { to: '/movies', labelKey: 'nav.movies' as const, icon: '▦' },
  { to: '/shows', labelKey: 'nav.shows' as const, icon: '▤' },
  { to: '/search', labelKey: 'nav.search' as const, icon: '⚲' },
  { to: '/collections', labelKey: 'nav.collections' as const, icon: '🗂' },
  { to: '/library', labelKey: 'nav.library' as const, icon: '🗀' },
  { to: '/offline', labelKey: 'nav.offline' as const, icon: '⬇' },
  { to: '/settings', labelKey: 'nav.settings' as const, icon: '⚙' },
];

function TabLink({
  to,
  labelKey,
  icon,
  end,
  rail,
}: {
  to: string;
  labelKey: (typeof TABS)[number]['labelKey'];
  icon: string;
  end?: boolean;
  rail?: boolean;
}): ReactNode {
  const label = t(labelKey);
  return (
    <NavLink
      to={to}
      end={end}
      aria-label={label}
      className={({ isActive }) =>
        `mm-navlink${isActive ? ' mm-navlink-active' : ''}${rail ? ' mm-navlink-rail' : ''}`
      }
      style={({ isActive }) => ({
        color: isActive ? 'var(--accent)' : 'var(--text2)',
      })}
    >
      <span aria-hidden="true" style={{ fontSize: rail ? 22 : 20 }}>
        {icon}
      </span>
      <span className={rail ? 'mm-navlabel-rail' : 'mm-navlabel'}>{label}</span>
    </NavLink>
  );
}

export function Layout({ children }: { children: ReactNode }): ReactNode {
  const { kind } = useViewport();
  const location = useLocation();
  const isPlayer = location.pathname.startsWith('/play/');

  if (isPlayer) {
    return <div className="mm-player-root">{children}</div>;
  }

  return (
    <div className={`mm-app mm-app-${kind}`}>
      {kind === 'desktop' && (
        <aside className="mm-sidebar" aria-label={t('nav.home')}>
          <div className="mm-brand">{APP_NAME}</div>
          <nav aria-label="Primary">
            {TABS.map((tab) => (
              <TabLink key={tab.to} {...tab} rail />
            ))}
          </nav>
        </aside>
      )}
      {kind === 'tablet' && (
        <nav className="mm-rail" aria-label="Primary">
          {TABS.map((tab) => (
            <TabLink key={tab.to} {...tab} rail />
          ))}
        </nav>
      )}
      <main className="mm-main" id="main">
        {children}
      </main>
      {kind === 'phone' && (
        <nav className="mm-bottomnav" aria-label="Primary">
          {TABS.map((tab) => (
            <TabLink key={tab.to} {...tab} />
          ))}
        </nav>
      )}
      <style>{`
        .mm-app { display: flex; min-height: 100dvh; }
        .mm-main { flex: 1; min-width: 0; padding-bottom: env(safe-area-inset-bottom); }
        .mm-app-phone .mm-main { padding-bottom: calc(76px + env(safe-area-inset-bottom)); }
        .mm-brand { font-size: 22px; font-weight: 800; padding: 20px 16px; letter-spacing: -0.02em; }
        .mm-brand::after { content: ''; display: block; width: 32px; height: 4px; border-radius: 2px; background: var(--accent); margin-top: 6px; }
        .mm-navlink { display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-radius: var(--r-md); text-decoration: none; font-weight: 600; font-size: 15px; min-height: 44px; }
        .mm-navlink-active { background: var(--accent-soft); }
        .mm-sidebar { width: 248px; flex-shrink: 0; border-right: 1px solid var(--line); padding: 8px; display: flex; flex-direction: column; gap: 4px; position: sticky; top: 0; height: 100dvh; }
        .mm-rail { width: 76px; flex-shrink: 0; border-right: 1px solid var(--line); display: flex; flex-direction: column; align-items: stretch; padding: 12px 8px; gap: 4px; position: sticky; top: 0; height: 100dvh; }
        .mm-navlink-rail { flex-direction: column; gap: 4px; justify-content: center; padding: 10px 4px; font-size: 11px; text-align: center; }
        .mm-bottomnav { position: fixed; left: 0; right: 0; bottom: 0; z-index: 40; display: flex; background: color-mix(in srgb, var(--bg1) 92%, transparent); backdrop-filter: blur(16px); border-top: 1px solid var(--line); padding-bottom: env(safe-area-inset-bottom); }
        .mm-bottomnav .mm-navlink { flex: 1; flex-direction: column; gap: 2px; justify-content: center; padding: 8px 2px; font-size: 11px; border-radius: 0; }
        .mm-player-root { height: 100dvh; background: #000; }
      `}</style>
    </div>
  );
}
