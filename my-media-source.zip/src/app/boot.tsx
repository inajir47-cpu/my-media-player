// ---------------------------------------------------------------------------
// Boot: first-run folder setup, optional PIN lock, offline banner, and theme
// application. The app opens directly to the library — never a login.
// ---------------------------------------------------------------------------

import { useEffect, useRef, useState, type ReactNode } from 'react';
import { APP_NAME } from '../config';
import { t, setLocaleByCode } from '../shared/i18n';
import { Button } from '../shared/ui';
import { useLibrary } from './libraryContext';
import { useOnline } from './hooks';
import { loadSettings, useSettings } from '../settings/store';
import { hasPin, verifyPin } from '../storage/adapters';

function PinGate({ onUnlock }: { onUnlock: () => void }): ReactNode {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  return (
    <div className="mm-empty" style={{ paddingTop: '30dvh' }} role="dialog" aria-label="App lock">
      <h2>{APP_NAME}</h2>
      <p>
        Enter your PIN to open the app. This lock protects the app screen only — it is not file encryption.
      </p>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          void verifyPin(pin).then((ok) => {
            if (ok) onUnlock();
            else {
              setError(true);
              setPin('');
            }
          });
        }}
        style={{ display: 'flex', gap: 8, justifyContent: 'center', marginTop: 16 }}
      >
        <input
          type="password"
          inputMode="numeric"
          aria-label="PIN"
          className="mm-input"
          style={{ width: 160, textAlign: 'center', fontSize: 22 }}
          value={pin}
          onChange={(e) => {
            setPin(e.target.value.replace(/\D/g, '').slice(0, 8));
          }}
          autoFocus
        />
        <Button type="submit" variant="primary" label="Unlock">
          Unlock
        </Button>
      </form>
      {error && (
        <p role="alert" style={{ color: 'var(--danger)' }}>
          Wrong PIN. Try again.
        </p>
      )}
    </div>
  );
}

function FirstRun(): ReactNode {
  const { addFolder, addFilesFallback } = useLibrary();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [needsInput, setNeedsInput] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const choose = async (): Promise<void> => {
    setBusy(true);
    setError(null);
    try {
      const res = await addFolder();
      if (!res.ok && res.reason === 'needs-file-input') setNeedsInput(true);
      else if (!res.ok && res.reason && res.reason !== 'cancelled') setError(res.reason);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not add the folder. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mm-empty" style={{ paddingTop: '12dvh', maxWidth: 560, margin: '0 auto' }}>
      <h1 style={{ fontSize: 30, margin: '0 0 8px' }}>{t('setup.title')}</h1>
      <p>{t('setup.body')}</p>
      <p style={{ fontSize: 13, color: 'var(--text3)' }}>{t('setup.browserNote')}</p>
      <div style={{ display: 'flex', gap: 12, justifyContent: 'center', marginTop: 20, flexWrap: 'wrap' }}>
        <Button
          variant="primary"
          label={t('setup.chooseFolder')}
          onClick={() => void choose()}
          disabled={busy}
        >
          {busy ? t('common.loading') : t('setup.chooseFolder')}
        </Button>
        {error && (
          <p role="alert" style={{ color: 'var(--danger)', fontSize: 14, maxWidth: 420 }}>
            {error}
          </p>
        )}
        {needsInput && (
          <Button variant="ghost" label={t('setup.chooseFiles')} onClick={() => fileRef.current?.click()}>
            {t('setup.chooseFiles')}
          </Button>
        )}
      </div>
      <input
        ref={fileRef}
        type="file"
        multiple
        // @ts-expect-error webkitdirectory is non-standard but widely supported
        webkitdirectory=""
        className="sr-only"
        aria-label={t('setup.chooseFiles')}
        onChange={(e) => {
          const files = [...(e.target.files ?? [])];
          if (files.length > 0) void addFilesFallback(files);
        }}
      />
    </div>
  );
}

export function Boot({ children }: { children: ReactNode }): ReactNode {
  const { ready, folders } = useLibrary();
  const settings = useSettings();
  const online = useOnline();
  const [unlocked, setUnlocked] = useState(false);
  const [settingsReady, setSettingsReady] = useState(false);
  const [pinRequired, setPinRequired] = useState(false);

  useEffect(() => {
    void loadSettings().then(() => {
      setSettingsReady(true);
    });
    void hasPin().then(setPinRequired);
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    root.dataset.theme = settings.theme;
    root.dataset.density = settings.density;
    root.dataset.reduceMotion = String(settings.reduceMotion);
    root.dataset.highContrast = String(settings.highContrast);
    root.dataset.reduceTransparency = String(settings.reduceTransparency);
    root.style.fontSize = `${16 * settings.fontScale}px`;
    root.dir = settings.locale === 'ar' ? 'rtl' : 'ltr';
    root.lang = settings.locale;
    // Translated strings follow the language choice (Arabic catalog + RTL).
    setLocaleByCode(settings.locale);
  }, [
    settings.theme,
    settings.density,
    settings.reduceMotion,
    settings.highContrast,
    settings.reduceTransparency,
    settings.fontScale,
    settings.locale,
  ]);

  if (!ready || !settingsReady) {
    return (
      <div
        className="mm-empty"
        style={{ paddingTop: '30dvh' }}
        role="status"
        aria-label={t('common.loading')}
      >
        <h2>{APP_NAME}</h2>
        <p>{t('common.loading')}</p>
      </div>
    );
  }

  if (pinRequired && !unlocked) {
    return (
      <PinGate
        onUnlock={() => {
          setUnlocked(true);
        }}
      />
    );
  }

  const showFirstRun = folders.length === 0;

  return (
    <>
      {!online && (
        <div
          role="status"
          style={{
            background: 'var(--bg2)',
            borderBottom: '1px solid var(--line)',
            padding: '8px 16px',
            fontSize: 13,
            color: 'var(--text2)',
            textAlign: 'center',
          }}
        >
          {t('offline.title')} — {t('offline.body')}
        </div>
      )}
      {showFirstRun ? <FirstRun /> : children}
    </>
  );
}
