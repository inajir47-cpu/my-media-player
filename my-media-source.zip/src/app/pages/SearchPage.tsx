// ---------------------------------------------------------------------------
// Global search: instant, debounced, fully offline against the local index.
// Filters: type, genre, year, watched, favorite, folder, season, rating.
// Sort: title, recently added, last played, year, duration, rating.
// ---------------------------------------------------------------------------

import { useDeferredValue, useMemo, useState, type ReactNode } from 'react';
import { useLibrary } from '../libraryContext';
import { ItemGrid } from '../../shared/ItemGrid';
import { EmptyState, Segmented, Field } from '../../shared/ui';
import { t } from '../../shared/i18n';
import type { MediaItem } from '../../storage/types';

type SortId = 'title' | 'added' | 'played' | 'year' | 'duration' | 'rating';

interface Filters {
  type: 'all' | 'movie' | 'episode' | 'audio';
  genre: string;
  year: string;
  watched: 'all' | 'watched' | 'unwatched';
  favorite: boolean;
  folderId: string;
  season: string;
  minRating: number;
}

const DEFAULT_FILTERS: Filters = {
  type: 'all',
  genre: '',
  year: '',
  watched: 'all',
  favorite: false,
  folderId: '',
  season: '',
  minRating: 0,
};

export function SearchPage(): ReactNode {
  const { items, folders } = useLibrary();
  const [query, setQuery] = useState('');
  const [filters, setFilters] = useState<Filters>(DEFAULT_FILTERS);
  const [sort, setSort] = useState<SortId>('title');
  const [showFilters, setShowFilters] = useState(false);
  const deferredQuery = useDeferredValue(query.trim().toLowerCase());

  const genres = useMemo(() => {
    const set = new Set<string>();
    for (const it of items) for (const g of it.genres) set.add(g);
    return [...set].sort();
  }, [items]);

  const years = useMemo(() => {
    const set = new Set<number>();
    for (const it of items) if (it.year) set.add(it.year);
    return [...set].sort((a, b) => b - a);
  }, [items]);

  const results = useMemo(() => {
    const q = deferredQuery;
    let out = items.filter((it) => {
      if (it.missing) return false;
      if (q && !`${it.title} ${it.fileName}`.toLowerCase().includes(q)) return false;
      if (filters.type !== 'all' && it.kind !== filters.type) return false;
      if (filters.genre && !it.genres.includes(filters.genre)) return false;
      if (filters.year && it.year !== parseInt(filters.year, 10)) return false;
      if (filters.watched === 'watched' && !it.watched) return false;
      if (filters.watched === 'unwatched' && it.watched) return false;
      if (filters.favorite && !it.favorite) return false;
      if (filters.folderId && it.folderId !== filters.folderId) return false;
      if (filters.season && it.season !== parseInt(filters.season, 10)) return false;
      if (filters.minRating > 0 && (it.localRating?.stars ?? 0) < filters.minRating) return false;
      return true;
    });
    const by = {
      title: (a: MediaItem, b: MediaItem) => a.sortTitle.localeCompare(b.sortTitle),
      added: (a: MediaItem, b: MediaItem) => b.addedAt - a.addedAt,
      played: (a: MediaItem, b: MediaItem) => (b.lastPlayedAt ?? 0) - (a.lastPlayedAt ?? 0),
      year: (a: MediaItem, b: MediaItem) => (b.year ?? 0) - (a.year ?? 0),
      duration: (a: MediaItem, b: MediaItem) => (b.durationMs ?? 0) - (a.durationMs ?? 0),
      rating: (a: MediaItem, b: MediaItem) => (b.localRating?.stars ?? 0) - (a.localRating?.stars ?? 0),
    }[sort];
    out = [...out].sort(by);
    return out;
  }, [items, deferredQuery, filters, sort]);

  const set = <K extends keyof Filters>(k: K, v: Filters[K]): void => {
    setFilters((f) => ({ ...f, [k]: v }));
  };

  return (
    <div style={{ padding: '16px 12px 24px', maxWidth: 1400, margin: '0 auto' }}>
      <div style={{ position: 'sticky', top: 0, background: 'var(--bg0)', padding: '8px 0', zIndex: 5 }}>
        <input
          type="search"
          className="mm-input"
          aria-label={t('search.placeholder')}
          placeholder={t('search.placeholder')}
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
          }}
          autoComplete="off"
        />
        <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap', alignItems: 'center' }}>
          <button
            type="button"
            className="mm-chip"
            aria-pressed={showFilters}
            onClick={() => {
              setShowFilters((s) => !s);
            }}
          >
            {t('search.filters')}
            {showFilters ? ' ▲' : ' ▼'}
          </button>
          <span style={{ fontSize: 13, color: 'var(--text3)' }} role="status">
            {results.length} result{results.length === 1 ? '' : 's'}
          </span>
        </div>
        {showFilters && (
          <div
            className="mm-card"
            style={{
              padding: 16,
              marginTop: 8,
              display: 'grid',
              gap: 4,
              gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
            }}
          >
            <Field label="Type">
              <select
                className="mm-select"
                value={filters.type}
                onChange={(e) => {
                  set('type', e.target.value as Filters['type']);
                }}
                aria-label="Type"
              >
                <option value="all">All</option>
                <option value="movie">Movies</option>
                <option value="episode">Episodes</option>
                <option value="audio">Audio</option>
              </select>
            </Field>
            <Field label="Genre">
              <select
                className="mm-select"
                value={filters.genre}
                onChange={(e) => {
                  set('genre', e.target.value);
                }}
                aria-label="Genre"
              >
                <option value="">All</option>
                {genres.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Year">
              <select
                className="mm-select"
                value={filters.year}
                onChange={(e) => {
                  set('year', e.target.value);
                }}
                aria-label="Year"
              >
                <option value="">All</option>
                {years.map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Watched">
              <select
                className="mm-select"
                value={filters.watched}
                onChange={(e) => {
                  set('watched', e.target.value as Filters['watched']);
                }}
                aria-label="Watched state"
              >
                <option value="all">All</option>
                <option value="watched">Watched</option>
                <option value="unwatched">Unwatched</option>
              </select>
            </Field>
            <Field label="Folder">
              <select
                className="mm-select"
                value={filters.folderId}
                onChange={(e) => {
                  set('folderId', e.target.value);
                }}
                aria-label="Folder"
              >
                <option value="">All folders</option>
                {folders.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Min rating">
              <select
                className="mm-select"
                value={filters.minRating}
                onChange={(e) => {
                  set('minRating', parseFloat(e.target.value));
                }}
                aria-label="Minimum rating"
              >
                {[0, 1, 2, 3, 4, 5].map((r) => (
                  <option key={r} value={r}>
                    {r === 0 ? 'Any' : `${r}+ ★`}
                  </option>
                ))}
              </select>
            </Field>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8 }}>
              <button
                type="button"
                className="mm-chip"
                aria-pressed={filters.favorite}
                onClick={() => {
                  set('favorite', !filters.favorite);
                }}
              >
                ★ Favorites only
              </button>
              <button
                type="button"
                className="mm-chip"
                onClick={() => {
                  setFilters(DEFAULT_FILTERS);
                }}
              >
                Reset
              </button>
            </div>
          </div>
        )}
        <div style={{ marginTop: 8 }}>
          <Segmented
            label={t('search.sort')}
            value={sort}
            onChange={setSort}
            options={[
              { id: 'title', label: 'Title' },
              { id: 'added', label: 'Added' },
              { id: 'played', label: 'Played' },
              { id: 'year', label: 'Year' },
              { id: 'duration', label: 'Duration' },
              { id: 'rating', label: 'Rating' },
            ]}
          />
        </div>
      </div>
      <div style={{ marginTop: 12 }}>
        <ItemGrid
          items={results}
          empty={
            <EmptyState
              title={t('search.noResults.title')}
              body={t('search.noResults.body', { query: query || '—' })}
            />
          }
        />
      </div>
    </div>
  );
}
