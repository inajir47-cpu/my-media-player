// ---------------------------------------------------------------------------
// Movies and Shows listing pages with sorting.
// ---------------------------------------------------------------------------

import { useMemo, useState, type ReactNode } from 'react';
import { useLibrary } from '../libraryContext';
import { ItemGrid } from '../../shared/ItemGrid';
import { EmptyState, Segmented } from '../../shared/ui';
import { t } from '../../shared/i18n';

type SortId = 'title' | 'added' | 'played' | 'year' | 'duration' | 'rating';

const SORTS: { id: SortId; label: string }[] = [
  { id: 'title', label: 'Title' },
  { id: 'added', label: 'Recently added' },
  { id: 'played', label: 'Last played' },
  { id: 'year', label: 'Year' },
  { id: 'duration', label: 'Duration' },
  { id: 'rating', label: 'Rating' },
];

function sortItems<
  T extends {
    sortTitle: string;
    addedAt: number;
    lastPlayedAt?: number;
    year?: number;
    durationMs?: number;
    localRating?: { stars: number };
  },
>(items: T[], sort: SortId): T[] {
  const arr = [...items];
  switch (sort) {
    case 'title':
      return arr.sort((a, b) => a.sortTitle.localeCompare(b.sortTitle));
    case 'added':
      return arr.sort((a, b) => b.addedAt - a.addedAt);
    case 'played':
      return arr.sort((a, b) => (b.lastPlayedAt ?? 0) - (a.lastPlayedAt ?? 0));
    case 'year':
      return arr.sort((a, b) => (b.year ?? 0) - (a.year ?? 0));
    case 'duration':
      return arr.sort((a, b) => (b.durationMs ?? 0) - (a.durationMs ?? 0));
    case 'rating':
      return arr.sort((a, b) => (b.localRating?.stars ?? 0) - (a.localRating?.stars ?? 0));
  }
}

export function MoviesPage(): ReactNode {
  const { items } = useLibrary();
  const [sort, setSort] = useState<SortId>('title');
  const movies = useMemo(
    () =>
      sortItems(
        items.filter((i) => i.kind === 'movie' && !i.missing),
        sort,
      ),
    [items, sort],
  );
  return (
    <div style={{ padding: '16px 12px 24px', maxWidth: 1400, margin: '0 auto' }}>
      <div className="mm-section-title">
        <h2>{t('nav.movies')}</h2>
      </div>
      <div style={{ marginBottom: 12 }}>
        <Segmented label={t('search.sort')} options={SORTS} value={sort} onChange={setSort} />
      </div>
      <ItemGrid
        items={movies}
        empty={<EmptyState title={t('home.empty.title')} body={t('home.empty.body')} />}
      />
    </div>
  );
}

export function ShowsPage(): ReactNode {
  const { shows } = useLibrary();
  const [sort, setSort] = useState<SortId>('title');
  const cards = useMemo(() => {
    const mapped = shows.map((s) => ({ ...s, kind: 'show-card' as const, year: s.years.from }));
    return sortItems(mapped, sort);
  }, [shows, sort]);
  return (
    <div style={{ padding: '16px 12px 24px', maxWidth: 1400, margin: '0 auto' }}>
      <div className="mm-section-title">
        <h2>{t('nav.shows')}</h2>
      </div>
      <div style={{ marginBottom: 12 }}>
        <Segmented label={t('search.sort')} options={SORTS} value={sort} onChange={setSort} />
      </div>
      <ItemGrid
        items={cards}
        empty={<EmptyState title={t('home.empty.title')} body={t('home.empty.body')} />}
      />
    </div>
  );
}
