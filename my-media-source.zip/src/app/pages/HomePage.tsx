// ---------------------------------------------------------------------------
// Home: cinematic hero (random muted local clip, rotating with crossfade),
// then Continue Watching, Recently Added, Favorites, Watchlist, Movies,
// Shows, Recently Played and Collections.
// ---------------------------------------------------------------------------

import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useLibrary } from '../libraryContext';
import { MediaCard } from '../../shared/MediaCard';
import { PreviewVideo } from '../../previews/PreviewVideo';
import { Button, EmptyState, IconButton, Skeleton } from '../../shared/ui';
import { continueWatching, recentlyAdded, recentlyPlayed } from '../../collections/store';
import { previewsAllowed, useSettings } from '../../settings/store';
import { progressFraction } from '../../player/persistence';
import { formatDuration } from '../../shared/format';
import { t } from '../../shared/i18n';
import type { MediaItem } from '../../storage/types';
import { hash01 } from '../../previews/engine';

function Section({
  title,
  to,
  children,
  empty,
}: {
  title: string;
  to?: string;
  children: ReactNode;
  empty?: ReactNode;
}): ReactNode {
  return (
    <section aria-label={title} style={{ marginTop: 8 }}>
      <div className="mm-section-title">
        <h2>{title}</h2>
        {to && (
          <Link to={to} style={{ color: 'var(--accent)', fontSize: 14, fontWeight: 650 }}>
            {t('common.done') === 'Done' ? 'See all' : 'See all'}
          </Link>
        )}
      </div>
      {children ?? empty}
    </section>
  );
}

function Rail({ items, kind }: { items: MediaItem[]; kind?: 'show-card' }): ReactNode {
  if (items.length === 0) return null;
  return (
    <div
      style={{
        display: 'flex',
        gap: 12,
        overflowX: 'auto',
        padding: '4px 4px 12px',
        scrollSnapType: 'x mandatory',
      }}
    >
      {items.map((it) => (
        <div key={it.id} style={{ flex: '0 0 150px', scrollSnapAlign: 'start' }}>
          <MediaCard item={kind === 'show-card' ? ({ ...it, kind: 'show-card' } as never) : it} />
        </div>
      ))}
    </div>
  );
}

function Hero({ items }: { items: MediaItem[] }): ReactNode {
  const navigate = useNavigate();
  const settings = useSettings();
  const [index, setIndex] = useState(() =>
    Math.floor(hash01(`hero:${new Date().toDateString()}`) * Math.max(1, items.length)),
  );
  const [paused, setPaused] = useState(false);
  const [fading, setFading] = useState(false);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  const candidates = useMemo(
    () =>
      items.filter(
        (it) => !it.missing && !it.technical.unsupportedReason && !it.previewDisabled && it.kind !== 'audio',
      ),
    [items],
  );
  const current: MediaItem | undefined =
    candidates.length > 0 ? candidates[index % candidates.length] : undefined;

  useEffect(() => {
    if (paused || candidates.length < 2 || !previewsAllowed(settings)) return;
    timer.current = setInterval(
      () => {
        setFading(true);
        setTimeout(() => {
          setIndex((i) => (i + 1) % candidates.length);
          setFading(false);
        }, 350);
      },
      Math.max(10, settings.heroRotationSec) * 1000,
    );
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
  }, [paused, candidates.length, settings]);

  if (!current) return null;
  const detailPath =
    current.kind === 'episode' && current.groupId ? `/show/${current.groupId}` : `/movie/${current.id}`;

  return (
    <section
      aria-label="Featured"
      className="mm-hero"
      style={{
        position: 'relative',
        borderRadius: 'var(--r-xl)',
        overflow: 'hidden',
        minHeight: 380,
        margin: '12px 4px 0',
      }}
    >
      <div
        style={{
          position: 'absolute',
          inset: 0,
          opacity: fading ? 0 : 1,
          transition: 'opacity 350ms var(--ease)',
        }}
        key={current.id}
      >
        {previewsAllowed(settings) && !paused ? (
          <PreviewVideo item={current} slotId="hero" />
        ) : current.backdrop.uri || current.poster.uri ? (
          <img
            src={current.backdrop.uri ?? current.poster.uri}
            alt=""
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
        ) : null}
      </div>
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background:
            'linear-gradient(180deg, rgba(5,5,8,0.25) 0%, rgba(5,5,8,0.05) 35%, rgba(5,5,8,0.88) 100%)',
        }}
        aria-hidden="true"
      />
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          bottom: 0,
          padding: 24,
          display: 'flex',
          flexDirection: 'column',
          gap: 12,
        }}
      >
        <p
          style={{
            margin: 0,
            fontSize: 13,
            fontWeight: 700,
            letterSpacing: '0.08em',
            textTransform: 'uppercase',
            color: 'var(--accent)',
          }}
        >
          Featured
        </p>
        <h1
          style={{
            margin: 0,
            fontSize: 'clamp(26px, 5vw, 44px)',
            fontWeight: 800,
            letterSpacing: '-0.02em',
            textShadow: 'var(--overlayTextShadow, 0 1px 12px rgba(0,0,0,0.9))',
          }}
        >
          {current.title}
        </h1>
        <p style={{ margin: 0, color: 'var(--text2)', fontSize: 14 }}>
          {[
            current.year,
            current.durationMs ? formatDuration(current.durationMs) : '',
            (current.genres ?? []).slice(0, 3).join(' · '),
          ]
            .filter(Boolean)
            .join(' · ')}
        </p>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
          <Button
            variant="primary"
            label={t('home.hero.play')}
            onClick={() => navigate(`/play/${current.id}`)}
          >
            ▶ {t('home.hero.play')}
          </Button>
          <Button variant="ghost" label={t('home.hero.details')} onClick={() => navigate(detailPath)}>
            {t('home.hero.details')}
          </Button>
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
            <IconButton
              label={paused ? t('home.hero.playPreview') : t('home.hero.pausePreview')}
              onClick={() => {
                setPaused((p) => !p);
              }}
            >
              {paused ? '▶' : '⏸'}
            </IconButton>
          </div>
        </div>
      </div>
      <style>{`.mm-hero { box-shadow: var(--shadow-card); }`}</style>
    </section>
  );
}

function ContinueWatchingCard({ item }: { item: MediaItem }): ReactNode {
  const navigate = useNavigate();
  const frac = progressFraction(item.progressMs, item.durationMs);
  return (
    <article className="mm-card" style={{ flex: '0 0 280px', scrollSnapAlign: 'start' }}>
      <button
        type="button"
        onClick={() => navigate(`/play/${item.id}`)}
        aria-label={`${t('detail.resume')}: ${item.title}`}
        style={{ display: 'block', width: '100%', textAlign: 'left' }}
      >
        <div style={{ position: 'relative', aspectRatio: '16 / 9', background: 'var(--bg3)' }}>
          {item.backdrop.uri || item.poster.uri ? (
            <img
              src={item.backdrop.uri ?? item.poster.uri}
              alt=""
              loading="lazy"
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            />
          ) : null}
          <span
            style={{
              position: 'absolute',
              inset: 0,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <span className="mm-icon-btn" aria-hidden="true" style={{ width: 56, height: 56, fontSize: 22 }}>
              ▶
            </span>
          </span>
        </div>
        <div style={{ padding: '10px 12px 12px' }}>
          <h3 style={{ margin: 0, fontSize: 14 }}>{item.title}</h3>
          <p style={{ margin: '4px 0 8px', fontSize: 12, color: 'var(--text3)' }}>
            {formatDuration(item.progressMs)} / {item.durationMs ? formatDuration(item.durationMs) : '—'}
          </p>
          <div className="mm-progress">
            <div style={{ width: `${frac * 100}%` }} />
          </div>
        </div>
      </button>
    </article>
  );
}

export function HomePage(): ReactNode {
  const { ready, items, shows, collections } = useLibrary();
  const settings = useSettings();

  const movies = useMemo(
    () =>
      items
        .filter((i) => i.kind === 'movie' && !i.missing)
        .sort((a, b) => a.sortTitle.localeCompare(b.sortTitle)),
    [items],
  );
  const favorites = useMemo(() => items.filter((i) => i.favorite && !i.missing), [items]);
  const watchlist = useMemo(() => items.filter((i) => i.watchlist && !i.missing), [items]);
  const cw = useMemo(() => continueWatching(items).slice(0, 12), [items]);
  const added = useMemo(() => recentlyAdded(items, 15), [items]);
  const played = useMemo(() => recentlyPlayed(items, 15), [items]);
  const showCards = useMemo(() => shows.map((s) => ({ ...s, kind: 'show-card' as const })), [shows]);

  if (!ready) {
    return (
      <div style={{ padding: 16, display: 'grid', gap: 12 }}>
        <Skeleton height={380} />
        <Skeleton height={200} />
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <EmptyState
        title={t('home.empty.title')}
        body={t('home.empty.body')}
        action={
          <Link className="mm-btn mm-btn-primary" to="/library">
            {t('library.addFolder')}
          </Link>
        }
      />
    );
  }

  return (
    <div style={{ padding: '0 12px 24px', maxWidth: 1400, margin: '0 auto' }}>
      {previewsAllowed(settings) && <Hero items={items} />}

      {cw.length > 0 && (
        <Section title={t('home.continueWatching')}>
          <div
            style={{
              display: 'flex',
              gap: 12,
              overflowX: 'auto',
              padding: '4px 4px 12px',
              scrollSnapType: 'x mandatory',
            }}
          >
            {cw.map((it) => (
              <ContinueWatchingCard key={it.id} item={it} />
            ))}
          </div>
        </Section>
      )}

      <Section title={t('home.recentlyAdded')}>
        <Rail items={added} />
      </Section>
      {favorites.length > 0 && (
        <Section title={t('home.favorites')}>
          <Rail items={favorites} />
        </Section>
      )}
      {watchlist.length > 0 && (
        <Section title={t('home.watchlist')}>
          <Rail items={watchlist} />
        </Section>
      )}
      {movies.length > 0 && (
        <Section title={t('home.movies')} to="/movies">
          <Rail items={movies.slice(0, 15)} />
        </Section>
      )}
      {showCards.length > 0 && (
        <Section title={t('home.shows')} to="/shows">
          <Rail items={showCards.slice(0, 15) as never[]} kind="show-card" />
        </Section>
      )}
      {played.length > 0 && (
        <Section title={t('home.recentlyPlayed')}>
          <Rail items={played} />
        </Section>
      )}
      {collections.length > 0 && (
        <Section title={t('home.collections')}>
          <div style={{ display: 'flex', gap: 12, overflowX: 'auto', padding: '4px 4px 12px' }}>
            {collections.map((c) => (
              <Link
                key={c.id}
                to={`/collection/${c.id}`}
                className="mm-card"
                style={{ flex: '0 0 200px', padding: 16, textDecoration: 'none', color: 'inherit' }}
              >
                <h3 style={{ margin: '0 0 4px', fontSize: 15 }}>{c.name}</h3>
                <p style={{ margin: 0, fontSize: 12, color: 'var(--text3)' }}>{c.itemIds.length} titles</p>
              </Link>
            ))}
          </div>
        </Section>
      )}
    </div>
  );
}
