// ---------------------------------------------------------------------------
// CollectionsPage: list, create, rename and delete user collections.
// ---------------------------------------------------------------------------

import { useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { useLibrary } from '../libraryContext';
import { createCollection, renameCollection } from '../../collections/store';
import { repository } from '../../storage/repository';
import type { UserCollection } from '../../storage/types';
import { BottomSheet, Button, EmptyState, Field, IconButton } from '../../shared/ui';
import { t } from '../../shared/i18n';
import { logger } from '../../shared/logger';

export function CollectionsPage(): ReactNode {
  const { collections, refresh } = useLibrary();
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [renaming, setRenaming] = useState<UserCollection | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [confirmingDelete, setConfirmingDelete] = useState<UserCollection | null>(null);

  const create = async (): Promise<void> => {
    const trimmed = name.trim();
    if (!trimmed || busy) return;
    setBusy(true);
    setError('');
    try {
      await createCollection(trimmed);
      setName('');
      await refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };

  const rename = async (): Promise<void> => {
    if (!renaming || busy) return;
    setBusy(true);
    try {
      await renameCollection(renaming.id, renameValue);
      setRenaming(null);
      await refresh();
    } catch {
      logger.warn('collections', 'rename failed', { id: renaming.id });
    } finally {
      setBusy(false);
    }
  };

  const remove = async (): Promise<void> => {
    if (!confirmingDelete || busy) return;
    setBusy(true);
    try {
      await repository.deleteCollection(confirmingDelete.id);
      setConfirmingDelete(null);
      await refresh();
    } catch {
      logger.warn('collections', 'delete failed', { id: confirmingDelete.id });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div style={{ padding: '16px 16px 96px', maxWidth: 720 }}>
      <h1 style={{ fontSize: 24, margin: '8px 0 16px' }}>{t('collections.title')}</h1>

      <Field label={t('collections.new')}>
        <div style={{ display: 'flex', gap: 8 }}>
          <input
            className="mm-input"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') void create();
            }}
            maxLength={80}
            placeholder={t('collections.nameLabel')}
            aria-label={t('collections.nameLabel')}
          />
          <Button
            variant="primary"
            label={t('collections.create')}
            onClick={() => void create()}
            disabled={busy || name.trim().length === 0}
          >
            {t('collections.create')}
          </Button>
        </div>
      </Field>
      {error !== '' && (
        <p role="alert" style={{ color: 'var(--danger)', fontSize: 14 }}>
          {error}
        </p>
      )}

      {collections.length === 0 ? (
        <EmptyState title={t('collections.title')} body={t('collections.empty')} />
      ) : (
        <ul style={{ listStyle: 'none', margin: '16px 0 0', padding: 0 }}>
          {collections.map((c) => (
            <li
              key={c.id}
              className="mm-card"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                padding: '12px 16px',
                marginBottom: 8,
              }}
            >
              <Link
                to={`/collection/${c.id}`}
                style={{ flex: 1, textDecoration: 'none', color: 'inherit', minWidth: 0 }}
                aria-label={`${c.name}`}
              >
                <div style={{ fontWeight: 650, overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.name}</div>
                <div style={{ color: 'var(--text3)', fontSize: 13 }}>
                  {t('collections.count', { n: c.itemIds.length })}
                </div>
              </Link>
              <IconButton
                label={t('collections.rename')}
                onClick={() => {
                  setRenaming(c);
                  setRenameValue(c.name);
                }}
              >
                ✎
              </IconButton>
              <IconButton label={t('collections.delete')} onClick={() => setConfirmingDelete(c)}>
                🗑
              </IconButton>
            </li>
          ))}
        </ul>
      )}

      {renaming && (
        <BottomSheet title={t('collections.rename')} onClose={() => setRenaming(null)}>
          <Field label={t('collections.nameLabel')}>
            <div style={{ display: 'flex', gap: 8 }}>
              <input
                className="mm-input"
                value={renameValue}
                onChange={(e) => setRenameValue(e.target.value)}
                maxLength={80}
                aria-label={t('collections.nameLabel')}
              />
              <Button
                variant="primary"
                label={t('common.save')}
                onClick={() => void rename()}
                disabled={busy || renameValue.trim().length === 0}
              >
                {t('common.save')}
              </Button>
            </div>
          </Field>
        </BottomSheet>
      )}

      {confirmingDelete && (
        <BottomSheet title={t('collections.delete')} onClose={() => setConfirmingDelete(null)}>
          <p>{t('collections.deleteConfirm', { name: confirmingDelete.name })}</p>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button variant="ghost" label={t('common.cancel')} onClick={() => setConfirmingDelete(null)}>
              {t('common.cancel')}
            </Button>
            <Button
              variant="primary"
              label={t('collections.delete')}
              onClick={() => void remove()}
              disabled={busy}
            >
              {t('collections.delete')}
            </Button>
          </div>
        </BottomSheet>
      )}
    </div>
  );
}
