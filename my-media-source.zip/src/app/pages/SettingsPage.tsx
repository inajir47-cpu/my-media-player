// ---------------------------------------------------------------------------
// Settings page: all eleven groups — Playback, Gestures, Subtitles,
// Appearance, Library, Metadata, Storage, Backup, Accessibility, Privacy,
// About. Bound directly to the settings store; everything persists locally.
// ---------------------------------------------------------------------------

import { useEffect, useRef, useState, type ReactNode } from 'react';
import { useSettings, updateSettings } from '../../settings/store';
import type { AppSettings, GestureId } from '../../storage/types';
import { Button, Field, Segmented, Slider, Toggle } from '../../shared/ui';
import { APP_NAME, APP_VERSION, DEFAULT_HOME_SECTIONS, PLAYBACK_SPEEDS } from '../../config';
import { t } from '../../shared/i18n';
import { exportBackupFile, importBackupFile } from '../../storage/backup';
import { setPin, clearPin, hasPin, confirmNative } from '../../storage/adapters';
import { getProvider } from '../../metadata/providers';
import { repository } from '../../storage/repository';
import { GESTURE_ACTIONS, GESTURE_LABELS } from '../../player/gestures';

function Section({ title, children }: { title: string; children: ReactNode }): ReactNode {
  return (
    <section className="mm-card" style={{ padding: 16, marginBottom: 12 }}>
      <h2 style={{ fontSize: 16, margin: '0 0 12px' }}>{title}</h2>
      <div style={{ display: 'grid', gap: 4 }}>{children}</div>
    </section>
  );
}

function set(patch: Partial<AppSettings>): void {
  void updateSettings(patch);
}

const HOME_SECTION_LABELS: Record<string, string> = {
  'continue-watching': 'Continue Watching',
  'recently-added': 'Recently Added',
  favorites: 'Favorites',
  watchlist: 'Watchlist',
  movies: 'Movies',
  shows: 'Shows & Anime',
  'recently-played': 'Recently Played',
  collections: 'Collections',
  hero: 'Featured hero',
};

function PlaybackSection({ s }: { s: AppSettings }): ReactNode {
  return (
    <Section title={t('settings.playback')}>
      <div>
        <p style={{ fontSize: 14.5, fontWeight: 600, margin: '8px 0 0' }}>
          {t('settings.playback.watchedThreshold')}
        </p>
        <Slider
          label={t('settings.playback.watchedThreshold')}
          value={Math.round(s.watchedThreshold * 100)}
          min={50}
          max={99}
          step={1}
          onChange={(v) => {
            set({ watchedThreshold: v / 100 });
          }}
          formatValue={(v) => `${v}%`}
        />
      </div>
      <Field label={t('settings.playback.resumeBehavior')}>
        <Segmented
          label={t('settings.playback.resumeBehavior')}
          value={s.resumeBehavior}
          onChange={(v) => {
            set({ resumeBehavior: v });
          }}
          options={[
            { id: 'always', label: t('settings.playback.resume.auto') },
            { id: 'ask', label: t('settings.playback.resume.ask') },
            { id: 'never', label: t('settings.playback.resume.never') },
          ]}
        />
      </Field>
      <Toggle
        label={t('settings.playback.autoplayNext')}
        checked={s.autoplayNext}
        onChange={(v) => {
          set({ autoplayNext: v });
        }}
      />
      {s.autoplayNext && (
        <div>
          <p style={{ fontSize: 14.5, fontWeight: 600, margin: '8px 0 0' }}>
            {t('settings.playback.autoplayDelay')}
          </p>
          <Slider
            label={t('settings.playback.autoplayDelay')}
            value={s.autoplayDelaySec}
            min={0}
            max={30}
            step={1}
            onChange={(v) => {
              set({ autoplayDelaySec: v });
            }}
            formatValue={(v) => `${v}s`}
          />
        </div>
      )}
      <Field label={t('settings.playback.doubleTapSeek')}>
        <Segmented
          label={t('settings.playback.doubleTapSeek')}
          value={String(s.seekIntervalSec)}
          onChange={(v) => {
            set({ seekIntervalSec: parseInt(v, 10) });
          }}
          options={[
            { id: '5', label: '5s' },
            { id: '10', label: '10s' },
            { id: '30', label: '30s' },
          ]}
        />
      </Field>
      <Field label={t('settings.playback.defaultSpeed')}>
        <select
          className="mm-select"
          value={s.defaultSpeed}
          onChange={(e) => {
            set({ defaultSpeed: parseFloat(e.target.value) });
          }}
          aria-label={t('settings.playback.defaultSpeed')}
        >
          {PLAYBACK_SPEEDS.map((sp) => (
            <option key={sp} value={sp}>
              {sp}×
            </option>
          ))}
        </select>
      </Field>
      <Field label={t('settings.playback.sleepTimer')}>
        <select
          className="mm-select"
          value={s.sleepTimerMin}
          onChange={(e) => {
            set({ sleepTimerMin: parseInt(e.target.value, 10) });
          }}
          aria-label={t('settings.playback.sleepTimer')}
        >
          {[0, 5, 10, 15, 30, 45, 60, 90, 120].map((m) => (
            <option key={m} value={m}>
              {m === 0 ? 'Off' : `${m} min`}
            </option>
          ))}
        </select>
      </Field>
      <Toggle
        label={t('settings.playback.startMuted')}
        checked={s.startMuted}
        onChange={(v) => {
          set({ startMuted: v });
        }}
      />
    </Section>
  );
}

const SUBTITLE_BACKGROUNDS = [
  { id: 'none', label: 'None', css: 'transparent' },
  { id: 'shadow', label: 'Shadow', css: 'rgba(0,0,0,0.6)' },
  { id: 'box', label: 'Box', css: 'rgba(0,0,0,0.85)' },
] as const;

function SubtitlesSection({ s }: { s: AppSettings }): ReactNode {
  const st = s.subtitleStyle;
  return (
    <Section title={t('settings.subtitles')}>
      <div>
        <p style={{ fontSize: 14.5, fontWeight: 600, margin: '8px 0 0' }}>
          {t('settings.subtitles.fontSize')}
        </p>
        <Slider
          label={t('settings.subtitles.fontSize')}
          value={st.size}
          min={50}
          max={200}
          step={10}
          onChange={(v) => {
            set({ subtitleStyle: { ...st, size: v } });
          }}
          formatValue={(v) => `${v}%`}
        />
      </div>
      <Field label={t('settings.subtitles.color')}>
        <Segmented
          label={t('settings.subtitles.color')}
          value={st.color}
          onChange={(v) => {
            set({ subtitleStyle: { ...st, color: v } });
          }}
          options={[
            { id: '#ffffff', label: 'White' },
            { id: '#ffe14d', label: 'Yellow' },
          ]}
        />
      </Field>
      <Field label={t('settings.subtitles.background')}>
        <Segmented
          label={t('settings.subtitles.background')}
          value={st.background}
          onChange={(v) => {
            set({ subtitleStyle: { ...st, background: v } });
          }}
          options={SUBTITLE_BACKGROUNDS.map((b) => ({ id: b.css, label: b.label }))}
        />
      </Field>
      <Field label="Position">
        <Segmented
          label="Subtitle position"
          value={st.position}
          onChange={(v) => {
            set({ subtitleStyle: { ...st, position: v } });
          }}
          options={[
            { id: 'bottom', label: 'Bottom' },
            { id: 'top', label: 'Top' },
          ]}
        />
      </Field>
      <div>
        <p style={{ fontSize: 14.5, fontWeight: 600, margin: '8px 0 0' }}>{t('settings.subtitles.delay')}</p>
        <Slider
          label={t('settings.subtitles.delay')}
          value={s.subtitleDelayMs}
          min={-5000}
          max={5000}
          step={100}
          onChange={(v) => {
            set({ subtitleDelayMs: v });
          }}
          formatValue={(v) => `${v >= 0 ? '+' : ''}${v} ms`}
        />
      </div>
      <div>
        <p style={{ fontSize: 14.5, fontWeight: 600, margin: '8px 0 0' }}>{t('settings.audio.delay')}</p>
        <Slider
          label={t('settings.audio.delay')}
          value={s.audioDelayMs}
          min={-5000}
          max={5000}
          step={100}
          onChange={(v) => {
            set({ audioDelayMs: v });
          }}
          formatValue={(v) => `${v >= 0 ? '+' : ''}${v} ms`}
        />
      </div>
    </Section>
  );
}

function AppearanceSection({ s }: { s: AppSettings }): ReactNode {
  return (
    <Section title={t('settings.appearance')}>
      <Field label={t('settings.appearance.theme')}>
        <Segmented
          label={t('settings.appearance.theme')}
          value={s.theme}
          onChange={(v) => {
            set({ theme: v });
          }}
          options={[
            { id: 'dark', label: t('settings.appearance.theme.dark') },
            { id: 'light', label: t('settings.appearance.theme.light') },
          ]}
        />
      </Field>
      <Field label={t('settings.appearance.density')}>
        <Segmented
          label={t('settings.appearance.density')}
          value={s.density}
          onChange={(v) => {
            set({ density: v });
          }}
          options={[
            { id: 'comfortable', label: t('settings.appearance.density.comfortable') },
            { id: 'compact', label: t('settings.appearance.density.compact') },
          ]}
        />
      </Field>
      <Field label={t('settings.appearance.tabletDensity')}>
        <Segmented
          label={t('settings.appearance.tabletDensity')}
          value={s.tabletDensity}
          onChange={(v) => {
            set({ tabletDensity: v });
          }}
          options={[
            { id: 'comfortable', label: t('settings.appearance.density.comfortable') },
            { id: 'compact', label: t('settings.appearance.density.compact') },
          ]}
        />
      </Field>
      <div>
        <p style={{ fontSize: 14.5, fontWeight: 600, margin: '8px 0 0' }}>
          {t('settings.appearance.fontSize')}
        </p>
        <Slider
          label={t('settings.appearance.fontSize')}
          value={Math.round(s.fontScale * 100)}
          min={85}
          max={150}
          step={5}
          onChange={(v) => {
            set({ fontScale: v / 100 });
          }}
          formatValue={(v) => `${v}%`}
        />
      </div>
      <div>
        <p style={{ fontSize: 14.5, fontWeight: 600, margin: '8px 0 0' }}>
          {t('settings.appearance.heroRotation')}
        </p>
        <Slider
          label={t('settings.appearance.heroRotation')}
          value={s.heroRotationSec}
          min={0}
          max={60}
          step={5}
          onChange={(v) => {
            set({ heroRotationSec: v });
          }}
          formatValue={(v) => (v === 0 ? 'Off' : `${v}s`)}
        />
      </div>
      <Toggle
        label={t('settings.appearance.highContrast')}
        checked={s.highContrast}
        onChange={(v) => {
          set({ highContrast: v });
        }}
      />
      <Toggle
        label={t('settings.appearance.reduceMotion')}
        checked={s.reduceMotion}
        onChange={(v) => {
          set({ reduceMotion: v });
        }}
      />
      <Toggle
        label={t('settings.appearance.reduceTransparency')}
        checked={s.reduceTransparency}
        onChange={(v) => {
          set({ reduceTransparency: v });
        }}
      />
      <Field label={t('settings.appearance.language')}>
        <select
          className="mm-select"
          value={s.locale}
          onChange={(e) => {
            set({ locale: e.target.value as 'en' | 'ar' });
          }}
          aria-label={t('settings.appearance.language')}
        >
          <option value="en">English</option>
          <option value="ar">العربية (RTL)</option>
        </select>
      </Field>
    </Section>
  );
}

function LibrarySection({ s }: { s: AppSettings }): ReactNode {
  return (
    <Section title={t('settings.library')}>
      <h3 style={{ fontSize: 14, margin: '4px 0' }}>{t('settings.library.homeSections')}</h3>
      <div style={{ display: 'grid', gap: 2 }}>
        {DEFAULT_HOME_SECTIONS.map((id) => (
          <Toggle
            key={id}
            label={HOME_SECTION_LABELS[id] ?? id}
            checked={s.homeSections.includes(id)}
            onChange={(v) => {
              set({ homeSections: v ? [...s.homeSections, id] : s.homeSections.filter((x) => x !== id) });
            }}
          />
        ))}
      </div>
      <div>
        <p style={{ fontSize: 14.5, fontWeight: 600, margin: '8px 0 0' }}>
          {t('settings.library.previewLength')}
        </p>
        <Slider
          label={t('settings.library.previewLength')}
          value={s.previewLengthSec}
          min={6}
          max={30}
          step={1}
          onChange={(v) => {
            set({ previewLengthSec: v });
          }}
          formatValue={(v) => `${v}s`}
        />
      </div>
      <Toggle
        label={t('settings.previews.enable')}
        checked={s.previewEnabled}
        onChange={(v) => {
          set({ previewEnabled: v });
        }}
      />
      <Field label={t('settings.library.cardPreview')}>
        <Segmented
          label={t('settings.library.cardPreview')}
          value={s.cardPreviewMode}
          onChange={(v) => {
            set({ cardPreviewMode: v });
          }}
          options={[
            { id: 'hover', label: t('settings.library.cardPreview.hover') },
            { id: 'longpress', label: t('settings.library.cardPreview.longpress') },
            { id: 'off', label: t('settings.library.cardPreview.off') },
          ]}
        />
      </Field>
      <Toggle
        label={t('settings.library.autoScan')}
        checked={s.autoScanOnLaunch}
        onChange={(v) => {
          set({ autoScanOnLaunch: v });
        }}
      />
      <Toggle
        label={t('settings.library.preferLocal')}
        checked={s.preferLocalMetadata}
        onChange={(v) => {
          set({ preferLocalMetadata: v });
        }}
      />
    </Section>
  );
}

function GesturesSection({ s }: { s: AppSettings }): ReactNode {
  const setBinding = (id: GestureId, patch: Partial<AppSettings['gestures'][GestureId]>): void => {
    set({ gestures: { ...s.gestures, [id]: { ...s.gestures[id]!, ...patch } } });
  };
  return (
    <Section title={t('settings.gestures')}>
      <p style={{ fontSize: 13, color: 'var(--text2)', marginTop: 0 }}>{t('settings.gestures.hint')}</p>
      {(Object.keys(GESTURE_LABELS) as GestureId[]).map((id) => {
        const b = s.gestures[id] ?? { enabled: true, action: 'none' };
        return (
          <div
            key={id}
            className="mm-row"
            style={{ justifyContent: 'space-between', gap: 12, padding: '6px 0' }}
          >
            <button
              type="button"
              role="switch"
              aria-checked={b.enabled}
              aria-label={`${GESTURE_LABELS[id]} enabled`}
              onClick={() => {
                setBinding(id, { enabled: !b.enabled });
              }}
              style={{
                width: 44,
                height: 26,
                borderRadius: 13,
                border: '1px solid var(--line)',
                flexShrink: 0,
                background: b.enabled ? 'var(--accent)' : 'var(--bg3)',
                cursor: 'pointer',
                position: 'relative',
              }}
            >
              <span
                style={{
                  display: 'block',
                  width: 20,
                  height: 20,
                  borderRadius: '50%',
                  background: '#fff',
                  position: 'absolute',
                  top: 2,
                  left: b.enabled ? 20 : 2,
                }}
              />
            </button>
            <span style={{ flex: 1, fontSize: 14.5 }}>{GESTURE_LABELS[id]}</span>
            <select
              className="mm-select"
              style={{ maxWidth: 190 }}
              value={b.action}
              disabled={!b.enabled}
              onChange={(e) => {
                setBinding(id, { action: e.target.value });
              }}
              aria-label={`${GESTURE_LABELS[id]} action`}
            >
              {GESTURE_ACTIONS.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.label}
                </option>
              ))}
            </select>
          </div>
        );
      })}
    </Section>
  );
}

function MetadataSection({ s }: { s: AppSettings }): ReactNode {
  const [key, setKey] = useState('');
  const [hasKey, setHasKey] = useState(false);
  const [msg, setMsg] = useState('');
  useEffect(() => {
    void getProvider('tmdb')
      ?.isConfigured()
      .then((c) => {
        setHasKey(!!c);
      });
  }, []);

  const saveKey = async (): Promise<void> => {
    if (!key.trim()) return;
    try {
      await getProvider('tmdb')?.setApiKey(key.trim());
      setKey('');
      setHasKey(true);
      setMsg(t('settings.metadata.keySaved'));
    } catch (err) {
      setMsg(err instanceof Error ? err.message : 'Failed to save key.');
    }
  };

  return (
    <Section title={t('settings.metadata')}>
      <Field label={t('settings.metadata.provider')}>
        <select
          className="mm-select"
          value={s.metadataProvider ?? 'none'}
          onChange={(e) => {
            set({ metadataProvider: e.target.value === 'none' ? undefined : e.target.value });
          }}
          aria-label={t('settings.metadata.provider')}
        >
          <option value="none">{t('settings.metadata.provider.none')}</option>
          <option value="tmdb">TMDB (your key)</option>
        </select>
      </Field>
      <Field label={t('settings.metadata.apiKey')} hint={t('settings.metadata.providerKey.hint')}>
        <input
          className="mm-input"
          type="password"
          value={key}
          onChange={(e) => {
            setKey(e.target.value);
          }}
          placeholder={
            hasKey ? t('settings.metadata.apiKey.saved') : t('settings.metadata.apiKey.placeholder')
          }
          autoComplete="off"
          aria-label={t('settings.metadata.apiKey')}
        />
      </Field>
      <div className="mm-row">
        <Button
          variant="primary"
          label={t('settings.metadata.saveKey')}
          onClick={() => void saveKey()}
          disabled={!key.trim()}
        >
          {t('settings.metadata.saveKey')}
        </Button>
        {hasKey && (
          <Button
            variant="danger"
            label={t('settings.metadata.removeKey')}
            onClick={() =>
              void getProvider('tmdb')
                ?.clearApiKey()
                .then(() => {
                  setHasKey(false);
                  setMsg(t('settings.metadata.keyRemoved'));
                })
            }
          >
            {t('settings.metadata.removeKey')}
          </Button>
        )}
      </div>
      {msg && (
        <p role="status" style={{ fontSize: 13, color: 'var(--ok)' }}>
          {msg}
        </p>
      )}
      <p style={{ fontSize: 12.5, color: 'var(--text3)', lineHeight: 1.5 }}>
        {t('settings.metadata.noKeyWarning')}
      </p>
      <Toggle
        label={t('settings.metadata.cacheResponses')}
        checked={s.cacheProviderResponses}
        onChange={(v) => {
          set({ cacheProviderResponses: v });
        }}
      />
      <Toggle
        label={t('settings.metadata.wifiOnly')}
        checked={s.wifiOnlyMetadata}
        onChange={(v) => {
          set({ wifiOnlyMetadata: v });
        }}
      />
    </Section>
  );
}

function BackupSection(): ReactNode {
  const [msg, setMsg] = useState('');
  const [confirmReset, setConfirmReset] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const doExport = async (): Promise<void> => {
    try {
      await exportBackupFile();
      setMsg(t('settings.backup.exported'));
    } catch {
      setMsg(t('settings.backup.exportFailed'));
    }
  };

  const doImport = async (file: File): Promise<void> => {
    setMsg(t('settings.backup.validating'));
    try {
      const text = await file.text();
      const report = await importBackupFile(text, true);
      const proceed = await confirmNative(
        `Backup from ${new Date(report.exportedAt).toLocaleString()}: ${report.counts.items} items, ${report.counts.shows} shows, ${report.counts.collections} collections, ${report.counts.reviews} reviews. ${report.problems.length} problem(s) found — invalid records will be skipped. Import?`,
      );
      if (!proceed) {
        setMsg(t('settings.backup.cancelled'));
        return;
      }
      await importBackupFile(text, false);
      setMsg(t('settings.backup.imported'));
      setTimeout(() => {
        window.location.reload();
      }, 800);
    } catch (err) {
      setMsg(`${t('settings.backup.failed')}: ${err instanceof Error ? err.message : 'invalid file'}`);
    }
  };

  return (
    <Section title={t('settings.backup')}>
      <div className="mm-row">
        <Button variant="primary" label={t('settings.backup.export')} onClick={() => void doExport()}>
          {t('settings.backup.export')}
        </Button>
        <Button variant="ghost" label={t('settings.backup.import')} onClick={() => fileRef.current?.click()}>
          {t('settings.backup.import')}
        </Button>
      </div>
      <input
        ref={fileRef}
        type="file"
        accept="application/json"
        className="sr-only"
        aria-label={t('settings.backup.import')}
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) void doImport(f);
          e.target.value = '';
        }}
      />
      <div className="mm-row" style={{ marginTop: 8 }}>
        <Button
          variant="danger"
          label={t('settings.storage.reset')}
          onClick={() => {
            setConfirmReset(true);
          }}
        >
          {t('settings.storage.reset')}
        </Button>
      </div>
      {confirmReset && (
        <div
          className="mm-card"
          style={{ padding: 12, marginTop: 8, borderColor: 'var(--danger)' }}
          role="alertdialog"
          aria-label={t('settings.storage.reset')}
        >
          <p>{t('settings.storage.resetConfirm')}</p>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button
              label={t('common.cancel')}
              onClick={() => {
                setConfirmReset(false);
              }}
            >
              {t('common.cancel')}
            </Button>
            <Button
              variant="danger"
              label={t('common.delete')}
              onClick={() =>
                void repository.clearAll().then(() => {
                  window.location.reload();
                })
              }
            >
              {t('common.delete')}
            </Button>
          </div>
        </div>
      )}
      {msg && (
        <p role="status" style={{ fontSize: 13, color: 'var(--text2)' }}>
          {msg}
        </p>
      )}
    </Section>
  );
}

function PrivacySection({ s }: { s: AppSettings }): ReactNode {
  const [pinSet, setPinSet] = useState(false);
  const [pin, setPinInput] = useState('');
  const [pinMsg, setPinMsg] = useState('');
  useEffect(() => {
    void hasPin().then(setPinSet);
  }, []);

  const applyPin = async (): Promise<void> => {
    if (pinSet && pin === '') {
      await clearPin();
      setPinSet(false);
      setPinMsg(t('settings.privacy.pin.removed'));
      return;
    }
    if (!/^\d{4,8}$/.test(pin)) {
      setPinMsg(t('settings.privacy.pin.bad'));
      return;
    }
    await setPin(pin);
    setPinInput('');
    setPinSet(true);
    setPinMsg(t('settings.privacy.pin.done'));
  };

  return (
    <Section title={t('settings.privacy')}>
      <Toggle
        label={t('settings.privacy.crashReports')}
        checked={s.shareCrashReports}
        onChange={(v) => {
          set({ shareCrashReports: v });
        }}
      />
      <Toggle
        label={t('settings.privacy.includePaths')}
        checked={s.includeFullPathsInDiagnostics}
        onChange={(v) => {
          set({ includeFullPathsInDiagnostics: v });
        }}
      />
      <Field label={t('settings.privacy.pin')}>
        <div className="mm-row">
          <input
            className="mm-input"
            type="password"
            inputMode="numeric"
            value={pin}
            onChange={(e) => {
              setPinInput(e.target.value);
            }}
            placeholder={pinSet ? t('settings.privacy.pin.setMsg') : t('settings.privacy.pin.placeholder')}
            aria-label={t('settings.privacy.pin')}
          />
          <Button
            variant="primary"
            label={pinSet ? t('settings.privacy.pin.change') : t('settings.privacy.pin.set')}
            onClick={() => void applyPin()}
          >
            {pinSet ? t('settings.privacy.pin.change') : t('settings.privacy.pin.set')}
          </Button>
        </div>
        {pinMsg && (
          <p role="status" style={{ fontSize: 13 }}>
            {pinMsg}
          </p>
        )}
      </Field>
      <p style={{ fontSize: 12.5, color: 'var(--text3)' }}>{t('settings.privacy.noTracking')}</p>
    </Section>
  );
}

function StorageSection(): ReactNode {
  const [info, setInfo] = useState('—');
  useEffect(() => {
    void (async () => {
      if ('storage' in navigator && navigator.storage.estimate) {
        try {
          const est = await navigator.storage.estimate();
          const used = est.usage ?? 0;
          const quota = est.quota ?? 0;
          const mb = (b: number): string => `${(b / 1048576).toFixed(1)} MB`;
          setInfo(`${mb(used)} of ${mb(quota)} (${Math.round((used / Math.max(quota, 1)) * 100)}%)`);
        } catch {
          setInfo('Unavailable');
        }
      } else {
        setInfo('Unavailable on this platform');
      }
    })();
  }, []);
  return (
    <Section title={t('settings.storage')}>
      <p style={{ fontSize: 14 }}>
        {t('settings.storage.usage')}: <strong>{info}</strong>
      </p>
      <p style={{ fontSize: 13, color: 'var(--text2)', lineHeight: 1.6 }}>
        {t('settings.storage.explainer')}
      </p>
    </Section>
  );
}

function AccessibilitySection({ s }: { s: AppSettings }): ReactNode {
  return (
    <Section title={t('settings.accessibility')}>
      <div>
        <p style={{ fontSize: 14.5, fontWeight: 600, margin: '8px 0 0' }}>
          {t('settings.appearance.fontSize')}
        </p>
        <Slider
          label={t('settings.appearance.fontSize')}
          value={Math.round(s.fontScale * 100)}
          min={85}
          max={150}
          step={5}
          onChange={(v) => {
            set({ fontScale: v / 100 });
          }}
          formatValue={(v) => `${v}%`}
        />
      </div>
      <Toggle
        label={t('settings.appearance.highContrast')}
        checked={s.highContrast}
        onChange={(v) => {
          set({ highContrast: v });
        }}
      />
      <Toggle
        label={t('settings.appearance.reduceMotion')}
        checked={s.reduceMotion}
        onChange={(v) => {
          set({ reduceMotion: v });
        }}
      />
      <Toggle
        label={t('settings.appearance.reduceTransparency')}
        checked={s.reduceTransparency}
        onChange={(v) => {
          set({ reduceTransparency: v });
        }}
      />
      <Toggle
        label={t('settings.accessibility.dpadHints')}
        checked={s.dpadHints}
        onChange={(v) => {
          set({ dpadHints: v });
        }}
      />
      <p style={{ fontSize: 13, color: 'var(--text2)' }}>{t('settings.accessibility.shortcuts')}</p>
    </Section>
  );
}

export function SettingsPage(): ReactNode {
  const s = useSettings();
  const [active, setActive] = useState('playback');

  const groups: { id: string; label: string }[] = [
    { id: 'playback', label: t('settings.playback') },
    { id: 'gestures', label: t('settings.gestures') },
    { id: 'subtitles', label: t('settings.subtitles') },
    { id: 'appearance', label: t('settings.appearance') },
    { id: 'library', label: t('settings.library') },
    { id: 'metadata', label: t('settings.metadata') },
    { id: 'storage', label: t('settings.storage') },
    { id: 'backup', label: t('settings.backup') },
    { id: 'accessibility', label: t('settings.accessibility') },
    { id: 'privacy', label: t('settings.privacy') },
    { id: 'about', label: t('settings.about') },
  ];

  return (
    <div style={{ padding: '16px 12px 24px', maxWidth: 900, margin: '0 auto' }}>
      <h1 style={{ fontSize: 22, margin: '0 0 12px' }}>{t('nav.settings')}</h1>
      <div
        style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 12, marginBottom: 8 }}
        role="tablist"
        aria-label="Settings groups"
      >
        {groups.map((g) => (
          <button
            key={g.id}
            type="button"
            role="tab"
            aria-selected={active === g.id}
            className="mm-chip"
            style={active === g.id ? { background: 'var(--accent-soft)', color: 'var(--accent)' } : undefined}
            onClick={() => {
              setActive(g.id);
            }}
          >
            {g.label}
          </button>
        ))}
      </div>

      {active === 'playback' && <PlaybackSection s={s} />}
      {active === 'gestures' && <GesturesSection s={s} />}
      {active === 'subtitles' && <SubtitlesSection s={s} />}
      {active === 'appearance' && <AppearanceSection s={s} />}
      {active === 'library' && <LibrarySection s={s} />}
      {active === 'metadata' && <MetadataSection s={s} />}
      {active === 'storage' && <StorageSection />}
      {active === 'backup' && <BackupSection />}
      {active === 'accessibility' && <AccessibilitySection s={s} />}
      {active === 'privacy' && <PrivacySection s={s} />}
      {active === 'about' && (
        <Section title={t('settings.about')}>
          <p style={{ margin: 0, fontSize: 14 }}>
            {APP_NAME} {APP_VERSION}
          </p>
          <p style={{ fontSize: 13, color: 'var(--text2)', lineHeight: 1.6 }}>{t('settings.about.line1')}</p>
          <p style={{ fontSize: 13, color: 'var(--text2)' }}>{t('settings.about.license')}</p>
        </Section>
      )}
    </div>
  );
}
