// ---------------------------------------------------------------------------
// Library page: folder management (add/remove/rename/rescan), scan progress
// with cancel, and storage-permission explanations per platform.
// ---------------------------------------------------------------------------

import { useRef, useState, type ReactNode } from 'react';
import { useLibrary } from '../libraryContext';
import { Button, EmptyState, ErrorState, IconButton, ProgressBar, BottomSheet, Field } from '../../shared/ui';
import { t } from '../../shared/i18n';
import { isNative, nativeHasPermission } from '../../storage/adapters';
import { formatDateTime } from '../../shared/format';
import { repository } from '../../storage/repository';
import type { LibraryFolder } from '../../storage/types';

function FolderRow({ folder }: { folder: LibraryFolder }): ReactNode {
  const { startScan, removeFolder, scan } = useLibrary();
  const [confirmRemove, setConfirmRemove] = useState(false);
  const [rename, setRename] = useState<string | null>(null);
  const [permissionOk, setPermissionOk] = useState<boolean | null>(null);
  const scanning = scan.running && scan.folderId === folder.id;

  const checkPermission = async (): Promise<void> => {
    if (isNative) {
      setPermissionOk(await nativeHasPermission(folder.ref));
    } else if (folder.ref.startsWith('fsa:')) {
      const { hasDirectoryPermission } = await import('../../library/walkers');
      setPermissionOk(await hasDirectoryPermission(folder.id));
    } else {
      setPermissionOk(true);
    }
  };

  const reselect = async (): Promise<void> => {
    if (!isNative && folder.ref.startsWith('fsa:')) {
      const { requestDirectoryPermission } = await import('../../library/walkers');
      const ok = await requestDirectoryPermission(folder.id);
      setPermissionOk(ok);
      if (ok) void startScan(folder.id);
    }
  };

  return (
    <div className="mm-card" style={{ padding: 16 }}>
      <div className="mm-row" style={{ justifyContent: 'space-between' }}>
        <div style={{ minWidth: 0 }}>
          <h3 style={{ margin: 0, fontSize: 16, overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {folder.name}
          </h3>
          <p style={{ margin: '4px 0 0', fontSize: 12, color: 'var(--text3)' }}>
            {folder.lastScannedAt ? `Last scanned ${formatDateTime(folder.lastScannedAt)}` : 'Never scanned'}
            {' · '}
            {folder.platform === 'android' ? 'Android' : 'Browser'}
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
          <IconButton
            label={t('library.rescan')}
            onClick={() => void startScan(folder.id)}
            disabled={scanning}
          >
            ⟳
          </IconButton>
          <IconButton
            label="Rename folder"
            onClick={() => {
              setRename(folder.name);
            }}
          >
            ✎
          </IconButton>
          <IconButton
            label={t('library.removeFolder')}
            onClick={() => {
              setConfirmRemove(true);
            }}
          >
            🗑
          </IconButton>
        </div>
      </div>

      {scanning && scan.stats && (
        <div style={{ marginTop: 12 }} role="status" aria-label={t('library.scanning')}>
          <p style={{ fontSize: 13, color: 'var(--text2)', margin: '0 0 6px' }}>
            {t('library.currentFolder', { name: scan.stats.currentPath.split('/').pop() ?? '' })}
          </p>
          <ProgressBar
            fraction={scan.stats.total > 0 ? scan.stats.done / scan.stats.total : 0}
            label={t('library.scanning')}
          />
          <p style={{ fontSize: 12, color: 'var(--text3)', margin: '6px 0' }}>
            {t('library.scanProgress', {
              done: scan.stats.done,
              total: scan.stats.total,
              added: scan.stats.added,
              updated: scan.stats.updated,
              skipped: scan.stats.skipped,
              errors: scan.stats.errors,
            })}
          </p>
        </div>
      )}

      <div className="mm-row" style={{ marginTop: 8 }}>
        <Button variant="ghost" label="Check access" onClick={() => void checkPermission()}>
          Check access
        </Button>
        {permissionOk === false && (
          <>
            <span role="alert" style={{ fontSize: 13, color: 'var(--danger)', flex: 1 }}>
              {t('library.permissionLost.body', { name: folder.name })}
            </span>
            {!isNative && folder.ref.startsWith('fsa:') && (
              <Button variant="primary" label={t('setup.reselect')} onClick={() => void reselect()}>
                {t('setup.reselect')}
              </Button>
            )}
          </>
        )}
        {permissionOk === true && <span style={{ fontSize: 13, color: 'var(--ok)' }}>Access OK</span>}
      </div>

      {confirmRemove && (
        <BottomSheet
          title={t('library.removeFolder')}
          onClose={() => {
            setConfirmRemove(false);
          }}
        >
          <p>
            Remove “{folder.name}” from the library? Your files stay on the device; only the library entries
            and their progress are removed.
          </p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
            <Button
              label={t('common.cancel')}
              onClick={() => {
                setConfirmRemove(false);
              }}
            >
              {t('common.cancel')}
            </Button>
            <Button
              variant="danger"
              label={t('common.delete')}
              onClick={() => {
                void removeFolder(folder.id);
                setConfirmRemove(false);
              }}
            >
              {t('common.delete')}
            </Button>
          </div>
        </BottomSheet>
      )}
      {rename !== null && (
        <BottomSheet
          title="Rename folder"
          onClose={() => {
            setRename(null);
          }}
        >
          <Field label="Display name">
            <input
              className="mm-input"
              value={rename}
              onChange={(e) => {
                setRename(e.target.value);
              }}
              aria-label="Display name"
            />
          </Field>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
            <Button
              label={t('common.cancel')}
              onClick={() => {
                setRename(null);
              }}
            >
              {t('common.cancel')}
            </Button>
            <Button
              variant="primary"
              label={t('common.save')}
              onClick={() => {
                const name = rename.trim();
                if (name)
                  void repository.upsertFolder({ ...folder, name }).then(() => {
                    window.location.reload();
                  });
                setRename(null);
              }}
            >
              {t('common.save')}
            </Button>
          </div>
        </BottomSheet>
      )}
    </div>
  );
}

export function LibraryPage(): ReactNode {
  const { folders, addFolder, addFilesFallback, scan, cancelScan } = useLibrary();
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const choose = async (): Promise<void> => {
    setBusy(true);
    try {
      const res = await addFolder();
      if (!res.ok && res.reason === 'needs-file-input') fileRef.current?.click();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div style={{ padding: '16px 12px 24px', maxWidth: 900, margin: '0 auto' }}>
      <div className="mm-section-title">
        <h2>{t('library.folders')}</h2>
        <Button
          variant="primary"
          label={t('library.addFolder')}
          onClick={() => void choose()}
          disabled={busy}
        >
          + {t('library.addFolder')}
        </Button>
      </div>

      <div className="mm-card" style={{ padding: 16, marginBottom: 16 }}>
        <h3 style={{ margin: '0 0 8px', fontSize: 15 }}>{t('setup.howItWorks')}</h3>
        <p style={{ margin: 0, fontSize: 13.5, color: 'var(--text2)', lineHeight: 1.55 }}>
          {isNative ? t('setup.androidNote') : t('setup.browserNote')}
        </p>
      </div>

      {scan.running && (
        <div className="mm-card" style={{ padding: 16, marginBottom: 16 }} role="status">
          <div className="mm-row" style={{ justifyContent: 'space-between' }}>
            <strong>{t('library.scanning')}</strong>
            <Button variant="danger" label={t('library.cancelScan')} onClick={cancelScan}>
              {t('library.cancelScan')}
            </Button>
          </div>
          {scan.stats && (
            <p style={{ fontSize: 13, color: 'var(--text2)' }}>
              {t('library.scanProgress', {
                done: scan.stats.done,
                total: scan.stats.total,
                added: scan.stats.added,
                updated: scan.stats.updated,
                skipped: scan.stats.skipped,
                errors: scan.stats.errors,
              })}
            </p>
          )}
        </div>
      )}

      {folders.length === 0 ? (
        <EmptyState
          title={t('library.emptyFolder.title')}
          body={t('library.emptyFolder.body', { list: 'MP4, MKV, WebM, MOV, MP3, FLAC…' })}
          action={
            <Button variant="primary" label={t('library.addFolder')} onClick={() => void choose()}>
              {t('library.addFolder')}
            </Button>
          }
        />
      ) : (
        <div style={{ display: 'grid', gap: 12 }}>
          {folders.map((f) => (
            <FolderRow key={f.id} folder={f} />
          ))}
        </div>
      )}

      <input
        ref={fileRef}
        type="file"
        multiple
        // @ts-expect-error webkitdirectory is non-standard but widely supported
        webkitdirectory=""
        className="sr-only"
        aria-label={t('setup.chooseFiles')}
        onChange={(e) => {
          const files = [...(e.target.files ?? [])];
          if (files.length > 0) void addFilesFallback(files);
          e.target.value = '';
        }}
      />
    </div>
  );
}

export function ScanErrorNotice({ onRescan }: { onRescan: () => void }): ReactNode {
  return (
    <ErrorState
      title={t('player.error.title')}
      body={t('library.emptyFolder.body', { list: '' })}
      onRetry={onRescan}
    />
  );
}
