// ---------------------------------------------------------------------------
// Offline page: titles with app-managed copies, storage usage, and honest
// platform messaging. On Android every file is already on the device.
// ---------------------------------------------------------------------------

import { useEffect, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import {
  listOfflineCopies,
  offlineBytesTotal,
  removeOfflineCopy,
  type OfflineCopy,
} from '../../storage/offline';
import { repository } from '../../storage/repository';
import { isNative } from '../../storage/adapters';
import { Button, EmptyState, IconButton } from '../../shared/ui';
import { formatBytes, formatDateTime } from '../../shared/format';
import { t } from '../../shared/i18n';

export function OfflinePage(): ReactNode {
  const [copies, setCopies] = useState<(OfflineCopy & { title: string })[]>([]);
  const [bytes, setBytes] = useState(0);
  const [ready, setReady] = useState(false);

  const reload = async (): Promise<void> => {
    const list = await listOfflineCopies();
    const items = await repository.getItems(list.map((c) => c.itemId));
    const byId = new Map(items.map((i) => [i.id, i]));
    setCopies(list.map((c) => ({ ...c, title: byId.get(c.itemId)?.title ?? 'Unknown title' })));
    setBytes(await offlineBytesTotal());
    setReady(true);
  };

  useEffect(() => {
    void reload();
  }, []);

  const remove = async (itemId: string): Promise<void> => {
    await removeOfflineCopy(itemId);
    await reload();
  };

  return (
    <div style={{ padding: '16px 12px 24px', maxWidth: 900, margin: '0 auto' }}>
      <div className="mm-section-title">
        <h2>{t('nav.offline')}</h2>
      </div>

      {isNative ? (
        <div className="mm-card" style={{ padding: 16 }}>
          <h3 style={{ margin: '0 0 8px' }}>Everything is already offline</h3>
          <p style={{ margin: 0, color: 'var(--text2)', fontSize: 14, lineHeight: 1.55 }}>
            On Android your media files live on this device, so the whole library — artwork, progress,
            favorites, reviews and settings — works without internet. No separate downloads are needed.
          </p>
        </div>
      ) : (
        <div className="mm-card" style={{ padding: 16, marginBottom: 16 }}>
          <h3 style={{ margin: '0 0 8px' }}>App-managed copies</h3>
          <p style={{ margin: '0 0 8px', color: 'var(--text2)', fontSize: 14, lineHeight: 1.55 }}>
            Browsers forget folder permissions when you leave. Save a copy of a title inside the app and it
            stays playable. Copies live in this browser's private storage ({ready ? formatBytes(bytes) : '…'}{' '}
            used). Use “Save offline copy” on any title's detail page.
          </p>
        </div>
      )}

      {!isNative && ready && copies.length === 0 && (
        <EmptyState
          title="No offline copies"
          body="Save a copy from a title's detail page and it will appear here, playable even after the browser forgets your folders."
          action={
            <Link className="mm-btn mm-btn-primary" to="/">
              Browse library
            </Link>
          }
        />
      )}

      {!isNative && copies.length > 0 && (
        <div style={{ display: 'grid', gap: 8 }}>
          {copies.map((c) => (
            <div key={c.itemId} className="mm-card" style={{ padding: '12px 16px' }}>
              <div className="mm-row" style={{ justifyContent: 'space-between' }}>
                <div>
                  <strong>{c.title}</strong>
                  <p style={{ margin: '4px 0 0', fontSize: 12, color: 'var(--text3)' }}>
                    {formatBytes(c.bytes)} · saved {formatDateTime(c.savedAt)}
                  </p>
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <Link className="mm-btn mm-btn-ghost" to={`/play/${c.itemId}`}>
                    Play
                  </Link>
                  <IconButton
                    label={`Remove offline copy of ${c.title}`}
                    onClick={() => void remove(c.itemId)}
                  >
                    🗑
                  </IconButton>
                </div>
              </div>
            </div>
          ))}
          <p style={{ fontSize: 12, color: 'var(--text3)' }}>Total: {formatBytes(bytes)}</p>
        </div>
      )}

      {!isNative && !ready && <p>{t('common.loading')}</p>}
      <div style={{ height: 8 }} />
      <Button variant="ghost" label="Refresh" onClick={() => void reload()}>
        Refresh
      </Button>
    </div>
  );
}
