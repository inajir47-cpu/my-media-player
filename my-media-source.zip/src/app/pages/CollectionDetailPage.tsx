// ---------------------------------------------------------------------------
// CollectionDetailPage: view, reorder, remove and add titles in a collection.
// ---------------------------------------------------------------------------

import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useLibrary } from '../libraryContext';
import { addToCollection, removeFromCollection, reorderCollection } from '../../collections/store';
import { repository } from '../../storage/repository';
import type { MediaItem } from '../../storage/types';
import { BottomSheet, Button, EmptyState, IconButton } from '../../shared/ui';
import { t } from '../../shared/i18n';
import { logger } from '../../shared/logger';

function detailPath(item: MediaItem): string {
  return item.kind === 'episode' && item.groupId ? `/show/${item.groupId}` : `/movie/${item.id}`;
}

function AddItemsSheet({
  collectionId,
  existingIds,
  onClose,
  onChanged,
}: {
  collectionId: string;
  existingIds: Set<string>;
  onClose: () => void;
  onChanged: () => Promise<void>;
}): ReactNode {
  const [query, setQuery] = useState('');
  const [candidates, setCandidates] = useState<MediaItem[]>([]);
  const [busyId, setBusyId] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    const q = query.trim().toLowerCase();
    void repository.allItems().then((all) => {
      if (cancelled) return;
      const filtered = all
        .filter((it) => !existingIds.has(it.id))
        .filter((it) => q === '' || it.title.toLowerCase().includes(q))
        .sort((a, b) => a.title.localeCompare(b.title))
        .slice(0, 100);
      setCandidates(filtered);
    });
    return () => {
      cancelled = true;
    };
  }, [query, existingIds]);

  const add = async (item: MediaItem): Promise<void> => {
    setBusyId(item.id);
    try {
      await addToCollection(collectionId, item.id);
      await onChanged();
    } catch {
      logger.warn('collections', 'add item failed', { id: item.id });
    } finally {
      setBusyId(null);
    }
  };

  return (
    <BottomSheet title={t('collections.addItems')} onClose={onClose}>
      <input
        className="mm-input"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder={t('collections.searchHint')}
        aria-label={t('collections.searchHint')}
        style={{ margin: '8px 0' }}
      />
      <ul style={{ listStyle: 'none', margin: 0, padding: 0, maxHeight: '50vh', overflowY: 'auto' }}>
        {candidates.map((it) => (
          <li
            key={it.id}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '8px 0',
              borderBottom: '1px solid var(--line)',
            }}
          >
            <span style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {it.title}
              {it.year ? ` (${it.year})` : ''}
            </span>
            <Button
              variant="ghost"
              label={`${t('collections.addItems')}: ${it.title}`}
              onClick={() => void add(it)}
              disabled={busyId === it.id}
            >
              ＋
            </Button>
          </li>
        ))}
        {candidates.length === 0 && (
          <li style={{ color: 'var(--text3)', padding: '12px 0' }}>{t('collections.emptyDetail')}</li>
        )}
      </ul>
    </BottomSheet>
  );
}

export function CollectionDetailPage(): ReactNode {
  const { id } = useParams();
  const navigate = useNavigate();
  const { collections, refresh } = useLibrary();
  const collection = useMemo(() => collections.find((c) => c.id === id), [collections, id]);
  const [items, setItems] = useState<MediaItem[]>([]);
  const [pickerOpen, setPickerOpen] = useState(false);

  useEffect(() => {
    if (!collection) return;
    let cancelled = false;
    void repository.getItems(collection.itemIds).then((found) => {
      if (!cancelled) setItems(found);
    });
    return () => {
      cancelled = true;
    };
  }, [collection]);

  if (!collection) {
    return (
      <div style={{ padding: '16px 16px 96px' }}>
        <EmptyState title={t('collections.title')} body={t('collections.empty')} />
        <Button variant="ghost" label={t('collections.back')} onClick={() => navigate('/collections')}>
          ← {t('collections.back')}
        </Button>
      </div>
    );
  }

  const byId = new Map(items.map((it) => [it.id, it]));
  const ordered = collection.itemIds
    .map((itemId) => byId.get(itemId))
    .filter((it): it is MediaItem => it !== undefined);

  const move = async (index: number, delta: -1 | 1): Promise<void> => {
    const next = [...collection.itemIds];
    const j = index + delta;
    if (j < 0 || j >= next.length) return;
    const a = next[index];
    const b = next[j];
    if (a === undefined || b === undefined) return;
    next[index] = b;
    next[j] = a;
    await reorderCollection(collection.id, next);
    await refresh();
  };

  const remove = async (itemId: string): Promise<void> => {
    await removeFromCollection(collection.id, itemId);
    await refresh();
  };

  const existingIds = new Set(collection.itemIds);

  return (
    <div style={{ padding: '16px 16px 96px', maxWidth: 720 }}>
      <Button variant="ghost" label={t('collections.back')} onClick={() => navigate('/collections')}>
        ← {t('collections.back')}
      </Button>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '12px 0 4px' }}>
        <h1 style={{ fontSize: 24, margin: 0, flex: 1 }}>{collection.name}</h1>
        <Button variant="primary" label={t('collections.addItems')} onClick={() => setPickerOpen(true)}>
          ＋ {t('collections.addItems')}
        </Button>
      </div>
      <p style={{ color: 'var(--text3)', fontSize: 13, margin: '0 0 16px' }}>
        {t('collections.count', { n: collection.itemIds.length })}
      </p>

      {ordered.length === 0 ? (
        <EmptyState title={collection.name} body={t('collections.emptyDetail')} />
      ) : (
        <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
          {ordered.map((it, index) => (
            <li
              key={it.id}
              className="mm-card"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 4,
                padding: '10px 12px',
                marginBottom: 8,
              }}
            >
              <Link
                to={detailPath(it)}
                style={{ flex: 1, textDecoration: 'none', color: 'inherit', minWidth: 0 }}
              >
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{it.title}</span>
                {it.year ? <span style={{ color: 'var(--text3)', fontSize: 12 }}> ({it.year})</span> : null}
              </Link>
              <IconButton
                label={t('collections.moveUp')}
                onClick={() => void move(index, -1)}
                disabled={index === 0}
              >
                ↑
              </IconButton>
              <IconButton
                label={t('collections.moveDown')}
                onClick={() => void move(index, 1)}
                disabled={index === ordered.length - 1}
              >
                ↓
              </IconButton>
              <IconButton label={t('collections.remove')} onClick={() => void remove(it.id)}>
                ✕
              </IconButton>
            </li>
          ))}
        </ul>
      )}

      {pickerOpen && (
        <AddItemsSheet
          collectionId={collection.id}
          existingIds={existingIds}
          onClose={() => setPickerOpen(false)}
          onChanged={refresh}
        />
      )}
    </div>
  );
}
