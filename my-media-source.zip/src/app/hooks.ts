// ---------------------------------------------------------------------------
// Shared app hooks: viewport classification, media queries, online status.
// ---------------------------------------------------------------------------

import { useEffect, useState } from 'react';
import { breakpoints } from '../shared/tokens';

export type ViewportKind = 'phone' | 'tablet' | 'desktop';

export function viewportKind(width: number): ViewportKind {
  if (width >= breakpoints.desktop) return 'desktop';
  if (width >= breakpoints.tablet) return 'tablet';
  return 'phone';
}

export function useViewport(): { kind: ViewportKind; width: number; landscape: boolean } {
  const [width, setWidth] = useState(() => (typeof window === 'undefined' ? 1280 : window.innerWidth));
  const [landscape, setLandscape] = useState(() =>
    typeof window === 'undefined' ? false : window.innerWidth > window.innerHeight,
  );
  useEffect(() => {
    const onResize = (): void => {
      setWidth(window.innerWidth);
      setLandscape(window.innerWidth > window.innerHeight);
    };
    window.addEventListener('resize', onResize);
    window.addEventListener('orientationchange', onResize);
    return () => {
      window.removeEventListener('resize', onResize);
      window.removeEventListener('orientationchange', onResize);
    };
  }, []);
  return { kind: viewportKind(width), width, landscape };
}

export function useOnline(): boolean {
  const [online, setOnline] = useState(() => (typeof navigator === 'undefined' ? true : navigator.onLine));
  useEffect(() => {
    const on = (): void => {
      setOnline(true);
    };
    const off = (): void => {
      setOnline(false);
    };
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
    };
  }, []);
  return online;
}
