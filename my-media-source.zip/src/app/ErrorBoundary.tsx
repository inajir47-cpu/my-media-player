// ---------------------------------------------------------------------------
// Error boundary: a crashed screen never becomes a blank page.
// ---------------------------------------------------------------------------

import { Component, type ReactNode } from 'react';
import { logger } from '../shared/logger';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error): void {
    logger.error('ui', 'render crash caught', { message: error.message.slice(0, 120) });
  }

  render(): ReactNode {
    if (this.state.error) {
      return (
        this.props.fallback ?? (
          <div className="mm-empty" role="alert" style={{ paddingTop: 80 }}>
            <h2>Something went wrong</h2>
            <p>This screen crashed, but your library is safe. Try going back or restarting the app.</p>
            <button
              type="button"
              className="mm-btn mm-btn-primary"
              onClick={() => {
                this.setState({ error: null });
              }}
              aria-label="Try again"
            >
              Try again
            </button>
          </div>
        )
      );
    }
    return this.props.children;
  }
}
