// ---------------------------------------------------------------------------
// App: provider composition + route table. The player route renders outside
// the chrome layout (it is its own fullscreen surface).
// ---------------------------------------------------------------------------

import type { ReactNode } from 'react';
import { HashRouter, Navigate, Route, Routes } from 'react-router-dom';
import { Boot } from './boot';
import { ErrorBoundary } from './ErrorBoundary';
import { Layout } from './layout';
import { LibraryProvider } from './libraryContext';
import { HomePage } from './pages/HomePage';
import { LibraryPage } from './pages/LibraryPage';
import { MoviesPage, ShowsPage } from './pages/ListPages';
import { OfflinePage } from './pages/OfflinePage';
import { SearchPage } from './pages/SearchPage';
import { SettingsPage } from './pages/SettingsPage';
import { CollectionsPage } from './pages/CollectionsPage';
import { CollectionDetailPage } from './pages/CollectionDetailPage';
import { MovieDetailPage } from '../details/MovieDetail';
import { ShowDetailPage } from '../details/ShowDetail';
import { IdentifyPage } from '../details/IdentifyPage';
import { PlayerPage } from '../player/PlayerPage';

function Chrome({ children }: { children: ReactNode }): ReactNode {
  return <Layout>{children}</Layout>;
}

export function App(): ReactNode {
  return (
    <ErrorBoundary>
      <LibraryProvider>
        <Boot>
          <HashRouter>
            <Routes>
              {/* Fullscreen player: no app chrome. */}
              <Route path="/play/:id" element={<PlayerPage />} />
              <Route
                path="/*"
                element={
                  <Chrome>
                    <Routes>
                      <Route path="/" element={<HomePage />} />
                      <Route path="/library" element={<LibraryPage />} />
                      <Route path="/movies" element={<MoviesPage />} />
                      <Route path="/shows" element={<ShowsPage />} />
                      <Route path="/search" element={<SearchPage />} />
                      <Route path="/offline" element={<OfflinePage />} />
                      <Route path="/settings" element={<SettingsPage />} />
                      <Route path="/collections" element={<CollectionsPage />} />
                      <Route path="/collection/:id" element={<CollectionDetailPage />} />
                      <Route path="/movie/:id" element={<MovieDetailPage />} />
                      <Route path="/show/:id" element={<ShowDetailPage />} />
                      <Route path="/identify/:id" element={<IdentifyPage />} />
                      <Route path="*" element={<Navigate to="/" replace />} />
                    </Routes>
                  </Chrome>
                }
              />
            </Routes>
          </HashRouter>
        </Boot>
      </LibraryProvider>
    </ErrorBoundary>
  );
}
