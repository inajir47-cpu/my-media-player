// ---------------------------------------------------------------------------
// Playback state rules: when to resume vs restart, when to mark watched,
// when an item counts as completed. Pure functions — unit tested.
// ---------------------------------------------------------------------------

/** Restart instead of resuming when fewer than this was watched. */
export const RESTART_THRESHOLD_MS = 30_000;
/** With less than this remaining, the item counts as completed. */
export const COMPLETION_REMAINING_MS = 60_000;
/** Progress is "meaningful" for Continue Watching above this. */
export const MIN_PROGRESS_MS = 5_000;

export interface ResumeDecision {
  action: 'resume' | 'restart' | 'fresh';
  positionMs: number;
}

/**
 * Decide what playback should do given saved progress.
 * - < 30 s watched -> restart from 0 (user barely started)
 * - < 60 s remaining -> treat as completed (start over / next)
 * - otherwise resume
 */
export function decideResume(progressMs: number, durationMs: number | undefined): ResumeDecision {
  if (!progressMs || progressMs < MIN_PROGRESS_MS) return { action: 'fresh', positionMs: 0 };
  if (progressMs < RESTART_THRESHOLD_MS) return { action: 'restart', positionMs: 0 };
  if (durationMs && durationMs - progressMs < COMPLETION_REMAINING_MS) {
    return { action: 'restart', positionMs: 0 };
  }
  return { action: 'resume', positionMs: progressMs };
}

/** Has the item crossed the watched threshold? Default 90%. */
export function isWatched(progressMs: number, durationMs: number | undefined, threshold: number): boolean {
  if (!durationMs || durationMs <= 0) return false;
  return progressMs / durationMs >= threshold;
}

/** Fraction 0..1 for progress bars. */
export function progressFraction(progressMs: number, durationMs: number | undefined): number {
  if (!durationMs || durationMs <= 0 || progressMs <= 0) return 0;
  return Math.min(1, progressMs / durationMs);
}

/** Remaining ms; used for the "less than 60 s remain" completion rule. */
export function remainingMs(progressMs: number, durationMs: number | undefined): number | undefined {
  if (!durationMs) return undefined;
  return Math.max(0, durationMs - progressMs);
}

/** Autoplay countdown seconds before advancing (cancelable). */
export const AUTOPLAY_COUNTDOWN_SEC = 10;
