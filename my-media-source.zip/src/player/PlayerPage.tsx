// ---------------------------------------------------------------------------
// PlayerPage: the full custom media player. One <video> element, custom
// controls, real platform capabilities only — every button maps to a working
// behavior, and capabilities that do not exist are never offered.
// ---------------------------------------------------------------------------

import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties, type ReactNode } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { repository } from '../storage/repository';
import type { MediaItem } from '../storage/types';
import { getSettings, updateSettings, useSettings } from '../settings/store';
import { t } from '../shared/i18n';
import { BottomSheet, Button, EmptyState, ErrorState, IconButton, Slider } from '../shared/ui';
import { resolvePlayableUrl, resolveSubtitleTrackUrl } from '../library/playable';
import { cueAt, parseVtt, type Cue } from './cues';
import {
  AUTOPLAY_COUNTDOWN_SEC,
  COMPLETION_REMAINING_MS,
  decideResume,
  isWatched,
  RESTART_THRESHOLD_MS,
} from './persistence';
import {
  createQueue,
  currentId,
  cycleRepeat,
  queueNext,
  queuePrevious,
  seasonQueue,
  toggleShuffle,
  type QueueState,
} from './queue';
import { gestureActionFor, type GestureAction } from './gestures';
import { nextSpeedDown, nextSpeedUp, SPEEDS } from './shortcuts';
import { brightness, haptics, isNative, openExternalPlayer, volume } from '../storage/adapters';
import { formatDuration } from '../shared/format';
import type { GestureId } from '../storage/types';

type FitMode = 'contain' | 'cover' | 'fill';

interface EmbeddedSub {
  index: number;
  label: string;
}

interface AudioTrackInfo {
  index: number;
  label: string;
}

const TUTORIAL_KEY = 'mm.player.gestureTutorialSeen';

function clamp(v: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, v));
}

export function PlayerPage(): ReactNode {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const settings = useSettings();

  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const saveTimer = useRef<number>(0);
  const sleepTimerRef = useRef<number>(0);
  const hideControlsTimer = useRef<number>(0);
  const gestureState = useRef({
    pointers: new Map<number, { x: number; y: number }>(),
    startX: 0,
    startY: 0,
    startT: 0,
    lastTapT: 0,
    lastTapX: 0,
    moved: false,
    pinchDist: 0,
    scrubbing: false,
    scrubStartX: 0,
    scrubStartTime: 0,
    verticalSide: null as 'left' | 'right' | null,
    verticalStartY: 0,
    verticalStartValue: 0,
    longPressTimer: 0,
    longPressFired: false,
    overlayTimer: 0,
  });
  const sessionRef = useRef({ startedAt: 0, fromMs: 0, playCounted: false, ended: false });
  const autoplayRef = useRef(0);
  const wakeLockRef = useRef<{ release: () => Promise<void> } | null>(null);

  const [item, setItem] = useState<MediaItem | null>(null);
  const [queue, setQueue] = useState<QueueState | null>(null);
  const [queueTitles, setQueueTitles] = useState<Map<string, string>>(new Map());
  const [src, setSrc] = useState<string | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [videoError, setVideoError] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [bufferedEnd, setBufferedEnd] = useState(0);
  const [rate, setRate] = useState(1);
  const [muted, setMuted] = useState(false);
  const [vol, setVol] = useState(1);
  const [showControls, setShowControls] = useState(true);
  const [locked, setLocked] = useState(false);
  const [fit, setFit] = useState<FitMode>('contain');
  const [sheet, setSheet] = useState<
    'subtitles' | 'audio' | 'speed' | 'sleep' | 'more' | 'queue' | 'resume' | null
  >(null);
  const [embeddedSubs, setEmbeddedSubs] = useState<EmbeddedSub[]>([]);
  const [embeddedSubIndex, setEmbeddedSubIndex] = useState<number>(-1);
  const [sidecarUrls, setSidecarUrls] = useState<string[]>([]);
  const [sidecarCues, setSidecarCues] = useState<Cue[][]>([]);
  const [sidecarIndex, setSidecarIndex] = useState<number>(-1);
  const [audioTracks, setAudioTracks] = useState<AudioTrackInfo[]>([]);
  const [audioIndex, setAudioIndex] = useState(0);
  const [overlay, setOverlay] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [autoplayIn, setAutoplayIn] = useState<number | null>(null);
  const [sleepIn, setSleepIn] = useState<number | null>(null);
  const [showTutorial, setShowTutorial] = useState(false);
  const [brightnessOverlay, setBrightnessOverlay] = useState(1);

  const seekSecs = settings.seekIntervalSec;
  const gesture = useCallback(
    (gid: GestureId): GestureAction => gestureActionFor(settings.gestures, gid),
    [settings.gestures],
  );

  // -- load item, queue, playable url -------------------------------------------
  useEffect(() => {
    if (!id) return;
    let cancelled = false;
    void (async () => {
      const found = await repository.getItem(id);
      if (cancelled) return;
      if (!found) {
        setLoadError('not-found');
        return;
      }
      setItem(found);
      let q: QueueState;
      if (found.kind === 'episode' && found.groupId) {
        const eps = await repository.episodesForShow(found.groupId);
        q = seasonQueue(eps, found.id);
        if (!cancelled) setQueueTitles(new Map(eps.map((e) => [e.id, e.title])));
      } else {
        q = createQueue([found.id]);
        if (!cancelled) setQueueTitles(new Map<string, string>([[found.id, found.title]]));
      }
      if (cancelled) return;
      setQueue(q);
      const url = await resolvePlayableUrl(found);
      if (cancelled) return;
      if (!url) {
        setLoadError(found.technical.unsupportedReason ? 'unsupported' : 'unreachable');
        return;
      }
      setSrc(url);
      // Sidecar subtitles: resolve to VTT and parse cues for the custom renderer.
      const urls: string[] = [];
      const cues: Cue[][] = [];
      for (let i = 0; i < found.subtitleTracks.length; i++) {
        const u = await resolveSubtitleTrackUrl(found, i);
        if (cancelled) break;
        urls.push(u ?? '');
        if (u) {
          try {
            const text = await (await fetch(u)).text();
            cues.push(parseVtt(text));
          } catch {
            cues.push([]);
          }
        } else {
          cues.push([]);
        }
      }
      if (!cancelled) {
        setSidecarUrls(urls);
        setSidecarCues(cues);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [id]);

  // Revoke sidecar blob URLs on unmount / item change.
  useEffect(
    () => () => {
      for (const u of sidecarUrls) if (u.startsWith('blob:')) URL.revokeObjectURL(u);
    },
    [sidecarUrls],
  );

  // -- video element setup --------------------------------------------------------
  useEffect(() => {
    const v = videoRef.current;
    if (!v || !src) return;
    v.src = src;
    v.playbackRate = getSettings().defaultSpeed;
    setRate(getSettings().defaultSpeed);
    const fromParam = searchParams.get('from');
    const startAt = fromParam === '0' ? 0 : -1;
    const onError = (): void => {
      const e = v.error;
      setVideoError(errorMessage(e, item?.technical.unsupportedReason));
    };
    const onLoaded = (): void => {
      const durMs = Number.isFinite(v.duration) ? v.duration * 1000 : 0;
      setDuration(durMs);
      if (item) {
        const decision =
          startAt === 0 ? { action: 'fresh' as const, positionMs: 0 } : decideResume(item.progressMs, durMs);
        if (decision.action === 'resume' && decision.positionMs > 0) {
          if (getSettings().resumeBehavior === 'ask' && startAt !== 0) {
            setSheet('resume');
          } else if (getSettings().resumeBehavior === 'always' || startAt !== 0) {
            v.currentTime = decision.positionMs / 1000;
          }
          setTime(decision.positionMs);
        }
        // Only expose embedded subtitle / audio tracks that actually exist.
        try {
          const subs: EmbeddedSub[] = [];
          const tt = v.textTracks;
          for (let i = 0; i < tt.length; i++) {
            const track = tt[i];
            if (!track) continue;
            track.mode = 'hidden';
            subs.push({ index: i, label: track.label || track.language || `Track ${i + 1}` });
          }
          setEmbeddedSubs(subs);
        } catch {
          setEmbeddedSubs([]);
        }
        try {
          const at = (
            v as HTMLVideoElement & {
              audioTracks?: { length: number; [i: number]: { label: string; language: string } };
            }
          ).audioTracks;
          if (at && at.length > 1) {
            const list: AudioTrackInfo[] = [];
            for (let i = 0; i < at.length; i++) {
              const a = at[i];
              list.push({ index: i, label: a?.label || a?.language || t('player.audioTrack', { n: i + 1 }) });
            }
            setAudioTracks(list);
          }
        } catch {
          setAudioTracks([]);
        }
      }
    };
    v.addEventListener('loadedmetadata', onLoaded, { once: true });
    v.addEventListener('error', onError);
    const onPlay = (): void => {
      setPlaying(true);
      pokeControls();
    };
    const onPause = (): void => {
      setPlaying(false);
      void saveProgress();
      pokeControls();
    };
    const onTime = (): void => {
      setTime(v.currentTime * 1000);
      try {
        if (v.buffered.length > 0) setBufferedEnd(v.buffered.end(v.buffered.length - 1) * 1000);
      } catch {
        /* ignore */
      }
    };
    const onEnded = (): void => {
      void handleEnded();
    };
    v.addEventListener('play', onPlay);
    v.addEventListener('pause', onPause);
    v.addEventListener('timeupdate', onTime);
    v.addEventListener('progress', onTime);
    v.addEventListener('ended', onEnded);
    return () => {
      v.removeEventListener('loadedmetadata', onLoaded);
      v.removeEventListener('error', onError);
      v.removeEventListener('play', onPlay);
      v.removeEventListener('pause', onPause);
      v.removeEventListener('timeupdate', onTime);
      v.removeEventListener('progress', onTime);
      v.removeEventListener('ended', onEnded);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [src]);

  // -- progress persistence --------------------------------------------------------
  const saveProgress = useCallback(async (): Promise<void> => {
    const v = videoRef.current;
    if (!v || !item || !Number.isFinite(v.duration) || v.duration <= 0) return;
    const posMs = Math.floor(v.currentTime * 1000);
    const durMs = Math.floor(v.duration * 1000);
    const patch: Partial<MediaItem> = {
      progressMs: posMs,
      progressUpdatedAt: Date.now(),
      durationMs: durMs,
      lastPlayedAt: Date.now(),
    };
    const done =
      isWatched(posMs, durMs, getSettings().watchedThreshold) || durMs - posMs < COMPLETION_REMAINING_MS;
    if (done) {
      patch.watched = true;
      patch.watchedAt = Date.now();
    }
    await repository.updateItem(item.id, patch);
    setItem((prev) => (prev ? { ...prev, ...patch } : prev));
  }, [item]);

  useEffect(() => {
    saveTimer.current = window.setInterval(() => {
      if (!videoRef.current?.paused) void saveProgress();
    }, 5000);
    const onHide = (): void => {
      if (document.visibilityState === 'hidden') void saveProgress();
    };
    const onUnload = (): void => {
      void saveProgress();
    };
    document.addEventListener('visibilitychange', onHide);
    window.addEventListener('pagehide', onUnload);
    const videoEl = videoRef.current;
    return () => {
      window.clearInterval(saveTimer.current);
      document.removeEventListener('visibilitychange', onHide);
      window.removeEventListener('pagehide', onUnload);
      void saveProgress();
      // Session playback event for history / recently played.
      const s = sessionRef.current;
      if (s.playCounted && item) {
        void repository.addPlaybackEvent({
          id: `pe-${Date.now()}-${item.id}`,
          itemId: item.id,
          startedAt: s.startedAt,
          endedAt: Date.now(),
          fromMs: s.fromMs,
          toMs:
            videoEl && Number.isFinite(videoEl.currentTime)
              ? Math.floor(videoEl.currentTime * 1000)
              : s.fromMs,
        });
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [item?.id]);

  // Play count: one increment per session start.
  useEffect(() => {
    if (!item || sessionRef.current.playCounted) return;
    sessionRef.current = {
      startedAt: Date.now(),
      fromMs: item.progressMs,
      playCounted: true,
      ended: false,
    };
    void repository.updateItem(item.id, { playCount: item.playCount + 1 });
  }, [item]);

  // -- wake lock --------------------------------------------------------------------
  useEffect(() => {
    let cancelled = false;
    const apply = async (): Promise<void> => {
      if (playing) {
        try {
          const nav = navigator as Navigator & {
            wakeLock?: { request: (t: string) => Promise<{ release: () => Promise<void> }> };
          };
          if (nav.wakeLock && !wakeLockRef.current) {
            const lock = await nav.wakeLock.request('screen');
            if (!cancelled) wakeLockRef.current = lock;
            else await lock.release();
          }
        } catch {
          /* wake lock unavailable — playback continues */
        }
      } else if (wakeLockRef.current) {
        await wakeLockRef.current.release().catch(() => {});
        wakeLockRef.current = null;
      }
    };
    void apply();
    return () => {
      cancelled = true;
    };
  }, [playing]);

  // -- controls auto-hide --------------------------------------------------------------
  const pokeControls = useCallback((): void => {
    setShowControls(true);
    window.clearTimeout(hideControlsTimer.current);
    hideControlsTimer.current = window.setTimeout(() => {
      if (videoRef.current && !videoRef.current.paused) setShowControls(false);
    }, 3500);
  }, []);

  // -- transport --------------------------------------------------------------------------
  const togglePlay = useCallback((): void => {
    const v = videoRef.current;
    if (!v || locked) return;
    if (v.paused) void v.play().catch(() => {});
    else v.pause();
    pokeControls();
  }, [locked, pokeControls]);

  const seekBy = useCallback(
    (deltaMs: number): void => {
      const v = videoRef.current;
      if (!v || locked) return;
      v.currentTime = clamp(v.currentTime + deltaMs / 1000, 0, v.duration || 0);
      pokeControls();
    },
    [locked, pokeControls],
  );

  const seekTo = useCallback(
    (frac: number): void => {
      const v = videoRef.current;
      if (!v || !Number.isFinite(v.duration) || locked) return;
      v.currentTime = clamp(frac, 0, 1) * v.duration;
      pokeControls();
    },
    [locked, pokeControls],
  );

  const goToQueueIndex = useCallback(
    (index: number): void => {
      if (!queue) return;
      const targetId = queue.itemIds[index];
      if (targetId) void navigate(`/play/${targetId}`);
    },
    [queue, navigate],
  );

  const next = useCallback((): void => {
    if (!queue) return;
    const { queue: q, wrapped } = queueNext(queue);
    setQueue(q);
    if (wrapped && q.repeat === 'off') {
      showToast(t('player.queue') + ' — ' + t('common.done'));
      return;
    }
    const nid = currentId(q);
    if (nid && nid !== id) void navigate(`/play/${nid}`);
  }, [queue, id, navigate]);

  const previous = useCallback((): void => {
    if (!queue) return;
    const v = videoRef.current;
    const pos = v ? v.currentTime * 1000 : 0;
    // Past the restart threshold: restart the current item instead of going back.
    if (pos > RESTART_THRESHOLD_MS) {
      if (v) v.currentTime = 0;
      return;
    }
    const q = queuePrevious(queue, pos);
    setQueue(q);
    const nid = currentId(q);
    if (nid && nid !== id) void navigate(`/play/${nid}`);
  }, [queue, id, navigate]);

  const handleEnded = useCallback(async (): Promise<void> => {
    await saveProgress();
    sessionRef.current.ended = true;
    if (!queue || !item) return;
    const { queue: q } = queueNext(queue);
    const nid = currentId(q);
    if (nid && nid !== id && getSettings().autoplayNext) {
      let remaining = getSettings().autoplayDelaySec || AUTOPLAY_COUNTDOWN_SEC;
      setAutoplayIn(remaining);
      window.clearInterval(autoplayRef.current);
      autoplayRef.current = window.setInterval(() => {
        remaining -= 1;
        if (remaining <= 0) {
          window.clearInterval(autoplayRef.current);
          setAutoplayIn(null);
          void navigate(`/play/${nid}`);
        } else {
          setAutoplayIn(remaining);
        }
      }, 1000);
    }
  }, [queue, item, id, navigate, saveProgress]);

  const cancelAutoplay = useCallback((): void => {
    window.clearInterval(autoplayRef.current);
    setAutoplayIn(null);
  }, []);

  const cycleSpeed = useCallback(
    (dir: 1 | -1): void => {
      const v = videoRef.current;
      if (!v) return;
      const next = dir === 1 ? nextSpeedUp(rate) : nextSpeedDown(rate);
      v.playbackRate = next;
      setRate(next);
      showToast(t('gesture.speed', { value: next }));
    },
    [rate],
  );

  const setExactRate = useCallback((r: number): void => {
    const v = videoRef.current;
    if (!v) return;
    v.playbackRate = r;
    setRate(r);
  }, []);

  const toggleMute = useCallback((): void => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !v.muted;
    setMuted(v.muted);
  }, []);

  const changeVolume = useCallback((delta: number): void => {
    const v = videoRef.current;
    const nv = clamp((isNative ? volume.current : (v?.volume ?? 1)) + delta, 0, 1);
    void volume.set(nv);
    if (v && !isNative) v.volume = nv;
    setVol(nv);
    showOverlay(t('gesture.volume', { value: Math.round(nv * 100) }));
  }, []);

  const changeBrightness = useCallback((delta: number): void => {
    const nv = clamp(brightness.current + delta, 0.05, 1);
    void brightness.set(nv);
    setBrightnessOverlay(nv);
    showOverlay(
      brightness.mode === 'simulated'
        ? t('gesture.brightness.simulated', { value: Math.round(nv * 100) })
        : t('gesture.brightness', { value: Math.round(nv * 100) }),
    );
  }, []);

  const toggleFullscreen = useCallback((): void => {
    const el = containerRef.current;
    if (!el) return;
    if (document.fullscreenElement) void document.exitFullscreen().catch(() => {});
    else void el.requestFullscreen().catch(() => {});
  }, []);

  const togglePip = useCallback(async (): Promise<void> => {
    const v = videoRef.current;
    if (!v) return;
    try {
      const doc = document as Document & {
        pictureInPictureEnabled?: boolean;
        pictureInPictureElement?: Element | null;
        exitPictureInPicture?: () => Promise<void>;
      };
      const vv = v as HTMLVideoElement & {
        requestPictureInPicture?: () => Promise<void>;
        disablePictureInPicture?: boolean;
      };
      if (doc.pictureInPictureElement && doc.exitPictureInPicture) {
        await doc.exitPictureInPicture();
      } else if (doc.pictureInPictureEnabled !== false && vv.requestPictureInPicture) {
        await vv.requestPictureInPicture();
      } else {
        showToast(t('player.pip.unavailable'));
      }
    } catch {
      showToast(t('player.pip.unavailable'));
    }
  }, []);

  const toggleLock = useCallback((): void => {
    setLocked((l) => !l);
    pokeControls();
  }, [pokeControls]);

  // -- sleep timer --------------------------------------------------------------------------
  const startSleepTimer = useCallback((minutes: number): void => {
    window.clearTimeout(sleepTimerRef.current);
    if (minutes <= 0) {
      setSleepIn(null);
      return;
    }
    const endAt = Date.now() + minutes * 60_000;
    setSleepIn(minutes * 60);
    sleepTimerRef.current = window.setTimeout(() => {
      videoRef.current?.pause();
      setSleepIn(null);
      showToast(t('player.sleepTimer.off'));
    }, minutes * 60_000);
    // Tick the countdown display.
    const tick = window.setInterval(() => {
      const left = Math.max(0, Math.round((endAt - Date.now()) / 1000));
      setSleepIn(left);
      if (left <= 0) window.clearInterval(tick);
    }, 1000);
  }, []);

  useEffect(() => () => window.clearTimeout(sleepTimerRef.current), []);

  // -- overlays / toast ----------------------------------------------------------------------
  function showOverlay(text: string): void {
    setOverlay(text);
    window.clearTimeout(gestureState.current.overlayTimer);
    gestureState.current.overlayTimer = window.setTimeout(() => {
      setOverlay(null);
    }, 900);
  }

  function showToast(text: string): void {
    setToast(text);
    window.setTimeout(() => {
      setToast((cur) => (cur === text ? null : cur));
    }, 2600);
  }

  function errorMessage(e: MediaError | null, unsupported?: string): string {
    if (unsupported) return t('player.unsupportedCodec', { detail: unsupported });
    if (!e) return t('player.error.body', { title: item?.title ?? '', detail: '' });
    switch (e.code) {
      case e.MEDIA_ERR_SRC_NOT_SUPPORTED:
        return t('player.unsupportedCodec', { detail: item?.technical.container ?? 'unknown' });
      case e.MEDIA_ERR_NETWORK:
        return t('player.error.body', { title: item?.title ?? '', detail: 'Network/file access failed.' });
      case e.MEDIA_ERR_DECODE:
        return t('player.unsupportedCodec', { detail: item?.technical.videoCodec ?? 'decode' });
      default:
        return t('player.error.body', { title: item?.title ?? '', detail: '' });
    }
  }

  // -- subtitle selection -----------------------------------------------------------------------
  const selectSidecar = useCallback((index: number): void => {
    setSidecarIndex(index);
    setEmbeddedSubIndex(-1);
    const v = videoRef.current;
    if (v) {
      for (let i = 0; i < v.textTracks.length; i++) {
        const tr = v.textTracks[i];
        if (tr) tr.mode = 'disabled';
      }
    }
  }, []);

  const selectEmbedded = useCallback((index: number): void => {
    const v = videoRef.current;
    if (!v) return;
    setEmbeddedSubIndex(index);
    setSidecarIndex(-1);
    for (let i = 0; i < v.textTracks.length; i++) {
      const tr = v.textTracks[i];
      if (tr) tr.mode = i === index ? 'showing' : 'disabled';
    }
  }, []);

  const activeCue: Cue | null = useMemo(() => {
    if (sidecarIndex < 0) return null;
    const cues = sidecarCues[sidecarIndex];
    if (!cues || cues.length === 0) return null;
    return cueAt(cues, time, getSettings().subtitleDelayMs);
  }, [sidecarIndex, sidecarCues, time]);

  // -- audio track selection -----------------------------------------------------------------------
  const selectAudioTrack = useCallback((index: number): void => {
    const v = videoRef.current as
      | (HTMLVideoElement & { audioTracks?: { length: number; [i: number]: { enabled: boolean } } })
      | null;
    const at = v?.audioTracks;
    if (!at) return;
    for (let i = 0; i < at.length; i++) {
      const a = at[i];
      if (a) a.enabled = i === index;
    }
    setAudioIndex(index);
  }, []);

  // -- screenshot --------------------------------------------------------------------------------------
  const takeScreenshot = useCallback((): void => {
    const v = videoRef.current;
    if (!v || v.videoWidth === 0) {
      showToast(t('player.screenshot.unsupported'));
      return;
    }
    try {
      const canvas = document.createElement('canvas');
      canvas.width = v.videoWidth;
      canvas.height = v.videoHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('no 2d context');
      ctx.drawImage(v, 0, 0);
      canvas.toBlob((blob) => {
        if (!blob) {
          showToast(t('player.screenshot.unsupported'));
          return;
        }
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${(item?.title ?? 'screenshot').replace(/[^\w\- ]+/g, '').trim() || 'screenshot'}.png`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => {
          URL.revokeObjectURL(url);
        }, 5000);
        showToast(t('player.screenshot.saved'));
      }, 'image/png');
    } catch {
      // Canvas is tainted (protected content) or capture is blocked: say so.
      showToast(t('player.screenshot.unsupported'));
    }
  }, [item?.title]);

  const openExternal = useCallback(async (): Promise<void> => {
    if (!src) return;
    const ok = await openExternalPlayer(src);
    if (!ok) showToast(t('player.externalPlayer.unavailable'));
  }, [src]);

  // -- gestures ---------------------------------------------------------------------------------------------
  const runAction = useCallback(
    (action: GestureAction, value?: number): void => {
      const s = getSettings();
      switch (action) {
        case 'toggleControls':
          setShowControls((sc) => !sc);
          break;
        case 'togglePlay':
          togglePlay();
          break;
        case 'rewind':
          seekBy(-s.seekIntervalSec * 1000);
          showOverlay(t('gesture.rewind', { seconds: s.seekIntervalSec }));
          break;
        case 'forward':
          seekBy(s.seekIntervalSec * 1000);
          showOverlay(t('gesture.forward', { seconds: s.seekIntervalSec }));
          break;
        case 'scrub':
          break; // handled continuously during the swipe
        case 'brightness':
          changeBrightness(value ?? 0);
          break;
        case 'volume':
          changeVolume(value ?? 0);
          break;
        case 'zoom':
          setFit((f) => {
            const order: FitMode[] = ['contain', 'cover', 'fill'];
            const nf = order[(order.indexOf(f) + 1) % order.length] ?? 'contain';
            showOverlay(t('gesture.fit.changed', { value: t(`player.fit.${nf}` as 'player.fit.contain') }));
            return nf;
          });
          break;
        case 'temp2x': {
          const v = videoRef.current;
          if (v) {
            v.playbackRate = 2;
            showOverlay(t('gesture.speed', { value: 2 }));
          }
          break;
        }
        case 'toggleMute':
          toggleMute();
          break;
        case 'none':
          break;
      }
    },
    [togglePlay, seekBy, changeBrightness, changeVolume, toggleMute],
  );

  const endTemp2x = useCallback((): void => {
    const v = videoRef.current;
    if (v) v.playbackRate = rate;
  }, [rate]);

  const onPointerDown = useCallback(
    (e: React.PointerEvent): void => {
      const gs = gestureState.current;
      gs.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (gs.pointers.size === 1) {
        gs.startX = e.clientX;
        gs.startY = e.clientY;
        gs.startT = Date.now();
        gs.moved = false;
        gs.verticalSide = null;
        gs.longPressFired = false;
        const action = gesture('longPress');
        if (action === 'temp2x') {
          window.clearTimeout(gs.longPressTimer);
          gs.longPressTimer = window.setTimeout(() => {
            gs.longPressFired = true;
            runAction('temp2x');
            void haptics.impact();
          }, 500);
        }
      } else if (gs.pointers.size === 2) {
        const pts = [...gs.pointers.values()];
        const a = pts[0];
        const b = pts[1];
        if (a && b) gs.pinchDist = Math.hypot(a.x - b.x, a.y - b.y);
        window.clearTimeout(gs.longPressTimer);
        // Two-finger tap action fires on pointerup; mark that a second finger is down.
      }
    },
    [gesture, runAction],
  );

  const onPointerMove = useCallback(
    (e: React.PointerEvent): void => {
      const gs = gestureState.current;
      const pt = gs.pointers.get(e.pointerId);
      if (!pt) return;
      pt.x = e.clientX;
      pt.y = e.clientY;
      if (locked) return;
      const dx = e.clientX - gs.startX;
      const dy = e.clientY - gs.startY;
      if (Math.hypot(dx, dy) > 12) {
        gs.moved = true;
        window.clearTimeout(gs.longPressTimer);
      }
      if (gs.pointers.size === 2) {
        const pts = [...gs.pointers.values()];
        const a = pts[0];
        const b = pts[1];
        if (a && b) {
          const d = Math.hypot(a.x - b.x, a.y - b.y);
          if (gs.pinchDist > 0 && Math.abs(d - gs.pinchDist) > 40) {
            gs.pinchDist = d;
            const action = gesture('pinch');
            if (action !== 'none') runAction(action);
          }
        }
        return;
      }
      if (!gs.moved || gs.pointers.size !== 1) return;
      const el = containerRef.current;
      const rect = el?.getBoundingClientRect();
      const adx = Math.abs(dx);
      const ady = Math.abs(dy);
      if (!gs.scrubbing && gs.verticalSide === null) {
        if (adx > 24 && adx > ady * 1.5) {
          if (gesture('swipeHorizontal') === 'scrub') {
            gs.scrubbing = true;
            gs.scrubStartX = e.clientX;
            gs.scrubStartTime = videoRef.current?.currentTime ?? 0;
          }
        } else if (ady > 24 && ady > adx * 1.5 && rect) {
          const side = e.clientX < rect.left + rect.width / 2 ? 'left' : 'right';
          const gid = side === 'left' ? 'swipeVerticalLeft' : 'swipeVerticalRight';
          const action = gesture(gid);
          if (action === 'brightness' || action === 'volume') {
            gs.verticalSide = side;
            gs.verticalStartY = e.clientY;
            gs.verticalStartValue =
              side === 'left'
                ? brightness.current
                : isNative
                  ? volume.current
                  : (videoRef.current?.volume ?? 1);
          }
        }
      }
      if (gs.scrubbing && rect) {
        const v = videoRef.current;
        if (v && Number.isFinite(v.duration)) {
          const deltaFrac = (e.clientX - gs.scrubStartX) / rect.width;
          v.currentTime = clamp(gs.scrubStartTime + deltaFrac * v.duration, 0, v.duration);
          showOverlay(formatDuration(v.currentTime * 1000));
        }
      } else if (gs.verticalSide && rect) {
        const delta = (gs.verticalStartY - e.clientY) / (rect.height * 0.8); // full swipe = 80% of range
        if (gs.verticalSide === 'left') {
          const nv = clamp(gs.verticalStartValue + delta, 0.05, 1);
          void brightness.set(nv);
          setBrightnessOverlay(nv);
          showOverlay(
            brightness.mode === 'simulated'
              ? t('gesture.brightness.simulated', { value: Math.round(nv * 100) })
              : t('gesture.brightness', { value: Math.round(nv * 100) }),
          );
        } else {
          const nv = clamp(gs.verticalStartValue + delta, 0, 1);
          void volume.set(nv);
          const v = videoRef.current;
          if (v && !isNative) v.volume = nv;
          setVol(nv);
          showOverlay(t('gesture.volume', { value: Math.round(nv * 100) }));
        }
      }
    },
    [gesture, locked, runAction],
  );

  const onPointerUp = useCallback(
    (e: React.PointerEvent): void => {
      const gs = gestureState.current;
      const wasTwoFinger = gs.pointers.size === 2;
      gs.pointers.delete(e.pointerId);
      window.clearTimeout(gs.longPressTimer);
      if (gs.longPressFired) {
        endTemp2x();
        gs.longPressFired = false;
      }
      if (gs.pointers.size > 0) return;
      if (locked) {
        pokeControls();
        return;
      }
      if (wasTwoFinger && !gs.moved) {
        const action = gesture('twoFingerTap');
        if (action !== 'none') {
          runAction(action);
          void haptics.impact();
        }
      } else if (!gs.moved && !wasTwoFinger) {
        const now = Date.now();
        const rect = containerRef.current?.getBoundingClientRect();
        const x = rect ? (e.clientX - rect.left) / rect.width : 0.5;
        const dt = now - gs.lastTapT;
        const near = Math.hypot(e.clientX - gs.lastTapX, 0) < 60;
        if (dt < 320 && near) {
          // Double tap: left / center / right zones.
          const gid = x < 0.33 ? 'doubleTapLeft' : x > 0.67 ? 'doubleTapRight' : 'doubleTapCenter';
          const action = gesture(gid);
          if (action !== 'none') {
            runAction(action);
            void haptics.impact();
          }
          gs.lastTapT = 0;
        } else {
          gs.lastTapT = now;
          gs.lastTapX = e.clientX;
          // Single tap fires after the double-tap window, so double taps
          // do not also trigger the single-tap action.
          window.setTimeout(() => {
            if (gestureState.current.lastTapT === now) {
              const action = gesture('tap');
              if (action !== 'none') runAction(action);
            }
          }, 330);
        }
      }
      gs.scrubbing = false;
      gs.verticalSide = null;
    },
    [gesture, locked, runAction, endTemp2x, pokeControls],
  );

  // -- keyboard / D-pad ---------------------------------------------------------------------------
  useEffect(() => {
    const onKey = (e: KeyboardEvent): void => {
      if (sheet) {
        if (e.key === 'Escape') setSheet(null);
        return;
      }
      if (locked && e.key !== 'Escape') return;
      const s = getSettings();
      switch (e.key) {
        case ' ':
        case 'k':
        case 'Enter':
          e.preventDefault();
          togglePlay();
          break;
        case 'ArrowLeft':
          e.preventDefault();
          seekBy(-s.seekIntervalSec * 1000);
          break;
        case 'ArrowRight':
          e.preventDefault();
          seekBy(s.seekIntervalSec * 1000);
          break;
        case 'ArrowUp':
          e.preventDefault();
          changeVolume(0.05);
          break;
        case 'ArrowDown':
          e.preventDefault();
          changeVolume(-0.05);
          break;
        case 'j':
          seekBy(-10000);
          break;
        case 'l':
          seekBy(10000);
          break;
        case 'm':
          toggleMute();
          break;
        case 'f':
          toggleFullscreen();
          break;
        case 'p':
          void togglePip();
          break;
        case 'c':
          setSheet('subtitles');
          break;
        case '[':
          cycleSpeed(-1);
          break;
        case ']':
          cycleSpeed(1);
          break;
        case 'n':
          next();
          break;
        case 'Escape': {
          // Android back / dialog dismiss: close sheets, exit lock, else leave.
          if (locked) setLocked(false);
          else void navigate(-1);
          break;
        }
      }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
    };
  }, [
    sheet,
    locked,
    togglePlay,
    seekBy,
    changeVolume,
    toggleMute,
    toggleFullscreen,
    togglePip,
    cycleSpeed,
    next,
    navigate,
  ]);

  // -- gesture tutorial (discoverability) ---------------------------------------------------------------
  useEffect(() => {
    try {
      if (!localStorage.getItem(TUTORIAL_KEY)) setShowTutorial(true);
    } catch {
      /* ignore */
    }
  }, []);

  const dismissTutorial = useCallback((): void => {
    try {
      localStorage.setItem(TUTORIAL_KEY, '1');
    } catch {
      /* ignore */
    }
    setShowTutorial(false);
  }, []);

  // -- render ---------------------------------------------------------------------------------------------------
  if (loadError === 'not-found') {
    return (
      <div style={{ padding: 24 }}>
        <ErrorState
          title="Not found"
          body="This title is no longer in your library."
          onRetry={() => navigate('/')}
        />
      </div>
    );
  }
  if (loadError || videoError) {
    const unsupported = loadError === 'unsupported';
    return (
      <div style={{ padding: 24, maxWidth: 560, margin: '0 auto' }}>
        <ErrorState
          title={t('player.error.title')}
          body={
            unsupported
              ? t('player.unsupportedCodec', { detail: item?.technical.container ?? 'unknown' })
              : (videoError ?? t('player.error.body', { title: item?.title ?? '', detail: '' }))
          }
          onRetry={() => {
            setVideoError(null);
            setLoadError(null);
            const v = videoRef.current;
            if (v && src) {
              v.src = src;
              void v.play().catch(() => {});
            } else {
              void navigate(0);
            }
          }}
        />
        <details style={{ marginTop: 16, fontSize: 13, color: 'var(--text2)' }}>
          <summary>{t('player.error.details')}</summary>
          <p>
            {item?.technical.container ? `Container: ${item.technical.container}. ` : ''}
            {item?.technical.videoCodec ? `Video: ${item.technical.videoCodec}. ` : ''}
            {item?.technical.audioCodec ? `Audio: ${item.technical.audioCodec}.` : ''}
          </p>
        </details>
        {isNative && src ? (
          <div style={{ marginTop: 16 }}>
            <Button variant="ghost" label={t('player.chooseAnother')} onClick={() => void openExternal()}>
              {t('player.chooseAnother')}
            </Button>
          </div>
        ) : null}
        <div style={{ marginTop: 16 }}>
          <Button variant="ghost" label={t('common.cancel')} onClick={() => navigate(-1)}>
            {t('common.cancel')}
          </Button>
        </div>
      </div>
    );
  }
  if (!item || !src) {
    return (
      <div style={{ padding: 24 }}>
        <EmptyState title={t('common.loading')} body="" />
      </div>
    );
  }

  const frac = duration > 0 ? time / duration : 0;
  const bufferedFrac = duration > 0 ? bufferedEnd / duration : 0;
  const queueList = queue?.itemIds ?? [];
  const subStyle = settings.subtitleStyle;

  return (
    <div
      ref={containerRef}
      style={{
        position: 'fixed',
        inset: 0,
        background: '#000',
        color: '#fff',
        overflow: 'hidden',
        touchAction: 'none',
        userSelect: 'none',
        zIndex: 50,
      }}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
    >
      <video
        ref={videoRef}
        playsInline
        preload="auto"
        style={{ width: '100%', height: '100%', objectFit: fit, background: '#000' }}
        aria-label={item.title}
      />
      {/* Simulated brightness overlay (web/PWA only — Android uses the real window). */}
      {brightness.mode === 'simulated' && brightnessOverlay < 1 ? (
        <div
          aria-hidden="true"
          style={{
            position: 'absolute',
            inset: 0,
            background: '#000',
            opacity: 1 - brightnessOverlay,
            pointerEvents: 'none',
          }}
        />
      ) : null}

      {/* Custom sidecar subtitle renderer: real delay + style control. */}
      {activeCue ? (
        <div
          aria-hidden="true"
          style={{
            position: 'absolute',
            left: 16,
            right: 16,
            [subStyle.position === 'top' ? 'top' : 'bottom']: 'calc(96px + env(safe-area-inset-bottom))',
            textAlign: 'center',
            pointerEvents: 'none',
          }}
        >
          <span
            style={{
              display: 'inline-block',
              fontSize: `${subStyle.size}%`,
              color: subStyle.color,
              background: subStyle.background,
              padding: '4px 12px',
              borderRadius: 6,
              whiteSpace: 'pre-line',
              lineHeight: 1.4,
            }}
          >
            {activeCue.text}
          </span>
        </div>
      ) : null}

      {/* Center gesture overlay */}
      {overlay ? (
        <div
          aria-hidden="true"
          style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            background: 'rgba(0,0,0,0.65)',
            padding: '10px 18px',
            borderRadius: 12,
            fontSize: 15,
            pointerEvents: 'none',
          }}
        >
          {overlay}
        </div>
      ) : null}

      {/* Top bar */}
      {(showControls || locked) && (
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            padding: 'calc(12px + env(safe-area-inset-top)) 12px 24px',
            background: 'linear-gradient(180deg, rgba(0,0,0,0.7), transparent)',
            display: 'flex',
            alignItems: 'center',
            gap: 8,
          }}
        >
          <IconButton label={t('common.cancel')} onClick={() => navigate(-1)}>
            <span style={{ color: '#fff' }}>←</span>
          </IconButton>
          <div style={{ flex: 1, minWidth: 0 }}>
            <p
              style={{
                margin: 0,
                fontWeight: 700,
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
              }}
            >
              {item.title}
            </p>
            {item.kind === 'episode' && (item.season !== undefined || item.episode !== undefined) ? (
              <p style={{ margin: 0, fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>
                S{item.season ?? 0} E{item.episode ?? 0}
              </p>
            ) : null}
          </div>
          {sleepIn !== null ? (
            <span style={{ fontSize: 12, color: 'var(--accent)' }} role="timer">
              ⏾ {formatDuration(sleepIn * 1000)}
            </span>
          ) : null}
          <IconButton label={t('player.lock')} onClick={toggleLock}>
            <span style={{ color: locked ? 'var(--accent)' : '#fff' }}>{locked ? '🔒' : '🔓'}</span>
          </IconButton>
        </div>
      )}

      {/* Lock overlay */}
      {locked ? (
        <button
          type="button"
          onClick={toggleLock}
          aria-label={t('player.lock')}
          style={{
            position: 'absolute',
            right: 16,
            bottom: 'calc(120px + env(safe-area-inset-bottom))',
            background: 'rgba(0,0,0,0.6)',
            border: '1px solid rgba(255,255,255,0.25)',
            borderRadius: 12,
            color: '#fff',
            padding: '12px 16px',
            fontSize: 14,
          }}
        >
          🔒 {t('player.unlock')}
        </button>
      ) : null}

      {/* Bottom controls */}
      {showControls && !locked ? (
        <div
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            bottom: 0,
            padding: '24px 12px calc(12px + env(safe-area-inset-bottom))',
            background: 'linear-gradient(0deg, rgba(0,0,0,0.8), transparent)',
          }}
        >
          {/* Seek bar with buffered display */}
          <div style={{ position: 'relative', height: 28, display: 'flex', alignItems: 'center' }}>
            <div
              style={{
                position: 'absolute',
                left: 0,
                right: 0,
                height: 4,
                background: 'rgba(255,255,255,0.25)',
                borderRadius: 2,
              }}
            />
            <div
              style={{
                position: 'absolute',
                left: 0,
                width: `${bufferedFrac * 100}%`,
                height: 4,
                background: 'rgba(255,255,255,0.45)',
                borderRadius: 2,
              }}
            />
            <div
              style={{
                position: 'absolute',
                left: 0,
                width: `${frac * 100}%`,
                height: 4,
                background: 'var(--accent)',
                borderRadius: 2,
              }}
            />
            <input
              type="range"
              aria-label={t('player.seekForward', { seconds: seekSecs })}
              min={0}
              max={1000}
              value={Math.round(frac * 1000)}
              onChange={(e) => {
                seekTo(parseInt(e.target.value, 10) / 1000);
              }}
              style={{ position: 'absolute', inset: 0, width: '100%', opacity: 0, height: 28, margin: 0 }}
            />
            <div
              aria-hidden="true"
              style={{
                position: 'absolute',
                left: `calc(${frac * 100}% - 7px)`,
                width: 14,
                height: 14,
                borderRadius: '50%',
                background: 'var(--accent)',
              }}
            />
          </div>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              fontSize: 12,
              color: 'rgba(255,255,255,0.8)',
              marginBottom: 4,
            }}
          >
            <span>{formatDuration(time)}</span>
            <span>{formatDuration(duration)}</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 4 }}>
            <IconButton label={t('player.previous')} onClick={previous}>
              <span style={{ color: '#fff' }}>⏮</span>
            </IconButton>
            <IconButton
              label={t('player.seekBack', { seconds: seekSecs })}
              onClick={() => {
                seekBy(-seekSecs * 1000);
              }}
            >
              <span style={{ color: '#fff' }}>⟲</span>
            </IconButton>
            <button
              type="button"
              onClick={togglePlay}
              aria-label={playing ? t('player.pause') : t('player.play')}
              style={{
                width: 64,
                height: 64,
                borderRadius: '50%',
                background: 'var(--accent)',
                border: 'none',
                color: '#000',
                fontSize: 26,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              {playing ? '⏸' : '▶'}
            </button>
            <IconButton
              label={t('player.seekForward', { seconds: seekSecs })}
              onClick={() => {
                seekBy(seekSecs * 1000);
              }}
            >
              <span style={{ color: '#fff' }}>⟳</span>
            </IconButton>
            <IconButton label={t('player.next')} onClick={next}>
              <span style={{ color: '#fff' }}>⏭</span>
            </IconButton>
          </div>
          <div
            style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 6 }}
          >
            <div style={{ display: 'flex', gap: 2 }}>
              <IconButton label={muted ? t('player.unmute') : t('player.mute')} onClick={toggleMute}>
                <span style={{ color: '#fff' }}>{muted || vol === 0 ? '🔇' : '🔊'}</span>
              </IconButton>
              <IconButton
                label={t('player.speed')}
                onClick={() => {
                  setSheet('speed');
                }}
              >
                <span style={{ color: '#fff', fontSize: 13, fontWeight: 700 }}>{rate}×</span>
              </IconButton>
            </div>
            <div style={{ display: 'flex', gap: 2 }}>
              {queueList.length > 1 ? (
                <IconButton
                  label={t('player.queue')}
                  onClick={() => {
                    setSheet('queue');
                  }}
                >
                  <span style={{ color: '#fff' }}>☰</span>
                </IconButton>
              ) : null}
              <IconButton
                label={t('player.subtitles')}
                onClick={() => {
                  setSheet('subtitles');
                }}
              >
                <span
                  style={{ color: sidecarIndex >= 0 || embeddedSubIndex >= 0 ? 'var(--accent)' : '#fff' }}
                >
                  💬
                </span>
              </IconButton>
              <IconButton label={t('player.pip')} onClick={() => void togglePip()}>
                <span style={{ color: '#fff' }}>⧉</span>
              </IconButton>
              <IconButton label={t('player.fullscreen')} onClick={toggleFullscreen}>
                <span style={{ color: '#fff' }}>⛶</span>
              </IconButton>
              <IconButton
                label={t('player.sleepTimer')}
                onClick={() => {
                  setSheet('sleep');
                }}
              >
                <span style={{ color: sleepIn !== null ? 'var(--accent)' : '#fff' }}>⏾</span>
              </IconButton>
              <IconButton
                label="⋯"
                onClick={() => {
                  setSheet('more');
                }}
              >
                <span style={{ color: '#fff' }}>⋯</span>
              </IconButton>
            </div>
          </div>
        </div>
      ) : null}

      {/* Autoplay countdown */}
      {autoplayIn !== null ? (
        <div
          role="status"
          style={{
            position: 'absolute',
            right: 16,
            bottom: 'calc(150px + env(safe-area-inset-bottom))',
            background: 'rgba(0,0,0,0.75)',
            borderRadius: 12,
            padding: 12,
            display: 'flex',
            alignItems: 'center',
            gap: 12,
          }}
        >
          <span style={{ fontSize: 14 }}>{t('player.autoplay.next', { seconds: autoplayIn })}</span>
          <Button variant="ghost" label={t('player.autoplay.cancel')} onClick={cancelAutoplay}>
            {t('player.autoplay.cancel')}
          </Button>
        </div>
      ) : null}

      {/* Toast */}
      {toast ? (
        <div
          role="status"
          style={{
            position: 'absolute',
            bottom: 'calc(24px + env(safe-area-inset-bottom))',
            left: '50%',
            transform: 'translateX(-50%)',
            background: 'rgba(0,0,0,0.8)',
            padding: '8px 16px',
            borderRadius: 8,
            fontSize: 13,
            whiteSpace: 'nowrap',
          }}
        >
          {toast}
        </div>
      ) : null}

      {/* Sheets */}
      {sheet === 'subtitles' ? (
        <BottomSheet
          title={t('player.subtitles')}
          onClose={() => {
            setSheet(null);
          }}
        >
          <SubtitleSheet
            sidecarTracks={item.subtitleTracks.map((s, i) => ({
              label: s.label,
              active: i === sidecarIndex,
              hasCues: (sidecarCues[i]?.length ?? 0) > 0,
              onSelect: () => {
                selectSidecar(i);
              },
            }))}
            embedded={embeddedSubs.map((s) => ({
              label: `${t('player.embedded')}: ${s.label}`,
              active: s.index === embeddedSubIndex,
              onSelect: () => {
                selectEmbedded(s.index);
              },
            }))}
            noneActive={sidecarIndex < 0 && embeddedSubIndex < 0}
            onNone={() => {
              selectSidecar(-1);
              selectEmbedded(-1);
            }}
            delayMs={settings.subtitleDelayMs}
            onDelay={(v) => void updateSettings({ subtitleDelayMs: v })}
          />
        </BottomSheet>
      ) : null}
      {sheet === 'audio' ? (
        <BottomSheet
          title={t('player.audio')}
          onClose={() => {
            setSheet(null);
          }}
        >
          {audioTracks.length > 0 ? (
            <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
              {audioTracks.map((a) => (
                <li key={a.index}>
                  <button
                    type="button"
                    onClick={() => {
                      selectAudioTrack(a.index);
                      setSheet(null);
                    }}
                    style={{
                      width: '100%',
                      textAlign: 'left',
                      padding: '12px 4px',
                      background: 'none',
                      border: 'none',
                      color: a.index === audioIndex ? 'var(--accent)' : 'var(--text)',
                      fontSize: 15,
                    }}
                  >
                    {a.index === audioIndex ? '● ' : '○ '}
                    {a.label}
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p style={{ color: 'var(--text2)' }}>{t('player.noTracks')}</p>
          )}
          <Slider
            label={t('player.audioDelay')}
            value={settings.audioDelayMs}
            min={-500}
            max={500}
            step={25}
            onChange={(v) => void updateSettings({ audioDelayMs: v })}
            formatValue={(v) => `${v} ms`}
          />
          <p style={{ fontSize: 12, color: 'var(--text3)' }}>
            {t('player.audioDelay')}: {settings.audioDelayMs} ms
          </p>
        </BottomSheet>
      ) : null}
      {sheet === 'speed' ? (
        <BottomSheet
          title={t('player.speed')}
          onClose={() => {
            setSheet(null);
          }}
        >
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {SPEEDS.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => {
                  setExactRate(s);
                  setSheet(null);
                }}
                aria-pressed={s === rate}
                style={{
                  padding: '10px 16px',
                  borderRadius: 10,
                  border: s === rate ? '2px solid var(--accent)' : '1px solid var(--line)',
                  background: 'var(--bg2)',
                  color: 'var(--text)',
                  fontSize: 15,
                  minHeight: 44,
                }}
              >
                {s}×
              </button>
            ))}
          </div>
        </BottomSheet>
      ) : null}
      {sheet === 'sleep' ? (
        <BottomSheet
          title={t('player.sleepTimer')}
          onClose={() => {
            setSheet(null);
          }}
        >
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {[0, 15, 30, 45, 60, 90].map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => {
                  startSleepTimer(m);
                  setSheet(null);
                }}
                aria-pressed={(sleepIn ?? 0) > 0 && m > 0}
                style={{
                  padding: '10px 16px',
                  borderRadius: 10,
                  border: '1px solid var(--line)',
                  background: 'var(--bg2)',
                  color: 'var(--text)',
                  fontSize: 15,
                  minHeight: 44,
                }}
              >
                {m === 0 ? t('player.sleepTimer.off') : t('common.minutes', { n: m })}
              </button>
            ))}
          </div>
          {sleepIn !== null && sleepIn > 0 ? (
            <p role="timer" style={{ color: 'var(--accent)' }}>
              {t('player.sleepTimer.endsAt', { minutes: Math.ceil(sleepIn / 60) })}
            </p>
          ) : null}
        </BottomSheet>
      ) : null}
      {sheet === 'queue' ? (
        <BottomSheet
          title={t('player.queue')}
          onClose={() => {
            setSheet(null);
          }}
        >
          <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
            <Button
              variant="ghost"
              label="shuffle"
              onClick={() => {
                setQueue((q) => (q ? toggleShuffle(q) : q));
              }}
            >
              {queue?.shuffle ? '🔀 ✓' : '🔀'}
            </Button>
            <Button
              variant="ghost"
              label="repeat"
              onClick={() => {
                setQueue((q) => (q ? cycleRepeat(q) : q));
              }}
            >
              🔁 {queue?.repeat}
            </Button>
          </div>
          <ol style={{ listStyle: 'none', margin: 0, padding: 0, maxHeight: '40vh', overflowY: 'auto' }}>
            {queueList.map((qid, i) => (
              <li key={qid}>
                <button
                  type="button"
                  onClick={() => {
                    setSheet(null);
                    goToQueueIndex(i);
                  }}
                  style={{
                    width: '100%',
                    textAlign: 'left',
                    padding: '10px 4px',
                    background: 'none',
                    border: 'none',
                    color: qid === id ? 'var(--accent)' : 'var(--text)',
                    fontSize: 15,
                    display: 'flex',
                    gap: 8,
                  }}
                >
                  <span aria-hidden="true">{qid === id ? '▶' : `${i + 1}.`}</span>
                  <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {queueTitles.get(qid) ?? qid}
                  </span>
                </button>
              </li>
            ))}
          </ol>
        </BottomSheet>
      ) : null}
      {sheet === 'more' ? (
        <BottomSheet
          title="⋯"
          onClose={() => {
            setSheet(null);
          }}
        >
          <MoreSheet
            item={item}
            fit={fit}
            onFit={(f) => {
              setFit(f);
            }}
            onScreenshot={takeScreenshot}
            onExternal={isNative ? () => void openExternal() : undefined}
            onToggleWatched={() => {
              void repository
                .updateItem(item.id, {
                  watched: !item.watched,
                  watchedAt: !item.watched ? Date.now() : undefined,
                  progressMs: !item.watched && duration > 0 ? duration : item.progressMs,
                })
                .then(() => {
                  setItem((p) => (p ? { ...p, watched: !p.watched } : p));
                });
              setSheet(null);
            }}
            onRemoveContinue={() => {
              void repository.updateItem(item.id, { progressMs: 0, progressUpdatedAt: Date.now() });
              setSheet(null);
              showToast(t('common.done'));
            }}
            onAudio={() => {
              setSheet('audio');
            }}
            hasAudioTracks={audioTracks.length > 0}
          />
        </BottomSheet>
      ) : null}
      {sheet === 'resume' ? (
        <BottomSheet
          title={item.title}
          onClose={() => {
            setSheet(null);
          }}
        >
          <p style={{ color: 'var(--text2)' }}>
            {t('player.resumeFrom', { time: formatDuration(item.progressMs) })}
          </p>
          <div style={{ display: 'flex', gap: 8 }}>
            <Button
              variant="primary"
              label={t('player.resumeFrom', { time: formatDuration(item.progressMs) })}
              onClick={() => {
                const v = videoRef.current;
                if (v) v.currentTime = item.progressMs / 1000;
                setSheet(null);
                pokeControls();
              }}
            >
              {t('detail.resume')}
            </Button>
            <Button
              variant="ghost"
              label={t('player.startOver')}
              onClick={() => {
                setSheet(null);
              }}
            >
              {t('player.startOver')}
            </Button>
          </div>
        </BottomSheet>
      ) : null}

      {/* Gesture tutorial */}
      {showTutorial ? (
        <BottomSheet title={t('gesture.tutorial.title')} onClose={dismissTutorial}>
          <p style={{ color: 'var(--text2)', fontSize: 14 }}>{t('gesture.tutorial.body')}</p>
          <p style={{ color: 'var(--text3)', fontSize: 13 }}>{t('player.controlsHint')}</p>
          <Button variant="primary" label={t('gesture.tutorial.gotIt')} onClick={dismissTutorial}>
            {t('gesture.tutorial.gotIt')}
          </Button>
        </BottomSheet>
      ) : null}
    </div>
  );
}

function SubtitleSheet({
  sidecarTracks,
  embedded,
  noneActive,
  onNone,
  delayMs,
  onDelay,
}: {
  sidecarTracks: { label: string; active: boolean; hasCues: boolean; onSelect: () => void }[];
  embedded: { label: string; active: boolean; onSelect: () => void }[];
  noneActive: boolean;
  onNone: () => void;
  delayMs: number;
  onDelay: (v: number) => void;
}): ReactNode {
  const rows: { label: string; active: boolean; onSelect: () => void; note?: string }[] = [
    ...sidecarTracks.map((s) => ({
      label: s.label,
      active: s.active,
      onSelect: s.onSelect,
      note: s.hasCues ? undefined : t('player.noTracks'),
    })),
    ...embedded,
  ];
  return (
    <div>
      <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
        <li>
          <button type="button" onClick={onNone} style={rowStyle(noneActive)}>
            {noneActive ? '● ' : '○ '}
            {t('player.sleepTimer.off')}
          </button>
        </li>
        {rows.map((r, i) => (
          <li key={i}>
            <button
              type="button"
              onClick={r.onSelect}
              disabled={r.note !== undefined && !r.active}
              style={rowStyle(r.active)}
            >
              {r.active ? '● ' : '○ '}
              {r.label}
              {r.note ? <span style={{ color: 'var(--text3)', fontSize: 12 }}> — {r.note}</span> : null}
            </button>
          </li>
        ))}
      </ul>
      {rows.length === 0 ? <p style={{ color: 'var(--text2)' }}>{t('player.noTracks')}</p> : null}
      <Slider
        label={t('player.subtitleDelay')}
        value={delayMs}
        min={-2000}
        max={2000}
        step={50}
        onChange={onDelay}
        formatValue={(v) => `${v} ms`}
      />
    </div>
  );
}

function rowStyle(active: boolean): CSSProperties {
  return {
    width: '100%',
    textAlign: 'left',
    padding: '12px 4px',
    background: 'none',
    border: 'none',
    color: active ? 'var(--accent)' : 'var(--text)',
    fontSize: 15,
  };
}

function MoreSheet({
  item,
  fit,
  onFit,
  onScreenshot,
  onExternal,
  onToggleWatched,
  onRemoveContinue,
  onAudio,
  hasAudioTracks,
}: {
  item: MediaItem;
  fit: FitMode;
  onFit: (f: FitMode) => void;
  onScreenshot: () => void;
  onExternal?: () => void;
  onToggleWatched: () => void;
  onRemoveContinue: () => void;
  onAudio: () => void;
  hasAudioTracks: boolean;
}): ReactNode {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
      <p style={{ margin: '4px 0', fontSize: 13, color: 'var(--text3)' }}>{t('player.fit')}</p>
      <div style={{ display: 'flex', gap: 8 }}>
        {(['contain', 'cover', 'fill'] as FitMode[]).map((f) => (
          <button
            key={f}
            type="button"
            onClick={() => {
              onFit(f);
            }}
            aria-pressed={fit === f}
            style={{
              padding: '10px 16px',
              borderRadius: 10,
              border: fit === f ? '2px solid var(--accent)' : '1px solid var(--line)',
              background: 'var(--bg2)',
              color: 'var(--text)',
              minHeight: 44,
            }}
          >
            {t(`player.fit.${f}` as 'player.fit.contain')}
          </button>
        ))}
      </div>
      {hasAudioTracks ? (
        <button type="button" onClick={onAudio} style={rowStyle(false)}>
          {t('player.audio')}
        </button>
      ) : null}
      <button type="button" onClick={onScreenshot} style={rowStyle(false)}>
        📷 {t('player.screenshot')}
      </button>
      {onExternal ? (
        <button type="button" onClick={onExternal} style={rowStyle(false)}>
          {t('player.externalPlayer')}
        </button>
      ) : null}
      <button type="button" onClick={onToggleWatched} style={rowStyle(false)}>
        {item.watched ? t('player.markUnwatched') : t('player.markWatched')}
      </button>
      {item.progressMs > 0 ? (
        <button type="button" onClick={onRemoveContinue} style={rowStyle(false)}>
          {t('player.removeContinue')}
        </button>
      ) : null}
      <div style={{ marginTop: 12, fontSize: 13, color: 'var(--text3)' }}>
        <p style={{ margin: '4px 0' }}>
          {item.technical.container ? `${item.technical.container.toUpperCase()} · ` : ''}
          {item.technical.videoCodec ? `${item.technical.videoCodec} · ` : ''}
          {item.technical.width && item.technical.height
            ? `${item.technical.width}×${item.technical.height} · `
            : ''}
          {item.durationMs ? formatDuration(item.durationMs) : ''}
        </p>
        <p style={{ margin: '4px 0' }}>{t('player.cast.omitted')}</p>
      </div>
    </div>
  );
}
