import { describe, expect, it } from 'vitest';
import type { MediaItem } from '../storage/types';
import {
  createQueue,
  currentId,
  cycleRepeat,
  queueNext,
  queuePrevious,
  seasonQueue,
  toggleShuffle,
} from './queue';

function episode(id: string): MediaItem {
  return {
    id,
    kind: 'episode',
    title: id,
    sortTitle: id,
    uri: `file:///${id}.mkv`,
    fileName: `${id}.mkv`,
    folderId: 'folder-1',
    sizeBytes: 100,
    mtimeMs: 1,
    addedAt: 1,
    updatedAt: 1,
    missing: false,
    year: 2024,
    genres: [],
    cast: [],
    crew: [],
    favorite: false,
    watchlist: false,
    watched: false,
    playCount: 0,
    progressMs: 0,
    progressUpdatedAt: 0,
    providerReviews: [],
    poster: {},
    backdrop: {},
    thumbnail: {},
    subtitleTracks: [],
    technical: {},
  } as unknown as MediaItem;
}

describe('createQueue / currentId', () => {
  it('starts at the requested index', () => {
    const q = createQueue(['a', 'b', 'c'], 1);
    expect(currentId(q)).toBe('b');
  });

  it('clamps out-of-range start indexes', () => {
    expect(currentId(createQueue(['a'], 99))).toBe('a');
  });
});

describe('queueNext', () => {
  it('advances through the queue', () => {
    const q = createQueue(['a', 'b', 'c']);
    const r = queueNext(q);
    expect(currentId(r.queue)).toBe('b');
    expect(r.wrapped).toBe(false);
  });

  it('stops at the end when repeat is off', () => {
    const q = createQueue(['a'], 0);
    const r = queueNext(q);
    expect(currentId(r.queue)).toBe('a');
    expect(r.wrapped).toBe(false);
  });

  it('wraps when repeat is all', () => {
    const q = cycleRepeat(createQueue(['a', 'b'], 1)); // off -> all
    const r = queueNext(q);
    expect(currentId(r.queue)).toBe('a');
    expect(r.wrapped).toBe(true);
  });

  it('stays on repeat one', () => {
    const q = cycleRepeat(cycleRepeat(createQueue(['a', 'b'], 0))); // off -> all -> one
    const r = queueNext(q);
    expect(currentId(r.queue)).toBe('a');
  });
});

describe('cycleRepeat', () => {
  it('cycles off -> all -> one -> off', () => {
    const q0 = createQueue(['a']);
    expect(cycleRepeat(q0).repeat).toBe('all');
    expect(cycleRepeat(cycleRepeat(q0)).repeat).toBe('one');
    expect(cycleRepeat(cycleRepeat(cycleRepeat(q0))).repeat).toBe('off');
  });
});

describe('queuePrevious', () => {
  it('goes back when near the start of the item', () => {
    const q = createQueue(['a', 'b'], 1);
    expect(currentId(queuePrevious(q, 1000))).toBe('a');
  });

  it('restarts the item when well into it (caller seeks to 0)', () => {
    const q = createQueue(['a', 'b'], 1);
    const r = queuePrevious(q, 60_000);
    expect(currentId(r)).toBe('b'); // unchanged: caller restarts instead
  });
});

describe('toggleShuffle', () => {
  it('shuffles deterministically and restores order', () => {
    const ids = ['a', 'b', 'c', 'd', 'e'];
    const q = createQueue(ids, 2);
    const s1 = toggleShuffle(q);
    const s2 = toggleShuffle(createQueue(ids, 2));
    expect(s1.shuffle).toBe(true);
    expect(s1.itemIds).toEqual(s2.itemIds); // deterministic seed
    expect(currentId(s1)).toBe('c'); // current item stays first
    const restored = toggleShuffle(s1);
    expect(restored.shuffle).toBe(false);
    expect(restored.itemIds).toEqual(ids);
    expect(currentId(restored)).toBe('c');
  });
});

describe('seasonQueue', () => {
  it('orders episodes and starts at the given one', () => {
    const eps = [episode('e1'), episode('e2'), episode('e3')];
    const q = seasonQueue(eps, 'e2');
    expect(q.itemIds).toEqual(['e1', 'e2', 'e3']);
    expect(currentId(q)).toBe('e2');
  });
});
