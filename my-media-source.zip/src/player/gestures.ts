// ---------------------------------------------------------------------------
// Gesture layer: mapping of touch gestures to player actions. Every gesture
// can be enabled/disabled or remapped in Settings > Gestures. The player
// consults this table; it never hardcodes gesture behavior.
// ---------------------------------------------------------------------------

import type { GestureBinding, GestureId } from '../storage/types';
import { t } from '../shared/i18n';

export type GestureAction =
  | 'none'
  | 'toggleControls'
  | 'togglePlay'
  | 'rewind'
  | 'forward'
  | 'scrub'
  | 'brightness'
  | 'volume'
  | 'zoom'
  | 'temp2x'
  | 'toggleMute';

export const GESTURE_LABELS: Record<GestureId, string> = {
  tap: 'Single tap',
  doubleTapLeft: 'Double tap left',
  doubleTapRight: 'Double tap right',
  doubleTapCenter: 'Double tap center',
  swipeHorizontal: 'Swipe horizontally',
  swipeVerticalLeft: 'Swipe vertically (left side)',
  swipeVerticalRight: 'Swipe vertically (right side)',
  pinch: 'Pinch',
  twoFingerTap: 'Two-finger tap',
  longPress: 'Long press (hold)',
};

export const GESTURE_ACTIONS: { id: GestureAction; label: string }[] = [
  { id: 'none', label: 'Disabled' },
  { id: 'toggleControls', label: 'Show/hide controls' },
  { id: 'togglePlay', label: 'Play/pause' },
  { id: 'rewind', label: 'Rewind' },
  { id: 'forward', label: 'Forward' },
  { id: 'scrub', label: 'Scrub' },
  { id: 'brightness', label: 'Brightness' },
  { id: 'volume', label: 'Volume' },
  { id: 'zoom', label: 'Zoom (video fit)' },
  { id: 'temp2x', label: '2× speed while held' },
  { id: 'toggleMute', label: 'Mute/unmute' },
];

export function gestureActionFor(gestures: Record<GestureId, GestureBinding>, id: GestureId): GestureAction {
  const binding = gestures[id];
  if (!binding || !binding.enabled) return 'none';
  return binding.action as GestureAction;
}

/** Human-readable overlay text for an in-progress gesture. */
export function gestureOverlayText(action: GestureAction, value: number, seekIntervalSec: number): string {
  switch (action) {
    case 'rewind':
      return t('gesture.rewind', { seconds: seekIntervalSec });
    case 'forward':
      return t('gesture.forward', { seconds: seekIntervalSec });
    case 'volume':
      return t('gesture.volume', { value: Math.round(value * 100) });
    case 'brightness':
      return t('gesture.brightness', { value: Math.round(value * 100) });
    case 'temp2x':
      return t('gesture.speed', { value: 2 });
    case 'zoom':
      return t('gesture.fit.changed', { value: 'zoom' });
    default:
      return '';
  }
}
