// ---------------------------------------------------------------------------
// WebVTT cue parsing for the player's custom sidecar-subtitle renderer.
// Rendering cues ourselves (instead of <track>) gives us real control over
// subtitle delay (settings.subtitleDelayMs) and subtitle styles, and lets us
// apply the user's delay to any sidecar file. Malformed input yields no cues
// rather than an error — the player then exposes no subtitle option.
// ---------------------------------------------------------------------------

export interface Cue {
  startMs: number;
  endMs: number;
  text: string;
}

function parseTimestamp(ts: string): number | null {
  // mm:ss.mmm or hh:mm:ss.mmm
  const m = /^(?:(\d+):)?([0-5]?\d):([0-5]?\d)\.(\d{3})$/.exec(ts.trim());
  if (!m) return null;
  const h = parseInt(m[1] ?? '0', 10);
  const min = parseInt(m[2] ?? '0', 10);
  const sec = parseInt(m[3] ?? '0', 10);
  const ms = parseInt(m[4] ?? '0', 10);
  return ((h * 60 + min) * 60 + sec) * 1000 + ms;
}

/** Parse WebVTT text into cues. Never throws; returns [] for malformed input. */
export function parseVtt(vtt: string): Cue[] {
  const cues: Cue[] = [];
  try {
    const clean = vtt.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n');
    const blocks = clean.split(/\n{2,}/);
    for (const block of blocks) {
      const lines = block.split('\n').filter((l) => l.trim() !== '');
      if (lines.length === 0) continue;
      // Skip header / NOTE / STYLE / REGION blocks.
      const first = lines[0] ?? '';
      if (/^(WEBVTT|NOTE|STYLE|REGION)/.test(first)) continue;
      // Optional cue identifier line before the timestamp line.
      const tsLine = first.includes('-->') ? first : (lines[1] ?? '');
      if (!tsLine.includes('-->')) continue;
      const [startRaw, endRaw] = tsLine.split('-->').map((s) => s.trim().split(' ')[0] ?? '');
      const startMs = parseTimestamp(startRaw ?? '');
      const endMs = parseTimestamp(endRaw ?? '');
      if (startMs === null || endMs === null || endMs <= startMs) continue;
      const textLines = first.includes('-->') ? lines.slice(1) : lines.slice(2);
      const text = textLines
        .join('\n')
        .replace(/<[^>]*>/g, '') // strip voice tags / basic markup
        .trim();
      if (!text) continue;
      cues.push({ startMs, endMs, text });
    }
  } catch {
    return [];
  }
  cues.sort((a, b) => a.startMs - b.startMs);
  return cues;
}

/** Find the cue visible at a position (with a delay offset applied). */
export function cueAt(cues: Cue[], positionMs: number, delayMs: number): Cue | null {
  const t = positionMs - delayMs;
  for (const cue of cues) {
    if (t >= cue.startMs && t <= cue.endMs) return cue;
    if (cue.startMs > t) break;
  }
  return null;
}
