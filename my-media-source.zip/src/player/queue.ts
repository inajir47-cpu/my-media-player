// ---------------------------------------------------------------------------
// Playback queue: ordered item ids with repeat/shuffle, next/previous,
// and sensible restore of per-item preferences (speed, fit, tracks).
// ---------------------------------------------------------------------------

import type { MediaItem } from '../storage/types';

export type RepeatMode = 'off' | 'one' | 'all';

export interface QueueState {
  itemIds: string[];
  index: number;
  repeat: RepeatMode;
  shuffle: boolean;
  /** Original order before shuffle, so unshuffling restores it. */
  originalOrder?: string[];
}

export function createQueue(itemIds: string[], startIndex = 0): QueueState {
  return {
    itemIds: [...itemIds],
    index: Math.max(0, Math.min(startIndex, itemIds.length - 1)),
    repeat: 'off',
    shuffle: false,
  };
}

/** Deterministic shuffle with a seed so tests are stable. */
export function shuffled<T>(arr: T[], seed = 42): T[] {
  const out = [...arr];
  let s = seed;
  const rand = (): number => {
    s = (Math.imul(s, 1103515245) + 12345) & 0x7fffffff;
    return s / 0x7fffffff;
  };
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [out[i], out[j]] = [out[j]!, out[i]!];
  }
  return out;
}

export function toggleShuffle(q: QueueState): QueueState {
  if (!q.shuffle) {
    const current = q.itemIds[q.index];
    const rest = q.itemIds.filter((_, i) => i !== q.index);
    const newOrder = current !== undefined ? [current, ...shuffled(rest)] : shuffled(rest);
    return { ...q, shuffle: true, originalOrder: q.itemIds, itemIds: newOrder, index: 0 };
  }
  const originalOrder = q.originalOrder ?? q.itemIds;
  const current = q.itemIds[q.index];
  return {
    ...q,
    shuffle: false,
    originalOrder: undefined,
    itemIds: originalOrder,
    index: Math.max(0, originalOrder.indexOf(current ?? '')),
  };
}

export function cycleRepeat(q: QueueState): QueueState {
  const next: RepeatMode = q.repeat === 'off' ? 'all' : q.repeat === 'all' ? 'one' : 'off';
  return { ...q, repeat: next };
}

export function queueNext(q: QueueState): { queue: QueueState; wrapped: boolean } {
  if (q.repeat === 'one') return { queue: q, wrapped: false };
  if (q.index < q.itemIds.length - 1) return { queue: { ...q, index: q.index + 1 }, wrapped: false };
  if (q.repeat === 'all' && q.itemIds.length > 0) return { queue: { ...q, index: 0 }, wrapped: true };
  return { queue: q, wrapped: false };
}

export function queuePrevious(q: QueueState, positionMs: number): QueueState {
  // Like classic players: restart the item when more than a few seconds in.
  if (positionMs > 5000) return q;
  return { ...q, index: Math.max(0, q.index - 1) };
}

export function currentId(q: QueueState): string | undefined {
  return q.itemIds[q.index];
}

/** Build a season queue: all episodes of the show ordered, starting at one. */
export function seasonQueue(episodes: MediaItem[], startId: string): QueueState {
  const ids = episodes.map((e) => e.id);
  return createQueue(ids, Math.max(0, ids.indexOf(startId)));
}
