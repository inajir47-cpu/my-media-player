// ---------------------------------------------------------------------------
// Keyboard and remote/D-pad shortcuts. Shown in the player's shortcut help
// panel; configurable where marked.
// ---------------------------------------------------------------------------

export interface Shortcut {
  keys: string[];
  action: string;
  label: string;
}

export const SHORTCUTS: Shortcut[] = [
  { keys: ['Space', 'K'], action: 'togglePlay', label: 'Play / pause' },
  { keys: ['ArrowLeft'], action: 'seekBack', label: 'Seek back (interval)' },
  { keys: ['ArrowRight'], action: 'seekForward', label: 'Seek forward (interval)' },
  { keys: ['J'], action: 'seekBackLarge', label: 'Seek back 30 s' },
  { keys: ['L'], action: 'seekForwardLarge', label: 'Seek forward 30 s' },
  { keys: ['ArrowUp'], action: 'volumeUp', label: 'Volume up' },
  { keys: ['ArrowDown'], action: 'volumeDown', label: 'Volume down' },
  { keys: ['M'], action: 'toggleMute', label: 'Mute / unmute' },
  { keys: ['F'], action: 'toggleFullscreen', label: 'Fullscreen' },
  { keys: ['P'], action: 'togglePip', label: 'Picture in picture' },
  { keys: ['C'], action: 'toggleCaptions', label: 'Captions on/off' },
  { keys: ['['], action: 'speedDown', label: 'Slower' },
  { keys: [']'], action: 'speedUp', label: 'Faster' },
  { keys: ['0'], action: 'speedReset', label: 'Reset speed to 1×' },
  { keys: ['N'], action: 'next', label: 'Next item' },
  { keys: ['B'], action: 'previous', label: 'Previous item' },
  { keys: ['S'], action: 'toggleShuffle', label: 'Shuffle' },
  { keys: ['R'], action: 'cycleRepeat', label: 'Repeat mode' },
  { keys: ['Escape'], action: 'closeOrExit', label: 'Close overlays / exit fullscreen' },
  { keys: ['?'], action: 'showHelp', label: 'Shortcut help' },
];

export const SPEEDS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.5, 3, 4];

export function nextSpeedUp(current: number): number {
  const next = SPEEDS.find((s) => s > current + 0.001);
  return next ?? SPEEDS[SPEEDS.length - 1]!;
}

export function nextSpeedDown(current: number): number {
  const prev = [...SPEEDS].reverse().find((s) => s < current - 0.001);
  return prev ?? SPEEDS[0]!;
}
