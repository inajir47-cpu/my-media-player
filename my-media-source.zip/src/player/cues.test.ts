import { describe, expect, it } from 'vitest';
import { cueAt, parseVtt, type Cue } from './cues';

const VTT = `WEBVTT

00:00:01.000 --> 00:00:04.000
Hello <b>world</b>

00:00:05.500 --> 00:00:07.000
Second cue
with two lines
`;

describe('parseVtt', () => {
  it('parses cues with timestamps and strips markup', () => {
    const cues = parseVtt(VTT);
    expect(cues).toHaveLength(2);
    expect(cues[0]).toMatchObject({ startMs: 1000, endMs: 4000, text: 'Hello world' });
    expect(cues[1]).toMatchObject({
      startMs: 5500,
      endMs: 7000,
      text: 'Second cue\nwith two lines',
    });
  });

  it('handles hour timestamps', () => {
    const cues = parseVtt('WEBVTT\n\n01:02:03.000 --> 01:02:05.000\nHi\n');
    expect(cues[0]?.startMs).toBe(((1 * 60 + 2) * 60 + 3) * 1000);
  });

  it('skips cue identifiers and NOTE blocks', () => {
    const vtt = 'WEBVTT\n\nNOTE this is a comment\n\ncue-1\n00:00:01.000 --> 00:00:02.000\nText\n';
    const cues = parseVtt(vtt);
    expect(cues).toHaveLength(1);
    expect(cues[0]?.text).toBe('Text');
  });

  it('returns [] for malformed input instead of throwing', () => {
    expect(parseVtt('')).toEqual([]);
    expect(parseVtt('not a subtitle file at all')).toEqual([]);
    expect(parseVtt('WEBVTT\n\nthis --> is not a timestamp\nText\n')).toEqual([]);
    expect(parseVtt('WEBVTT\n\n00:00:05.000 --> 00:00:01.000\nBackwards\n')).toEqual([]);
  });
});

describe('cueAt', () => {
  const cues: Cue[] = [
    { startMs: 1000, endMs: 4000, text: 'one' },
    { startMs: 5000, endMs: 7000, text: 'two' },
  ];

  it('finds the cue visible at a position', () => {
    expect(cueAt(cues, 2000, 0)?.text).toBe('one');
    expect(cueAt(cues, 6000, 0)?.text).toBe('two');
    expect(cueAt(cues, 4500, 0)).toBeNull();
  });

  it('applies the subtitle delay offset', () => {
    // +500 ms delay shifts cues later: at 1400 ms the first cue is not yet shown.
    expect(cueAt(cues, 1400, 500)).toBeNull();
    expect(cueAt(cues, 1600, 500)?.text).toBe('one');
    // -500 ms delay shifts cues earlier.
    expect(cueAt(cues, 600, -500)?.text).toBe('one');
  });
});
