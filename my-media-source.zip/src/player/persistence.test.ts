import { describe, expect, it } from 'vitest';
import {
  AUTOPLAY_COUNTDOWN_SEC,
  COMPLETION_REMAINING_MS,
  decideResume,
  isWatched,
  MIN_PROGRESS_MS,
  progressFraction,
  remainingMs,
  RESTART_THRESHOLD_MS,
} from './persistence';

describe('decideResume', () => {
  it('starts fresh when there is no meaningful progress', () => {
    expect(decideResume(0, 3_600_000)).toEqual({ action: 'fresh', positionMs: 0 });
    expect(decideResume(MIN_PROGRESS_MS - 1, 3_600_000).action).toBe('fresh');
  });

  it('restarts when barely started (< 30 s)', () => {
    expect(decideResume(RESTART_THRESHOLD_MS - 1, 3_600_000)).toEqual({
      action: 'restart',
      positionMs: 0,
    });
  });

  it('restarts when treated as completed (< 60 s remaining)', () => {
    const duration = 3_600_000;
    const d = decideResume(duration - (COMPLETION_REMAINING_MS - 1), duration);
    expect(d.action).toBe('restart');
  });

  it('resumes mid-file progress', () => {
    const d = decideResume(1_800_000, 3_600_000);
    expect(d).toEqual({ action: 'resume', positionMs: 1_800_000 });
  });

  it('handles unknown duration without crashing', () => {
    expect(decideResume(120_000, undefined).action).toBe('resume');
    expect(decideResume(0, undefined).action).toBe('fresh');
  });
});

describe('isWatched', () => {
  it('applies the configurable threshold (default 90%)', () => {
    expect(isWatched(3_240_000, 3_600_000, 0.9)).toBe(true);
    expect(isWatched(3_239_999, 3_600_000, 0.9)).toBe(false);
  });

  it('returns false for unknown/zero duration', () => {
    expect(isWatched(100, undefined, 0.9)).toBe(false);
    expect(isWatched(100, 0, 0.9)).toBe(false);
  });
});

describe('progressFraction / remainingMs', () => {
  it('clamps the fraction to 0..1', () => {
    expect(progressFraction(1_800_000, 3_600_000)).toBeCloseTo(0.5);
    expect(progressFraction(9_999_999, 3_600_000)).toBe(1);
    expect(progressFraction(-5, 3_600_000)).toBe(0);
    expect(progressFraction(100, undefined)).toBe(0);
  });

  it('reports remaining time', () => {
    expect(remainingMs(1_800_000, 3_600_000)).toBe(1_800_000);
    expect(remainingMs(9_999_999, 3_600_000)).toBe(0);
    expect(remainingMs(100, undefined)).toBeUndefined();
  });
});

describe('autoplay constant', () => {
  it('exposes a sane cancellable countdown', () => {
    expect(AUTOPLAY_COUNTDOWN_SEC).toBeGreaterThan(0);
    expect(AUTOPLAY_COUNTDOWN_SEC).toBeLessThanOrEqual(30);
  });
});
