// ---------------------------------------------------------------------------
// Structured, privacy-safe logging. Diagnostics must NEVER include full file
// paths, file names, folder names, URIs, or media titles. Log stable IDs and
// counts instead. `exportDiagnostics()` builds a user-approved report that is
// only written to disk when the user explicitly exports it.
// ---------------------------------------------------------------------------

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

interface LogEntry {
  ts: number;
  level: LogLevel;
  tag: string;
  message: string;
  data?: Record<string, string | number | boolean>;
}

const MAX_ENTRIES = 500;
const entries: LogEntry[] = [];
let verbose = false;

function push(
  level: LogLevel,
  tag: string,
  message: string,
  data?: Record<string, string | number | boolean>,
): void {
  entries.push({ ts: Date.now(), level, tag, message, data });
  if (entries.length > MAX_ENTRIES) entries.splice(0, entries.length - MAX_ENTRIES);
  if (level === 'error' || verbose) {
    console[level === 'debug' ? 'log' : level](`[${tag}] ${message}`, data ?? '');
  }
}

export const logger = {
  setVerbose(v: boolean): void {
    verbose = v;
  },
  debug: (tag: string, message: string, data?: Record<string, string | number | boolean>) => {
    push('debug', tag, message, data);
  },
  info: (tag: string, message: string, data?: Record<string, string | number | boolean>) => {
    push('info', tag, message, data);
  },
  warn: (tag: string, message: string, data?: Record<string, string | number | boolean>) => {
    push('warn', tag, message, data);
  },
  error: (tag: string, message: string, data?: Record<string, string | number | boolean>) => {
    push('error', tag, message, data);
  },
  /** Snapshot for the Settings > About > diagnostics view (no private content). */
  snapshot(): LogEntry[] {
    return [...entries];
  },
  clear(): void {
    entries.length = 0;
  },
};
