// ---------------------------------------------------------------------------
// MediaCard: rounded poster card used across grids. Desktop hover / keyboard
// focus plays the item's own local preview after a short delay; touch devices
// get a long-press "Preview" action (with haptics) instead of hover. A normal
// tap always opens details — never starts full playback.
// ---------------------------------------------------------------------------

import { useEffect, useRef, useState, type ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import type { MediaItem } from '../storage/types';
import type { ShowSummary } from '../library/indexer';
import { PreviewVideo } from '../previews/PreviewVideo';
import { previewsAllowed, useSettings } from '../settings/store';
import { haptics } from '../storage/adapters';
import { progressFraction } from '../player/persistence';
import { formatDurationShort } from '../shared/format';
import { t } from '../shared/i18n';

type CardItem = MediaItem | (ShowSummary & { kind: 'show-card' });

function isShow(item: CardItem): item is ShowSummary & { kind: 'show-card' } {
  return (item as { kind?: string }).kind === 'show-card';
}

function detailPath(item: CardItem): string {
  return isShow(item)
    ? `/show/${item.id}`
    : item.kind === 'episode'
      ? `/show/${item.groupId}`
      : `/movie/${item.id}`;
}

const HOVER_DELAY_MS = 600;
const LONG_PRESS_MS = 500;

export function MediaCard({ item, width }: { item: CardItem; width?: number }): ReactNode {
  const navigate = useNavigate();
  const settings = useSettings();
  const [hoverPreview, setHoverPreview] = useState(false);
  const [touchPreview, setTouchPreview] = useState(false);
  const hoverTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pressStart = useRef<{ x: number; y: number } | null>(null);

  const title = item.title;
  const poster = item.poster.uri;
  const showPreviewUi = previewsAllowed(settings) && !isShow(item) && !item.previewDisabled;

  useEffect(
    () => () => {
      if (hoverTimer.current) clearTimeout(hoverTimer.current);
      if (pressTimer.current) clearTimeout(pressTimer.current);
    },
    [],
  );

  const open = (): void => {
    void navigate(detailPath(item));
  };

  const startHover = (): void => {
    if (!showPreviewUi) return;
    hoverTimer.current = setTimeout(() => {
      setHoverPreview(true);
    }, HOVER_DELAY_MS);
  };
  const stopHover = (): void => {
    if (hoverTimer.current) clearTimeout(hoverTimer.current);
    setHoverPreview(false);
  };

  const onTouchStart = (e: React.TouchEvent): void => {
    const touch = e.touches[0];
    if (!touch) return;
    pressStart.current = { x: touch.clientX, y: touch.clientY };
    pressTimer.current = setTimeout(() => {
      if (showPreviewUi && settings.haptics) void haptics.impact();
      if (showPreviewUi) setTouchPreview(true);
    }, LONG_PRESS_MS);
  };
  const onTouchMove = (e: React.TouchEvent): void => {
    const touch = e.touches[0];
    const start = pressStart.current;
    if (!touch || !start) return;
    if (Math.hypot(touch.clientX - start.x, touch.clientY - start.y) > 12 && pressTimer.current) {
      clearTimeout(pressTimer.current);
    }
  };
  const onTouchEnd = (): void => {
    if (pressTimer.current) clearTimeout(pressTimer.current);
    pressStart.current = null;
  };

  const progress = !isShow(item) ? progressFraction(item.progressMs, item.durationMs) : 0;
  const watched = !isShow(item) && item.watched;
  const duration = !isShow(item) ? item.durationMs : undefined;
  const showProgress = isShow(item)
    ? (item as ShowSummary).watchedCount / Math.max(1, (item as ShowSummary).episodeCount)
    : 0;

  return (
    <article
      className="mm-card mm-media-card"
      style={width ? { width } : undefined}
      onMouseEnter={startHover}
      onMouseLeave={stopHover}
      onFocus={startHover}
      onBlur={stopHover}
    >
      <button
        type="button"
        onClick={open}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
        aria-label={`${title}${watched ? ` (${t('detail.markWatched')})` : ''}`}
        style={{ display: 'block', width: '100%', textAlign: 'left', position: 'relative' }}
      >
        <div
          style={{ position: 'relative', aspectRatio: '2 / 3', overflow: 'hidden', background: 'var(--bg3)' }}
        >
          {poster ? (
            <img src={poster} alt="" className="mm-poster" loading="lazy" draggable={false} />
          ) : (
            <div
              className="mm-poster"
              aria-hidden="true"
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--text3)',
                fontSize: 13,
                padding: 12,
                textAlign: 'center',
              }}
            >
              {title}
            </div>
          )}
          {(hoverPreview || touchPreview) && !isShow(item) && (
            <div style={{ position: 'absolute', inset: 0 }}>
              <PreviewVideo item={item} slotId={`card-${item.id}`} />
            </div>
          )}
          {touchPreview && (
            <span
              className="mm-chip"
              style={{ position: 'absolute', top: 8, left: 8, background: 'rgba(0,0,0,0.7)' }}
            >
              {t('detail.preview')}
            </span>
          )}
          {!isShow(item) && progress > 0 && !watched && (
            <div style={{ position: 'absolute', left: 8, right: 8, bottom: 8 }}>
              <div className="mm-progress" role="img" aria-label={`${Math.round(progress * 100)}% watched`}>
                <div style={{ width: `${progress * 100}%` }} />
              </div>
            </div>
          )}
          {isShow(item) && showProgress > 0 && (
            <div style={{ position: 'absolute', left: 8, right: 8, bottom: 8 }}>
              <div
                className="mm-progress"
                role="img"
                aria-label={`${Math.round(showProgress * 100)}% watched`}
              >
                <div style={{ width: `${showProgress * 100}%` }} />
              </div>
            </div>
          )}
          {watched && (
            <span
              aria-hidden="true"
              style={{
                position: 'absolute',
                top: 8,
                right: 8,
                background: 'var(--ok)',
                color: '#06281c',
                borderRadius: '50%',
                width: 28,
                height: 28,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontWeight: 800,
              }}
            >
              ✓
            </span>
          )}
        </div>
        <div style={{ padding: '10px 12px 12px' }}>
          <h3
            style={{
              margin: 0,
              fontSize: 14,
              fontWeight: 650,
              lineHeight: 1.3,
              display: '-webkit-box',
              WebkitLineClamp: 2,
              WebkitBoxOrient: 'vertical',
              overflow: 'hidden',
            }}
          >
            {title}
          </h3>
          <p style={{ margin: '4px 0 0', fontSize: 12, color: 'var(--text3)' }}>
            {isShow(item)
              ? `${(item as ShowSummary).episodeCount} episodes`
              : [item.year, duration ? formatDurationShort(duration) : ''].filter(Boolean).join(' · ')}
          </p>
        </div>
      </button>
      <style>{`
        .mm-media-card { transition: transform var(--motion-fast) var(--ease); }
        .mm-media-card:hover { transform: translateY(-2px); }
      `}</style>
    </article>
  );
}
