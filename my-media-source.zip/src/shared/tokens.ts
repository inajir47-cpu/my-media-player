// ---------------------------------------------------------------------------
// Design tokens. Every color, type ramp, spacing, radius, shadow, duration and
// breakpoint in the UI must come from here (mirrored as CSS variables in
// src/app/theme.css). Editing the look of the app starts here.
// ---------------------------------------------------------------------------

export const colors = {
  bg0: '#0b0b0d', // app background
  bg1: '#121214', // raised surface
  bg2: '#1a1a1e', // cards / sheets
  bg3: '#232329', // pressed / active surface
  line: '#2c2c33', // subtle borders
  text: '#ffffff', // primary text
  text2: '#b9b9c2', // secondary text
  text3: '#7d7d88', // tertiary / captions
  accent: '#f59e0b', // warm amber
  accentSoft: 'rgba(245, 158, 11, 0.16)',
  accentText: '#1a1206', // text on amber
  danger: '#f87171',
  ok: '#34d399',
  info: '#60a5fa',
  scrim: 'rgba(0, 0, 0, 0.72)',
  overlayTextShadow: '0 1px 12px rgba(0,0,0,0.9)',
} as const;

export const lightColors = {
  bg0: '#f7f5f1',
  bg1: '#ffffff',
  bg2: '#f0ede7',
  bg3: '#e4ded4',
  line: '#d9d2c4',
  text: '#191612',
  text2: '#4a443b',
  text3: '#8a8172',
  accent: '#d97706',
  accentSoft: 'rgba(217, 119, 6, 0.14)',
  accentText: '#ffffff',
  danger: '#dc2626',
  ok: '#059669',
  info: '#2563eb',
  scrim: 'rgba(0, 0, 0, 0.6)',
  overlayTextShadow: '0 1px 12px rgba(0,0,0,0.9)',
} as const;

export type ColorScheme = typeof colors;

export const type = {
  family: "Inter, system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif",
  display: { size: 34, weight: 800, line: 1.15 },
  h1: { size: 26, weight: 750, line: 1.2 },
  h2: { size: 20, weight: 700, line: 1.25 },
  h3: { size: 16, weight: 650, line: 1.3 },
  body: { size: 15, weight: 400, line: 1.5 },
  caption: { size: 12.5, weight: 500, line: 1.4 },
  tiny: { size: 11, weight: 600, line: 1.35 },
} as const;

export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32, xxxl: 48 } as const;
export const radii = { sm: 8, md: 12, lg: 16, xl: 24, pill: 999 } as const;

export const shadows = {
  card: '0 2px 16px rgba(0,0,0,0.45)',
  sheet: '0 -8px 40px rgba(0,0,0,0.6)',
  hero: '0 8px 60px rgba(0,0,0,0.7)',
} as const;

export const motion = {
  fast: 120,
  base: 200,
  slow: 320,
  ease: 'cubic-bezier(0.2, 0.8, 0.2, 1)',
} as const;

export const breakpoints = {
  phone: 0,
  phoneLandscape: 640,
  tablet: 768,
  tabletLandscape: 1100,
  desktop: 1280,
} as const;

export const touch = {
  minTarget: 44,
  navBarHeight: 64,
  railWidth: 76,
  sidebarWidth: 248,
} as const;
