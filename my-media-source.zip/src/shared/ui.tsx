// ---------------------------------------------------------------------------
// Accessible UI primitives. Every interactive element meets the 44px touch
// target minimum and carries an accessible name.
// ---------------------------------------------------------------------------

import { type ReactNode, useEffect, useRef } from 'react';
import { t } from './i18n';

// -- buttons ---------------------------------------------------------------------

interface ButtonProps {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'default' | 'danger' | 'ghost';
  label: string;
  disabled?: boolean;
  type?: 'button' | 'submit';
}

export function Button({
  children,
  onClick,
  variant = 'default',
  label,
  disabled,
  type = 'button',
}: ButtonProps): ReactNode {
  const cls = `mm-btn${variant === 'primary' ? ' mm-btn-primary' : ''}${variant === 'danger' ? ' mm-btn-danger' : ''}${variant === 'ghost' ? ' mm-btn-ghost' : ''}`;
  return (
    <button type={type} className={cls} onClick={onClick} aria-label={label} disabled={disabled}>
      {children}
    </button>
  );
}

export function IconButton({
  children,
  onClick,
  label,
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  label: string;
  disabled?: boolean;
}): ReactNode {
  return (
    <button type="button" className="mm-icon-btn" onClick={onClick} aria-label={label} disabled={disabled}>
      {children}
    </button>
  );
}

// -- bottom sheet dialog --------------------------------------------------------------

export function BottomSheet({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
}): ReactNode {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    el?.querySelector<HTMLElement>('button, input, select, textarea, [tabindex]')?.focus();
    const onKey = (e: KeyboardEvent): void => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
    };
  }, [onClose]);
  return (
    <>
      <div className="mm-scrim" onClick={onClose} aria-hidden="true" />
      <div ref={ref} className="mm-sheet" role="dialog" aria-modal="true" aria-label={title}>
        <div className="mm-row" style={{ justifyContent: 'space-between' }}>
          <h2 style={{ margin: 0, fontSize: 18 }}>{title}</h2>
          <IconButton label={t('common.close')} onClick={onClose}>
            ✕
          </IconButton>
        </div>
        {children}
      </div>
    </>
  );
}

// -- slider ----------------------------------------------------------------------------

export function Slider({
  label,
  value,
  min,
  max,
  step,
  onChange,
  formatValue,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
  formatValue?: (v: number) => string;
}): ReactNode {
  return (
    <label style={{ display: 'block', padding: '8px 0' }}>
      <span className="sr-only">{label}</span>
      <input
        type="range"
        aria-label={label}
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => {
          onChange(parseFloat(e.target.value));
        }}
        style={{ width: '100%', accentColor: 'var(--accent)', minHeight: 44 }}
      />
      {formatValue && (
        <span style={{ fontSize: 12, color: 'var(--text3)' }} aria-hidden="true">
          {formatValue(value)}
        </span>
      )}
    </label>
  );
}

// -- toggle ------------------------------------------------------------------------------

export function Toggle({
  label,
  checked,
  onChange,
  hint,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  hint?: string;
}): ReactNode {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => {
        onChange(!checked);
      }}
      className="mm-row"
      style={{ width: '100%', justifyContent: 'space-between', minHeight: 44, textAlign: 'left' }}
    >
      <span>
        <span style={{ display: 'block', fontWeight: 600 }}>{label}</span>
        {hint && (
          <span style={{ display: 'block', fontSize: 13, color: 'var(--text3)', marginTop: 2 }}>{hint}</span>
        )}
      </span>
      <span
        aria-hidden="true"
        style={{
          width: 52,
          height: 30,
          borderRadius: 999,
          flexShrink: 0,
          background: checked ? 'var(--accent)' : 'var(--bg3)',
          border: '1px solid var(--line)',
          position: 'relative',
          transition: 'background var(--motion-fast) var(--ease)',
        }}
      >
        <span
          style={{
            position: 'absolute',
            top: 2,
            left: checked ? 24 : 2,
            width: 24,
            height: 24,
            borderRadius: '50%',
            background: '#fff',
            transition: 'left var(--motion-fast) var(--ease)',
          }}
        />
      </span>
    </button>
  );
}

// -- states --------------------------------------------------------------------------------

export function Skeleton({
  width = '100%',
  height = 160,
  label,
}: {
  width?: string | number;
  height?: string | number;
  label?: string;
}): ReactNode {
  return (
    <div
      className="mm-skeleton"
      style={{ width, height }}
      role="status"
      aria-label={label ?? t('common.loading')}
    />
  );
}

export function EmptyState({
  title,
  body,
  action,
}: {
  title: string;
  body: string;
  action?: ReactNode;
}): ReactNode {
  return (
    <div className="mm-empty" role="status">
      <h2>{title}</h2>
      <p>{body}</p>
      {action}
    </div>
  );
}

export function ErrorState({
  title,
  body,
  onRetry,
  retryLabel,
}: {
  title: string;
  body: string;
  onRetry?: () => void;
  retryLabel?: string;
}): ReactNode {
  return (
    <div className="mm-empty" role="alert">
      <h2>{title}</h2>
      <p>{body}</p>
      {onRetry && (
        <Button label={retryLabel ?? t('common.retry')} onClick={onRetry}>
          {retryLabel ?? t('common.retry')}
        </Button>
      )}
    </div>
  );
}

export function ProgressBar({ fraction, label }: { fraction: number; label: string }): ReactNode {
  return (
    <div
      className="mm-progress"
      role="progressbar"
      aria-label={label}
      aria-valuenow={Math.round(fraction * 100)}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div style={{ width: `${Math.min(100, Math.max(0, fraction * 100))}%` }} />
    </div>
  );
}

// -- stars (0.5–5) ---------------------------------------------------------------------------

export function Stars({
  value,
  onChange,
  label,
  readOnly,
}: {
  value: number;
  onChange?: (v: number) => void;
  label: string;
  readOnly?: boolean;
}): ReactNode {
  const stars = [0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5];
  if (readOnly || !onChange) {
    return (
      <span
        role="img"
        aria-label={`${label}: ${value} / 5`}
        style={{ color: 'var(--accent)', letterSpacing: 2 }}
      >
        {'★'.repeat(Math.round(value))}
        {'☆'.repeat(5 - Math.round(value))}
      </span>
    );
  }
  return (
    <div role="radiogroup" aria-label={label} style={{ display: 'flex', gap: 4 }}>
      {stars.map((s) => (
        <button
          key={s}
          type="button"
          role="radio"
          aria-checked={value === s}
          aria-label={`${s} stars`}
          onClick={() => {
            onChange(s);
          }}
          style={{
            width: 44,
            height: 44,
            fontSize: 22,
            color: s <= value ? 'var(--accent)' : 'var(--text3)',
          }}
        >
          ★
        </button>
      ))}
    </div>
  );
}

// -- segmented control --------------------------------------------------------------------------

export function Segmented<T extends string>({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: { id: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
}): ReactNode {
  return (
    <div role="radiogroup" aria-label={label} style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
      {options.map((o) => (
        <button
          key={o.id}
          type="button"
          role="radio"
          aria-checked={value === o.id}
          className="mm-chip"
          aria-pressed={value === o.id}
          onClick={() => {
            onChange(o.id);
          }}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

// -- field ----------------------------------------------------------------------------------

export function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: ReactNode;
  hint?: string;
}): ReactNode {
  return (
    <label style={{ display: 'block', margin: '12px 0' }}>
      <span style={{ display: 'block', fontWeight: 650, marginBottom: 6 }}>{label}</span>
      {children}
      {hint && (
        <span style={{ display: 'block', fontSize: 13, color: 'var(--text3)', marginTop: 6 }}>{hint}</span>
      )}
    </label>
  );
}
