import { describe, expect, it, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { EmptyState, ErrorState, ProgressBar } from './ui';

describe('EmptyState', () => {
  it('renders title and body with a status role', () => {
    render(<EmptyState title="No movies yet" body="Add a folder to get started." />);
    expect(screen.getByRole('status')).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: 'No movies yet' })).toBeInTheDocument();
    expect(screen.getByText('Add a folder to get started.')).toBeInTheDocument();
  });

  it('renders an optional action node', () => {
    render(<EmptyState title="T" body="B" action={<button type="button">Do it</button>} />);
    expect(screen.getByRole('button', { name: 'Do it' })).toBeInTheDocument();
  });
});

describe('ErrorState', () => {
  it('renders as an alert and fires retry', async () => {
    const onRetry = vi.fn();
    const user = userEvent.setup();
    render(<ErrorState title="Scan failed" body="Permission was revoked." onRetry={onRetry} />);
    expect(screen.getByRole('alert')).toBeInTheDocument();
    const btn = screen.getByRole('button');
    await user.click(btn);
    expect(onRetry).toHaveBeenCalledTimes(1);
  });

  it('omits the retry button when no handler is given', () => {
    render(<ErrorState title="T" body="B" />);
    expect(screen.queryByRole('button')).not.toBeInTheDocument();
  });
});

describe('ProgressBar', () => {
  it('exposes an accessible progressbar with the right value', () => {
    render(<ProgressBar fraction={0.42} label="Scan progress" />);
    const bar = screen.getByRole('progressbar', { name: 'Scan progress' });
    expect(bar).toHaveAttribute('aria-valuenow', '42');
    expect(bar).toHaveAttribute('aria-valuemin', '0');
    expect(bar).toHaveAttribute('aria-valuemax', '100');
  });

  it('clamps out-of-range fractions visually', () => {
    const { rerender } = render(<ProgressBar fraction={2} label="x" />);
    expect(screen.getByRole('progressbar').firstElementChild).toHaveStyle({ width: '100%' });
    rerender(<ProgressBar fraction={-1} label="x" />);
    expect(screen.getByRole('progressbar').firstElementChild).toHaveStyle({ width: '0%' });
  });
});
