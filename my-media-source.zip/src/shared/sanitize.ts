// ---------------------------------------------------------------------------
// Sanitization for user-supplied and metadata text before rendering.
// We render text via React (which escapes by default); this module handles
// cases where markup must be stripped (NFO/HTML sidecars) or dangerous
// protocols blocked.
// ---------------------------------------------------------------------------

/** Strip HTML/XML tags and decode the most common entities. */
export function stripMarkup(input: string): string {
  return input
    .replace(/<[^>]*>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .trim();
}

/** Collapse whitespace runs to single spaces and clamp length. */
export function cleanText(input: string, maxLength = 4000): string {
  const cleaned = stripMarkup(input).replace(/\s+/g, ' ').trim();
  return cleaned.length > maxLength ? `${cleaned.slice(0, maxLength)}…` : cleaned;
}

/** Allow only http(s) artwork URLs; local blob/data URLs are passed through. */
export function isSafeArtworkUrl(url: string): boolean {
  if (url.startsWith('blob:') || url.startsWith('data:image/') || url.startsWith('content://')) return true;
  try {
    const parsed = new URL(url);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}
