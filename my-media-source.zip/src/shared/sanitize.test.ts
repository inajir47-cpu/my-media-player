import { describe, expect, it } from 'vitest';
import { stripMarkup, cleanText, isSafeArtworkUrl } from './sanitize';

describe('stripMarkup', () => {
  it('removes tags and decodes entities', () => {
    expect(stripMarkup('<b>Tom &amp; Jerry</b>')).toBe('Tom & Jerry');
    expect(stripMarkup('&lt;tag&gt; &quot;q&quot; &#39;s&#39;')).toBe('<tag> "q" \'s\'');
  });

  it('strips NFO-style XML', () => {
    expect(stripMarkup('<plot>A <i>great</i> movie.</plot>')).toBe('A great movie.');
  });
});

describe('cleanText', () => {
  it('collapses whitespace and clamps length', () => {
    expect(cleanText('a\n\n  b\tc')).toBe('a b c');
    const long = cleanText('x'.repeat(5000), 100);
    expect(long.length).toBe(101); // 100 chars + ellipsis
    expect(long.endsWith('…')).toBe(true);
  });
});

describe('isSafeArtworkUrl', () => {
  it('allows local blob/data/content URLs', () => {
    expect(isSafeArtworkUrl('blob:https://x/abc')).toBe(true);
    expect(isSafeArtworkUrl('data:image/png;base64,AAA')).toBe(true);
    expect(isSafeArtworkUrl('content://media/1')).toBe(true);
  });

  it('allows http(s) but blocks dangerous protocols', () => {
    expect(isSafeArtworkUrl('https://example.com/a.jpg')).toBe(true);
    expect(isSafeArtworkUrl('http://example.com/a.jpg')).toBe(true);
    expect(isSafeArtworkUrl('javascript:alert(1)')).toBe(false);
    expect(isSafeArtworkUrl('file:///etc/passwd')).toBe(false);
    expect(isSafeArtworkUrl('not a url')).toBe(false);
  });
});
