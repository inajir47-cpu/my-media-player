// ---------------------------------------------------------------------------
// Locale-aware formatting for durations, dates, times and numbers.
// ---------------------------------------------------------------------------

/** 3723000 ms -> "1:02:03", 65000 -> "1:05" */
export function formatDuration(ms: number | undefined | null, _locale?: string): string {
  if (ms == null || !Number.isFinite(ms) || ms < 0) return '--:--';
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  const mm = hours > 0 ? String(minutes).padStart(2, '0') : String(minutes);
  const ss = String(seconds).padStart(2, '0');
  return hours > 0 ? `${hours}:${mm}:${ss}` : `${mm}:${ss}`;
}

/** Short "1h 2m" style duration for cards. */
export function formatDurationShort(ms: number | undefined | null, locale = 'en'): string {
  if (ms == null || !Number.isFinite(ms) || ms <= 0) return '';
  const totalMinutes = Math.round(ms / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  const nf = new Intl.NumberFormat(locale);
  if (hours === 0) return `${nf.format(minutes)}m`;
  if (minutes === 0) return `${nf.format(hours)}h`;
  return `${nf.format(hours)}h ${nf.format(minutes)}m`;
}

export function formatDate(timestamp: number | undefined | null, locale = 'en'): string {
  if (timestamp == null || !Number.isFinite(timestamp)) return '';
  return new Intl.DateTimeFormat(locale, { year: 'numeric', month: 'short', day: 'numeric' }).format(
    new Date(timestamp),
  );
}

export function formatDateTime(timestamp: number | undefined | null, locale = 'en'): string {
  if (timestamp == null || !Number.isFinite(timestamp)) return '';
  return new Intl.DateTimeFormat(locale, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  }).format(new Date(timestamp));
}

export function formatNumber(n: number | undefined | null, locale = 'en'): string {
  if (n == null || !Number.isFinite(n)) return '–';
  return new Intl.NumberFormat(locale).format(n);
}

export function formatBytes(bytes: number | undefined | null, locale = 'en'): string {
  if (bytes == null || !Number.isFinite(bytes) || bytes < 0) return '–';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  return `${new Intl.NumberFormat(locale, { maximumFractionDigits: 1 }).format(value)} ${units[unit]}`;
}

/** "2h ago", "3d ago" relative time for Recently Added etc. */
export function formatRelative(
  timestamp: number | undefined | null,
  locale = 'en',
  now = Date.now(),
): string {
  if (timestamp == null || !Number.isFinite(timestamp)) return '';
  const diffMs = now - timestamp;
  const rtf = new Intl.RelativeTimeFormat(locale, { numeric: 'auto' });
  const minute = 60_000;
  const hour = 60 * minute;
  const day = 24 * hour;
  const week = 7 * day;
  const month = 30 * day;
  if (diffMs < hour) return rtf.format(-Math.max(1, Math.round(diffMs / minute)), 'minute');
  if (diffMs < day) return rtf.format(-Math.round(diffMs / hour), 'hour');
  if (diffMs < week) return rtf.format(-Math.round(diffMs / day), 'day');
  if (diffMs < month) return rtf.format(-Math.round(diffMs / week), 'week');
  return formatDate(timestamp, locale);
}
