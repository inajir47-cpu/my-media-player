// ---------------------------------------------------------------------------
// Chunked grid: renders cards in batches so 10k-item libraries stay smooth.
// (Full virtualization would complicate variable card heights; chunked
// rendering with an intersection sentinel keeps scrolling at 60fps.)
// ---------------------------------------------------------------------------

import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { MediaCard } from './MediaCard';
import type { MediaItem } from '../storage/types';
import type { ShowSummary } from '../library/indexer';
import { useViewport } from '../app/hooks';

const CHUNK = 60;

type GridItem = MediaItem | (ShowSummary & { kind: 'show-card' });

export function ItemGrid({ items, empty }: { items: GridItem[]; empty?: ReactNode }): ReactNode {
  const { kind } = useViewport();
  const [count, setCount] = useState(CHUNK);
  const sentinel = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setCount(CHUNK);
  }, [items]);

  useEffect(() => {
    const el = sentinel.current;
    if (!el || count >= items.length) return;
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) setCount((c) => Math.min(items.length, c + CHUNK));
      },
      { rootMargin: '800px' },
    );
    obs.observe(el);
    return () => {
      obs.disconnect();
    };
  }, [count, items.length]);

  const columns = useMemo(() => {
    if (kind === 'desktop') return 'repeat(auto-fill, minmax(170px, 1fr))';
    if (kind === 'tablet') return 'repeat(auto-fill, minmax(150px, 1fr))';
    return 'repeat(auto-fill, minmax(118px, 1fr))';
  }, [kind]);

  if (items.length === 0) return <>{empty}</>;

  return (
    <>
      <div className="mm-grid" style={{ gridTemplateColumns: columns }} role="list">
        {items.slice(0, count).map((it) => (
          <div role="listitem" key={it.id}>
            <MediaCard item={it} />
          </div>
        ))}
      </div>
      {count < items.length && <div ref={sentinel} style={{ height: 40 }} aria-hidden="true" />}
    </>
  );
}
