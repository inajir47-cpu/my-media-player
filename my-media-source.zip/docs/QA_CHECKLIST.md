# Manual QA Checklist — My Media 1.0.0

Use a real Android device (or emulator) with a folder of local video files,
and a desktop browser for the PWA. Mark each item pass/fail with the build
under test. Anything failing blocks release.

## Install

- [ ] Debug APK installs on Android 9+ without warnings about the signature.
- [ ] App icon (charcoal + amber play mark) appears in the launcher.
- [ ] PWA: "Install app" offered in Chrome/Edge; installed icon launches
      standalone; works fully offline after first load (airplane mode).

## First run / library

- [ ] First-run screen offers "Add folder" and "Browse without media".
- [ ] Android: folder picker opens the system SAF picker; grant persists
      after app restart (no re-prompt).
- [ ] Scan shows live progress with counts and is cancellable mid-scan.
- [ ] After scan: movies, shows, seasons, episodes grouped correctly,
      including `S02E05`, `2x05`, and season-folder layouts.
- [ ] Rescan adds only new files — no duplicates.
- [ ] Zero-byte media file is listed but marked unplayable, no crash.
- [ ] Revoke the folder grant in system Settings → app still opens, shows an
      honest "permission revoked" state with a re-grant action.
- [ ] Remove the USB drive / SD card → items show "offline", metadata and
      progress retained.

## Home / search / details

- [ ] Continue Watching, Recently Added, Favorites, Watchlist, Movies,
      Shows, Recently Played sections all render real data (no empty
      sections with spinners).
- [ ] Random hero plays the correct local file's preview on tap.
- [ ] Search filters by title/genre/year/type; sort orders work; results
      open the correct title.
- [ ] Detail page shows real metadata only; **Reviews is the last section**.
- [ ] Review: create 4.5★ with spoiler flag → persists offline → edit →
      delete. All offline.

## Collections

- [ ] Collections tab: create "Test" → appears in list and on Home.
- [ ] Movie detail → "Add to collection" → pick "Test" → toast confirms.
- [ ] Show detail → "Add season to collection" → adds current season's episodes.
- [ ] Collection detail: ↑/↓ reorder persists; ✕ removes title (media kept);
      "+ Add titles" search adds from library.
- [ ] Rename via ✎ (whitespace normalized); delete via 🗑 with confirm —
      titles stay in the library.
- [ ] Home collection cards open `/collection/:id`; unknown id shows empty
      state with a back link (no dead route).

## Player

- [ ] Play/pause, seek bar with buffered display, ±10s buttons, 0.25×–4×
      speeds, volume/mute, fullscreen, PiP (where supported).
- [ ] Subtitle track picker lists only tracks that exist; sidecar `.srt`
      loads; delay ± and styling apply.
- [ ] Audio track picker lists only existing tracks.
- [ ] Pause → background the app → progress saved; resume offers
      Resume / Start Over.
- [ ] Watch to 90% (or <60s remaining) → marked watched, leaves
      Continue Watching.
- [ ] Queue: next/previous, shuffle, repeat modes; autoplay-next shows a
      cancellable countdown.
- [ ] Gestures: double-tap sides ±10s, horizontal scrub, left-side
      brightness (app window only), right-side volume, pinch zoom fit,
      long-hold 2×, lock mode hides gestures.
- [ ] Keyboard: Space/K, J/L, arrows, M, F, P, C, [/], Esc.
- [ ] Unsupported codec → truthful error naming the container/codec with
      an "Open in external player" action on Android.
- [ ] Sleep timer pauses playback; wake lock held during playback.

## Previews

- [ ] Card/hero/detail previews play muted, correct title/episode, ~12s,
      not from the first/last 10% of the file.
- [ ] Preview pauses when the card scrolls off-screen or the app is
      backgrounded.
- [ ] Reduced motion / battery saver → no autoplay previews.
- [ ] Desktop: hover delay before preview; touch: Preview button / long-press
      with haptics; normal tap opens details.

## Settings / backup / privacy

- [ ] Every settings group (Playback, Gestures, Subtitles, Appearance,
      Library, Metadata, Storage, Backup, Accessibility, Privacy, About)
      opens and persists changes across restart.
- [ ] JSON backup downloads; file contains no secrets or absolute private
      paths; restore shows a preview before applying.
- [ ] Optional PIN: set → required on launch; stated as "not encryption".
- [ ] Clear cache / reset / remove-location / delete-file are separate,
      each confirmed; delete-file is explicitly labeled and never implicit.
- [ ] Optional metadata provider: key stored, never shown in logs/URLs;
      failed key shows an honest error; no fabricated metadata ever appears.

## Accessibility

- [ ] TalkBack/VoiceOver: all controls labeled, focus order sane.
- [ ] 200% font scaling: no clipped text or overlapping controls.
- [ ] High contrast + reduced motion + reduced transparency respected.
- [ ] RTL (Arabic locale): layout mirrors, strings translated.
- [ ] Phone bottom nav / tablet rail / desktop sidebar all present.

## Performance

- [ ] 10,000-item library: list scrolls smoothly, search debounced,
      thumbnails lazy-load, no ANR during scan.
- [ ] Leaving the player releases the decoder (no leaked object URLs /
      wake locks — check via `chrome://inspect` or logcat).

## Release build

- [ ] `assembleRelease`/`bundleRelease` unsigned → apksigner verifies
      "no signature"; signed with your keystore → verified, installs,
      upgrades over the debug build only after uninstall (different sig).
- [ ] `allowBackup=false` confirmed in the merged manifest.
- [ ] No `INTERNET` permission surprises: `aapt dump permissions`
      reviewed.
