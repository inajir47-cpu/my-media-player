# My Media — legal E2E fixture

Everything under `media/` is **synthetically generated** for automated testing.
No copyrighted or third-party content is included:

- Video files: `ffmpeg` `testsrc` pattern, 5 s, 320×240, H.264 (`libx264`).
- Audio file: `ffmpeg` sine-wave tone, 3 s, MP3.
- `.srt` / `.nfo` files: hand-written for this fixture.
- `Zero.Byte.2024.mp4`: an empty file, to exercise the zero-byte media path.

File names deliberately cover the scanner's parsing rules:

| File                                                | Exercises                                    |
| --------------------------------------------------- | -------------------------------------------- |
| `Movies/Dune.Part.Two.2024.1080p.WEB-DL.mp4`        | movie + year + tags, sidecar `.srt` + `.nfo` |
| `Movies/Zero.Byte.2024.mp4`                         | zero-byte media handling                     |
| `Shows/My.Show/S01/My.Show.S01E01.Pilot.720p.mp4`   | `S01E01` notation, sidecar `.srt`            |
| `Shows/My.Show/S01/My.Show.S01E02.720p.mp4`         | episode grouping into a show                 |
| `Shows/My.Show/Season 2/My.Show.E03.The.Return.mp4` | season from parent folder                    |
| `Audio/Sample.Track.mp3`                            | audio-kind detection                         |

`manifest.json` lists every file with its byte size. Total fixture size is well
under 1 MB.
