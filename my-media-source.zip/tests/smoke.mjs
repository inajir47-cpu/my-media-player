// PWA smoke test for My Media.
// Serves the production build (dist/), drives it with headless Chromium via
// playwright-core, and asserts: app boots, key routes render without errors,
// the web manifest is correct, the service worker registers, and the app shell
// still loads while offline.
//
// Run: npm run test:e2e   (requires `npm run build` first)
import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { join, extname, normalize } from 'node:path';
import { chromium } from 'playwright-core';

const DIST = new URL('../dist/', import.meta.url).pathname;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.mp4': 'video/mp4',
};

async function serveFile(res, filePath) {
  try {
    const st = await stat(filePath);
    if (!st.isFile()) return false;
    const data = await readFile(filePath);
    res.writeHead(200, { 'Content-Type': MIME[extname(filePath)] ?? 'application/octet-stream' });
    res.end(data);
    return true;
  } catch {
    return false;
  }
}

const server = createServer(async (req, res) => {
  const urlPath = normalize(decodeURIComponent(new URL(req.url, 'http://x').pathname)).replace(
    /^(\.\.[/\\])+/,
    '',
  );
  const filePath = join(DIST, urlPath);
  // Static file if it exists; otherwise fall back to the app shell (SPA).
  if (!(await serveFile(res, filePath))) {
    if (!(await serveFile(res, join(DIST, 'index.html')))) {
      res.writeHead(404);
      res.end('not found');
    }
  }
});

await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
const port = server.address().port;
const base = `http://127.0.0.1:${port}`;

const failures = [];
const check = (name, ok, detail = '') => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ` — ${detail}` : ''}`);
  if (!ok) failures.push(name);
};

let browser;
try {
  // Pin to the full Chromium binary explicitly: newer playwright-core versions
  // default headless launches to the smaller "headless shell" build, which may
  // not be downloaded. The full Chrome-for-Testing binary supports headless
  // mode (including service workers) on its own.
  browser = await chromium.launch({ executablePath: chromium.executablePath() });
  const context = await browser.newContext();
  const page = await context.newPage();

  const consoleErrors = [];
  const pageErrors = [];
  page.on('console', (msg) => {
    if (msg.type() === 'error') consoleErrors.push(msg.text());
  });
  page.on('pageerror', (err) => pageErrors.push(String(err && err.message ? err.message : err)));

  // 1. App boots on the home route.
  await page.goto(`${base}/`, { waitUntil: 'networkidle' });
  await page.waitForSelector('#root > *', { timeout: 15000 });
  const title = await page.title();
  check('home boots with title', title === 'My Media', `title="${title}"`);

  // 2. Key routes render without page errors.
  const routes = [
    '#/library',
    '#/movies',
    '#/shows',
    '#/search',
    '#/settings',
    '#/offline',
    '#/collections',
    '#/collection/does-not-exist',
  ];
  for (const hash of routes) {
    await page.goto(`${base}/${hash}`, { waitUntil: 'networkidle' });
    await page.waitForSelector('#root > *', { timeout: 15000 });
    const hasBlank = await page.evaluate(
      () => document.querySelector('#root')?.textContent?.trim().length === 0,
    );
    check(`route ${hash} renders content`, !hasBlank);
  }

  // 3. Web manifest is correct.
  const manifest = await page.evaluate(() => fetch('manifest.webmanifest').then((r) => r.json()));
  check('manifest name', manifest.name === 'My Media', `name="${manifest.name}"`);
  check('manifest display', manifest.display === 'standalone', `display="${manifest.display}"`);
  const iconSizes = (manifest.icons ?? []).map((i) => i.sizes);
  check(
    'manifest icons 192+512',
    iconSizes.includes('192x192') && iconSizes.includes('512x512'),
    iconSizes.join(','),
  );

  // 4. Service worker registers and controls the page.
  await page.goto(`${base}/`, { waitUntil: 'networkidle' });
  const swState = await page.evaluate(async () => {
    if (!('serviceWorker' in navigator)) return 'unsupported';
    const reg = await navigator.serviceWorker.ready;
    await new Promise((r) => setTimeout(r, 1500));
    return reg.active ? reg.active.state : 'no-active';
  });
  check('service worker active', swState === 'activated', swState);

  // 5. Offline: the app shell still loads from the service worker cache.
  await context.setOffline(true);
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForSelector('#root > *', { timeout: 15000 }).catch(() => {});
  const offlineText = await page.evaluate(
    () => document.querySelector('#root')?.textContent?.trim().length ?? 0,
  );
  check('offline shell reload renders', offlineText > 0, `${offlineText} chars`);
  await context.setOffline(false);

  // 6. No console errors or uncaught page errors across the whole run.
  check('no console errors', consoleErrors.length === 0, consoleErrors.slice(0, 3).join(' | '));
  check('no page errors', pageErrors.length === 0, pageErrors.slice(0, 3).join(' | '));
} finally {
  await browser?.close();
  server.close();
}

if (failures.length > 0) {
  console.error(`\n${failures.length} smoke test(s) failed.`);
  process.exit(1);
}
console.log('\nAll smoke tests passed.');
