import js from '@eslint/js';
import reactHooks from 'eslint-plugin-react-hooks';
import tseslint from 'typescript-eslint';

export default tseslint.config(
  { ignores: ['dist/**', 'android/**', 'node_modules/**', 'coverage/**', 'tests/fixtures/**'] },
  js.configs.recommended,
  // recommendedTypeChecked: type-aware safety (no floating/misused promises,
  // no unsafe assignments) without strictTypeChecked's stylistic noise
  // (e.g. banning numbers in template literals or all non-null assertions).
  ...tseslint.configs.recommendedTypeChecked,
  {
    files: ['**/*.{ts,tsx}'],
    languageOptions: {
      parserOptions: { projectService: true, tsconfigRootDir: import.meta.dirname },
    },
    plugins: { 'react-hooks': reactHooks },
    rules: {
      'react-hooks/rules-of-hooks': 'error',
      'react-hooks/exhaustive-deps': 'warn',
      '@typescript-eslint/no-explicit-any': 'error',
      '@typescript-eslint/no-unused-vars': ['error', { argsIgnorePattern: '^_' }],
      '@typescript-eslint/consistent-type-imports': 'error',
      // Fire-and-forget UI handlers (navigate(), repository writes that handle
      // their own errors) are idiomatic in this codebase and already marked
      // with `void` where the promise is intentionally ignored. Only flag
      // promises misused in conditionals/spreads, not void-return slots.
      '@typescript-eslint/no-misused-promises': ['error', { checksVoidReturn: false }],
    },
  },
  {
    files: ['**/*.test.{ts,tsx}', 'tests/**/*.ts'],
    ...tseslint.configs.disableTypeChecked,
  },
);
