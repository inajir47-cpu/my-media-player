package app.mymedia.library

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioManager
import android.net.Uri
import android.provider.DocumentsContract
import android.view.WindowManager
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

/**
 * MediaBridge: the native bridge for My Media.
 *
 * - SAF folder grants (persisted, prefix-capable) and recursive document-tree
 *   listing — no broad storage permission is ever requested.
 * - A localhost-only HTTP media server that streams content:// URIs to the
 *   WebView with byte-range support, so <video> can play SAF files.
 * - EncryptedSharedPreferences-backed secure storage for provider API keys.
 * - App-window-only brightness, music-stream volume, external-player intents.
 */
private const val REQUEST_PICK_FOLDER = 0xB41D

@CapacitorPlugin(
    name = "MediaBridge",
    // REQUIRED: the bridge routes startActivityForResult() results back to the
    // plugin via getPluginWithRequestCode(). Without this, handleOnActivityResult
    // is never called and pickFolder()'s promise hangs forever.
    requestCodes = [REQUEST_PICK_FOLDER]
)
class MediaBridgePlugin : Plugin() {

    // ------------------------------------------------------------------
    // SAF folder grants
    // ------------------------------------------------------------------

    @PluginMethod
    fun pickFolder(call: PluginCall) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
            )
        }
        startActivityForResult(call, intent, REQUEST_PICK_FOLDER)
    }

    override fun handleOnActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.handleOnActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PICK_FOLDER) return
        val call = savedCall ?: return
        if (resultCode == Activity.RESULT_OK && data?.data != null) {
            val treeUri = data.data!!
            try {
                context.contentResolver.takePersistableUriPermission(
                    treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: SecurityException) {
                call.reject("Could not persist folder permission", e)
                return
            }
            val ret = JSObject()
            ret.put("treeUri", treeUri.toString())
            ret.put("displayName", displayNameForTree(treeUri) ?: "Folder")
            call.resolve(ret)
        } else {
            call.reject("Folder picking was cancelled")
        }
    }

    @PluginMethod
    fun hasPermission(call: PluginCall) {
        val treeUri = call.getString("treeUri") ?: return call.reject("Missing treeUri")
        val ret = JSObject()
        ret.put("granted", hasPersistedPermission(treeUri))
        call.resolve(ret)
    }

    @PluginMethod
    fun releaseFolder(call: PluginCall) {
        val treeUri = call.getString("treeUri") ?: return call.reject("Missing treeUri")
        try {
            context.contentResolver.releasePersistableUriPermission(
                Uri.parse(treeUri),
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (e: SecurityException) {
            // Already released or never held — treat as released.
        }
        call.resolve()
    }

    private fun hasPersistedPermission(treeUri: String): Boolean {
        return context.contentResolver.persistedUriPermissions.any {
            it.uri.toString() == treeUri && it.isReadPermission
        }
    }

    private fun displayNameForTree(treeUri: Uri): String? {
        return try {
            val docId = DocumentsContract.getTreeDocumentId(treeUri)
            val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
            context.contentResolver.query(
                docUri,
                arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------------
    // Recursive document-tree listing
    // ------------------------------------------------------------------

    @PluginMethod
    fun listFiles(call: PluginCall) {
        val treeUri = call.getString("treeUri") ?: return call.reject("Missing treeUri")
        if (!hasPersistedPermission(treeUri)) {
            call.reject("Permission revoked for this folder")
            return
        }
        thread(name = "MediaBridge-listFiles") {
            try {
                val tree = Uri.parse(treeUri)
                val files = JSArray()
                val rootDocId = DocumentsContract.getTreeDocumentId(tree)
                val rootUri = DocumentsContract.buildDocumentUriUsingTree(tree, rootDocId)
                walkTree(tree, rootUri, "", files)
                val ret = JSObject()
                ret.put("files", files)
                call.resolve(ret)
            } catch (e: Exception) {
                call.reject("Folder listing failed: ${e.message}", e)
            }
        }
    }

    private fun walkTree(treeUri: Uri, dirUri: Uri, relativeDir: String, out: JSArray) {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(
            treeUri, DocumentsContract.getDocumentId(dirUri)
        )
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
            val sizeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE)
            val modCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
            while (cursor.moveToNext()) {
                val docId = cursor.getString(idCol) ?: continue
                val name = cursor.getString(nameCol) ?: continue
                val mime = cursor.getString(mimeCol) ?: ""
                val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    val childRel = if (relativeDir.isEmpty()) name else "$relativeDir/$name"
                    walkTree(treeUri, docUri, childRel, out)
                } else {
                    val entry = JSObject()
                    entry.put("uri", docUri.toString())
                    entry.put("name", name)
                    entry.put("size", if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L)
                    entry.put("mtimeMs", if (modCol >= 0) cursor.getLong(modCol) else 0L)
                    entry.put("relativePath", if (relativeDir.isEmpty()) name else "$relativeDir/$name")
                    out.put(entry)
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Localhost media server (127.0.0.1 only, byte-range streaming)
    // ------------------------------------------------------------------

    private var mediaServer: ServerSocket? = null
    private var mediaBaseUrl: String? = null
    private val tokenToUri = ConcurrentHashMap<String, String>()

    @PluginMethod
    fun startMediaServer(call: PluginCall) {
        try {
            synchronized(this) {
                if (mediaServer == null || mediaServer!!.isClosed) {
                    val server = ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"))
                    mediaServer = server
                    mediaBaseUrl = "http://127.0.0.1:${server.localPort}"
                    thread(isDaemon = true, name = "MediaBridge-Server") { acceptLoop(server) }
                }
            }
            val ret = JSObject()
            ret.put("baseUrl", mediaBaseUrl)
            call.resolve(ret)
        } catch (e: Exception) {
            call.reject("Could not start media server: ${e.message}", e)
        }
    }

    @PluginMethod
    fun playableUrl(call: PluginCall) {
        val uri = call.getString("uri") ?: return call.reject("Missing uri")
        val base = mediaBaseUrl ?: return call.reject("Media server is not running")
        val token = UUID.randomUUID().toString()
        tokenToUri[token] = uri
        val ret = JSObject()
        ret.put("url", "$base/m/$token")
        call.resolve(ret)
    }

    private fun acceptLoop(server: ServerSocket) {
        while (!server.isClosed) {
            try {
                val socket = server.accept()
                thread(isDaemon = true, name = "MediaBridge-Conn") {
                    try {
                        handleConnection(socket)
                    } catch (e: Exception) {
                        try { socket.close() } catch (ignored: Exception) {}
                    }
                }
            } catch (e: Exception) {
                if (server.isClosed) break
            }
        }
    }

    private fun handleConnection(socket: Socket) {
        socket.use { s ->
            val reader: BufferedReader = BufferedReader(InputStreamReader(s.getInputStream()))
            val requestLine = reader.readLine() ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) {
                writeStatus(s.getOutputStream(), 400, "Bad Request")
                return
            }
            val method = parts[0].uppercase()
            val path = parts[1]
            var rangeHeader: String? = null
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val header = line ?: break
                if (header.isEmpty()) break
                if (header.startsWith("Range:", ignoreCase = true)) {
                    rangeHeader = header.substringAfter(":").trim()
                }
            }

            val token = path.removePrefix("/m/").substringBefore("?").substringBefore("/")
            val uriString = tokenToUri[token]
            if (uriString == null) {
                writeStatus(s.getOutputStream(), 404, "Not Found")
                return
            }
            val uri = Uri.parse(uriString)
            val afd = try {
                context.contentResolver.openFileDescriptor(uri, "r")
            } catch (e: Exception) {
                null
            }
            if (afd == null) {
                writeStatus(s.getOutputStream(), 410, "Gone")
                return
            }
            afd.use { descriptor ->
                val total = descriptor.statSize
                val (start, end) = parseRange(rangeHeader, total)
                val length = end - start + 1
                val out: OutputStream = s.getOutputStream()
                val ext = uriString.substringAfterLast('.', "").lowercase()
                val contentType = mimeForExtension(ext)
                val head = method == "HEAD"
                if (rangeHeader != null && (start != 0L || end != total - 1)) {
                    writeHeaders(
                        out, 206, "Partial Content", contentType, length,
                        "bytes $start-$end/$total", total
                    )
                } else {
                    writeHeaders(out, 200, "OK", contentType, total, null, total)
                }
                if (!head) {
                    val input = java.io.FileInputStream(descriptor.fileDescriptor)
                    input.channel.position(start)
                    val buffer = ByteArray(64 * 1024)
                    var remaining = length
                    while (remaining > 0) {
                        val toRead = minOf(buffer.size.toLong(), remaining).toInt()
                        val read = input.read(buffer, 0, toRead)
                        if (read <= 0) break
                        out.write(buffer, 0, read)
                        remaining -= read
                    }
                    out.flush()
                }
            }
        }
    }

    private fun parseRange(header: String?, total: Long): Pair<Long, Long> {
        if (total <= 0) return Pair(0L, 0L)
        if (header == null || !header.startsWith("bytes=")) return Pair(0L, total - 1)
        val spec = header.removePrefix("bytes=").substringBefore(",").trim()
        return try {
            if (spec.startsWith("-")) {
                // Suffix range: last N bytes.
                val n = spec.removePrefix("-").toLong().coerceAtMost(total)
                Pair(total - n, total - 1)
            } else {
                val dash = spec.indexOf('-')
                val start = spec.substring(0, dash).toLong().coerceIn(0, total - 1)
                val endPart = spec.substring(dash + 1)
                val end = if (endPart.isEmpty()) total - 1 else endPart.toLong().coerceIn(start, total - 1)
                Pair(start, end)
            }
        } catch (e: Exception) {
            Pair(0L, total - 1)
        }
    }

    private fun mimeForExtension(ext: String): String = when (ext) {
        "mp4", "m4v", "mov" -> "video/mp4"
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        "mp3" -> "audio/mpeg"
        "m4a", "aac" -> "audio/mp4"
        "flac" -> "audio/flac"
        "ogg", "oga" -> "audio/ogg"
        "wav" -> "audio/wav"
        else -> "application/octet-stream"
    }

    private fun writeStatus(out: OutputStream, code: Int, message: String) {
        out.write("HTTP/1.1 $code $message\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray())
        out.flush()
    }

    private fun writeHeaders(
        out: OutputStream,
        code: Int,
        message: String,
        contentType: String,
        contentLength: Long,
        contentRange: String?,
        total: Long
    ) {
        val sb = StringBuilder()
        sb.append("HTTP/1.1 $code $message\r\n")
        sb.append("Content-Type: $contentType\r\n")
        sb.append("Content-Length: $contentLength\r\n")
        sb.append("Accept-Ranges: bytes\r\n")
        if (contentRange != null) sb.append("Content-Range: $contentRange\r\n")
        if (total > 0) sb.append("X-Content-Total: $total\r\n")
        sb.append("Connection: close\r\n")
        sb.append("\r\n")
        out.write(sb.toString().toByteArray())
        out.flush()
    }

    // ------------------------------------------------------------------
    // Secure storage (EncryptedSharedPreferences — provider API keys)
    // ------------------------------------------------------------------

    private fun securePrefs(): SharedPreferences {
        val masterKey = MasterKey.Builder(context, MasterKey.DEFAULT_MASTER_KEY_ALIAS)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            context,
            "media_bridge_secure",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    @PluginMethod
    fun setSecureValue(call: PluginCall) {
        val key = call.getString("key") ?: return call.reject("Missing key")
        val value = call.getString("value") ?: return call.reject("Missing value")
        try {
            securePrefs().edit().putString(key, value).apply()
            call.resolve()
        } catch (e: Exception) {
            call.reject("Secure storage write failed: ${e.message}", e)
        }
    }

    @PluginMethod
    fun getSecureValue(call: PluginCall) {
        val key = call.getString("key") ?: return call.reject("Missing key")
        try {
            val ret = JSObject()
            // put with explicit null handling: JSObject.put(String, String?) stores null.
            ret.put("value", securePrefs().getString(key, null))
            call.resolve(ret)
        } catch (e: Exception) {
            call.reject("Secure storage read failed: ${e.message}", e)
        }
    }

    @PluginMethod
    fun removeSecureValue(call: PluginCall) {
        val key = call.getString("key") ?: return call.reject("Missing key")
        try {
            securePrefs().edit().remove(key).apply()
            call.resolve()
        } catch (e: Exception) {
            call.reject("Secure storage delete failed: ${e.message}", e)
        }
    }

    // ------------------------------------------------------------------
    // App-window brightness (never touches system settings)
    // ------------------------------------------------------------------

    @PluginMethod
    fun setWindowBrightness(call: PluginCall) {
        val value = call.getDouble("value") ?: return call.reject("Missing value")
        val activity = activity ?: return call.reject("No activity")
        val clamped = value.toFloat().coerceIn(0.05f, 1f)
        activity.runOnUiThread {
            val attrs: WindowManager.LayoutParams = activity.window.attributes
            attrs.screenBrightness = clamped
            activity.window.attributes = attrs
        }
        call.resolve()
    }

    @PluginMethod
    fun getWindowBrightness(call: PluginCall) {
        val activity = activity ?: return call.reject("No activity")
        val current = activity.window.attributes.screenBrightness
        val ret = JSObject()
        // < 0 means "follow system"; report full brightness as the effective value.
        ret.put("value", if (current < 0) 1.0 else current.toDouble())
        call.resolve(ret)
    }

    // ------------------------------------------------------------------
    // Music-stream volume
    // ------------------------------------------------------------------

    @PluginMethod
    fun getVolume(call: PluginCall) {
        val audio = context.getSystemService(Activity.AUDIO_SERVICE) as AudioManager
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        val ret = JSObject()
        ret.put("value", cur.toDouble() / max.toDouble())
        call.resolve(ret)
    }

    @PluginMethod
    fun setVolume(call: PluginCall) {
        val value = call.getDouble("value") ?: return call.reject("Missing value")
        val audio = context.getSystemService(Activity.AUDIO_SERVICE) as AudioManager
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val index = (value.coerceIn(0.0, 1.0) * max).toInt()
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, index, 0)
        call.resolve()
    }

    // ------------------------------------------------------------------
    // External player (explicit, user-invoked only)
    // ------------------------------------------------------------------

    @PluginMethod
    fun openExternal(call: PluginCall) {
        val url = call.getString("url") ?: return call.reject("Missing url")
        val activity = activity ?: return call.reject("No activity")
        try {
            val uri = Uri.parse(url)
            val ext = uri.toString().substringAfterLast('.', "").lowercase().substringBefore("?")
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeForExtension(ext))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (intent.resolveActivity(context.packageManager) != null) {
                activity.startActivity(intent)
                call.resolve()
            } else {
                call.reject("No installed app can open this file")
            }
        } catch (e: Exception) {
            call.reject("Could not open external player: ${e.message}", e)
        }
    }
}
