import type { CapacitorConfig } from '@capacitor/cli';
import { APP_ID, APP_NAME } from './src/config';

const config: CapacitorConfig = {
  appId: APP_ID,
  appName: APP_NAME,
  webDir: 'dist',
  backgroundColor: '#0b0b0d',
  android: {
    // Keep the WebView edge-to-edge; the app handles safe areas itself.
    allowMixedContent: false,
    // Cleartext HTTP is disabled in AndroidManifest.xml via a restrictive
    // network security config, so media/metadata never leak to the network.
  },
  server: {
    // No remote server. Only localhost for live-reload in development.
    androidScheme: 'https',
  },
};

export default config;
