# My Media

A local-first personal media library for Android and the web. One codebase
(React + TypeScript + Vite) ships as an installable Android app (via
Capacitor) and as an installable offline PWA.

**Your files never leave your device.** No account, no server, no analytics,
no ads, no trackers, no background uploads. There is no online metadata
fetching unless you explicitly configure a provider with your own API key —
and even then, responses are cached locally and you review every match.

## Features

- **Library**: add folders (Android: Storage Access Framework with persisted
  grants — no broad storage permission; Web: File System Access API with
  file-input fallback). Recursive, incremental, cancellable scans with live
  progress. Stable identity (URI + size + modified time) — rescans never
  duplicate.
- **Smart parsing**: movie name/year parsing, `S02E05`, `2x05`, season
  folders, episode numbering; Movies / Shows / Seasons / Episodes grouping.
- **Home**: Continue Watching, Recently Added, Favorites, Watchlist, Movies,
  Shows, Recently Played, collections, and a large random local-video hero.
- **Player**: full custom player — play/pause, precise seek with buffered
  display, previous/next, configurable seek interval, volume/mute,
  0.25×–4× speed, real subtitle/audio track selection, subtitle delay,
  subtitle styling, fit modes, fullscreen, PiP, wake lock, queue with
  repeat/shuffle, sleep timer, player lock, screenshot (where the platform
  allows), progress saving, autoplay-next with cancel countdown, and an
  Android external-player option. Discoverable, remappable gestures (tap,
  double-tap zones, scrub, brightness/volume swipes, pinch zoom, two-finger
  tap, long-hold 2×) plus full keyboard shortcuts and D-pad support.
- **Previews**: one decoder at a time; deterministic 12-second clips avoiding
  the first/last 10% of a file; muted by default; hover on desktop, long-press
  / Preview action on touch; pauses when backgrounded or under reduced motion.
- **Details**: real local metadata, technical details, history, related
  titles, episode lists with progress — and **reviews always last**. Local
  0.5–5 star reviews with title/body/spoiler flag, editable, offline.
- **Management**: favorites, watchlist, collections with reordering, history,
  bulk watched actions, metadata/artwork editing, JSON backup & restore
  (media and secrets excluded), optional PIN (a lock, not encryption).
- **Accessibility & i18n**: 44×44 targets, focus states, screen-reader labels,
  font scaling, high contrast, reduced motion/transparency, RTL, English and
  Arabic strings, locale-aware formatting.
- **Privacy**: provider keys in Android EncryptedSharedPreferences / local
  PWA storage, excluded from backups and logs. A key is sent only to the
  provider you configured, using that provider's standard authentication
  (TMDB uses an `api_key` query parameter over HTTPS). Diagnostic logs never
  include full file paths unless you explicitly export them.

## Project structure

```
src/
  config.ts            # App name, IDs, supported extensions — customize here
  app/                 # Boot, layout, router, pages (Home, Library, Search, …)
  player/              # PlayerPage + queue, persistence, gestures, shortcuts, cues
  library/             # Scanning, filename parsing, playable-URL resolution
  details/             # Movie/show detail pages, reviews, metadata editing
  metadata/            # Provider interface, sidecar (NFO/JSON) parsing, match/undo
  storage/             # Dexie DB + repository, platform adapters, backup
  settings/            # Settings store and defaults
  shared/              # Design tokens, i18n, formatting, logger, UI primitives
  collections/         # Collections store
android/               # Capacitor Android shell (generated + customized)
  app/src/main/java/app/mymedia/library/MediaBridgePlugin.kt
                       # Native bridge: SAF, localhost media server, secure
                       # storage, brightness, volume, external player
public/icons/          # PWA icons (generated)
tests/fixtures/media/  # Synthetic ffmpeg-generated test media (no copyrighted content)
```

Key customization points:

| What                  | Where                                       |
| --------------------- | ------------------------------------------- |
| App name / ID         | `src/config.ts` (`APP_NAME`, `APP_ID`)      |
| Colors, spacing, type | `src/shared/tokens.ts` (design tokens)      |
| Strings (en/ar)       | `src/shared/i18n.ts`                        |
| Playback defaults     | `src/storage/types.ts` (`DEFAULT_SETTINGS`) |
| Supported extensions  | `src/config.ts`                             |

## Development

Requirements: Node ≥ 20, npm, JDK 21 (Capacitor 7 needs Java 21 to compile),
Android SDK (platform 35, build-tools 34.0.0) for Android builds.

```bash
npm install          # install pinned dependencies
npm run dev          # web dev server
npm run test         # unit + component tests (Vitest)
npm run lint         # ESLint, zero warnings allowed
npm run typecheck    # strict TypeScript
npm run build        # production PWA -> dist/
```

Android (SDK location is read from `ANDROID_HOME`/`ANDROID_SDK_ROOT`):

```bash
npm run android:dev          # build web + sync to the Android project
npm run android:apk:debug    # build + assemble debug APK
npm run android:apk:release  # build + assemble unsigned release APK
npm run android:aab:release  # build + assemble unsigned release bundle
```

The debug APK lands at
`android/app/build/outputs/apk/debug/app-debug.apk`.

> Sandbox note: in this build environment egress goes through an
> authenticated proxy whose password rotates every few minutes, and TLS is
> intercepted with a private CA. For Gradle builds: read the fresh password
> from the `https_proxy` env var for each invocation (an init script in
> `~/.gradle/init.d/` can do this — never persist the password), use the
> proxy's IPv6 address (IPv6-mapped IPv4 connections are blackholed here),
> and import the egress CA into the JDK's `cacerts`. The Gradle client JVM
> also needs `-Djava.net.preferIPv4Stack=true` (via `GRADLE_OPTS`) because
> the sandbox transparently proxies IPv6-mapped loopback connections, which
> breaks Gradle's client↔daemon socket ("Could not receive a message from
> the daemon").

## Android release signing

The release APK/AAB are built **unsigned**. Never commit signing keys.

1. Generate a keystore (once, keep it safe and backed up):
   ```bash
   keytool -genkeypair -v -keystore my-media-release.keystore \
     -alias my-media -keyalg RSA -keysize 4096 -validity 9125
   ```
2. Create `android/keystore.properties` (git-ignored):
   ```properties
   storeFile=/absolute/path/to/my-media-release.keystore
   storePassword=YOUR_STORE_PASSWORD
   keyAlias=my-media
   keyPassword=YOUR_KEY_PASSWORD
   ```
3. Build a signed release:
   ```bash
   cd android && ./gradlew bundleRelease   # or assembleRelease
   ```
   The build reads `keystore.properties` when present; without it the
   release stays unsigned (useful for CI inspection builds).
4. `bundleRelease` output:
   `android/app/build/outputs/bundle/release/app-release.aab` — upload this
   to Google Play. `assembleRelease` gives you a signed APK for direct
   distribution.

Losing the keystore means you can never update the Play listing — back it up
offline.

## Privacy & security notes

- Media scanning, playback, previews, search, reviews, and settings work
  fully offline.
- Android uses Storage Access Framework document-tree grants persisted with
  `takePersistableUriPermission`. Revoking access in system settings is
  detected and surfaced honestly; rescanning asks again.
- Playback of SAF files goes through a **localhost-only** HTTP server
  (`127.0.0.1`, random port, byte-range support) inside the app — the
  network security config forbids all other cleartext traffic.
- `android:allowBackup` is `false`: system backups could carry provider keys
  or library data. Use the in-app JSON backup instead (Settings → Backup);
  it excludes media files and secrets, and restore shows a preview first.
- The optional PIN is a UI lock, not encryption — stated as such in the app.
- No fabricated metadata: ratings, cast, episodes, and artwork are only
  shown when they come from your files or a provider you configured.

## Testing

- `npm run test` — 77 unit/component tests: filename parsing, grouping,
  dedup identity, preview timestamps, watched/resume rules, queue logic,
  subtitle cue parsing (SRT→VTT, delay offsets, malformed input), backup
  validation, sanitization, and component rendering.
- `tests/fixtures/media/` — synthetic videos generated with ffmpeg
  (`testsrc`), realistic names (movies, `S01E01` shows, `2x03` episodes,
  sidecar `.srt`, `.nfo`, one zero-byte file), plus a manifest. Everything
  is generated; no copyrighted content.
- `npm run test:e2e` — `tests/smoke.mjs` production-build smoke check.
- Manual QA checklist: see [`docs/QA_CHECKLIST.md`](docs/QA_CHECKLIST.md).

## Known limitations (honest)

- **Audio delay**: the setting is stored and shown, but not applied to
  playback — the web `<video>` element exposes no audio-delay API (it would
  need Web Audio rerouting). Subtitle delay is fully applied.
- **Chapters**: not implemented — only real chapter data would be shown, and
  no parser for it exists yet.
- **No emulator/device in this environment**: the debug APK is compiled and
  its structure verified (`aapt` dump), but on-device runtime testing
  (SAF grant flow, playback, MediaBridge calls) has not been exercised.
  Install on a real device and walk the QA checklist before release.
- **Codecs**: playback uses the platform `<video>` element — formats the
  device can't decode (e.g. some MKV/HEVC on older devices) surface a
  truthful error with container/codec details and an external-player option
  on Android. The app does not bundle its own codecs.
- **SQLite on Android**: the current build uses the WebView's IndexedDB via
  Dexie behind the repository abstraction; a native SQLite backend is
  future work (the abstraction is ready for it).
- **PWA file persistence**: where the File System Access API can't persist
  handles, the app says so and offers reselection — it never pretends.
- **iOS**: not targeted; Capacitor iOS shell and its MediaBridge equivalent
  are not implemented.
