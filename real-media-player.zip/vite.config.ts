import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['icons/icon-192.png', 'icons/icon-512.png', 'apple-touch-icon.png'],
      manifest: {
        name: 'My Media',
        short_name: 'My Media',
        description: 'Local-first personal media library. Your files, your library, no account.',
        theme_color: '#0d0d10',
        background_color: '#0d0d10',
        display: 'standalone',
        orientation: 'any',
        start_url: '.',
        scope: '.',
        icons: [
          { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
          { src: 'icons/icon-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        ],
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,png,ico,webmanifest}'],
        // App shell is precached; metadata APIs + artwork CDNs are cached at
        // runtime so the app works fully offline after the first lookup.
        runtimeCaching: [
          {
            urlPattern: /^https:\/\/graphql\.anilist\.co\/?.*/i,
            handler: 'NetworkFirst',
            options: { cacheName: 'meta-anilist', expiration: { maxEntries: 300, maxAgeSeconds: 60 * 60 * 24 * 30 } },
          },
          {
            urlPattern: /^https:\/\/api\.tvmaze\.com\/?.*/i,
            handler: 'NetworkFirst',
            options: { cacheName: 'meta-tvmaze', expiration: { maxEntries: 300, maxAgeSeconds: 60 * 60 * 24 * 30 } },
          },
          {
            urlPattern: /^https:\/\/api\.jikan\.moe\/?.*/i,
            handler: 'NetworkFirst',
            options: { cacheName: 'meta-jikan', expiration: { maxEntries: 300, maxAgeSeconds: 60 * 60 * 24 * 30 } },
          },
          {
            urlPattern: /^https:\/\/(s4\.anilist\.co|cdn\.myanimelist\.net|static\.tvmaze\.com)\/?.*/i,
            handler: 'CacheFirst',
            options: {
              cacheName: 'meta-artwork',
              expiration: { maxEntries: 1000, maxAgeSeconds: 60 * 60 * 24 * 90 },
            },
          },
        ],
      },
    }),
  ],
  test: {
    environment: 'node',
    include: ['src/**/*.test.ts'],
  },
});
