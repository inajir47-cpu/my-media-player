# Manual QA checklist — My Media

Automated gates already pass: `npm run lint` (0 warnings), `npm test`
(39/39), `npm run build`, `npm run smoke` (PWA offline shell, no console
errors). The items below need a human with real media files, ideally on an
Android phone/tablet.

## First run
- [ ] Fresh profile → first-run setup screen appears, explains the app is local-first.
- [ ] Add a folder with a mixed library (shows/movies/music). Scan progress banner shows counts; Cancel stops cleanly.
- [ ] Re-open the app later → library persists without rescanning (IndexedDB).

## Parsing / grouping
- [ ] `Show.S02E05.1080p.BluRay.x264-GROUP.mkv` → Show, Season 2, Episode 5.
- [ ] `Show 2x05`, `Show - Episode 5` inside `Season 2/` folder → same grouping.
- [ ] `[SubPlease] One Piece - 1071 [1080p].mkv` → Episode 1071 (absolute).
- [ ] `Dune Part Two (2024).mkv` → movie, year 2024, not split into episodes.
- [ ] Remove a file from the folder, rescan → marked missing, metadata kept.
- [ ] Local `poster.jpg` / `backdrop.jpg` next to files are used as artwork.

## Home / browsing
- [ ] Hero plays muted ~12 s clips rotating from your episodes; never an online trailer.
- [ ] Continue Watching resumes at the saved position; finished items drop off.
- [ ] Tabs filter Shows / Movies / Music; Saved shows favorites + watchlist.
- [ ] Search finds titles; genre/year/watched filters work.

## Detail page
- [ ] Identify via AniList/TVmaze/Jikan → poster/backdrop/synopsis/episode names appear; "Fetched" badge shown.
- [ ] Edit metadata manually → "Custom" badge; Refresh metadata does not clobber edits.
- [ ] Add/edit/delete a private review; stars render; spoiler text hidden until tapped.
- [ ] "Where to watch" links editable; legal streaming links only.
- [ ] Collections: create, add/remove titles.

## Player
- [ ] Play/pause, ±10 s, prev/next, playlist, shuffle, repeat off/all/one.
- [ ] Timeline scrub is smooth; time labels correct; buffered indicator shows.
- [ ] Subtitles: external .srt next to file is offered; delay/size/color/position apply.
- [ ] Sleep timer pauses at expiry; screen lock hides controls until unlocked.
- [ ] Autoplay-next countdown appears at end of episode; cancel works.
- [ ] Rotate / fullscreen / PiP.
- [ ] Gestures: horizontal swipe seeks; left-side vertical = brightness; right-side = volume; double-tap left/right/center = -10 s / +10 s / play-pause; single tap toggles controls. Each group can be disabled in Settings → Gestures.
- [ ] On Android (Capacitor): device volume/brightness change for real; in browser they are honestly labeled as simulated.

## Settings / backup
- [ ] Export backup → JSON downloads; includes posters as data URLs.
- [ ] Import backup on a fresh profile → titles, metadata, reviews, history, artwork restored.
- [ ] Reset actions (clear history / clear cache / full reset) behave as labeled.

## PWA
- [ ] `npm run preview` → install prompt available in Chrome/Edge; installed app opens standalone.
- [ ] Airplane mode after first load → app shell, library, and cached artwork still work.

## Known untested (no device available)
- Native `MediaBridge.pickFolder` / `listFiles` and `content://` playback on Android.
- Real touchscreen gesture feel; real device brightness/volume paths.
