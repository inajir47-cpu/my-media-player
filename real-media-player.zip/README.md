# My Media

A local-first personal media library — React 18 + strict TypeScript + Vite,
styled as a dark cinematic streaming app with warm orange accents. Your files
stay on your device; metadata is fetched from free, keyless public APIs
(AniList, TVmaze, Jikan) and cached in IndexedDB. **No online trailers, ever** —
the home hero plays muted 12-second clips taken from your own files.

> Built fresh in `~/workspace/media-player-app/`. The older projects
> `~/workspace/my-media/` and `~/workspace/your_files/my-media/` were not touched.

## Quick start

```bash
npm install
npm run dev        # dev server
npm run build      # strict tsc + production build -> dist/
npm run preview    # serve the production build locally
npm test           # vitest unit tests
npm run lint       # eslint, zero warnings allowed
npm run smoke      # Playwright PWA smoke test against dist/ (needs npm run build first)
npm run icons      # regenerate PWA icons into public/icons/
```

## What it does

- **Library tabs** — Home, Shows, Movies, Music, Saved, Search, Settings.
- **Home** — hero with rotating muted 12 s preview clips from your local
  episodes (deterministic timestamps, skips the first ~90 s and the credits
  zone), Continue Watching, Recently Added, Favorites rows.
- **Scanning** — native Android folder picker via Capacitor `MediaBridge`
  (`pickFolder` 120 s timeout / `listFiles` 180 s), web File System Access
  (handles persisted in IndexedDB), or a one-shot `<input webkitdirectory>`
  fallback. Parses `S02E05`, `2x05`, `Episode 12`, anime absolute numbers,
  release-tag cleanup, year detection; groups seasons/episodes, attaches
  local posters/backdrops, subtitles, and marks missing files without
  deleting your metadata.
- **Metadata** — identify a title against AniList / TVmaze / Jikan, fetch
  posters, backdrops, synopsis, genres, ratings, episode names/synopses,
  related movies/OVAs/specials, and public reviews; everything cached
  locally. Manual edits live in a separate `custom` bucket and are never
  overwritten by refreshes.
- **Player** — custom HTML5 player: orange timeline, ±10 s seek, playlist,
  shuffle/repeat, speeds, sleep timer, screen lock, PiP, fullscreen,
  embedded + external SRT/VTT subtitles (delay/size/color/background/
  position), audio-track picker, autoplay-next countdown, resume playback,
  touch gestures (swipe seek, left = brightness, right = volume, double-tap
  zones). All gesture groups can be toggled in Settings.
- **Library extras** — collections, favorites, Saved/watchlist, private
  local star reviews, watch history with per-file positions, legal
  "where to watch" links you edit yourself, JSON backup export/import
  (posters included as data URLs).
- **PWA** — installable manifest, offline-first service worker (app shell
  precached; metadata/API/artwork cached at runtime), icons
  (192/512/maskable + apple-touch-icon).

## Project layout

```
src/
  config.ts            constants (timeouts, preview length, gesture defaults)
  types.ts             domain records + metadata merge rules
  db/database.ts       Dexie IndexedDB schema, settings, JSON backup
  native/bridge.ts     Capacitor MediaBridge wrapper + honest web fallbacks
  scan/                filename parsing + folder scanner
  metadata/            anilist.ts, tvmaze.ts, jikan.ts, service.ts
  media/               playable URLs, artwork blobs, thumbnail capture
  previews/clips.ts    deterministic 12 s preview-timestamp selection
  player/              playbackState.ts, subtitles.ts, Player.tsx
  library/store.tsx    global library context + query hooks
  components/          MediaCard, Hero, TitleDetail, EditMetadata, ErrorBoundary
  pages/               Home, Browse, SearchPage, SettingsPage, LibrarySetup
  App.tsx / main.tsx / styles.css
scripts/               make-icons.mjs, smoke.mjs (Playwright PWA check)
```

## Verification status (2026-09-25)

- `npm run lint` — **0 errors, 0 warnings** (`--max-warnings 0`)
- `npm test` — **39/39 pass** (filename parsing, preview timestamps, playback state/history)
- `npm run build` — strict `tsc --noEmit` + Vite production build OK
- `npm run smoke` — **PASSED**: no console errors, manifest linked, service
  worker registered + active, app renders, offline reload renders under SW control
- `dist/` contains `index.html`, hashed JS/CSS, `manifest.webmanifest`,
  `sw.js` + workbox runtime, `icons/icon-192.png`, `icons/icon-512.png`,
  `icons/icon-maskable-512.png`, `apple-touch-icon.png`

## Honest limitations

- **No Android device/emulator was available** — native `MediaBridge`
  playback, SAF folder picking, and device brightness/volume paths are
  implemented against the documented bridge contract but **untested on a
  real device**. In a desktop browser the app falls back to File System
  Access / file-input, which is session- or permission-scoped.
- **Music metadata** — no dedicated music metadata service; album art comes
  from local files/folders and anime metadata lookups. Track names come from
  filenames.
- **Gesture settings** added late — wired into the player, but verify on a
  real touchscreen.
- See `docs/QA.md` for the manual checklist that still needs a human + device.
