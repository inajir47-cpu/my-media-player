// Metadata editing: manual overrides (which always survive metadata
// refreshes) plus the identify flow (AniList / TVmaze / Jikan, no keys).

import { useState } from 'react';
import { useLibrary } from '../library/store';
import { resolveMeta, type TitleRecord } from '../types';
import type { MetaCandidate } from '../metadata/service';
import { useArtworkUrl } from '../media/artwork';

export function EditMetadataSheet({ title, onClose }: { title: TitleRecord; onClose: () => void }): React.JSX.Element {
  const { updateCustomMeta, uploadPoster, searchMeta, applyMeta, clearMeta } = useLibrary();
  const meta = resolveMeta(title);
  const [tab, setTab] = useState<'edit' | 'identify'>('edit');
  const [draft, setDraft] = useState({
    name: title.custom.name ?? '',
    synopsis: title.custom.synopsis ?? '',
    genres: (title.custom.genres ?? []).join(', '),
    rating: title.custom.rating !== undefined ? String(title.custom.rating) : '',
    year: title.custom.year !== undefined ? String(title.custom.year) : '',
    language: title.custom.language ?? '',
  });
  const [candidates, setCandidates] = useState<MetaCandidate[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [applying, setApplying] = useState(false);
  const [error, setError] = useState('');
  const currentPoster = useArtworkUrl(meta.posterArtworkId);

  const save = async () => {
    const rating = draft.rating.trim() ? Math.min(10, Math.max(0, Number(draft.rating))) : undefined;
    await updateCustomMeta(title.id, {
      name: draft.name.trim() || undefined,
      synopsis: draft.synopsis.trim() || undefined,
      genres: draft.genres.split(',').map((g) => g.trim()).filter(Boolean),
      rating: Number.isFinite(rating) ? rating : undefined,
      year: draft.year.trim() ? parseInt(draft.year, 10) : undefined,
      language: draft.language.trim() || undefined,
    });
    onClose();
  };

  const runSearch = async () => {
    setSearching(true);
    setError('');
    try {
      setCandidates(await searchMeta(title.id));
    } catch (e) {
      setError(`Search failed: ${(e as Error).message}. Internet is only needed for this lookup.`);
    } finally {
      setSearching(false);
    }
  };

  const apply = async (c: MetaCandidate) => {
    setApplying(true);
    setError('');
    try {
      await applyMeta(title.id, c);
      onClose();
    } catch (e) {
      setError(`Fetch failed: ${(e as Error).message}`);
    } finally {
      setApplying(false);
    }
  };

  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="sheet tall" role="dialog" aria-label="Edit metadata" onClick={(e) => e.stopPropagation()}>
        <div className="sheet-head">
          <strong>Edit metadata</strong>
          <button className="icon-btn" onClick={onClose} aria-label="Close">✕</button>
        </div>
        <div className="chip-row">
          <button className={`chip ${tab === 'edit' ? 'active' : ''}`} onClick={() => setTab('edit')}>Manual edit</button>
          <button className={`chip ${tab === 'identify' ? 'active' : ''}`} onClick={() => setTab('identify')}>Identify online</button>
        </div>
        <div className="sheet-body">
          {tab === 'edit' && (
            <>
              <label>Name <input value={draft.name} placeholder={title.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} /></label>
              <label>Synopsis <textarea value={draft.synopsis} placeholder={title.fetched?.synopsis ?? 'No synopsis'} rows={4} onChange={(e) => setDraft({ ...draft, synopsis: e.target.value })} /></label>
              <label>Genres (comma separated) <input value={draft.genres} placeholder="Action, Drama" onChange={(e) => setDraft({ ...draft, genres: e.target.value })} /></label>
              <div className="row">
                <label>Your rating (0–10) <input value={draft.rating} inputMode="decimal" onChange={(e) => setDraft({ ...draft, rating: e.target.value })} /></label>
                <label>Year <input value={draft.year} inputMode="numeric" onChange={(e) => setDraft({ ...draft, year: e.target.value })} /></label>
              </div>
              <label>Language <input value={draft.language} placeholder="Japanese" onChange={(e) => setDraft({ ...draft, language: e.target.value })} /></label>
              <div className="row" style={{ alignItems: 'center' }}>
                {currentPoster && <img src={currentPoster} alt="" className="mini-poster" />}
                <label className="btn small">
                  Upload custom poster…
                  <input
                    type="file" accept="image/*" hidden
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) void uploadPoster(title.id, f).then(onClose);
                      e.target.value = '';
                    }}
                  />
                </label>
              </div>
              <p className="dim small">Manual edits always win — fetching online metadata later will never overwrite them.</p>
              <div className="row">
                <button className="btn primary" onClick={() => void save()}>Save</button>
                <button className="btn" onClick={onClose}>Cancel</button>
              </div>
            </>
          )}
          {tab === 'identify' && (
            <>
              <p className="dim small">
                Look up posters, synopsis, ratings, episode names and reviews from AniList, TVmaze and MyAnimeList.
                Internet is needed only for this lookup — everything is cached on your device afterwards.
              </p>
              {title.fetched && (
                <p className="small">
                  Currently matched: <strong>{title.fetched.providerId}</strong> via {title.fetched.provider === 'anilist' ? 'AniList' : title.fetched.provider === 'tvmaze' ? 'TVmaze' : 'MyAnimeList'}
                  {' '}<button className="btn small" onClick={() => void clearMeta(title.id)}>Clear online data</button>
                </p>
              )}
              <button className="btn" onClick={() => void runSearch()} disabled={searching}>
                {searching ? 'Searching…' : `Search for “${title.custom.name ?? title.name}”`}
              </button>
              {error && <p className="error">{error}</p>}
              {candidates && candidates.length === 0 && <p className="dim">No matches. Try editing the name first.</p>}
              {candidates?.map((c, i) => (
                <button key={`${c.provider}-${c.providerId}-${i}`} className="sheet-row" disabled={applying} onClick={() => void apply(c)}>
                  <span className="grow">
                    <strong>{c.title}</strong>
                    <small className="dim"> · {c.year ?? '—'}{c.score !== undefined && c.score !== null ? ` · ★ ${Number(c.score).toFixed(1)}` : ''} · {c.provider === 'anilist' ? 'AniList' : c.provider === 'tvmaze' ? 'TVmaze' : 'MyAnimeList'}</small>
                  </span>
                  <span>Use ›</span>
                </button>
              ))}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
