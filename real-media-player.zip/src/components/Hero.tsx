// Home hero: rotating MUTED 12-second preview clips from random local
// episodes. No online trailers, ever. Preview start points are deterministic
// per file and stored in the DB for consistency; rotation crossfades.

import { useCallback, useEffect, useRef, useState } from 'react';
import { HERO_ROTATE_MS, MAX_HERO_CANDIDATES, PREVIEW_LENGTH_MS } from '../config';
import { db } from '../db/database';
import { useLibrary } from '../library/store';
import { useArtworkUrl } from '../media/artwork';
import { resolvePlayableUrl } from '../media/playable';
import { hash01, selectPreviewClip, storedClipValid } from '../previews/clips';
import { resolveMeta } from '../types';

interface HeroCandidate {
  episodeId?: string;
  fileId: string;
  titleId: string;
  titleName: string;
  label: string;
  posterArtworkId?: string;
}

export function Hero({ onOpen }: { onOpen: (titleId: string) => void }): React.JSX.Element {
  const { openPlayer } = useLibrary();
  const [candidates, setCandidates] = useState<HeroCandidate[]>([]);
  const [slot, setSlot] = useState(0); // which candidate is showing
  const [phase, setPhase] = useState<'a' | 'b'>('a');
  const [srcA, setSrcA] = useState<string | null>(null);
  const [srcB, setSrcB] = useState<string | null>(null);
  const [paused, setPaused] = useState(false);
  const [muted] = useState(true);
  const videoA = useRef<HTMLVideoElement>(null);
  const videoB = useRef<HTMLVideoElement>(null);
  const reducedMotion = useRef(
    typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches,
  );

  // Pick random playable candidates (episodes preferred, else movies).
  useEffect(() => {
    let live = true;
    (async () => {
      const files = await db.files.where('kind').equals('video').filter((f) => !f.missing).toArray();
      if (!live || !files.length) return;
      // deterministic shuffle per day so the hero varies but stays stable in-session
      const daySeed = new Date().toDateString();
      const scored = files.map((f) => ({ f, s: hash01(`hero:${daySeed}:${f.id}`) }));
      scored.sort((a, b) => b.s - a.s);
      const picks = scored.slice(0, MAX_HERO_CANDIDATES);
      const out: HeroCandidate[] = [];
      for (const { f } of picks) {
        const title = f.titleId ? await db.titles.get(f.titleId) : undefined;
        if (!title) continue;
        const meta = resolveMeta(title);
        const ep = f.episodeId ? await db.episodes.get(f.episodeId) : undefined;
        out.push({
          episodeId: ep?.id,
          fileId: f.id,
          titleId: title.id,
          titleName: meta.name,
          label: ep ? `S${ep.season} E${ep.episode}${ep.name ? ` · ${ep.name}` : ''}` : (meta.year ? `${meta.year}` : ''),
          posterArtworkId: meta.backdropArtworkId ?? meta.posterArtworkId,
        });
      }
      if (live) setCandidates(out);
    })();
    return () => { live = false; };
  }, []);

  const current = candidates.length ? candidates[slot % candidates.length] : undefined;
  const posterUrl = useArtworkUrl(current?.posterArtworkId);

  const loadClip = useCallback(async (cand: HeroCandidate, which: 'a' | 'b') => {
    const setSrc = which === 'a' ? setSrcA : setSrcB;
    const video = which === 'a' ? videoA : videoB;
    const file = await db.files.get(cand.fileId);
    if (!file) return;
    const url = await resolvePlayableUrl(file);
    if (!url) return;
    setSrc(url);
    // Start the clip once metadata is known; compute/store the timestamp then.
    const el = video.current;
    if (!el) return;
    const onMeta = async () => {
      el.removeEventListener('loadedmetadata', onMeta);
      const durationMs = Math.floor((el.duration || 0) * 1000);
      let startMs: number | undefined;
      let lengthMs: number | undefined;
      if (cand.episodeId) {
        const ep = await db.episodes.get(cand.episodeId);
        if (ep && storedClipValid(ep.previewStartMs, ep.previewLengthMs)) {
          startMs = ep.previewStartMs;
          lengthMs = ep.previewLengthMs;
        }
      }
      if (startMs === undefined) {
        const clip = selectPreviewClip(durationMs, file.id, { desiredLengthMs: PREVIEW_LENGTH_MS });
        startMs = clip.startMs;
        lengthMs = clip.lengthMs;
        if (cand.episodeId && lengthMs > 0) {
          await db.episodes.update(cand.episodeId, { previewStartMs: startMs, previewLengthMs: lengthMs });
        } else if (lengthMs > 0) {
          await db.files.update(cand.fileId, { durationMs: durationMs || file.durationMs });
        }
      }
      try {
        el.currentTime = Math.min(startMs / 1000, Math.max(0, (el.duration || 1) - 1));
      } catch { /* ignore */ }
      const stopAt = (startMs + (lengthMs ?? PREVIEW_LENGTH_MS)) / 1000;
      const onTick = () => {
        if (el.currentTime >= stopAt) {
          try { el.currentTime = startMs / 1000; } catch { /* ignore */ }
        }
      };
      el.addEventListener('timeupdate', onTick);
    };
    el.addEventListener('loadedmetadata', onMeta);
  }, []);

  // Initial load + rotation with crossfade
  useEffect(() => {
    if (!current || reducedMotion.current || paused) return;
    void loadClip(current, phase);
    const el = phase === 'a' ? videoA.current : videoB.current;
    el?.play().catch(() => undefined);
    const timer = setTimeout(() => {
      setPhase((p) => (p === 'a' ? 'b' : 'a'));
      setSlot((s) => s + 1);
    }, HERO_ROTATE_MS);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slot, paused, candidates.length]);

  // Pause previews when the tab is hidden
  useEffect(() => {
    const onVis = () => {
      videoA.current?.pause();
      videoB.current?.pause();
      if (!document.hidden && !paused && !reducedMotion.current) {
        (phase === 'a' ? videoA.current : videoB.current)?.play().catch(() => undefined);
      }
    };
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, [paused, phase]);

  if (!current) return <div className="hero hero-empty" aria-hidden="true" />;

  return (
    <section className="hero" aria-label="Featured">
      <div className="hero-videos">
        {posterUrl && <img className="hero-poster" src={posterUrl} alt="" aria-hidden="true" />}
        <video
          ref={videoA}
          className={`hero-video ${phase === 'a' ? 'on' : ''}`}
          src={srcA ?? undefined}
          muted={muted}
          playsInline
          preload="auto"
          disablePictureInPicture
          aria-hidden="true"
        />
        <video
          ref={videoB}
          className={`hero-video ${phase === 'b' ? 'on' : ''}`}
          src={srcB ?? undefined}
          muted={muted}
          playsInline
          preload="auto"
          disablePictureInPicture
          aria-hidden="true"
        />
        <div className="hero-gradient" aria-hidden="true" />
      </div>
      <div className="hero-content">
        <p className="hero-kicker">Featured from your library</p>
        <h1>{current.titleName}</h1>
        {current.label && <p className="dim">{current.label}</p>}
        <div className="row">
          <button
            className="btn primary"
            onClick={() => {
              const cand = current;
              void (async () => {
                const file = await db.files.get(cand.fileId);
                if (!file) return;
                const title = await db.titles.get(cand.titleId);
                openPlayer(
                  [{ fileId: file.id, episodeId: cand.episodeId, titleId: cand.titleId, label: title?.name ?? cand.titleName, sublabel: cand.label }],
                  0,
                );
              })();
            }}
          >
            ▶ Play
          </button>
          <button className="btn" onClick={() => onOpen(current.titleId)}>Details</button>
          <button
            className="icon-btn"
            onClick={() => setPaused((p) => !p)}
            aria-label={paused ? 'Resume previews' : 'Pause previews'}
            aria-pressed={paused}
          >
            {paused ? '▶' : '⏸'}
          </button>
        </div>
      </div>
    </section>
  );
}
