import React from 'react';

interface Props {
  children: React.ReactNode;
}

interface State {
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error): void {
    // No telemetry — just a console error for local debugging.
    console.error('My Media crashed:', error);
  }

  render(): React.ReactNode {
    if (this.state.error) {
      return (
        <div className="setup">
          <div className="setup-card">
            <h1>Something went wrong</h1>
            <p className="dim">The app hit an unexpected error. Your library data is stored on this device and is safe.</p>
            <p className="small dim">{this.state.error.message}</p>
            <button className="btn primary" onClick={() => window.location.reload()}>Reload the app</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
