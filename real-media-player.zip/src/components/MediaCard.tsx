// Poster card. Clean streaming-service look: artwork, title, year/rating —
// never filenames, codec or quality badges.

import { useArtworkUrl } from '../media/artwork';
import { resolveMeta, type TitleRecord } from '../types';

interface Props {
  title: TitleRecord;
  onOpen: (id: string) => void;
  progress?: number; // 0..1 continue-watching progress
}

export function MediaCard({ title, onOpen, progress }: Props): React.JSX.Element {
  const meta = resolveMeta(title);
  const poster = useArtworkUrl(meta.posterArtworkId);
  const yearLabel = meta.year ? (meta.yearEnd && meta.yearEnd !== meta.year ? `${meta.year}–${meta.yearEnd}` : `${meta.year}`) : '';

  return (
    <button className="card" onClick={() => onOpen(title.id)} aria-label={meta.name}>
      <div className="card-art">
        {poster ? (
          <img src={poster} alt="" loading="lazy" draggable={false} />
        ) : (
          <div className="card-fallback" aria-hidden="true">
            <span>{meta.name.slice(0, 2).toUpperCase()}</span>
          </div>
        )}
        {title.watched && <span className="card-badge">Watched</span>}
        {progress !== undefined && progress > 0 && (
          <div className="card-progress"><div style={{ width: `${Math.round(progress * 100)}%` }} /></div>
        )}
      </div>
      <div className="card-meta">
        <strong>{meta.name}</strong>
        <span className="dim">
          {yearLabel}
          {yearLabel && meta.rating !== undefined ? ' · ' : ''}
          {meta.rating !== undefined ? `★ ${meta.rating.toFixed(1)}` : ''}
        </span>
      </div>
    </button>
  );
}

export function SkeletonCard(): React.JSX.Element {
  return (
    <div className="card" aria-hidden="true">
      <div className="card-art skeleton" />
      <div className="card-meta"><div className="skeleton-line" /><div className="skeleton-line short" /></div>
    </div>
  );
}
