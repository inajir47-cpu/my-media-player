// Title detail: backdrop, poster, actions, synopsis, season/episode grids,
// unified watch order (episodes + related movies/OVAs/specials — no
// separate "Release order" label), where-to-watch popup, and the Reviews
// section always LAST.

import { useEffect, useMemo, useRef, useState } from 'react';
import { useArtworkUrl } from '../media/artwork';
import { ensureEpisodeThumbnail } from '../media/thumbnails';
import { db } from '../db/database';
import {
  useEpisodes,
  useLibrary,
  useTitle,
  useTitleFiles,
  type PlayerQueueItem,
} from '../library/store';
import { providerLabel, resolveMeta, type EpisodeRecord } from '../types';
import { EditMetadataSheet } from './EditMetadata';
import { fmtTime } from '../player/Player';

interface Props {
  titleId: string;
  onBack: () => void;
}

function useInView<T extends HTMLElement>(): [React.RefObject<T>, boolean] {
  const ref = useRef<T>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => { if (entries[0].isIntersecting) { setInView(true); obs.disconnect(); } },
      { rootMargin: '200px' },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return [ref, inView];
}

function EpisodeRow({ ep, onPlay }: {
  ep: EpisodeRecord;
  onPlay: (episodeId: string) => void;
}): React.JSX.Element {
  const { markEpisodeWatched } = useLibrary();
  const [ref, inView] = useInView<HTMLDivElement>();
  const [artId, setArtId] = useState<string | undefined>(ep.artworkId);
  const thumb = useArtworkUrl(artId);
  const [renaming, setRenaming] = useState(false);
  const [nameDraft, setNameDraft] = useState(ep.customName ?? ep.name ?? '');
  const [showActions, setShowActions] = useState(false);

  useEffect(() => {
    if (inView && !artId) {
      void ensureEpisodeThumbnail(ep.id).then((id) => { if (id) setArtId(id); });
    }
  }, [inView, artId, ep.id]);

  const progress = ep.durationMs && ep.durationMs > 0 ? Math.min(1, ep.positionMs / ep.durationMs) : 0;
  const displayName = ep.customName ?? ep.name;

  const saveName = async () => {
    await db.episodes.update(ep.id, { customName: nameDraft.trim() || undefined });
    setRenaming(false);
  };

  return (
    <div ref={ref} className={`ep-row ${ep.watched ? 'watched' : ''}`}>
      <button className="ep-thumb" onClick={() => onPlay(ep.id)} aria-label={`Play episode ${ep.episode}${displayName ? `: ${displayName}` : ''}`}>
        {thumb ? <img src={thumb} alt="" loading="lazy" /> : <span className="ep-num">E{ep.episode}</span>}
        <span className="ep-play">▶</span>
        {progress > 0 && !ep.watched && (
          <div className="card-progress"><div style={{ width: `${Math.round(progress * 100)}%` }} /></div>
        )}
      </button>
      <div className="ep-info">
        <div className="ep-head">
          <strong>E{ep.episode}{ep.episodeEnd ? `–${ep.episodeEnd}` : ''}</strong>
          {renaming ? (
            <span className="row">
              <input value={nameDraft} onChange={(e) => setNameDraft(e.target.value)} aria-label="Episode name" />
              <button className="btn small primary" onClick={() => void saveName()}>Save</button>
              <button className="btn small" onClick={() => setRenaming(false)}>Cancel</button>
            </span>
          ) : (
            displayName && <span className="ep-name">{displayName}</span>
          )}
          {ep.watched && <span className="card-badge">Watched</span>}
        </div>
        <div className="dim small">
          {ep.durationMs ? fmtTime(ep.durationMs / 1000) : ''}
          {ep.synopsis ? ` · ${ep.synopsis.slice(0, 120)}${ep.synopsis.length > 120 ? '…' : ''}` : ''}
        </div>
      </div>
      <button className="icon-btn" aria-label="Episode actions" onClick={() => setShowActions((s) => !s)}>⋯</button>
      {showActions && (
        <div className="ep-actions">
          <button onClick={() => { void markEpisodeWatched(ep.id, !ep.watched); setShowActions(false); }}>
            {ep.watched ? 'Mark unwatched' : 'Mark watched'}
          </button>
          <button onClick={() => { setRenaming(true); setNameDraft(ep.customName ?? ep.name ?? ''); setShowActions(false); }}>
            Rename episode
          </button>
          <button onClick={() => { onPlay(ep.id); setShowActions(false); }}>Play now</button>
        </div>
      )}
    </div>
  );
}

export function TitleDetail({ titleId, onBack }: Props): React.JSX.Element {
  const title = useTitle(titleId);
  const episodes = useEpisodes(titleId);
  const files = useTitleFiles(titleId);
  const {
    toggleFavorite, toggleSaved, markTitleWatched, openPlayer,
    markEpisodeWatched, collections, toggleInCollection, createCollection,
    addReview, updateReview, deleteReview, setWhereToWatch,
  } = useLibrary();

  const seasons = useMemo(
    () => (episodes ? [...new Set(episodes.map((e) => e.season))].sort((a, b) => a - b) : []),
    [episodes],
  );
  const [season, setSeason] = useState<number>(1);
  const [seasonInit, setSeasonInit] = useState(false);
  useEffect(() => {
    if (!seasonInit && seasons.length) {
      setSeason(seasons[0]);
      setSeasonInit(true);
    }
  }, [seasons, seasonInit]);
  const [editing, setEditing] = useState(false);
  const [watchPopup, setWatchPopup] = useState<null | { heading: string }>(null);
  const [reviewDraft, setReviewDraft] = useState({ stars: 5, title: '', body: '', spoiler: false });
  const [editingReview, setEditingReview] = useState<string | null>(null);
  const [showSpoiler, setShowSpoiler] = useState<Set<string>>(new Set());
  const [linkDraft, setLinkDraft] = useState({ name: '', url: '' });

  const meta = title ? resolveMeta(title) : null;
  const poster = useArtworkUrl(meta?.posterArtworkId);
  const backdrop = useArtworkUrl(meta?.backdropArtworkId);

  if (title === undefined || episodes === undefined || files === undefined) {
    return <div className="detail"><div className="skeleton hero-skel" /></div>;
  }
  if (title === null) {
    return <div className="detail"><p>This title is gone.</p><button className="btn" onClick={onBack}>Back</button></div>;
  }

  const playableFiles = files.filter((f) => (f.kind === 'video' || f.kind === 'audio') && !f.missing);
  const seasonEps = episodes.filter((e) => e.season === season);
  const watchedCount = episodes.filter((e) => e.watched).length;

  const episodeQueue = (fromId?: string): PlayerQueueItem[] => {
    const sorted = [...episodes].sort((a, b) => a.season - b.season || a.episode - b.episode);
    const start = fromId ? sorted.findIndex((e) => e.id === fromId) : 0;
    return sorted.slice(Math.max(0, start)).map((e) => ({
      fileId: e.fileId,
      episodeId: e.id,
      titleId: title.id,
      label: `S${e.season} E${e.episode}${e.customName ?? e.name ? ` · ${e.customName ?? e.name}` : ''}`,
      sublabel: meta?.name,
    }));
  };

  const playEpisode = (episodeId: string) => openPlayer(episodeQueue(episodeId), 0);

  const playTitle = () => {
    if (title.kind === 'show') {
      const sorted = [...episodes].sort((a, b) => a.season - b.season || a.episode - b.episode);
      // Resume: first episode with progress; else first unwatched; else from start.
      const resume = sorted.find((e) => e.positionMs > 30_000 && !e.watched)
        ?? sorted.find((e) => !e.watched)
        ?? sorted[0];
      if (resume) playEpisode(resume.id);
    } else if (title.kind === 'movie') {
      const vids = playableFiles.filter((f) => f.kind === 'video');
      if (vids.length) {
        openPlayer(vids.map((f) => ({ fileId: f.id, titleId: title.id, label: meta?.name ?? title.name })), 0);
      }
    } else {
      const tracks = [...playableFiles].sort((a, b) => (a.trackNo ?? 999) - (b.trackNo ?? 999));
      if (tracks.length) {
        openPlayer(tracks.map((f) => ({
          fileId: f.id, titleId: title.id,
          label: f.trackName ?? f.name, sublabel: meta?.name ?? title.name,
        })), 0);
      }
    }
  };

  const yearLabel = meta?.year ? (meta.yearEnd && meta.yearEnd !== meta.year ? `${meta.year}–${meta.yearEnd}` : `${meta.year}`) : '';

  return (
    <div className="detail">
      <div className="detail-backdrop">
        {backdrop && <img src={backdrop} alt="" aria-hidden="true" />}
        <div className="hero-gradient" />
        <button className="icon-btn back" onClick={onBack} aria-label="Back">‹</button>
      </div>

      <div className="detail-head">
        <div className="detail-poster">{poster && <img src={poster} alt="" />}</div>
        <div className="detail-titles">
          <h1>{meta?.name}</h1>
          <p className="dim">
            {[yearLabel, title.kind === 'show' ? `${episodes.length} episodes` : title.kind, ...(meta?.genres ?? []).slice(0, 3)].filter(Boolean).join(' · ')}
          </p>
          {meta?.rating !== undefined && (
            <p className="rating">★ {meta.rating.toFixed(1)} <span className="dim small">({meta.ratingSource})</span></p>
          )}
        </div>
      </div>

      <div className="detail-actions">
        <button className="btn primary" onClick={playTitle} disabled={!playableFiles.length}>▶ Play</button>
        <button className="btn" onClick={() => void toggleFavorite(title.id)} aria-pressed={title.favorite}>
          {title.favorite ? '♥ Favorited' : '♡ Favorite'}
        </button>
        <button className="btn" onClick={() => void toggleSaved(title.id)} aria-pressed={title.saved}>
          {title.saved ? '★ Saved' : '☆ Save'}
        </button>
        <button className="btn" onClick={() => void markTitleWatched(title.id, !title.watched)}>
          {title.watched ? '✓ Watched' : 'Mark watched'}
        </button>
        <button className="btn" onClick={() => setEditing(true)}>Edit</button>
      </div>

      {playableFiles.length === 0 && (
        <div className="notice">
          <p>No playable files for this title right now — the files may have moved or folder access was revoked.</p>
          <button className="btn" onClick={() => setWatchPopup({ heading: meta?.name ?? title.name })}>Where to watch</button>
        </div>
      )}

      {meta?.synopsis && <p className="synopsis">{meta.synopsis}</p>}
      {meta?.genres && meta.genres.length > 0 && (
        <div className="chip-row">{meta.genres.map((g) => <span key={g} className="chip static">{g}</span>)}</div>
      )}

      {title.kind === 'show' && (
        <section aria-label="Seasons and episodes">
          <div className="section-head">
            <h2>Episodes</h2>
            <span className="dim small">{watchedCount}/{episodes.length} watched</span>
          </div>
          {seasons.length > 1 && (
            <div className="chip-row" role="tablist" aria-label="Seasons">
              {seasons.map((s) => {
                const yr = title.fetched?.year && s === 1 ? ` (${title.fetched.year})` : '';
                return (
                  <button key={s} role="tab" aria-selected={season === s} className={`chip ${season === s ? 'active' : ''}`} onClick={() => setSeason(s)}>
                    Season {s}{yr}
                  </button>
                );
              })}
            </div>
          )}
          <div className="ep-list">
            {seasonEps.map((ep) => (
              <EpisodeRow key={ep.id} ep={ep} onPlay={playEpisode} />
            ))}
          </div>
          <button className="btn small" onClick={() => {
            const eps = episodes.filter((e) => e.season === season);
            const allWatched = eps.every((e) => e.watched);
            void (async () => {
              for (const e of eps) await markEpisodeWatched(e.id, !allWatched);
            })();
          }}>
            {seasonEps.every((e) => e.watched) ? `Mark season ${season} unwatched` : `Mark season ${season} watched`}
          </button>
        </section>
      )}

      {title.kind === 'music' && (
        <section aria-label="Tracks">
          <h2>Tracks</h2>
          <div className="ep-list">
            {[...playableFiles].sort((a, b) => (a.trackNo ?? 999) - (b.trackNo ?? 999)).map((f, i) => (
              <button key={f.id} className="track-row" onClick={() => {
                const tracks = [...playableFiles].sort((a, b) => (a.trackNo ?? 999) - (b.trackNo ?? 999));
                openPlayer(tracks.map((t) => ({ fileId: t.id, titleId: title.id, label: t.trackName ?? t.name, sublabel: meta?.name })), i);
              }}>
                <span className="num">{f.trackNo ?? i + 1}</span>
                <span className="grow">{f.trackName ?? f.name}</span>
                {f.watched && <span className="card-badge">Played</span>}
              </button>
            ))}
          </div>
        </section>
      )}

      {/* Unified watch order: episodes already above; related films/OVAs/specials here. */}
      {title.fetched?.related && title.fetched.related.length > 0 && (
        <section aria-label="Watch order">
          <h2>Watch order</h2>
          <p className="dim small">Related movies, OVAs and specials for this series — in story order.</p>
          <div className="ep-list">
            {title.fetched.related.map((r, i) => (
              <button key={i} className="track-row" onClick={() => setWatchPopup({ heading: r.title })}>
                <span className={`kind-badge ${r.kind}`}>{r.kind === 'ova' ? 'OVA' : r.kind[0].toUpperCase() + r.kind.slice(1)}</span>
                <span className="grow">{r.title}{r.year ? <span className="dim"> · {r.year}</span> : null}</span>
                <span className="dim">›</span>
              </button>
            ))}
          </div>
        </section>
      )}

      {collections && collections.length > 0 && (
        <section aria-label="Collections">
          <h2>Collections</h2>
          <div className="chip-row">
            {collections.map((c) => (
              <button
                key={c.id}
                className={`chip ${c.titleIds.includes(title.id) ? 'active' : ''}`}
                onClick={() => void toggleInCollection(c.id, title.id)}
              >
                {c.titleIds.includes(title.id) ? '✓ ' : '+ '}{c.name}
              </button>
            ))}
            <button className="chip" onClick={() => {
              const name = window.prompt('New collection name:');
              if (name?.trim()) void createCollection(name.trim()).then((id) => toggleInCollection(id, title.id));
            }}>+ New</button>
          </div>
        </section>
      )}

      {/* Reviews — always the last section */}
      <section aria-label="Reviews" className="reviews">
        <h2>Reviews</h2>
        {title.reviews.length === 0 && <p className="dim">No reviews yet — write the first one.</p>}
        {title.reviews.map((r) => (
          <article key={r.id} className="review">
            <div className="review-head">
              <span className="stars">{'★'.repeat(Math.floor(r.stars))}{r.stars % 1 ? '½' : ''}</span>
              <strong>{r.title || 'Untitled'}</strong>
              <span className="dim small">{new Date(r.updatedAt).toLocaleDateString()}</span>
              {r.spoiler && <span className="card-badge">Spoiler</span>}
            </div>
            {r.spoiler && !showSpoiler.has(r.id) ? (
              <button className="btn small" onClick={() => setShowSpoiler((s) => new Set(s).add(r.id))}>Show spoiler</button>
            ) : (
              <p>{r.body}</p>
            )}
            <div className="row">
              <button className="btn small" onClick={() => { setEditingReview(r.id); setReviewDraft({ stars: r.stars, title: r.title, body: r.body, spoiler: r.spoiler }); }}>Edit</button>
              <button className="btn small" onClick={() => void deleteReview(title.id, r.id)}>Delete</button>
            </div>
            {editingReview === r.id && (
              <ReviewForm
                draft={reviewDraft}
                setDraft={setReviewDraft}
                onCancel={() => setEditingReview(null)}
                onSave={() => { void updateReview(title.id, { ...r, ...reviewDraft }); setEditingReview(null); }}
                saveLabel="Save review"
              />
            )}
          </article>
        ))}

        {title.fetched?.publicReviews && title.fetched.publicReviews.length > 0 && (
          <div className="public-reviews">
            <h3>What others say</h3>
            {title.fetched.publicReviews.map((pr, i) => (
              <article key={i} className="review public">
                <div className="review-head">
                  <strong>{pr.author}</strong>
                  <span className="dim small">via {providerLabel(pr.source)}</span>
                  {pr.rating !== undefined && <span className="stars">★ {pr.rating.toFixed(1)}</span>}
                </div>
                <p>{pr.summary}</p>
              </article>
            ))}
          </div>
        )}

        <h3>Write a review</h3>
        <ReviewForm
          draft={reviewDraft}
          setDraft={setReviewDraft}
          onCancel={() => setReviewDraft({ stars: 5, title: '', body: '', spoiler: false })}
          onSave={() => {
            void addReview(title.id, reviewDraft);
            setReviewDraft({ stars: 5, title: '', body: '', spoiler: false });
          }}
          saveLabel="Add review"
        />
      </section>

      {editing && <EditMetadataSheet title={title} onClose={() => setEditing(false)} />}

      {watchPopup && (
        <div className="sheet-backdrop" onClick={() => setWatchPopup(null)}>
          <div className="sheet" role="dialog" aria-label="Where to watch" onClick={(e) => e.stopPropagation()}>
            <div className="sheet-head">
              <strong>Where to watch</strong>
              <button className="icon-btn" onClick={() => setWatchPopup(null)} aria-label="Close">✕</button>
            </div>
            <div className="sheet-body">
              <p className="dim">“{watchPopup.heading}” isn&apos;t in your local library. These are legal streaming options you saved:</p>
              {(meta?.whereToWatch ?? []).length === 0 && <p className="dim">No links saved yet — add some below.</p>}
              {(meta?.whereToWatch ?? []).map((l, i) => (
                <a key={i} className="sheet-row" href={l.url} target="_blank" rel="noreferrer">{l.name} ↗</a>
              ))}
              <h4>Add a streaming link</h4>
              <div className="row">
                <input placeholder="Service name" value={linkDraft.name} onChange={(e) => setLinkDraft({ ...linkDraft, name: e.target.value })} aria-label="Service name" />
                <input placeholder="https://…" value={linkDraft.url} onChange={(e) => setLinkDraft({ ...linkDraft, url: e.target.value })} aria-label="Link URL" />
                <button className="btn small primary" onClick={() => {
                  if (!linkDraft.name.trim() || !/^https?:\/\//i.test(linkDraft.url.trim())) return;
                  void setWhereToWatch(title.id, [...(meta?.whereToWatch ?? []), { name: linkDraft.name.trim(), url: linkDraft.url.trim() }]);
                  setLinkDraft({ name: '', url: '' });
                }}>Add</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ReviewForm({ draft, setDraft, onCancel, onSave, saveLabel }: {
  draft: { stars: number; title: string; body: string; spoiler: boolean };
  setDraft: (d: { stars: number; title: string; body: string; spoiler: boolean }) => void;
  onCancel: () => void;
  onSave: () => void;
  saveLabel: string;
}): React.JSX.Element {
  return (
    <div className="review-form">
      <label>
        Rating
        <select value={draft.stars} onChange={(e) => setDraft({ ...draft, stars: Number(e.target.value) })} aria-label="Star rating">
          {[0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5].map((s) => (
            <option key={s} value={s}>{s} stars</option>
          ))}
        </select>
      </label>
      <input placeholder="Review title" value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} aria-label="Review title" />
      <textarea placeholder="What did you think?" value={draft.body} onChange={(e) => setDraft({ ...draft, body: e.target.value })} rows={4} aria-label="Review body" />
      <label className="check"><input type="checkbox" checked={draft.spoiler} onChange={(e) => setDraft({ ...draft, spoiler: e.target.checked })} /> Contains spoilers</label>
      <div className="row">
        <button className="btn primary" onClick={onSave} disabled={!draft.body.trim()}>{saveLabel}</button>
        <button className="btn" onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}
