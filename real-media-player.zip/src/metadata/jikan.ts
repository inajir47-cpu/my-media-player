// Jikan (MyAnimeList) provider (no key). Rate limit: 3 req/s — we serialize
// all Jikan calls through a small throttle.

import type { FetchedMeta, PublicReview } from '../types';

const BASE = 'https://api.jikan.moe/v4';

let lastCall = 0;
async function throttle(): Promise<void> {
  const now = Date.now();
  const wait = 400 - (now - lastCall);
  if (wait > 0) await new Promise((r) => setTimeout(r, wait));
  lastCall = Date.now();
}

async function get<T>(path: string): Promise<T> {
  await throttle();
  const res = await fetch(`${BASE}${path}`, { headers: { Accept: 'application/json' } });
  if (res.status === 429) {
    await new Promise((r) => setTimeout(r, 1500));
    return get<T>(path);
  }
  if (!res.ok) throw new Error(`Jikan ${res.status}`);
  return (await res.json()) as T;
}

interface JikanImages { jpg?: { image_url?: string; large_image_url?: string } }
interface JikanAnime {
  mal_id: number;
  title?: string;
  title_english?: string;
  synopsis?: string;
  score?: number | null;
  scored_by?: number | null;
  genres?: Array<{ name?: string }>;
  images?: JikanImages;
  year?: number | null;
  url?: string;
}
interface JikanEpisode { mal_id: number; title?: string; synopsis?: string }
interface JikanReview { user?: { username?: string }; score?: number | null; review?: string; url?: string }

export interface JikanCandidate {
  id: number;
  title: string;
  year?: number | null;
  score?: number | null;
  posterUrl?: string;
}

export async function jikanSearch(query: string): Promise<JikanCandidate[]> {
  const data = await get<{ data: JikanAnime[] }>(`/anime?q=${encodeURIComponent(query)}&limit=6&order_by=members&sort=desc`);
  return data.data.map((a) => ({
    id: a.mal_id,
    title: a.title_english ?? a.title ?? 'Unknown',
    year: a.year,
    score: a.score,
    posterUrl: a.images?.jpg?.large_image_url ?? a.images?.jpg?.image_url,
  }));
}

export async function jikanDetails(id: number): Promise<Omit<FetchedMeta, 'posterArtworkId' | 'backdropArtworkId' | 'fetchedAt'>> {
  const [{ data: a }, episodes, reviews] = await Promise.all([
    get<{ data: JikanAnime }>(`/anime/${id}/full`),
    get<{ data: JikanEpisode[] }>(`/anime/${id}/episodes`),
    get<{ data: JikanReview[] }>(`/anime/${id}/reviews?sort=helpful`),
  ]);
  const episodeNames: Record<string, string> = {};
  const episodeSynopsis: Record<string, string> = {};
  for (const ep of episodes.data) {
    const key = `s1e${ep.mal_id}`;
    if (ep.title && ep.title !== `Episode ${ep.mal_id}`) episodeNames[key] = ep.title;
    if (ep.synopsis) episodeSynopsis[key] = ep.synopsis;
  }
  const publicReviews: PublicReview[] = reviews.data
    .filter((r) => r.review)
    .slice(0, 5)
    .map((r) => ({
      source: 'jikan' as const,
      author: r.user?.username ?? 'MAL user',
      rating: r.score ?? undefined,
      summary: String(r.review).slice(0, 1200),
      url: r.url,
    }));
  return {
    provider: 'jikan',
    providerId: a.mal_id,
    providerUrl: a.url,
    synopsis: a.synopsis,
    genres: a.genres?.map((g) => g.name).filter((n): n is string => !!n),
    rating: a.score ?? undefined,
    ratingCount: a.scored_by ?? undefined,
    posterRemoteUrl: a.images?.jpg?.large_image_url ?? a.images?.jpg?.image_url,
    year: a.year ?? undefined,
    episodeNames: Object.keys(episodeNames).length ? episodeNames : undefined,
    episodeSynopsis: Object.keys(episodeSynopsis).length ? episodeSynopsis : undefined,
    publicReviews: publicReviews.length ? publicReviews : undefined,
  };
}
