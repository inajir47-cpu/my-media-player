// AniList GraphQL provider (no key). Search + full details: titles, cover,
// banner, description, score, genres, year, episode list, relations
// (movies / OVAs / specials), and reviews.

import type { FetchedMeta, PublicReview, RelatedEntry } from '../types';

const ENDPOINT = 'https://graphql.anilist.co';

async function gql<T>(query: string, variables: Record<string, unknown>): Promise<T> {
  const res = await fetch(ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ query, variables }),
  });
  if (!res.ok) throw new Error(`AniList ${res.status}`);
  const json = (await res.json()) as { data?: T; errors?: Array<{ message: string }> };
  if (json.errors?.length) throw new Error(`AniList: ${json.errors[0].message}`);
  if (!json.data) throw new Error('AniList: empty response');
  return json.data;
}

const SEARCH = `
  query ($q: String, $type: MediaType) {
    Page(page: 1, perPage: 6) {
      media(search: $q, type: $type, sort: SEARCH_MATCH) {
        id title { romaji english native }
        coverImage { large } bannerImage
        description averageScore genres
        seasonYear startDate { year } endDate { year }
        episodes format siteUrl
      }
    }
  }`;

const DETAILS = `
  query ($id: Int) {
    media(id: $id) {
      id title { romaji english native }
      coverImage { large extraLarge } bannerImage
      description averageScore meanScore genres
      seasonYear startDate { year } endDate { year }
      episodes duration format siteUrl
      streamingEpisodes { title thumbnail url site }
      relations { edges { relationType(version: 2) node { id title { romaji english } format startDate { year } } } }
      reviews(page: 1, perPage: 5, sort: RATING_DESC) {
        nodes { summary rating user { name } siteUrl }
      }
    }
  }`;

interface SearchMedia {
  id: number;
  title: { romaji?: string; english?: string; native?: string };
  coverImage?: { large?: string };
  bannerImage?: string;
  description?: string;
  averageScore?: number;
  genres?: string[];
  seasonYear?: number;
  startDate?: { year?: number };
  endDate?: { year?: number };
  episodes?: number;
  format?: string;
  siteUrl?: string;
}

function bestTitle(t: SearchMedia['title']): string {
  return t.english ?? t.romaji ?? t.native ?? 'Unknown';
}

function stripHtml(html?: string): string | undefined {
  if (!html) return undefined;
  return html.replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]*>/g, '').trim() || undefined;
}

function relationKind(format?: string): RelatedEntry['kind'] {
  switch (format) {
    case 'MOVIE': return 'movie';
    case 'OVA': return 'ova';
    case 'SPECIAL': return 'special';
    case 'ONA': return 'special';
    case 'MUSIC': return 'music';
    default: return 'series';
  }
}

export interface AniListCandidate {
  id: number;
  title: string;
  year?: number;
  score?: number; // 0-10
  posterUrl?: string;
  format?: string;
}

export async function anilistSearch(query: string): Promise<AniListCandidate[]> {
  const data = await gql<{ Page: { media: SearchMedia[] } }>(SEARCH, { q: query, type: 'ANIME' });
  return data.Page.media.map((m) => ({
    id: m.id,
    title: bestTitle(m.title),
    year: m.seasonYear ?? m.startDate?.year,
    score: m.averageScore ? m.averageScore / 10 : undefined,
    posterUrl: m.coverImage?.large,
    format: m.format,
  }));
}

interface DetailsMedia extends SearchMedia {
  coverImage?: { large?: string; extraLarge?: string };
  streamingEpisodes?: Array<{ title?: string; thumbnail?: string; url?: string; site?: string }>;
  relations?: { edges: Array<{ relationType?: string; node: { id: number; title: { romaji?: string; english?: string }; format?: string; startDate?: { year?: number } } }> };
  reviews?: { nodes: Array<{ summary?: string; rating?: number; user?: { name?: string }; siteUrl?: string }> };
}

export async function anilistDetails(id: number): Promise<Omit<FetchedMeta, 'posterArtworkId' | 'backdropArtworkId' | 'fetchedAt'>> {
  const data = await gql<{ media: DetailsMedia }>(DETAILS, { id });
  const m = data.media;
  const episodeNames: Record<string, string> = {};
  for (const ep of m.streamingEpisodes ?? []) {
    const n = ep.title?.match(/ep(?:isode)?\s*(\d+)/i);
    if (n && ep.title) episodeNames[`s1e${parseInt(n[1], 10)}`] = ep.title;
  }
  const related: RelatedEntry[] = [];
  for (const edge of m.relations?.edges ?? []) {
    const node = edge.node;
    const kind = relationKind(node.format);
    if (kind === 'series') continue; // keep the related list to movies/OVAs/specials
    related.push({
      kind,
      title: node.title.english ?? node.title.romaji ?? 'Unknown',
      year: node.startDate?.year,
      note: edge.relationType,
    });
  }
  const publicReviews: PublicReview[] = (m.reviews?.nodes ?? [])
    .filter((r) => r.summary)
    .map((r) => ({
      source: 'anilist' as const,
      author: r.user?.name ?? 'AniList user',
      rating: r.rating ? r.rating / 10 : undefined,
      summary: String(r.summary),
      url: r.siteUrl,
    }));
  return {
    provider: 'anilist',
    providerId: m.id,
    providerUrl: m.siteUrl,
    synopsis: stripHtml(m.description),
    genres: m.genres,
    rating: m.averageScore ? m.averageScore / 10 : undefined,
    posterRemoteUrl: m.coverImage?.extraLarge ?? m.coverImage?.large,
    backdropRemoteUrl: m.bannerImage ?? undefined,
    year: m.seasonYear ?? m.startDate?.year,
    yearEnd: m.endDate?.year,
    episodeNames: Object.keys(episodeNames).length ? episodeNames : undefined,
    related: related.length ? related : undefined,
    publicReviews: publicReviews.length ? publicReviews : undefined,
  };
}
