// TVmaze provider (no key). Best for live-action series/movies.

import type { FetchedMeta } from '../types';

const BASE = 'https://api.tvmaze.com';

interface TvMazeImage { medium?: string; original?: string }
interface TvMazeRating { average?: number | null }
interface TvMazeShow {
  id: number;
  name: string;
  genres?: string[];
  premiered?: string;
  ended?: string;
  summary?: string;
  rating?: TvMazeRating;
  image?: TvMazeImage | null;
  url?: string;
  _embedded?: { episodes?: TvMazeEpisode[] };
}
interface TvMazeEpisode {
  id: number;
  name?: string;
  season?: number;
  number?: number;
  summary?: string;
  image?: TvMazeImage | null;
}

async function get<T>(path: string): Promise<T> {
  const res = await fetch(`${BASE}${path}`, { headers: { Accept: 'application/json' } });
  if (!res.ok) throw new Error(`TVmaze ${res.status}`);
  return (await res.json()) as T;
}

function stripHtml(html?: string): string | undefined {
  if (!html) return undefined;
  return html.replace(/<[^>]*>/g, '').trim() || undefined;
}

function yearOf(date?: string): number | undefined {
  const m = date?.match(/^(\d{4})/);
  return m ? parseInt(m[1], 10) : undefined;
}

export interface TvMazeCandidate {
  id: number;
  title: string;
  year?: number;
  score?: number;
  posterUrl?: string;
}

export async function tvmazeSearch(query: string): Promise<TvMazeCandidate[]> {
  const results = await get<Array<{ show: TvMazeShow }>>(`/search/shows?q=${encodeURIComponent(query)}`);
  return results.slice(0, 6).map(({ show }) => ({
    id: show.id,
    title: show.name,
    year: yearOf(show.premiered),
    score: show.rating?.average ?? undefined,
    posterUrl: show.image?.medium ?? show.image?.original,
  }));
}

export async function tvmazeDetails(id: number): Promise<Omit<FetchedMeta, 'posterArtworkId' | 'backdropArtworkId' | 'fetchedAt'>> {
  const show = await get<TvMazeShow>(`/shows/${id}?embed[]=episodes&embed[]=seasons`);
  const episodeNames: Record<string, string> = {};
  const episodeSynopsis: Record<string, string> = {};
  for (const ep of show._embedded?.episodes ?? []) {
    if (ep.season !== undefined && ep.number !== undefined && ep.number !== null) {
      const key = `s${ep.season}e${ep.number}`;
      if (ep.name) episodeNames[key] = ep.name;
      const syn = stripHtml(ep.summary);
      if (syn) episodeSynopsis[key] = syn;
    }
  }
  return {
    provider: 'tvmaze',
    providerId: show.id,
    providerUrl: show.url,
    synopsis: stripHtml(show.summary),
    genres: show.genres,
    rating: show.rating?.average ?? undefined,
    posterRemoteUrl: show.image?.original ?? show.image?.medium,
    year: yearOf(show.premiered),
    yearEnd: yearOf(show.ended),
    episodeNames: Object.keys(episodeNames).length ? episodeNames : undefined,
    episodeSynopsis: Object.keys(episodeSynopsis).length ? episodeSynopsis : undefined,
  };
}
