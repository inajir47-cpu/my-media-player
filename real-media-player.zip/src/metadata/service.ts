// Metadata service: identify a title, fetch from AniList / TVmaze / Jikan,
// cache everything on device (IndexedDB, incl. artwork blobs), and NEVER
// overwrite the user's manual overrides — fetched data lives in
// `fetched`, user edits live in `custom` (see types.resolveMeta).

import { db } from '../db/database';
import type { EpisodeRecord, FetchedMeta, TitleKind } from '../types';
import { episodeKey, newId } from '../types';
import { anilistDetails, anilistSearch, type AniListCandidate } from './anilist';
import { jikanDetails, jikanSearch, type JikanCandidate } from './jikan';
import { tvmazeDetails, tvmazeSearch, type TvMazeCandidate } from './tvmaze';

export interface MetaCandidate {
  provider: 'anilist' | 'tvmaze' | 'jikan';
  providerId: string | number;
  title: string;
  year?: number | null;
  score?: number | null;
  posterUrl?: string;
}

/** Identify candidates for a title. Anime kinds query AniList+Jikan, others TVmaze. */
export async function searchMetadata(name: string, kind: TitleKind, year?: number): Promise<MetaCandidate[]> {
  const q = year ? `${name} ${year}` : name;
  const out: MetaCandidate[] = [];
  const push = (list: Array<AniListCandidate | TvMazeCandidate | JikanCandidate>, provider: MetaCandidate['provider']) => {
    for (const c of list) out.push({ provider, providerId: c.id, title: c.title, year: c.year, score: c.score, posterUrl: c.posterUrl });
  };
  if (kind === 'show') {
    const [a, t] = await Promise.allSettled([anilistSearch(q), tvmazeSearch(q)]);
    if (a.status === 'fulfilled') push(a.value, 'anilist');
    if (t.status === 'fulfilled') push(t.value, 'tvmaze');
  } else if (kind === 'movie') {
    const [t, a] = await Promise.allSettled([tvmazeSearch(q), anilistSearch(q)]);
    if (t.status === 'fulfilled') push(t.value, 'tvmaze');
    if (a.status === 'fulfilled') push(a.value, 'anilist');
  } else {
    const [a, j] = await Promise.allSettled([anilistSearch(q), jikanSearch(q)]);
    if (a.status === 'fulfilled') push(a.value, 'anilist');
    if (j.status === 'fulfilled') push(j.value, 'jikan');
  }
  return out.slice(0, 10);
}

async function downloadArtwork(url: string | undefined, kind: 'poster' | 'backdrop'): Promise<string | undefined> {
  if (!url) return undefined;
  try {
    const res = await fetch(url);
    if (!res.ok) return undefined;
    const blob = await res.blob();
    if (blob.size === 0 || blob.size > 8_000_000) return undefined;
    const id = newId('art');
    await db.artwork.put({ id, blob, kind, updatedAt: Date.now() });
    return id;
  } catch {
    return undefined;
  }
}

/**
 * Fetch full details for a chosen candidate and attach to the title.
 * Manual `custom` overrides are untouched; episode custom names win over
 * fetched episode names.
 */
export async function applyMetadata(titleId: string, candidate: MetaCandidate): Promise<void> {
  const title = await db.titles.get(titleId);
  if (!title) throw new Error('Title not found');

  let fetched: Omit<FetchedMeta, 'posterArtworkId' | 'backdropArtworkId' | 'fetchedAt'>;
  switch (candidate.provider) {
    case 'anilist': fetched = await anilistDetails(Number(candidate.providerId)); break;
    case 'tvmaze': fetched = await tvmazeDetails(Number(candidate.providerId)); break;
    case 'jikan': fetched = await jikanDetails(Number(candidate.providerId)); break;
  }

  const [posterArtworkId, backdropArtworkId] = await Promise.all([
    downloadArtwork(fetched.posterRemoteUrl, 'poster'),
    downloadArtwork(fetched.backdropRemoteUrl, 'backdrop'),
  ]);

  const full: FetchedMeta = { ...fetched, posterArtworkId, backdropArtworkId, fetchedAt: Date.now() };
  await db.titles.update(titleId, { fetched: full, updatedAt: Date.now() });

  // Sync episode names/synopses (only where the user hasn't set a custom name).
  if (title.kind === 'show' && (full.episodeNames || full.episodeSynopsis)) {
    const episodes = await db.episodes.where('titleId').equals(titleId).toArray();
    for (const ep of episodes) {
      const key = episodeKey(ep.season, ep.episode);
      const patch: Partial<EpisodeRecord> = {};
      if (!ep.customName && full.episodeNames?.[key]) patch.name = full.episodeNames[key];
      if (!ep.synopsis && full.episodeSynopsis?.[key]) patch.synopsis = full.episodeSynopsis[key];
      if (Object.keys(patch).length) await db.episodes.update(ep.id, patch);
    }
  }
}

/** Forget fetched metadata (custom overrides and artwork the user picked stay). */
export async function clearFetchedMetadata(titleId: string): Promise<void> {
  const title = await db.titles.get(titleId);
  const ids = [title?.fetched?.posterArtworkId, title?.fetched?.backdropArtworkId].filter(
    (x): x is string => !!x && x !== title?.custom.posterArtworkId && x !== title?.custom.backdropArtworkId,
  );
  await db.titles.update(titleId, { fetched: undefined, updatedAt: Date.now() });
  for (const id of ids) {
    const usedElsewhere = await db.titles.where('id').notEqual(titleId).toArray();
    if (!usedElsewhere.some((t) => t.fetched?.posterArtworkId === id || t.custom.posterArtworkId === id)) {
      await db.artwork.delete(id).catch(() => undefined);
    }
  }
}
