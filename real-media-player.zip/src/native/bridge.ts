// Native bridge. Mirrors the my-media MediaBridge conventions:
// - bridge name "MediaBridge", methods pickFolder / listFiles (+ helpers)
// - every picker/listing call races against a timeout so the UI can never
//   hang forever if the native side drops the result.
// On web/PWA the bridge is absent; folder access falls back to the
// File System Access API (see media/playable.ts).

import { Capacitor, registerPlugin } from '@capacitor/core';

export const isNative = Capacitor.isNativePlatform();
export const platformName: 'android' | 'web' = isNative ? 'android' : 'web';

export interface NativeFileEntry {
  uri: string;
  name: string;
  size: number;
  mtimeMs: number;
  relativePath: string;
}

interface MediaBridgePlugin {
  pickFolder(): Promise<{ treeUri: string; displayName: string }>;
  releaseFolder(options: { treeUri: string }): Promise<void>;
  hasPermission(options: { treeUri: string }): Promise<{ granted: boolean }>;
  /** Start the localhost media server; returns base URL like http://127.0.0.1:PORT */
  startMediaServer(): Promise<{ baseUrl: string }>;
  /** Map a content:// URI to a playable localhost URL served from this device. */
  playableUrl(options: { uri: string }): Promise<{ url: string }>;
  listFiles(options: { treeUri: string }): Promise<{ files: NativeFileEntry[] }>;
  setWindowBrightness(options: { value: number }): Promise<void>;
  getWindowBrightness(): Promise<{ value: number }>;
  setVolume(options: { value: number }): Promise<void>;
  getVolume(): Promise<{ value: number }>;
}

const MediaBridge = isNative ? registerPlugin<MediaBridgePlugin>('MediaBridge') : null;

/** Reject if a native bridge call never settles, so the UI can never hang forever. */
export function withNativeTimeout<T>(promise: Promise<T>, ms: number, message: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new Error(message)), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

export async function nativePickFolder(): Promise<{ treeUri: string; displayName: string } | null> {
  if (!MediaBridge) return null;
  return withNativeTimeout(
    MediaBridge.pickFolder(),
    120_000,
    'The folder picker did not respond. Please try again.',
  );
}

export async function nativeListFiles(treeUri: string): Promise<NativeFileEntry[]> {
  if (!MediaBridge) return [];
  return withNativeTimeout(
    MediaBridge.listFiles({ treeUri }).then((r) => r.files),
    180_000,
    'Listing that folder took too long. Try a smaller folder.',
  );
}

export async function nativeHasPermission(treeUri: string): Promise<boolean> {
  if (!MediaBridge) return false;
  try {
    return (await MediaBridge.hasPermission({ treeUri })).granted;
  } catch {
    return false;
  }
}

export async function nativeReleaseFolder(treeUri: string): Promise<void> {
  if (!MediaBridge) return;
  await MediaBridge.releaseFolder({ treeUri }).catch(() => undefined);
}

let mediaServerBase: string | null = null;

export async function ensureMediaServer(): Promise<string | null> {
  if (!MediaBridge) return null;
  if (mediaServerBase) return mediaServerBase;
  try {
    const { baseUrl } = await MediaBridge.startMediaServer();
    mediaServerBase = baseUrl;
    return baseUrl;
  } catch {
    return null;
  }
}

export async function nativePlayableUrl(uri: string): Promise<string | null> {
  if (!MediaBridge) return null;
  try {
    const { url } = await MediaBridge.playableUrl({ uri });
    return url;
  } catch {
    return null;
  }
}

// -- brightness & volume ----------------------------------------------------------
// Android: window brightness (app window only) / media-stream volume via the
// native plugin. Web: no system APIs exist — the player simulates brightness
// with a filter overlay and drives the media element's own volume, and the
// UI labels that honestly.

export const nativeBrightness = {
  supported: isNative,
  async get(): Promise<number> {
    if (!MediaBridge) return 1;
    try {
      return (await MediaBridge.getWindowBrightness()).value;
    } catch {
      return 1;
    }
  },
  async set(value: number): Promise<void> {
    if (!MediaBridge) return;
    await MediaBridge.setWindowBrightness({ value: Math.min(1, Math.max(0.05, value)) }).catch(() => undefined);
  },
};

export const nativeVolume = {
  supported: isNative,
  async get(): Promise<number> {
    if (!MediaBridge) return 1;
    try {
      return (await MediaBridge.getVolume()).value;
    } catch {
      return 1;
    }
  },
  async set(value: number): Promise<void> {
    if (!MediaBridge) return;
    await MediaBridge.setVolume({ value: Math.min(1, Math.max(0, value)) }).catch(() => undefined);
  },
};
