// IndexedDB via Dexie. Everything the app knows — library, collections,
// watch history, playback positions, custom metadata, preview timestamps,
// artwork blobs, web folder handles — lives here, on device.

import Dexie, { type Table } from 'dexie';
import type {
  ArtworkRecord,
  CollectionRecord,
  EpisodeRecord,
  FileRecord,
  FolderSource,
  HistoryEntry,
  TitleRecord,
} from '../types';

export interface SettingRecord {
  key: string;
  value: unknown;
}

export interface HandleRecord {
  id: string;
  handle: FileSystemDirectoryHandle | FileSystemFileHandle;
}

class MediaDb extends Dexie {
  titles!: Table<TitleRecord, string>;
  episodes!: Table<EpisodeRecord, string>;
  files!: Table<FileRecord, string>;
  sources!: Table<FolderSource, string>;
  collections!: Table<CollectionRecord, string>;
  history!: Table<HistoryEntry, string>;
  artwork!: Table<ArtworkRecord, string>;
  settings!: Table<SettingRecord, string>;
  handles!: Table<HandleRecord, string>;

  constructor() {
    super('my-media-db');
    this.version(1).stores({
      titles: 'id, kind, sortName, addedAt, lastPlayedAt, updatedAt',
      episodes: 'id, titleId, [titleId+season+episode], fileId, addedAt, lastPlayedAt',
      files: 'id, sourceId, titleId, episodeId, kind, addedAt, lastPlayedAt',
      sources: 'id, addedAt',
      collections: 'id, updatedAt',
      history: 'id, fileId, titleId, startedAt',
      artwork: 'id, kind, updatedAt',
      settings: 'key',
      handles: 'id',
    });
  }
}

export const db = new MediaDb();

// -- settings helpers ----------------------------------------------------------

export async function getSetting<T>(key: string, fallback: T): Promise<T> {
  const row = await db.settings.get(key);
  return row ? (row.value as T) : fallback;
}

export async function setSetting(key: string, value: unknown): Promise<void> {
  await db.settings.put({ key, value });
}

/** Export everything except secrets as human-readable JSON. */
export async function exportLibraryJson(): Promise<string> {
  const [titles, episodes, files, sources, collections, history, settings] = await Promise.all([
    db.titles.toArray(),
    db.episodes.toArray(),
    db.files.toArray(),
    db.sources.toArray(),
    db.collections.toArray(),
    db.history.toArray(),
    db.settings.toArray(),
  ]);
  // Artwork blobs are binary; export as data URLs so restore keeps posters.
  const artwork = await db.artwork.toArray();
  const artworkExport: Array<{ id: string; kind: ArtworkRecord['kind']; dataUrl: string; updatedAt: number }> = [];
  for (const a of artwork) {
    // Native-URI artwork has no blob to export (device-scoped URIs can't be restored).
    if (!a.blob) continue;
    artworkExport.push({
      id: a.id,
      kind: a.kind,
      dataUrl: await blobToDataUrl(a.blob),
      updatedAt: a.updatedAt,
    });
  }
  return JSON.stringify(
    {
      app: 'my-media',
      version: 1,
      exportedAt: new Date().toISOString(),
      titles,
      episodes,
      files: files.map((f) => ({ ...f, uri: redactUri(f.uri) })),
      sources: sources.map((s) => ({ ...s, treeUri: undefined })),
      collections,
      history,
      settings,
      artwork: artworkExport,
    },
    null,
    2,
  );
}

function redactUri(uri: string): string {
  // Native content:// URIs contain no secrets, but keep exports portable:
  // file identity is rebuilt on rescan anyway.
  return uri.startsWith('content://') ? uri : uri;
}

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = () => reject(r.error ?? new Error('read failed'));
    r.readAsDataURL(blob);
  });
}

export function dataUrlToBlob(dataUrl: string): Blob {
  const [head, data] = dataUrl.split(',');
  const mime = (head.match(/data:(.*?);/) ?? [])[1] ?? 'image/jpeg';
  const bin = atob(data);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}

export interface BackupPayload {
  titles?: TitleRecord[];
  episodes?: EpisodeRecord[];
  collections?: CollectionRecord[];
  history?: HistoryEntry[];
  settings?: SettingRecord[];
  artwork?: Array<{ id: string; kind: ArtworkRecord['kind']; dataUrl: string; updatedAt: number }>;
}

/** Validate + preview a backup before applying it. Returns counts, throws on invalid. */
export function previewBackup(json: string): { titles: number; episodes: number; collections: number; history: number; artwork: number } {
  let parsed: unknown;
  try {
    parsed = JSON.parse(json);
  } catch {
    throw new Error('That file is not valid JSON.');
  }
  const p = parsed as BackupPayload;
  if (!p || typeof p !== 'object') throw new Error('That file is not a My Media backup.');
  const n = (v: unknown) => (Array.isArray(v) ? v.length : 0);
  return {
    titles: n(p.titles),
    episodes: n(p.episodes),
    collections: n(p.collections),
    history: n(p.history),
    artwork: n(p.artwork),
  };
}

/** Apply a validated backup (files/sources are rebuilt by rescan, never imported). */
export async function restoreBackup(json: string): Promise<void> {
  const p = JSON.parse(json) as BackupPayload;
  await db.transaction('rw', [db.titles, db.episodes, db.collections, db.history, db.settings, db.artwork], async () => {
    if (p.titles) await db.titles.bulkPut(p.titles);
    if (p.episodes) await db.episodes.bulkPut(p.episodes);
    if (p.collections) await db.collections.bulkPut(p.collections);
    if (p.history) await db.history.bulkPut(p.history);
    if (p.settings) await db.settings.bulkPut(p.settings.filter((s) => !/secret|token|key|pin/i.test(s.key)));
    if (p.artwork) {
      for (const a of p.artwork) {
        await db.artwork.put({ id: a.id, kind: a.kind, blob: dataUrlToBlob(a.dataUrl), updatedAt: a.updatedAt });
      }
    }
  });
}

/** Non-destructive: drop file/episode/title rows but keep settings, reviews live on titles… */
export async function rebuildIndex(): Promise<void> {
  await db.transaction('rw', [db.titles, db.episodes, db.files], async () => {
    await db.files.clear();
    await db.episodes.clear();
    await db.titles.clear();
  });
}
