import { describe, expect, it } from 'vitest';
import {
  buildHistoryEntry,
  clampPosition,
  hasReachedWatched,
  isEffectivelyCompleted,
  nextQueueIndex,
  prevQueueIndex,
  shouldResume,
} from './playbackState';

describe('shouldResume', () => {
  it('resumes only when >=30 s watched and >60 s remain', () => {
    expect(shouldResume(120_000, 600_000)).toBe(true);
    expect(shouldResume(10_000, 600_000)).toBe(false); // barely started -> restart
    expect(shouldResume(590_000, 600_000)).toBe(false); // <60 s remain -> finished
    expect(shouldResume(0, 0)).toBe(false);
  });
});

describe('hasReachedWatched', () => {
  it('marks watched at the 90% threshold', () => {
    expect(hasReachedWatched(540_000, 600_000)).toBe(true);
    expect(hasReachedWatched(539_000, 600_000)).toBe(false);
    expect(hasReachedWatched(100, 0)).toBe(false);
  });
});

describe('isEffectivelyCompleted', () => {
  it('treats <60 s remaining as completed', () => {
    expect(isEffectivelyCompleted(545_000, 600_000)).toBe(true);
    expect(isEffectivelyCompleted(500_000, 600_000)).toBe(false);
  });
});

describe('nextQueueIndex', () => {
  it('advances linearly and stops at the end', () => {
    expect(nextQueueIndex(3, 0, { shuffle: false, repeat: 'off' })).toBe(1);
    expect(nextQueueIndex(3, 2, { shuffle: false, repeat: 'off' })).toBeNull();
  });
  it('wraps with repeat all', () => {
    expect(nextQueueIndex(3, 2, { shuffle: false, repeat: 'all' })).toBe(0);
  });
  it('repeats one', () => {
    expect(nextQueueIndex(3, 1, { shuffle: false, repeat: 'one' })).toBe(1);
  });
  it('shuffles to a different index with a stubbed random', () => {
    const n = nextQueueIndex(5, 2, { shuffle: true, repeat: 'off', randomIndex: () => 4 });
    expect(n).toBe(4);
  });
  it('handles empty queues', () => {
    expect(nextQueueIndex(0, 0, { shuffle: false, repeat: 'off' })).toBeNull();
  });
});

describe('prevQueueIndex', () => {
  it('restarts the item when well into it', () => {
    expect(prevQueueIndex(2, 30_000)).toBe('restart');
  });
  it('goes back when near the start', () => {
    expect(prevQueueIndex(2, 2_000)).toBe(1);
    expect(prevQueueIndex(0, 0)).toBe(0);
  });
});

describe('buildHistoryEntry', () => {
  it('marks completed when <60 s remain', () => {
    const e = buildHistoryEntry({
      fileId: 'f1', titleId: 't1', startedAt: 1000, endedAt: 2000,
      positionMs: 590_000, durationMs: 600_000,
    });
    expect(e.completed).toBe(true);
    expect(e.endedAt).toBe(2000);
  });
  it('marks incomplete otherwise', () => {
    const e = buildHistoryEntry({
      fileId: 'f1', titleId: 't1', startedAt: 1000, endedAt: 2000,
      positionMs: 60_000, durationMs: 600_000,
    });
    expect(e.completed).toBe(false);
  });
});

describe('clampPosition', () => {
  it('clamps into range', () => {
    expect(clampPosition(999_999, 600_000)).toBe(600_000);
    expect(clampPosition(-5, 600_000)).toBe(0);
    expect(clampPosition(123, 600_000)).toBe(123);
    expect(clampPosition(NaN)).toBe(0);
  });
});
