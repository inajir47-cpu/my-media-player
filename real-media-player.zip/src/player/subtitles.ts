// SRT/VTT parsing into VTTCue objects. Malformed cues are skipped —
// a bad subtitle file must never break playback.

export interface ParsedSubtitles {
  cues: VTTCue[];
  format: 'srt' | 'vtt';
}

function tsToSeconds(ts: string): number | null {
  const m = ts.trim().match(/(?:(\d+):)?(\d{1,2}):(\d{1,2})[,.](\d{1,3})/);
  if (!m) return null;
  const h = m[1] ? parseInt(m[1], 10) : 0;
  const min = parseInt(m[2], 10);
  const sec = parseInt(m[3], 10);
  const ms = parseInt(m[4].padEnd(3, '0'), 10);
  return h * 3600 + min * 60 + sec + ms / 1000;
}

function cleanCueText(text: string): string {
  return text
    .replace(/<[^>]*>/g, '')
    .replace(/\{[^}]*\}/g, '')
    .trim();
}

export function parseSubtitles(text: string, format: 'srt' | 'vtt'): VTTCue[] {
  const cues: VTTCue[] = [];
  const normalized = text.replace(/\r\n?/g, '\n');
  const body = format === 'vtt' ? normalized.replace(/^WEBVTT[^\n]*\n/, '') : normalized;
  const blocks = body.split(/\n{2,}/);
  for (const block of blocks) {
    const lines = block.split('\n').map((l) => l.trim()).filter((l) => l.length > 0);
    if (lines.length < 2) continue;
    // SRT blocks start with a numeric index; VTT may have a cue id.
    let timingIdx = 0;
    if (/^\d+$/.test(lines[0])) timingIdx = 1;
    const timing = lines[timingIdx];
    if (!timing || !timing.includes('-->')) continue;
    const [startRaw, endRaw] = timing.split('-->').map((s) => s.split(' ')[0]);
    const start = tsToSeconds(startRaw);
    const end = tsToSeconds(endRaw);
    if (start === null || end === null || end <= start) continue;
    const cueText = cleanCueText(lines.slice(timingIdx + 1).join('\n'));
    if (!cueText) continue;
    try {
      cues.push(new VTTCue(start, end, cueText));
    } catch {
      // ignore malformed cue
    }
  }
  return cues;
}

export function detectSubtitleFormat(name: string, text: string): 'srt' | 'vtt' {
  if (/\.vtt$/i.test(name)) return 'vtt';
  if (/^\s*WEBVTT/m.test(text)) return 'vtt';
  return 'srt';
}
