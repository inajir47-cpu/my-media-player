// Pure playback-state logic: resume rules, watched thresholds, queue
// advancement, history entries. Unit tested in playbackState.test.ts.

import { COMPLETED_REMAINING_MS, RESUME_MIN_WATCHED_MS, WATCHED_THRESHOLD } from '../config';

export interface QueueItem {
  id: string;
  title: string;
}

/** Resume only if enough was watched AND enough remains. */
export function shouldResume(positionMs: number, durationMs: number): boolean {
  if (!Number.isFinite(positionMs) || !Number.isFinite(durationMs) || durationMs <= 0) return false;
  if (positionMs < RESUME_MIN_WATCHED_MS) return false;
  return durationMs - positionMs > COMPLETED_REMAINING_MS;
}

/** True once the watched threshold (default 90%) is reached. */
export function hasReachedWatched(positionMs: number, durationMs: number, threshold = WATCHED_THRESHOLD): boolean {
  if (!Number.isFinite(positionMs) || !Number.isFinite(durationMs) || durationMs <= 0) return false;
  return positionMs / durationMs >= threshold;
}

/** Fewer than 60 s remaining counts as completed (offer next episode). */
export function isEffectivelyCompleted(positionMs: number, durationMs: number): boolean {
  if (!Number.isFinite(positionMs) || !Number.isFinite(durationMs) || durationMs <= 0) return false;
  return durationMs - positionMs <= COMPLETED_REMAINING_MS;
}

export type RepeatMode = 'off' | 'one' | 'all';

/**
 * Next queue index given shuffle/repeat. Returns null when playback should stop.
 */
export function nextQueueIndex(
  queueLength: number,
  currentIndex: number,
  opts: { shuffle: boolean; repeat: RepeatMode; randomIndex?: () => number },
): number | null {
  if (queueLength <= 0) return null;
  if (opts.repeat === 'one') return currentIndex;
  if (opts.shuffle) {
    if (queueLength === 1) return opts.repeat === 'all' ? 0 : null;
    const pick = opts.randomIndex ?? (() => Math.floor(Math.random() * queueLength));
    let next = pick();
    let guard = 0;
    while (next === currentIndex && guard++ < 20) next = pick();
    return next;
  }
  const next = currentIndex + 1;
  if (next < queueLength) return next;
  return opts.repeat === 'all' ? 0 : null;
}

/** Previous: restart the item when more than a few seconds in, else go back. */
export function prevQueueIndex(currentIndex: number, positionMs: number): number | 'restart' {
  if (positionMs > 5000 && currentIndex >= 0) return 'restart';
  return Math.max(0, currentIndex - 1);
}

export interface HistoryInput {
  fileId: string;
  titleId: string;
  episodeId?: string;
  startedAt: number;
  endedAt: number;
  positionMs: number;
  durationMs?: number;
}

export function buildHistoryEntry(input: HistoryInput): {
  fileId: string;
  titleId: string;
  episodeId?: string;
  startedAt: number;
  endedAt: number;
  completed: boolean;
  positionMs: number;
} {
  const completed = input.durationMs !== undefined && isEffectivelyCompleted(input.positionMs, input.durationMs);
  return {
    fileId: input.fileId,
    titleId: input.titleId,
    episodeId: input.episodeId,
    startedAt: input.startedAt,
    endedAt: input.endedAt,
    completed,
    positionMs: input.positionMs,
  };
}

/** Clamp a restored position into [0, duration]. */
export function clampPosition(positionMs: number, durationMs?: number): number {
  if (!Number.isFinite(positionMs) || positionMs < 0) return 0;
  if (durationMs !== undefined && Number.isFinite(durationMs) && durationMs > 0) {
    return Math.min(positionMs, durationMs);
  }
  return positionMs;
}
