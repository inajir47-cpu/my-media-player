// Full VLC-style player over a single HTML5 media element.
// Custom controls (orange timeline, elapsed/total), playlist, 10 s skips,
// volume/mute, brightness (simulated overlay on web, window brightness on
// native — the UI says which), aspect fit, audio/subtitle tracks, SRT/VTT
// file loading, shuffle/repeat, PiP, speed, sleep timer, fullscreen.
// Touch gestures: horizontal swipe = seek, left vertical = brightness,
// right vertical = volume, double-tap L/R = ∓10 s, single tap = controls.

import { useCallback, useEffect, useRef, useState } from 'react';
import { SEEK_STEP_MS, SAVE_POSITION_INTERVAL_MS } from '../config';
import { DEFAULT_GESTURES, type GestureSettings } from '../pages/SettingsPage';
import { db } from '../db/database';
import { useLibrary, type PlayerQueueItem } from '../library/store';
import { resolvePlayableUrl, siblingSubtitles } from '../media/playable';
import { isNative, nativeBrightness, nativeVolume } from '../native/bridge';
import { isEffectivelyCompleted, nextQueueIndex, prevQueueIndex, shouldResume, type RepeatMode } from './playbackState';
import { detectSubtitleFormat, parseSubtitles } from './subtitles';

interface PlayerProps {
  queue: PlayerQueueItem[];
  startIndex: number;
  onClose: () => void;
}

interface SubTrack {
  id: string;
  label: string;
  url?: string; // sidecar / uploaded: fetched + parsed on select
  nativeTrack?: TextTrack; // embedded container track
}

type Fit = 'contain' | 'cover' | 'stretch' | 'original' | '16:9' | '4:3';
type Sheet = null | 'playlist' | 'subs' | 'audio' | 'speed' | 'sleep' | 'aspect' | 'display';

const SPEEDS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 3, 4];
const SLEEP_OPTIONS: Array<{ id: string; label: string; minutes?: number }> = [
  { id: 'off', label: 'Off' },
  { id: '15', label: '15 min', minutes: 15 },
  { id: '30', label: '30 min', minutes: 30 },
  { id: '45', label: '45 min', minutes: 45 },
  { id: '60', label: '60 min', minutes: 60 },
  { id: 'end', label: 'End of episode' },
];

export function fmtTime(totalSeconds: number): string {
  if (!Number.isFinite(totalSeconds) || totalSeconds < 0) return '0:00';
  const s = Math.floor(totalSeconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return h > 0 ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}` : `${m}:${String(sec).padStart(2, '0')}`;
}

export function Player({ queue, startIndex, onClose }: PlayerProps): React.JSX.Element {
  const { savePosition, getSetting } = useLibrary();
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [index, setIndex] = useState(startIndex);
  const item = queue[index];

  const [src, setSrc] = useState<string | null>(null);
  const [srcState, setSrcState] = useState<'loading' | 'ready' | 'error'>('loading');
  const [srcError, setSrcError] = useState('');
  const [fileId, setFileId] = useState(item.fileId);

  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [volume, setVolumeState] = useState(1);
  const [muted, setMuted] = useState(false);
  const [rate, setRate] = useState(1);
  const [repeat, setRepeat] = useState<RepeatMode>('off');
  const [shuffle, setShuffle] = useState(false);
  const [brightness, setBrightnessState] = useState(1);
  const [fit, setFit] = useState<Fit>('contain');
  const [locked, setLocked] = useState(false);
  const [controlsVisible, setControlsVisible] = useState(true);
  const [sheet, setSheet] = useState<Sheet>(null);

  const [subTracks, setSubTracks] = useState<SubTrack[]>([]);
  const [activeSub, setActiveSub] = useState<string>('off');
  const [subDelay, setSubDelay] = useState(0);
  const [subSize, setSubSize] = useState(20);
  const [subColor, setSubColor] = useState('#ffffff');
  const [subBg, setSubBg] = useState('rgba(0,0,0,0.6)');
  const [subPos, setSubPos] = useState<'bottom' | 'top'>('bottom');
  const [audioTracks, setAudioTracks] = useState<Array<{ label: string; language: string }>>([]);
  const [audioIdx, setAudioIdx] = useState(0);
  const [sleep, setSleep] = useState('off');
  const [overlay, setOverlay] = useState<string | null>(null);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [autoplayNext, setAutoplayNext] = useState(true);
  const [gestures, setGestures] = useState<GestureSettings>(DEFAULT_GESTURES);

  const dynamicTrackRef = useRef<TextTrack | null>(null);
  const rawCuesRef = useRef<VTTCue[]>([]);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const saveTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const sleepTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const overlayTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const countdownTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const wakeLock = useRef<{ release: () => Promise<void> } | null>(null);
  const committedRef = useRef(false);

  const showOverlay = useCallback((text: string, ms = 1200) => {
    setOverlay(text);
    if (overlayTimer.current) clearTimeout(overlayTimer.current);
    overlayTimer.current = setTimeout(() => setOverlay(null), ms);
  }, []);

  const pokeControls = useCallback(() => {
    setControlsVisible(true);
    if (hideTimer.current) clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => setControlsVisible(false), 3500);
  }, []);

  // -- loading -----------------------------------------------------------------
  const persistNow = useCallback((commit: boolean) => {
    const v = videoRef.current;
    if (!v || !fileId) return;
    committedRef.current = committedRef.current || commit;
    void savePosition(fileId, Math.floor(v.currentTime * 1000), Math.floor(v.duration * 1000) || undefined, commit);
  }, [fileId, savePosition]);

  const loadIndex = useCallback(async (i: number) => {
    persistNow(true);
    setIndex(i);
    const q = queue[i];
    setFileId(q.fileId);
    committedRef.current = false;
    setSrc(null);
    setSrcState('loading');
    setSrcError('');
    setTime(0);
    setDuration(0);
    setBuffered(0);
    setSubTracks([]);
    setActiveSub('off');
    setAudioTracks([]);
    setCountdown(null);
    const file = await db.files.get(q.fileId);
    if (!file) {
      setSrcState('error');
      setSrcError('File record not found in the library.');
      return;
    }
    if (file.missing) {
      setSrcState('error');
      setSrcError('This file is not available — it was moved, renamed, or the folder permission was revoked. Rescan the folder or re-pick it in Settings.');
      return;
    }
    const url = await resolvePlayableUrl(file);
    if (!url) {
      setSrcState('error');
      setSrcError(
        file.uri.startsWith('webfs://')
          ? 'Could not re-open that folder. Browsers forget folder access — re-pick the folder in Settings to continue.'
          : 'Could not open this file for playback.',
      );
      return;
    }
    setSrc(url);
    setSrcState('ready');
    // Sidecar subtitles discovered at load; parsed lazily on select.
    siblingSubtitles(file).then(
      (subs) => setSubTracks(subs.map((s, n) => ({ id: `sidecar-${n}`, label: s.label, url: s.url }))),
      () => undefined,
    );
  }, [persistNow, queue]);

  useEffect(() => {
    void loadIndex(startIndex);
    getSetting('autoplayNext', true).then(setAutoplayNext).catch(() => undefined);
    getSetting('playerRate', 1).then((r) => setRate(typeof r === 'number' ? r : 1)).catch(() => undefined);
    getSetting('gestures', DEFAULT_GESTURES).then(setGestures).catch(() => undefined);
    return () => {
      if (saveTimer.current) clearInterval(saveTimer.current);
      if (sleepTimer.current) clearTimeout(sleepTimer.current);
      if (countdownTimer.current) clearInterval(countdownTimer.current);
      if (hideTimer.current) clearTimeout(hideTimer.current);
      wakeLock.current?.release().catch(() => undefined);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // keep native volume/brightness in sync at mount
  useEffect(() => {
    if (!isNative) return;
    nativeVolume.get().then(setVolumeState).catch(() => undefined);
    nativeBrightness.get().then(setBrightnessState).catch(() => undefined);
  }, []);

  // -- video events --------------------------------------------------------------
  const onLoadedMetadata = useCallback(async () => {
    const v = videoRef.current;
    if (!v) return;
    const d = v.duration || 0;
    setDuration(d);
    // Buffered + duration-driven extras
    const file = await db.files.get(fileId);
    if (file && !file.durationMs && d > 0) {
      const ms = Math.floor(d * 1000);
      await db.files.update(fileId, { durationMs: ms });
      if (file.episodeId) await db.episodes.update(file.episodeId, { durationMs: ms });
    }
    // Resume logic
    const posMs = file?.positionMs ?? 0;
    if (shouldResume(posMs, d * 1000)) {
      v.currentTime = posMs / 1000;
      showOverlay(`Resumed at ${fmtTime(posMs / 1000)}`);
    }
    v.playbackRate = rate;
    // Embedded subtitle/audio tracks
    const embedded: SubTrack[] = [];
    for (let i = 0; i < v.textTracks.length; i++) {
      const t = v.textTracks[i];
      if (t === dynamicTrackRef.current) continue;
      if (t.kind === 'subtitles' || t.kind === 'captions') {
        embedded.push({ id: `emb-${i}`, label: t.label || `Subtitle ${i + 1}`, nativeTrack: t });
        t.mode = 'disabled';
      }
    }
    setSubTracks((prev) => [...prev, ...embedded]);
    const at = (v as unknown as { audioTracks?: { length: number; [k: number]: { label: string; language: string; enabled: boolean } } }).audioTracks;
    if (at && at.length > 1) {
      const list: Array<{ label: string; language: string }> = [];
      for (let i = 0; i < at.length; i++) list.push({ label: at[i].label || `Audio ${i + 1}`, language: at[i].language || '' });
      setAudioTracks(list);
    }
    pokeControls();
  }, [fileId, pokeControls, rate, showOverlay]);

  const onTimeUpdate = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    setTime(v.currentTime);
    try {
      if (v.buffered.length) setBuffered(v.buffered.end(v.buffered.length - 1));
    } catch { /* ignore */ }
  }, []);

  const acquireWakeLock = useCallback(() => {
    try {
      const nav = navigator as Navigator & { wakeLock?: { request: (t: string) => Promise<{ release: () => Promise<void> }> } };
      nav.wakeLock?.request('screen').then(
        (l) => { wakeLock.current = l; },
        () => undefined,
      );
    } catch { /* unsupported */ }
  }, []);

  const onPlay = useCallback(() => {
    setPlaying(true);
    acquireWakeLock();
    pokeControls();
    if (saveTimer.current) clearInterval(saveTimer.current);
    saveTimer.current = setInterval(() => persistNow(false), SAVE_POSITION_INTERVAL_MS);
  }, [acquireWakeLock, persistNow, pokeControls]);

  const onPause = useCallback(() => {
    setPlaying(false);
    if (saveTimer.current) clearInterval(saveTimer.current);
    wakeLock.current?.release().catch(() => undefined);
    wakeLock.current = null;
    persistNow(true);
    pokeControls();
  }, [persistNow, pokeControls]);

  const goNext = useCallback((auto = false) => {
    const n = nextQueueIndex(queue.length, index, { shuffle, repeat: auto ? repeat : 'off' });
    if (n !== null && n !== undefined) void loadIndex(n);
    else if (!auto) showOverlay('End of queue');
  }, [index, loadIndex, queue.length, repeat, shuffle, showOverlay]);

  const onEnded = useCallback(() => {
    persistNow(true);
    if (sleep === 'end') {
      setSleep('off');
      showOverlay('Sleep timer: stopped at end of episode');
      return;
    }
    const v = videoRef.current;
    const completed = v ? isEffectivelyCompleted(v.currentTime * 1000, (v.duration || 0) * 1000) : true;
    if (!completed) return;
    const n = nextQueueIndex(queue.length, index, { shuffle, repeat });
    if (autoplayNext && n !== null && n !== index) {
      setCountdown(5);
      if (countdownTimer.current) clearInterval(countdownTimer.current);
      countdownTimer.current = setInterval(() => {
        setCountdown((c) => {
          if (c === null || c <= 1) {
            if (countdownTimer.current) clearInterval(countdownTimer.current);
            void loadIndex(n);
            return null;
          }
          return c - 1;
        });
      }, 1000);
    } else if (repeat === 'one') {
      const vv = videoRef.current;
      if (vv) { vv.currentTime = 0; void vv.play().catch(() => undefined); }
    }
  }, [index, loadIndex, persistNow, queue.length, repeat, shuffle, showOverlay, sleep, autoplayNext]);

  const goPrev = useCallback(() => {
    const v = videoRef.current;
    const pos = v ? v.currentTime * 1000 : 0;
    const prev = prevQueueIndex(index, pos);
    if (prev === 'restart') {
      if (v) v.currentTime = 0;
    } else {
      void loadIndex(prev);
    }
  }, [index, loadIndex]);

  const togglePlay = useCallback(() => {
    const v = videoRef.current;
    if (!v || srcState !== 'ready') return;
    if (v.paused) void v.play().catch(() => showOverlay('Playback failed — this format may not be supported by the browser'));
    else v.pause();
  }, [showOverlay, srcState]);

  const seekBy = useCallback((ms: number) => {
    const v = videoRef.current;
    if (!v) return;
    v.currentTime = Math.min(Math.max(0, v.currentTime + ms / 1000), v.duration || 0);
    showOverlay(`${ms >= 0 ? '+' : '−'}${Math.abs(ms / 1000)}s`);
    pokeControls();
  }, [pokeControls, showOverlay]);

  // -- volume / brightness ---------------------------------------------------------
  const applyVolume = useCallback((val: number, mute?: boolean) => {
    const v = Math.min(1, Math.max(0, val));
    setVolumeState(v);
    const m = mute ?? (v === 0 ? true : muted && v > 0 ? false : muted);
    setMuted(m);
    const el = videoRef.current;
    if (el) { el.volume = v; el.muted = m; }
    if (isNative) void nativeVolume.set(v);
    showOverlay(m ? 'Muted' : `Volume ${Math.round(v * 100)}%${isNative ? '' : ' (app)'}`);
  }, [muted, showOverlay]);

  const applyBrightness = useCallback((val: number) => {
    const b = Math.min(1, Math.max(0.05, val));
    setBrightnessState(b);
    if (isNative) void nativeBrightness.set(b);
    showOverlay(`Brightness ${Math.round(b * 100)}%${isNative ? '' : ' (simulated)'}`);
  }, [showOverlay]);

  // -- subtitles ---------------------------------------------------------------------
  const buildDynamicTrack = useCallback(() => {
    const v = videoRef.current;
    if (!v) return null;
    if (!dynamicTrackRef.current) {
      try {
        dynamicTrackRef.current = v.addTextTrack('subtitles', 'My Media subs', 'en');
      } catch {
        return null;
      }
    }
    return dynamicTrackRef.current;
  }, []);

  const renderCues = useCallback(() => {
    const track = dynamicTrackRef.current;
    if (!track) return;
    try {
      while (track.cues?.length) track.removeCue(track.cues[0]);
      for (const cue of rawCuesRef.current) {
        const c = new VTTCue(cue.startTime + subDelay, cue.endTime + subDelay, cue.text);
        c.line = subPos === 'top' ? 0 : 'auto';
        track.addCue(c);
      }
      track.mode = 'showing';
    } catch { /* ignore */ }
  }, [subDelay, subPos]);

  const selectSubtitle = useCallback(async (id: string) => {
    const v = videoRef.current;
    // disable everything first
    if (dynamicTrackRef.current) {
      try { dynamicTrackRef.current.mode = 'disabled'; } catch { /* ignore */ }
    }
    if (v) for (let i = 0; i < v.textTracks.length; i++) {
      const t = v.textTracks[i];
      if (t !== dynamicTrackRef.current) { try { t.mode = 'disabled'; } catch { /* ignore */ } }
    }
    setActiveSub(id);
    if (id === 'off' || !v) return;
    const track = subTracks.find((t) => t.id === id);
    if (!track) return;
    if (track.nativeTrack) {
      try { track.nativeTrack.mode = 'showing'; } catch { /* ignore */ }
      showOverlay(`Subtitles: ${track.label}`);
      return;
    }
    if (!track.url) return;
    try {
      showOverlay('Loading subtitles…');
      const text = await (await fetch(track.url)).text();
      const cues = parseSubtitles(text, detectSubtitleFormat(track.label, text));
      if (!cues.length) { showOverlay('No readable cues in that file'); return; }
      rawCuesRef.current = cues;
      const dyn = buildDynamicTrack();
      if (!dyn) { showOverlay('Subtitles not supported here'); return; }
      renderCues();
      showOverlay(`Subtitles: ${track.label}`);
    } catch {
      showOverlay('Could not load that subtitle file');
    }
  }, [buildDynamicTrack, renderCues, showOverlay, subTracks]);

  useEffect(() => { renderCues(); }, [renderCues]);

  const loadSubtitleFile = useCallback(async (file: File) => {
    const text = await file.text();
    const cues = parseSubtitles(text, detectSubtitleFormat(file.name, text));
    if (!cues.length) { showOverlay('No readable cues in that file'); return; }
    const id = `file-${Date.now()}`;
    setSubTracks((prev) => [...prev, { id, label: file.name }]);
    rawCuesRef.current = cues;
    const dyn = buildDynamicTrack();
    if (dyn) {
      if (dynamicTrackRef.current) { try { dynamicTrackRef.current.mode = 'disabled'; } catch { /* ignore */ } }
      setActiveSub(id);
      renderCues();
      showOverlay(`Subtitles: ${file.name}`);
    }
  }, [buildDynamicTrack, renderCues, showOverlay]);

  const selectAudioTrack = useCallback((i: number) => {
    const v = videoRef.current;
    const at = (v as unknown as { audioTracks?: { length: number; [k: number]: { enabled: boolean } } } | null)?.audioTracks;
    if (v && at) {
      for (let k = 0; k < at.length; k++) at[k].enabled = k === i;
      setAudioIdx(i);
      showOverlay(`Audio: ${audioTracks[i]?.label ?? i + 1}`);
    }
  }, [audioTracks, showOverlay]);

  // -- sleep timer ---------------------------------------------------------------------
  const setSleepTimer = useCallback((id: string) => {
    setSleep(id);
    if (sleepTimer.current) clearTimeout(sleepTimer.current);
    const opt = SLEEP_OPTIONS.find((o) => o.id === id);
    if (opt?.minutes) {
      sleepTimer.current = setTimeout(() => {
        videoRef.current?.pause();
        setSleep('off');
        showOverlay('Sleep timer: playback paused');
      }, opt.minutes * 60_000);
      showOverlay(`Sleep timer: ${opt.label}`);
    } else if (id === 'end') {
      showOverlay('Sleep timer: end of episode');
    }
    setSheet(null);
  }, [showOverlay]);

  // -- PiP / fullscreen / fit ------------------------------------------------------------
  const togglePip = useCallback(async () => {
    const v = videoRef.current;
    if (!v) return;
    try {
      const doc = document as Document & { pictureInPictureElement?: Element };
      if (doc.pictureInPictureElement) await document.exitPictureInPicture();
      else await (v as HTMLVideoElement & { requestPictureInPicture: () => Promise<void> }).requestPictureInPicture();
    } catch {
      showOverlay('Picture-in-picture not available');
    }
  }, [showOverlay]);

  const toggleFullscreen = useCallback(() => {
    const c = containerRef.current;
    if (!c) return;
    try {
      if (document.fullscreenElement) void document.exitFullscreen();
      else void c.requestFullscreen();
    } catch {
      showOverlay('Fullscreen not available');
    }
  }, [showOverlay]);

  const fitStyle = useCallback((): React.CSSProperties => {
    switch (fit) {
      case 'contain': return { objectFit: 'contain' };
      case 'cover': return { objectFit: 'cover' };
      case 'stretch': return { objectFit: 'fill' };
      case 'original': return { objectFit: 'none' };
      case '16:9': return { objectFit: 'fill', aspectRatio: '16 / 9' };
      case '4:3': return { objectFit: 'fill', aspectRatio: '4 / 3' };
    }
  }, [fit]);

  // -- gestures ----------------------------------------------------------------------------
  interface GState {
    pointerId: number; startX: number; startY: number;
    mode: 'pending' | 'seek' | 'brightness' | 'volume';
    startBrightness: number; startVolume: number; startTime: number;
  }
  const gestureRef = useRef<GState | null>(null);
  const pendingSeekRef = useRef<number | null>(null);
  const tapRef = useRef<{ time: number; x: number; timer: ReturnType<typeof setTimeout> } | null>(null);

  const clearTap = useCallback(() => {
    if (tapRef.current) { clearTimeout(tapRef.current.timer); tapRef.current = null; }
  }, []);

  const handleTap = useCallback((x: number, width: number) => {
    const now = Date.now();
    const prev = tapRef.current;
    if (gestures.doubleTap && prev && now - prev.time < 320 && Math.abs(x - prev.x) < 80) {
      clearTap();
      const zone = x < width * 0.35 ? 'left' : x > width * 0.65 ? 'right' : 'center';
      if (zone === 'left') seekBy(-SEEK_STEP_MS);
      else if (zone === 'right') seekBy(SEEK_STEP_MS);
      else togglePlay();
      return;
    }
    clearTap();
    if (!gestures.doubleTap) {
      // No double-tap waiting when the gesture is disabled: toggle immediately.
      pokeControls();
      setControlsVisible((vis) => !vis);
      return;
    }
    tapRef.current = {
      time: now, x,
      timer: setTimeout(() => { tapRef.current = null; pokeControls(); setControlsVisible((vis) => !vis); }, 320),
    };
  }, [clearTap, gestures.doubleTap, pokeControls, seekBy, togglePlay]);

  const onPointerDown = useCallback((e: React.PointerEvent) => {
    if (locked || srcState !== 'ready') return;
    (e.target as Element).setPointerCapture?.(e.pointerId);
    gestureRef.current = {
      pointerId: e.pointerId, startX: e.clientX, startY: e.clientY,
      mode: 'pending', startBrightness: brightness, startVolume: volume, startTime: videoRef.current?.currentTime ?? 0,
    };
    pendingSeekRef.current = null;
  }, [brightness, locked, srcState, volume]);

  const onPointerMove = useCallback((e: React.PointerEvent) => {
    const g = gestureRef.current;
    if (!g || g.pointerId !== e.pointerId) return;
    const dx = e.clientX - g.startX;
    const dy = e.clientY - g.startY;
    const rect = containerRef.current?.getBoundingClientRect();
    const w = rect?.width ?? 1;
    if (g.mode === 'pending') {
      if (Math.hypot(dx, dy) < 14) return;
      const horizontal = Math.abs(dx) > Math.abs(dy) * 1.2;
      if (horizontal && !gestures.seek) return; // disabled: stay a tap
      if (!horizontal && g.startX < w * 0.4 && !gestures.brightness) return;
      if (!horizontal && g.startX > w * 0.6 && !gestures.volume) return;
      if (horizontal) g.mode = 'seek';
      else g.mode = g.startX < w * 0.4 ? 'brightness' : g.startX > w * 0.6 ? 'volume' : 'seek';
      clearTap();
    }
    if (g.mode === 'seek') {
      const v = videoRef.current;
      if (!v || !v.duration) return;
      // full-width swipe ~= 90 s of seek
      const target = Math.min(Math.max(0, g.startTime + (dx / w) * 90), v.duration);
      pendingSeekRef.current = target;
      const delta = Math.round(target - g.startTime);
      showOverlay(`${delta >= 0 ? '+' : '−'}${fmtTime(Math.abs(delta))} → ${fmtTime(target)}`, 400);
    } else if (g.mode === 'brightness') {
      applyBrightness(g.startBrightness - dy / 350);
    } else if (g.mode === 'volume') {
      applyVolume(g.startVolume - dy / 350);
    }
  }, [applyBrightness, applyVolume, clearTap, gestures, showOverlay]);

  const onPointerUp = useCallback((e: React.PointerEvent) => {
    const g = gestureRef.current;
    if (!g || g.pointerId !== e.pointerId) return;
    gestureRef.current = null;
    const dx = e.clientX - g.startX;
    const dy = e.clientY - g.startY;
    if (g.mode === 'pending' && Math.hypot(dx, dy) < 14) {
      const rect = containerRef.current?.getBoundingClientRect();
      handleTap(e.clientX, rect?.width ?? 1);
      return;
    }
    if (g.mode === 'seek' && pendingSeekRef.current !== null) {
      const v = videoRef.current;
      if (v) v.currentTime = pendingSeekRef.current;
      pendingSeekRef.current = null;
      setOverlay(null);
    }
    pokeControls();
  }, [handleTap, pokeControls]);

  // -- keyboard ------------------------------------------------------------------------------
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (locked) return;
      const v = videoRef.current;
      switch (e.key) {
        case ' ': case 'k': e.preventDefault(); togglePlay(); break;
        case 'ArrowLeft': seekBy(e.shiftKey ? -30_000 : -SEEK_STEP_MS); break;
        case 'ArrowRight': seekBy(e.shiftKey ? 30_000 : SEEK_STEP_MS); break;
        case 'ArrowUp': e.preventDefault(); applyVolume(volume + 0.05); break;
        case 'ArrowDown': e.preventDefault(); applyVolume(volume - 0.05); break;
        case 'j': seekBy(-SEEK_STEP_MS); break;
        case 'l': seekBy(SEEK_STEP_MS); break;
        case 'm': applyVolume(volume, !muted); break;
        case 'f': toggleFullscreen(); break;
        case 'p': void togglePip(); break;
        case 'c': setSheet((s) => (s === 'subs' ? null : 'subs')); break;
        case '[': setRate((r) => Math.max(0.25, +(r - 0.25).toFixed(2))); break;
        case ']': setRate((r) => Math.min(4, +(r + 0.25).toFixed(2))); break;
        case 'Escape':
          if (sheet) setSheet(null);
          else if (document.fullscreenElement) void document.exitFullscreen();
          else onClose();
          break;
        default: break;
      }
      if (v && (e.key === '[' || e.key === ']')) v.playbackRate = rate;
      pokeControls();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [applyVolume, locked, muted, onClose, pokeControls, rate, seekBy, sheet, toggleFullscreen, togglePip, togglePlay, volume]);

  useEffect(() => {
    const v = videoRef.current;
    if (v) v.playbackRate = rate;
  }, [rate, src]);

  // unmount: final save
  useEffect(() => {
    return () => { persistNow(true); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const closeAll = useCallback(() => {
    if (countdownTimer.current) clearInterval(countdownTimer.current);
    setCountdown(null);
    persistNow(true);
    onClose();
  }, [onClose, persistNow]);

  const scrubTo = useCallback((ratio: number) => {
    const v = videoRef.current;
    if (!v || !v.duration) return;
    v.currentTime = ratio * v.duration;
    pokeControls();
  }, [pokeControls]);

  // -- render ----------------------------------------------------------------------------------
  const pct = duration > 0 ? (time / duration) * 100 : 0;
  const bufPct = duration > 0 ? (buffered / duration) * 100 : 0;

  return (
    <div
      ref={containerRef}
      className="player"
      onContextMenu={(e) => e.preventDefault()}
      role="dialog"
      aria-label={`Playing ${item.label}`}
    >
      {/* video surface + gesture layer */}
      <div
        className="player-stage"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={() => { gestureRef.current = null; }}
      >
        {srcState === 'ready' && src && (
          <video
            ref={videoRef}
            src={src}
            style={fitStyle()}
            playsInline
            preload="auto"
            autoPlay
            onLoadedMetadata={() => void onLoadedMetadata()}
            onTimeUpdate={onTimeUpdate}
            onPlay={onPlay}
            onPause={onPause}
            onEnded={onEnded}
            onError={() => { setSrcState('error'); setSrcError('The browser could not decode this file. Try “Open externally” on Android or another format.'); }}
          />
        )}
        {/* brightness simulation overlay (web) — honestly labeled */}
        {!isNative && brightness < 1 && (
          <div className="player-dim" style={{ opacity: 1 - brightness }} aria-hidden="true" />
        )}
        {srcState === 'loading' && (
          <div className="player-center"><div className="spinner" /><p>Loading…</p></div>
        )}
        {srcState === 'error' && (
          <div className="player-center player-error">
            <h3>Can&apos;t play this file</h3>
            <p>{srcError}</p>
            <div className="row">
              <button className="btn primary" onClick={() => void loadIndex(index)}>Retry</button>
              <button className="btn" onClick={closeAll}>Close player</button>
            </div>
          </div>
        )}
        {overlay && <div className="player-overlay-toast" aria-live="polite">{overlay}</div>}
        {countdown !== null && (
          <div className="player-nextup">
            <p>Up next: {queue[index + 1]?.label ?? 'next item'}</p>
            <div className="row">
              <button className="btn primary" onClick={() => { if (countdownTimer.current) clearInterval(countdownTimer.current); setCountdown(null); goNext(true); }}>
                Play now ({countdown})
              </button>
              <button className="btn" onClick={() => { if (countdownTimer.current) clearInterval(countdownTimer.current); setCountdown(null); }}>Cancel</button>
            </div>
          </div>
        )}
      </div>

      {/* dynamic subtitle styling */}
      <style>{`video::cue{font-size:${subSize}px;color:${subColor};background:${subBg};}`}</style>

      {/* top bar */}
      {!locked && (
        <div className={`player-top ${controlsVisible ? 'visible' : ''}`}>
          <button className="icon-btn" onClick={closeAll} aria-label="Close player">‹</button>
          <div className="player-titles">
            <strong>{item.label}</strong>
            {item.sublabel && <span>{item.sublabel}</span>}
          </div>
          <button className="icon-btn" onClick={() => setLocked(true)} aria-label="Lock controls">🔒</button>
          <button className="icon-btn" onClick={() => setSheet('playlist')} aria-label="Playlist">☰</button>
        </div>
      )}
      {locked && (
        <button className="player-unlock" onClick={() => setLocked(false)} aria-label="Unlock controls">🔒 Tap to unlock</button>
      )}

      {/* bottom controls */}
      {!locked && (
        <div className={`player-controls ${controlsVisible ? 'visible' : ''}`}>
          <div
            className="seekbar"
            role="slider"
            aria-label="Seek"
            aria-valuemin={0}
            aria-valuemax={Math.round(duration)}
            aria-valuenow={Math.round(time)}
            onPointerDown={(e) => {
              const el = e.currentTarget;
              (e.target as Element).setPointerCapture?.(e.pointerId);
              const move = (ev: PointerEvent) => {
                const r = el.getBoundingClientRect();
                scrubTo(Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width)));
              };
              const up = () => {
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
              };
              window.addEventListener('pointermove', move);
              window.addEventListener('pointerup', up);
              const r = el.getBoundingClientRect();
              scrubTo(Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)));
            }}
          >
            <div className="seekbar-buffered" style={{ width: `${bufPct}%` }} />
            <div className="seekbar-played" style={{ width: `${pct}%` }} />
            <div className="seekbar-thumb" style={{ left: `${pct}%` }} />
          </div>
          <div className="player-time">
            <span>{fmtTime(time)}</span>
            <span className="dim">{fmtTime(duration)}</span>
          </div>
          <div className="player-buttons">
            <button className="icon-btn" onClick={() => setShuffle((s) => !s)} aria-label="Shuffle" aria-pressed={shuffle} style={{ opacity: shuffle ? 1 : 0.45 }}>🔀</button>
            <button className="icon-btn" onClick={goPrev} aria-label="Previous">⏮</button>
            <button className="icon-btn" onClick={() => seekBy(-SEEK_STEP_MS)} aria-label="Back 10 seconds">↺</button>
            <button className="icon-btn big" onClick={togglePlay} aria-label={playing ? 'Pause' : 'Play'}>
              {playing ? '⏸' : '▶'}
            </button>
            <button className="icon-btn" onClick={() => seekBy(SEEK_STEP_MS)} aria-label="Forward 10 seconds">↻</button>
            <button className="icon-btn" onClick={() => goNext()} aria-label="Next">⏭</button>
            <button
              className="icon-btn"
              onClick={() => setRepeat((r) => (r === 'off' ? 'all' : r === 'all' ? 'one' : 'off'))}
              aria-label="Repeat"
              style={{ opacity: repeat === 'off' ? 0.45 : 1 }}
            >
              {repeat === 'one' ? '🔂' : '🔁'}
            </button>
          </div>
          <div className="player-buttons secondary">
            <button className="icon-btn" onClick={() => applyVolume(volume, !muted)} aria-label={muted ? 'Unmute' : 'Mute'}>
              {muted || volume === 0 ? '🔇' : volume < 0.5 ? '🔈' : '🔊'}
            </button>
            <button className="icon-btn" onClick={() => setSheet('speed')} aria-label="Playback speed">{rate}×</button>
            <button className="icon-btn" onClick={() => setSheet('subs')} aria-label="Subtitles">💬</button>
            {audioTracks.length > 1 && (
              <button className="icon-btn" onClick={() => setSheet('audio')} aria-label="Audio track">🎧</button>
            )}
            <button className="icon-btn" onClick={() => void togglePip()} aria-label="Picture in picture">⧉</button>
            <button className="icon-btn" onClick={() => setSheet('aspect')} aria-label="Aspect ratio">🖼</button>
            <button className="icon-btn" onClick={() => setSheet('sleep')} aria-label="Sleep timer" style={{ opacity: sleep === 'off' ? 0.45 : 1 }}>⏾</button>
            <button className="icon-btn" onClick={() => setSheet('display')} aria-label="Brightness and volume">☀</button>
            <button className="icon-btn" onClick={toggleFullscreen} aria-label="Fullscreen">⛶</button>
          </div>
        </div>
      )}

      {/* bottom sheets */}
      {sheet === 'playlist' && (
        <Sheet onClose={() => setSheet(null)} title="Playlist">
          {queue.map((q, i) => (
            <button key={q.fileId} className={`sheet-row ${i === index ? 'active' : ''}`} onClick={() => { setSheet(null); void loadIndex(i); }}>
              <span className="num">{i + 1}</span>
              <span className="grow"><strong>{q.label}</strong>{q.sublabel && <small>{q.sublabel}</small>}</span>
              {i === index && <span>▶</span>}
            </button>
          ))}
        </Sheet>
      )}
      {sheet === 'speed' && (
        <Sheet onClose={() => setSheet(null)} title="Playback speed">
          <div className="chip-row">
            {SPEEDS.map((s) => (
              <button key={s} className={`chip ${rate === s ? 'active' : ''}`} onClick={() => { setRate(s); setSheet(null); }}>
                {s}×
              </button>
            ))}
          </div>
        </Sheet>
      )}
      {sheet === 'sleep' && (
        <Sheet onClose={() => setSheet(null)} title="Sleep timer">
          {SLEEP_OPTIONS.map((o) => (
            <button key={o.id} className={`sheet-row ${sleep === o.id ? 'active' : ''}`} onClick={() => setSleepTimer(o.id)}>
              <span className="grow">{o.label}</span>
              {sleep === o.id && <span>✓</span>}
            </button>
          ))}
        </Sheet>
      )}
      {sheet === 'aspect' && (
        <Sheet onClose={() => setSheet(null)} title="Picture (aspect)">
          <div className="chip-row">
            {(['contain', 'cover', 'stretch', 'original', '16:9', '4:3'] as Fit[]).map((f) => (
              <button key={f} className={`chip ${fit === f ? 'active' : ''}`} onClick={() => { setFit(f); setSheet(null); }}>
                {f === 'stretch' ? 'Stretch' : f === 'original' ? 'Original' : f}
              </button>
            ))}
          </div>
        </Sheet>
      )}
      {sheet === 'audio' && (
        <Sheet onClose={() => setSheet(null)} title="Audio track">
          {audioTracks.map((t, i) => (
            <button key={i} className={`sheet-row ${i === audioIdx ? 'active' : ''}`} onClick={() => { selectAudioTrack(i); setSheet(null); }}>
              <span className="grow">{t.label}{t.language && <small> · {t.language}</small>}</span>
              {i === audioIdx && <span>✓</span>}
            </button>
          ))}
        </Sheet>
      )}
      {sheet === 'subs' && (
        <Sheet onClose={() => setSheet(null)} title="Subtitles">
          <button className={`sheet-row ${activeSub === 'off' ? 'active' : ''}`} onClick={() => void selectSubtitle('off')}>
            <span className="grow">Off</span>{activeSub === 'off' && <span>✓</span>}
          </button>
          {subTracks.map((t) => (
            <button key={t.id} className={`sheet-row ${activeSub === t.id ? 'active' : ''}`} onClick={() => void selectSubtitle(t.id)}>
              <span className="grow">{t.label}</span>{activeSub === t.id && <span>✓</span>}
            </button>
          ))}
          <label className="sheet-row">
            <span className="grow">Load .srt / .vtt file…</span>
            <input
              type="file"
              accept=".srt,.vtt"
              hidden
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) void loadSubtitleFile(f);
                e.target.value = '';
              }}
            />
          </label>
          {activeSub !== 'off' && (
            <div className="sub-style">
              <label>Delay <input type="range" min={-10} max={10} step={0.5} value={subDelay} onChange={(e) => setSubDelay(Number(e.target.value))} /> {subDelay.toFixed(1)}s</label>
              <label>Size <input type="range" min={12} max={36} step={1} value={subSize} onChange={(e) => setSubSize(Number(e.target.value))} /> {subSize}px</label>
              <label>Color <input type="color" value={subColor} onChange={(e) => setSubColor(e.target.value)} /></label>
              <label>Background <input type="color" value={subBg.startsWith('#') ? subBg : '#000000'} onChange={(e) => setSubBg(e.target.value)} /></label>
              <div className="chip-row">
                {(['bottom', 'top'] as const).map((p) => (
                  <button key={p} className={`chip ${subPos === p ? 'active' : ''}`} onClick={() => setSubPos(p)}>{p}</button>
                ))}
              </div>
            </div>
          )}
        </Sheet>
      )}
      {sheet === 'display' && (
        <Sheet onClose={() => setSheet(null)} title="Display & volume">
          <label className="sheet-slider">
            Brightness {isNative ? '(app window)' : '(simulated)'}
            <input type="range" min={5} max={100} value={Math.round(brightness * 100)} onChange={(e) => applyBrightness(Number(e.target.value) / 100)} />
          </label>
          <label className="sheet-slider">
            Volume {isNative ? '(device)' : '(app)'}
            <input type="range" min={0} max={100} value={Math.round(volume * 100)} onChange={(e) => applyVolume(Number(e.target.value) / 100)} />
          </label>
        </Sheet>
      )}
    </div>
  );
}

function Sheet({ title, children, onClose }: { title: string; children: React.ReactNode; onClose: () => void }): React.JSX.Element {
  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="sheet" role="dialog" aria-label={title} onClick={(e) => e.stopPropagation()}>
        <div className="sheet-head">
          <strong>{title}</strong>
          <button className="icon-btn" onClick={onClose} aria-label="Close">✕</button>
        </div>
        <div className="sheet-body">{children}</div>
      </div>
    </div>
  );
}
