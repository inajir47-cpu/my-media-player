// Central library store: Dexie is the source of truth; this context holds a
// version counter so hooks re-query after every mutation, plus the transient
// player state and scan state. No prop drilling.

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  useSyncExternalStore,
} from 'react';
import { db, exportLibraryJson, getSetting, previewBackup, restoreBackup, setSetting } from '../db/database';
import { nativePickFolder, nativeReleaseFolder } from '../native/bridge';
import { scanAll, scanSessionFiles, scanSource, type ProgressCallback, type ScanProgress } from '../scan/scanner';
import { clearSessionFiles, registerSessionFiles } from '../media/playable';
import { dropArtworkUrl } from '../media/artwork';
import { applyMetadata as svcApplyMetadata, clearFetchedMetadata, searchMetadata, type MetaCandidate } from '../metadata/service';
import { buildHistoryEntry, hasReachedWatched } from '../player/playbackState';
import {
  newId,
  type CollectionRecord,
  type CustomMeta,
  type EpisodeRecord,
  type FileRecord,
  type FolderSource,
  type LocalReview,
  type TitleKind,
  type TitleRecord,
  type WhereToWatch,
} from '../types';

export interface PlayerQueueItem {
  fileId: string;
  episodeId?: string;
  titleId: string;
  label: string;
  sublabel?: string;
}

interface PlayerState {
  queue: PlayerQueueItem[];
  index: number;
}

// -- version bus -----------------------------------------------------------------
let version = 0;
const listeners = new Set<() => void>();
function subscribe(fn: () => void): () => void {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}
function emit(): void {
  version++;
  listeners.forEach((l) => { try { l(); } catch { /* ignore */ } });
}
function useVersion(): number {
  return useSyncExternalStore(subscribe, () => version);
}

/** Re-run an async query whenever the library version changes. */
export function useQuery<T>(fn: () => Promise<T>, deps: unknown[] = []): T | undefined {
  const v = useVersion();
  const [val, setVal] = useState<T | undefined>(undefined);
  const fnRef = useRef(fn);
  fnRef.current = fn;
  useEffect(() => {
    let live = true;
    fnRef.current().then(
      (r) => { if (live) setVal(r); },
      () => { if (live) setVal(undefined); },
    );
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [v, ...deps]);
  return val;
}

// -- context ---------------------------------------------------------------------

interface LibraryApi {
  refresh: () => void;
  scanning: ScanProgress | null;
  scanError: string | null;
  runScan: (sourceId?: string) => Promise<void>;
  cancelScan: () => void;
  addNativeFolder: () => Promise<void>;
  addWebFolder: () => Promise<void>;
  addSessionFiles: (files: FileList | File[]) => Promise<void>;
  removeSource: (id: string) => Promise<void>;
  sources: FolderSource[] | undefined;

  toggleFavorite: (id: string) => Promise<void>;
  toggleSaved: (id: string) => Promise<void>;
  markTitleWatched: (id: string, watched: boolean) => Promise<void>;
  updateCustomMeta: (id: string, patch: Partial<CustomMeta>) => Promise<void>;
  setWhereToWatch: (id: string, links: WhereToWatch[]) => Promise<void>;
  uploadPoster: (id: string, blob: Blob) => Promise<void>;
  searchMeta: (titleId: string) => Promise<MetaCandidate[]>;
  applyMeta: (titleId: string, c: MetaCandidate) => Promise<void>;
  clearMeta: (titleId: string) => Promise<void>;

  savePosition: (fileId: string, positionMs: number, durationMs?: number, commitHistory?: boolean) => Promise<void>;
  markEpisodeWatched: (episodeId: string, watched: boolean) => Promise<void>;
  markSeasonWatched: (titleId: string, season: number, watched: boolean) => Promise<void>;

  collections: CollectionRecord[] | undefined;
  createCollection: (name: string) => Promise<string>;
  renameCollection: (id: string, name: string) => Promise<void>;
  deleteCollection: (id: string) => Promise<void>;
  toggleInCollection: (collectionId: string, titleId: string) => Promise<void>;

  addReview: (titleId: string, r: Omit<LocalReview, 'id' | 'createdAt' | 'updatedAt'>) => Promise<void>;
  updateReview: (titleId: string, review: LocalReview) => Promise<void>;
  deleteReview: (titleId: string, reviewId: string) => Promise<void>;

  getSetting: <T>(key: string, fallback: T) => Promise<T>;
  setSetting: (key: string, value: unknown) => Promise<void>;
  exportJson: () => Promise<string>;
  previewImport: (json: string) => { titles: number; episodes: number; collections: number; history: number; artwork: number };
  restoreJson: (json: string) => Promise<void>;

  player: PlayerState | null;
  openPlayer: (queue: PlayerQueueItem[], index: number) => void;
  closePlayer: () => void;
}

const LibraryContext = createContext<LibraryApi | null>(null);

export function useLibrary(): LibraryApi {
  const ctx = useContext(LibraryContext);
  if (!ctx) throw new Error('useLibrary outside provider');
  return ctx;
}

export function LibraryProvider({ children }: { children: React.ReactNode }): React.JSX.Element {
  const [scanning, setScanning] = useState<ScanProgress | null>(null);
  const [scanError, setScanError] = useState<string | null>(null);
  const [player, setPlayer] = useState<PlayerState | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const refresh = useCallback(() => emit(), []);
  const sources = useQuery(() => db.sources.orderBy('addedAt').toArray());
  const collections = useQuery(() => db.collections.orderBy('updatedAt').reverse().toArray());

  const onProgress: ProgressCallback = useCallback((p) => setScanning({ ...p }), []);

  const runScan = useCallback(async (sourceId?: string) => {
    if (abortRef.current) return;
    const abort = new AbortController();
    abortRef.current = abort;
    setScanError(null);
    try {
      if (sourceId) {
        const source = await db.sources.get(sourceId);
        if (!source) throw new Error('Folder not found');
        await scanSource(source, onProgress, abort.signal);
      } else {
        await scanAll(onProgress, abort.signal);
      }
    } catch (e) {
      if ((e as Error)?.name !== 'AbortError') setScanError((e as Error).message);
    } finally {
      abortRef.current = null;
      setScanning(null);
      emit();
    }
  }, [onProgress]);

  const cancelScan = useCallback(() => abortRef.current?.abort(), []);

  const addNativeFolder = useCallback(async () => {
    const picked = await nativePickFolder();
    if (!picked) throw new Error('Folder picker is only available in the native app.');
    const source: FolderSource = {
      id: newId('src'),
      displayName: picked.displayName,
      treeUri: picked.treeUri,
      addedAt: Date.now(),
    };
    await db.sources.add(source);
    emit();
    await runScan(source.id);
  }, [runScan]);

  const addWebFolder = useCallback(async () => {
    if (!('showDirectoryPicker' in window)) {
      throw new Error('This browser cannot pick folders — use the file fallback instead.');
    }
    const handle = await (window as unknown as {
      showDirectoryPicker: (o?: { mode: string }) => Promise<FileSystemDirectoryHandle>;
    }).showDirectoryPicker({ mode: 'read' });
    const handleId = newId('hdl');
    await db.handles.put({ id: handleId, handle });
    const source: FolderSource = {
      id: newId('src'),
      displayName: handle.name,
      webHandleId: handleId,
      addedAt: Date.now(),
    };
    await db.sources.add(source);
    emit();
    await runScan(source.id);
  }, [runScan]);

  const addSessionFiles = useCallback(async (files: FileList | File[]) => {
    if (!files || files.length === 0) return;
    registerSessionFiles(files);
    const first = (files as File[])[0] ?? (files as FileList)[0];
    const rel = (first as File & { webkitRelativePath?: string }).webkitRelativePath || '';
    const displayName = rel.split('/')[0] || 'Selected files';
    await scanSessionFiles(files, displayName);
    emit();
  }, []);

  const removeSource = useCallback(async (id: string) => {
    const source = await db.sources.get(id);
    const fileIds = await db.files.where('sourceId').equals(id).primaryKeys();
    await db.transaction('rw', [db.files, db.episodes, db.sources, db.handles], async () => {
      await db.files.where('sourceId').equals(id).delete();
      // Episodes whose file is gone lose their file link (title metadata stays).
      for (const ep of await db.episodes.where('fileId').anyOf(fileIds).toArray()) {
        await db.episodes.delete(ep.id);
      }
      if (source?.treeUri) await nativeReleaseFolder(source.treeUri).catch(() => undefined);
      if (source?.webHandleId) await db.handles.delete(source.webHandleId);
      await db.sources.delete(id);
    });
    if (id.startsWith('src_session_')) clearSessionFiles();
    emit();
  }, []);

  const toggleFavorite = useCallback(async (id: string) => {
    const t = await db.titles.get(id);
    if (t) { await db.titles.update(id, { favorite: !t.favorite, updatedAt: Date.now() }); emit(); }
  }, []);

  const toggleSaved = useCallback(async (id: string) => {
    const t = await db.titles.get(id);
    if (t) { await db.titles.update(id, { saved: !t.saved, updatedAt: Date.now() }); emit(); }
  }, []);

  const markTitleWatched = useCallback(async (id: string, watched: boolean) => {
    await db.transaction('rw', [db.titles, db.episodes, db.files], async () => {
      await db.titles.update(id, { watched, updatedAt: Date.now() });
      const eps = await db.episodes.where('titleId').equals(id).toArray();
      for (const ep of eps) {
        await db.episodes.update(ep.id, { watched, positionMs: watched ? (ep.durationMs ?? ep.positionMs) : 0 });
        if (ep.fileId) await db.files.update(ep.fileId, { watched, positionMs: watched ? ep.positionMs : 0 });
      }
      const files = await db.files.where('titleId').equals(id).toArray();
      for (const f of files) await db.files.update(f.id, { watched });
    });
    emit();
  }, []);

  const updateCustomMeta = useCallback(async (id: string, patch: Partial<CustomMeta>) => {
    const t = await db.titles.get(id);
    if (!t) return;
    await db.titles.update(id, { custom: { ...t.custom, ...patch }, updatedAt: Date.now() });
    emit();
  }, []);

  const setWhereToWatch = useCallback(async (id: string, links: WhereToWatch[]) => {
    const t = await db.titles.get(id);
    if (!t) return;
    await db.titles.update(id, { custom: { ...t.custom, whereToWatch: links }, updatedAt: Date.now() });
    emit();
  }, []);

  const uploadPoster = useCallback(async (id: string, blob: Blob) => {
    const t = await db.titles.get(id);
    if (!t) return;
    const artId = newId('art');
    await db.artwork.put({ id: artId, blob, kind: 'custom', updatedAt: Date.now() });
    if (t.custom.posterArtworkId) dropArtworkUrl(t.custom.posterArtworkId);
    await db.titles.update(id, { custom: { ...t.custom, posterArtworkId: artId }, updatedAt: Date.now() });
    emit();
  }, []);

  const searchMeta = useCallback(async (titleId: string): Promise<MetaCandidate[]> => {
    const t = await db.titles.get(titleId);
    if (!t) return [];
    return searchMetadata(t.custom.name ?? t.name, t.kind, t.year);
  }, []);

  const applyMeta = useCallback(async (titleId: string, c: MetaCandidate) => {
    await svcApplyMetadata(titleId, c);
    emit();
  }, []);

  const clearMeta = useCallback(async (titleId: string) => {
    await clearFetchedMetadata(titleId);
    emit();
  }, []);

  const savePosition = useCallback(async (fileId: string, positionMs: number, durationMs?: number, commitHistory = false) => {
    const file = await db.files.get(fileId);
    if (!file) return;
    const watched = durationMs !== undefined && hasReachedWatched(positionMs, durationMs);
    const now = Date.now();
    await db.transaction('rw', [db.files, db.episodes, db.titles, db.history], async () => {
      await db.files.update(fileId, { positionMs, durationMs: durationMs ?? file.durationMs, watched, lastPlayedAt: now });
      if (file.episodeId) {
        await db.episodes.update(file.episodeId, { positionMs, durationMs: durationMs, watched, lastPlayedAt: now });
      }
      if (file.titleId) {
        const title = await db.titles.get(file.titleId);
        if (title) {
          const newSession = !title.lastPlayedAt || now - title.lastPlayedAt > 10 * 60_000;
          await db.titles.update(file.titleId, {
            lastPlayedAt: now,
            playCount: newSession ? title.playCount + 1 : title.playCount,
            watched: title.kind !== 'show' ? watched || title.watched : title.watched,
            updatedAt: now,
          });
        }
      }
      // History records playback sessions, not every autosave tick.
      if (commitHistory) {
        await db.history.add({
          ...buildHistoryEntry({
            fileId,
            titleId: file.titleId ?? '',
            episodeId: file.episodeId,
            startedAt: now - 60_000,
            endedAt: now,
            positionMs,
            durationMs,
          }),
          id: newId('h'),
        });
      }
    });
    emit();
  }, []);

  const markEpisodeWatched = useCallback(async (episodeId: string, watched: boolean) => {
    const ep = await db.episodes.get(episodeId);
    if (!ep) return;
    await db.transaction('rw', [db.episodes, db.files], async () => {
      await db.episodes.update(episodeId, { watched, positionMs: watched ? (ep.durationMs ?? 0) : 0 });
      await db.files.update(ep.fileId, { watched, positionMs: watched ? (ep.durationMs ?? 0) : 0 });
    });
    emit();
  }, []);

  const markSeasonWatched = useCallback(async (titleId: string, season: number, watched: boolean) => {
    const eps = await db.episodes.where('[titleId+season+episode]').between([titleId, season, 0], [titleId, season, 99999]).toArray();
    await db.transaction('rw', [db.episodes, db.files], async () => {
      for (const ep of eps) {
        await db.episodes.update(ep.id, { watched, positionMs: watched ? (ep.durationMs ?? 0) : 0 });
        await db.files.update(ep.fileId, { watched });
      }
    });
    emit();
  }, []);

  const createCollection = useCallback(async (name: string): Promise<string> => {
    const id = newId('col');
    const now = Date.now();
    await db.collections.add({ id, name, titleIds: [], createdAt: now, updatedAt: now });
    emit();
    return id;
  }, []);

  const renameCollection = useCallback(async (id: string, name: string) => {
    await db.collections.update(id, { name, updatedAt: Date.now() });
    emit();
  }, []);

  const deleteCollection = useCallback(async (id: string) => {
    await db.collections.delete(id);
    emit();
  }, []);

  const toggleInCollection = useCallback(async (collectionId: string, titleId: string) => {
    const c = await db.collections.get(collectionId);
    if (!c) return;
    const has = c.titleIds.includes(titleId);
    const titleIds = has ? c.titleIds.filter((t) => t !== titleId) : [...c.titleIds, titleId];
    await db.collections.update(collectionId, { titleIds, updatedAt: Date.now() });
    emit();
  }, []);

  const addReview = useCallback(async (titleId: string, r: Omit<LocalReview, 'id' | 'createdAt' | 'updatedAt'>) => {
    const t = await db.titles.get(titleId);
    if (!t) return;
    const now = Date.now();
    const review: LocalReview = { ...r, id: newId('rev'), createdAt: now, updatedAt: now };
    await db.titles.update(titleId, { reviews: [...t.reviews, review], updatedAt: now });
    emit();
  }, []);

  const updateReview = useCallback(async (titleId: string, review: LocalReview) => {
    const t = await db.titles.get(titleId);
    if (!t) return;
    await db.titles.update(titleId, {
      reviews: t.reviews.map((r) => (r.id === review.id ? { ...review, updatedAt: Date.now() } : r)),
      updatedAt: Date.now(),
    });
    emit();
  }, []);

  const deleteReview = useCallback(async (titleId: string, reviewId: string) => {
    const t = await db.titles.get(titleId);
    if (!t) return;
    await db.titles.update(titleId, {
      reviews: t.reviews.filter((r) => r.id !== reviewId),
      updatedAt: Date.now(),
    });
    emit();
  }, []);

  const getSettingCb = useCallback(<T,>(key: string, fallback: T): Promise<T> => getSetting(key, fallback), []);
  const setSettingCb = useCallback(async (key: string, value: unknown) => {
    await setSetting(key, value);
    emit();
  }, []);

  const exportJson = useCallback(() => exportLibraryJson(), []);
  const previewImport = useCallback((json: string) => previewBackup(json), []);
  const restoreJson = useCallback(async (json: string) => {
    await restoreBackup(json);
    emit();
  }, []);

  const openPlayer = useCallback((queue: PlayerQueueItem[], index: number) => {
    setPlayer({ queue, index });
  }, []);
  const closePlayer = useCallback(() => setPlayer(null), []);

  const api: LibraryApi = {
    refresh, scanning, scanError, runScan, cancelScan,
    addNativeFolder, addWebFolder, addSessionFiles, removeSource, sources,
    toggleFavorite, toggleSaved, markTitleWatched, updateCustomMeta, setWhereToWatch,
    uploadPoster, searchMeta, applyMeta, clearMeta,
    savePosition, markEpisodeWatched, markSeasonWatched,
    collections, createCollection, renameCollection, deleteCollection, toggleInCollection,
    addReview, updateReview, deleteReview,
    getSetting: getSettingCb, setSetting: setSettingCb,
    exportJson, previewImport, restoreJson,
    player, openPlayer, closePlayer,
  };

  return <LibraryContext.Provider value={api}>{children}</LibraryContext.Provider>;
}

// -- shared query hooks ------------------------------------------------------------

export function useTitles(kind?: TitleKind): TitleRecord[] | undefined {
  return useQuery(async () => {
    const all = await db.titles.orderBy('sortName').toArray();
    return kind ? all.filter((t) => t.kind === kind) : all;
  }, [kind]);
}

export function useTitle(id: string | null): TitleRecord | undefined | null {
  return useQuery(async () => (id ? ((await db.titles.get(id)) ?? null) : null), [id]);
}

export function useEpisodes(titleId: string | null): EpisodeRecord[] | undefined {
  return useQuery(async () => {
    if (!titleId) return [];
    return db.episodes.where('titleId').equals(titleId).sortBy('[titleId+season+episode]').then((eps) =>
      eps.sort((a, b) => a.season - b.season || a.episode - b.episode),
    );
  }, [titleId]);
}

export function useTitleFiles(titleId: string | null): FileRecord[] | undefined {
  return useQuery(async () => {
    if (!titleId) return [];
    return db.files.where('titleId').equals(titleId).toArray();
  }, [titleId]);
}

export function useContinueWatching(): Array<{ file: FileRecord; episode?: EpisodeRecord; title?: TitleRecord }> | undefined {
  return useQuery(async () => {
    const files = await db.files
      .where('lastPlayedAt').above(0)
      .reverse()
      .limit(60)
      .toArray();
    const active = files.filter((f) => f.positionMs > 30_000 && !f.watched && !f.missing);
    const out: Array<{ file: FileRecord; episode?: EpisodeRecord; title?: TitleRecord }> = [];
    for (const f of active.slice(0, 20)) {
      out.push({
        file: f,
        episode: f.episodeId ? await db.episodes.get(f.episodeId) : undefined,
        title: f.titleId ? await db.titles.get(f.titleId) : undefined,
      });
    }
    return out;
  });
}

export function useRecentlyAdded(limit = 20): TitleRecord[] | undefined {
  return useQuery(() => db.titles.orderBy('addedAt').reverse().limit(limit).toArray(), [limit]);
}

export function useRecentlyPlayed(limit = 20): TitleRecord[] | undefined {
  return useQuery(async () => {
    const titles = await db.titles.where('lastPlayedAt').above(0).reverse().limit(limit).toArray();
    return titles.sort((a, b) => (b.lastPlayedAt ?? 0) - (a.lastPlayedAt ?? 0));
  }, [limit]);
}

export function useFavorites(): TitleRecord[] | undefined {
  // favorite is a plain boolean prop (booleans are not valid IndexedDB index
  // keys), so filter in memory instead of an indexed query.
  return useQuery(() => db.titles.filter((t) => t.favorite).sortBy('sortName'), []);
}

export function useSaved(): TitleRecord[] | undefined {
  return useQuery(() => db.titles.filter((t) => t.saved).sortBy('sortName'), []);
}
