// Artwork URL helper: blob / native-URI artwork records become object URLs.
// Cached per artwork id; revoked only when the artwork row is replaced.

import { useEffect, useState } from 'react';
import { db } from '../db/database';
import { nativePlayableUrl } from '../native/bridge';

const urlCache = new Map<string, string>();

export async function artworkUrl(id: string | undefined): Promise<string | null> {
  if (!id) return null;
  const cached = urlCache.get(id);
  if (cached) return cached;
  const rec = await db.artwork.get(id);
  if (!rec) return null;
  let url: string | null = null;
  if (rec.blob) {
    url = URL.createObjectURL(rec.blob);
  } else if (rec.nativeUri) {
    url = await nativePlayableUrl(rec.nativeUri);
  }
  if (url) urlCache.set(id, url);
  return url;
}

export function dropArtworkUrl(id: string): void {
  const url = urlCache.get(id);
  if (url) {
    URL.revokeObjectURL(url);
    urlCache.delete(id);
  }
}

/** React hook: artwork id -> playable URL (null while loading / unavailable). */
export function useArtworkUrl(id: string | undefined): string | null {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    let live = true;
    setUrl(null);
    if (!id) return;
    artworkUrl(id).then((u) => {
      if (live) setUrl(u);
    });
    return () => {
      live = false;
    };
  }, [id]);
  return url;
}
