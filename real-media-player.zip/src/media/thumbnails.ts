// Auto-generated video thumbnails: capture a frame with a hidden <video>
// + canvas, cache the JPEG blob in the artwork store. Runs lazily per
// episode — never during scanning, never for every card at once.

import { db } from '../db/database';
import { newId } from '../types';
import { resolvePlayableUrl } from './playable';

function captureFrame(videoUrl: string, atSeconds: number, timeoutMs = 20000): Promise<Blob | null> {
  return new Promise((resolve) => {
    const video = document.createElement('video');
    video.muted = true;
    (video as HTMLVideoElement & { playsInline?: boolean }).playsInline = true;
    video.preload = 'auto';
    let done = false;
    const finish = (blob: Blob | null) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      video.removeAttribute('src');
      video.load();
      resolve(blob);
    };
    const timer = setTimeout(() => finish(null), timeoutMs);
    video.onloadedmetadata = () => {
      const t = Math.min(Math.max(0, atSeconds), Math.max(0, video.duration - 0.5));
      try {
        video.currentTime = t;
      } catch {
        finish(null);
      }
    };
    video.onseeked = () => {
      try {
        if (!video.videoWidth) { finish(null); return; }
        const w = 320;
        const h = Math.round((video.videoHeight / video.videoWidth) * w);
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) { finish(null); return; }
        ctx.drawImage(video, 0, 0, w, h);
        canvas.toBlob((b) => finish(b), 'image/jpeg', 0.72);
      } catch {
        finish(null);
      }
    };
    video.onerror = () => finish(null);
    video.src = videoUrl;
  });
}

/**
 * Ensure an episode has a cached thumbnail. Returns the artwork id or null.
 * Captures at the stored preview start (a representative moment), else 25%.
 */
export async function ensureEpisodeThumbnail(episodeId: string): Promise<string | null> {
  const ep = await db.episodes.get(episodeId);
  if (!ep) return null;
  if (ep.artworkId) {
    const exists = await db.artwork.get(ep.artworkId);
    if (exists) return ep.artworkId;
  }
  const file = await db.files.get(ep.fileId);
  if (!file) return null;
  const url = await resolvePlayableUrl(file);
  if (!url) return null;
  try {
    const atMs = ep.previewStartMs ?? (file.durationMs ? file.durationMs * 0.25 : 30_000);
    const blob = await captureFrame(url, atMs / 1000);
    if (url.startsWith('blob:')) URL.revokeObjectURL(url);
    if (!blob) return null;
    const artId = newId('art');
    await db.artwork.put({ id: artId, blob, kind: 'thumbnail', updatedAt: Date.now() });
    await db.episodes.update(episodeId, { artworkId: artId });
    return artId;
  } catch {
    if (url.startsWith('blob:')) URL.revokeObjectURL(url);
    return null;
  }
}
