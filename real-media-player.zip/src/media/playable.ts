// Playable URL resolution. Native: the MediaBridge localhost server maps a
// content:// URI to an http://127.0.0.1 URL. Web: File System Access handles
// (persisted in IndexedDB) are re-resolved per session; a one-shot
// <input webkitdirectory> fallback keeps File objects in memory only.

import { db } from '../db/database';
import { nativePlayableUrl } from '../native/bridge';
import type { FileRecord } from '../types';

// -- session fallback (webkitdirectory): File objects live in memory only ------
const sessionFiles = new Map<string, File>();

export function registerSessionFiles(files: File[] | FileList): void {
  for (const f of Array.from(files)) {
    const rel = (f as File & { webkitRelativePath?: string }).webkitRelativePath || f.name;
    sessionFiles.set(`session://${rel}`, f);
  }
}

export function sessionUrlFor(uri: string): string | null {
  const f = sessionFiles.get(uri);
  return f ? URL.createObjectURL(f) : null;
}

export function clearSessionFiles(): void {
  sessionFiles.clear();
}

async function webFsFile(sourceId: string, relPath: string): Promise<File | null> {
  const source = await db.sources.get(sourceId);
  if (!source?.webHandleId) return null;
  const rec = await db.handles.get(source.webHandleId);
  const root = rec?.handle as FileSystemDirectoryHandle | undefined;
  if (!root || root.kind !== 'directory') return null;
  try {
    const perm = { mode: 'read' } as const;
    if ((await root.queryPermission(perm)) !== 'granted') {
      if ((await root.requestPermission(perm)) !== 'granted') return null;
    }
  } catch {
    return null;
  }
  try {
    const parts = relPath.split('/');
    let dir = root;
    for (let i = 0; i < parts.length - 1; i++) {
      dir = await dir.getDirectoryHandle(parts[i]);
    }
    const fh = await dir.getFileHandle(parts[parts.length - 1]);
    return fh.getFile();
  } catch {
    return null;
  }
}

/** Resolve a FileRecord to something a <video>/<audio> element can play. */
export async function resolvePlayableUrl(file: FileRecord): Promise<string | null> {
  if (file.missing) return null;
  if (file.uri.startsWith('content://')) {
    return nativePlayableUrl(file.uri);
  }
  if (file.uri.startsWith('session://')) {
    return sessionUrlFor(file.uri);
  }
  if (file.uri.startsWith('webfs://')) {
    const rest = file.uri.slice('webfs://'.length);
    const slash = rest.indexOf('/');
    if (slash < 0) return null;
    const f = await webFsFile(rest.slice(0, slash), rest.slice(slash + 1));
    return f ? URL.createObjectURL(f) : null;
  }
  return null;
}

/** Sibling subtitle files (.srt/.vtt) for a video/audio file. */
export async function siblingSubtitles(file: FileRecord): Promise<Array<{ label: string; url: string }>> {
  const subs = await db.files
    .where('titleId')
    .equals(file.titleId ?? '')
    .filter((f) => f.kind === 'subtitle' && !f.missing)
    .toArray();
  const base = file.name.replace(/\.[^.]+$/, '').toLowerCase();
  const out: Array<{ label: string; url: string }> = [];
  for (const s of subs) {
    const sbase = s.name.replace(/\.[^.]+$/, '').toLowerCase();
    if (!sbase.startsWith(base.slice(0, Math.min(base.length, 12)))) continue;
    const url = await resolvePlayableUrl(s);
    if (url) out.push({ label: s.name, url });
  }
  return out;
}
