// First-run folder setup. The app opens directly here when no library
// folders exist yet. Honest about what each platform can and cannot do.

import { useRef, useState } from 'react';
import { APP_NAME } from '../config';
import { useLibrary } from '../library/store';
import { isNative } from '../native/bridge';

export function LibrarySetup({ onDone }: { onDone: () => void }): React.JSX.Element {
  const { addNativeFolder, addWebFolder, addSessionFiles, scanning } = useLibrary();
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const canPickDir = !isNative && 'showDirectoryPicker' in window;

  const run = async (fn: () => Promise<void>) => {
    setBusy(true);
    setError('');
    try {
      await fn();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="setup">
      <div className="setup-card">
        <h1>{APP_NAME}</h1>
        <p className="dim">Your personal media library. No account, no server — just your files.</p>
        <h2>Add your media folders</h2>

        {isNative && (
          <>
            <button className="btn primary big" disabled={busy} onClick={() => void run(addNativeFolder)}>
              Choose a folder on this device
            </button>
            <p className="dim small">Uses Android&apos;s folder picker. Access survives restarts — you won&apos;t be asked again.</p>
          </>
        )}

        {canPickDir && (
          <>
            <button className="btn primary big" disabled={busy} onClick={() => void run(addWebFolder)}>
              Choose a folder
            </button>
            <p className="dim small">Uses the File System Access API. Some browsers forget the permission between visits — if playback breaks, just re-pick the folder in Settings.</p>
          </>
        )}

        {!isNative && !canPickDir && (
          <>
            <label className="btn primary big">
              Choose files…
              <input
                ref={fileInput} type="file" hidden multiple
                // @ts-expect-error webkitdirectory is non-standard but widely supported
                webkitdirectory=""
                onChange={(e) => {
                  const fl = e.target.files;
                  e.target.value = '';
                  if (fl?.length) void run(() => addSessionFiles(fl));
                }}
              />
            </label>
            <p className="dim small">
              This browser can&apos;t grant lasting folder access, so chosen files play for this session only.
              Your metadata and progress are still saved — reselect the files after a reload.
            </p>
          </>
        )}

        {scanning && (
          <p className="dim" role="status">
            Scanning {scanning.sourceName}: {scanning.scanned}/{scanning.total}…
          </p>
        )}
        {error && <p className="error" role="alert">{error}</p>}

        <button className="btn ghost" onClick={onDone}>Skip for now</button>
      </div>
    </div>
  );
}
