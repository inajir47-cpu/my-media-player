// Home: hero with local preview clips, Continue Watching, Recently Added,
// Recently Played, Favorites, Collections, and per-kind rows.

import { useEffect, useState } from 'react';
import { db } from '../db/database';
import {
  useContinueWatching,
  useFavorites,
  useLibrary,
  useRecentlyAdded,
  useRecentlyPlayed,
  useTitles,
} from '../library/store';
import { resolveMeta, type TitleRecord } from '../types';
import { Hero } from '../components/Hero';
import { MediaCard } from '../components/MediaCard';

function Row({ heading, children }: { heading: string; children: React.ReactNode }): React.JSX.Element | null {
  return (
    <section className="row-section" aria-label={heading}>
      <h2>{heading}</h2>
      <div className="h-scroll">{children}</div>
    </section>
  );
}

function progressOf(file: { positionMs: number; durationMs?: number }): number | undefined {
  if (file.durationMs && file.durationMs > 0) return Math.min(1, file.positionMs / file.durationMs);
  return undefined;
}

export function Home({ onOpen }: { onOpen: (id: string) => void }): React.JSX.Element {
  const continueWatching = useContinueWatching();
  const recent = useRecentlyAdded(20);
  const played = useRecentlyPlayed(20);
  const favorites = useFavorites();
  const shows = useTitles('show');
  const movies = useTitles('movie');
  const music = useTitles('music');
  const { collections, openPlayer } = useLibrary();

  const playContinue = async (fileId: string, titleId: string, episodeId?: string) => {
    const file = await db.files.get(fileId);
    if (!file) return;
    const title = titleId ? await db.titles.get(titleId) : undefined;
    const label = title ? resolveMeta(title).name : file.name;
    openPlayer([{ fileId, episodeId, titleId, label }], 0);
  };

  const collectionTitles = (ids: string[]): Promise<TitleRecord[]> =>
    db.titles.where('id').anyOf(ids).toArray();

  return (
    <div className="page">
      <Hero onOpen={onOpen} />

      {continueWatching && continueWatching.length > 0 && (
        <Row heading="Continue Watching">
          {continueWatching.map(({ file, title }) => (
            title && (
              <MediaCard
                key={file.id}
                title={title}
                onOpen={() => void playContinue(file.id, file.titleId ?? '', file.episodeId)}
                progress={progressOf(file)}
              />
            )
          ))}
        </Row>
      )}

      {recent && recent.length > 0 && (
        <Row heading="Recently Added">
          {recent.map((t) => <MediaCard key={t.id} title={t} onOpen={onOpen} />)}
        </Row>
      )}

      {played && played.length > 0 && (
        <Row heading="Recently Played">
          {played.map((t) => <MediaCard key={t.id} title={t} onOpen={onOpen} />)}
        </Row>
      )}

      {favorites && favorites.length > 0 && (
        <Row heading="Favorites">
          {favorites.map((t) => <MediaCard key={t.id} title={t} onOpen={onOpen} />)}
        </Row>
      )}

      {collections?.map((c) => (
        <CollectionRow key={c.id} name={c.name} ids={c.titleIds} load={collectionTitles} onOpen={onOpen} />
      ))}

      {shows && shows.length > 0 && (
        <Row heading="Shows">
          {shows.slice(0, 20).map((t) => <MediaCard key={t.id} title={t} onOpen={onOpen} />)}
        </Row>
      )}
      {movies && movies.length > 0 && (
        <Row heading="Movies">
          {movies.slice(0, 20).map((t) => <MediaCard key={t.id} title={t} onOpen={onOpen} />)}
        </Row>
      )}
      {music && music.length > 0 && (
        <Row heading="Music">
          {music.slice(0, 20).map((t) => <MediaCard key={t.id} title={t} onOpen={onOpen} />)}
        </Row>
      )}

      {(!recent || recent.length === 0) && (
        <div className="empty">
          <h2>Your library is empty</h2>
          <p>Add a folder with your movies, shows or music in Settings → Library to get started.</p>
        </div>
      )}
    </div>
  );
}

function CollectionRow({ name, ids, load, onOpen }: {
  name: string;
  ids: string[];
  load: (ids: string[]) => Promise<TitleRecord[]>;
  onOpen: (id: string) => void;
}): React.JSX.Element | null {
  const [titles, setTitles] = useState<TitleRecord[] | null>(null);
  useEffect(() => {
    let live = true;
    if (ids.length) void load(ids).then((t) => { if (live) setTitles(t); });
    else setTitles([]);
    return () => { live = false; };
  }, [ids, load]);
  if (!titles || titles.length === 0) return null;
  return (
    <Row heading={name}>
      {titles.map((t) => <MediaCard key={t.id} title={t} onOpen={onOpen} />)}
    </Row>
  );
}
