// Browse grids for Shows / Movies / Music / Saved with genre, year and
// watched filters plus sorting. All offline, against the local index.

import { useMemo, useState } from 'react';
import { useSaved, useTitles } from '../library/store';
import { resolveMeta, type TitleKind, type TitleRecord } from '../types';
import { MediaCard } from '../components/MediaCard';

type SortKey = 'name' | 'added' | 'played' | 'year' | 'rating';

const SORTS: Array<{ id: SortKey; label: string }> = [
  { id: 'name', label: 'Title' },
  { id: 'added', label: 'Recently added' },
  { id: 'played', label: 'Last played' },
  { id: 'year', label: 'Year' },
  { id: 'rating', label: 'Rating' },
];

export function Browse({ kind, onOpen }: { kind: TitleKind | 'saved'; onOpen: (id: string) => void }): React.JSX.Element {
  const shows = useTitles('show');
  const movies = useTitles('movie');
  const music = useTitles('music');
  const saved = useSaved();
  const [genre, setGenre] = useState('');
  const [year, setYear] = useState('');
  const [watched, setWatched] = useState<'all' | 'watched' | 'unwatched'>('all');
  const [sort, setSort] = useState<SortKey>('name');
  const [query, setQuery] = useState('');

  const base: TitleRecord[] | undefined =
    kind === 'show' ? shows : kind === 'movie' ? movies : kind === 'music' ? music : saved;

  const genres = useMemo(() => {
    const s = new Set<string>();
    for (const t of base ?? []) for (const g of resolveMeta(t).genres) s.add(g);
    return [...s].sort();
  }, [base]);

  const years = useMemo(() => {
    const s = new Set<number>();
    for (const t of base ?? []) {
      const y = resolveMeta(t).year;
      if (y) s.add(y);
    }
    return [...s].sort((a, b) => b - a);
  }, [base]);

  const filtered = useMemo(() => {
    let list = [...(base ?? [])];
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter((t) => resolveMeta(t).name.toLowerCase().includes(q));
    }
    if (genre) list = list.filter((t) => resolveMeta(t).genres.includes(genre));
    if (year) list = list.filter((t) => resolveMeta(t).year === Number(year));
    if (watched === 'watched') list = list.filter((t) => t.watched);
    if (watched === 'unwatched') list = list.filter((t) => !t.watched);
    const meta = (t: TitleRecord) => resolveMeta(t);
    switch (sort) {
      case 'name': list.sort((a, b) => a.sortName.localeCompare(b.sortName)); break;
      case 'added': list.sort((a, b) => b.addedAt - a.addedAt); break;
      case 'played': list.sort((a, b) => (b.lastPlayedAt ?? 0) - (a.lastPlayedAt ?? 0)); break;
      case 'year': list.sort((a, b) => (meta(b).year ?? 0) - (meta(a).year ?? 0)); break;
      case 'rating': list.sort((a, b) => (meta(b).rating ?? -1) - (meta(a).rating ?? -1)); break;
    }
    return list;
  }, [base, query, genre, year, watched, sort]);

  const heading = kind === 'show' ? 'Shows' : kind === 'movie' ? 'Movies' : kind === 'music' ? 'Music' : 'Saved';

  return (
    <div className="page">
      <h1 className="page-title">{heading}</h1>
      <div className="filters">
        <input
          className="filter-input"
          placeholder={`Filter ${heading.toLowerCase()}…`}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          aria-label={`Filter ${heading}`}
        />
        <select value={genre} onChange={(e) => setGenre(e.target.value)} aria-label="Genre filter">
          <option value="">All genres</option>
          {genres.map((g) => <option key={g} value={g}>{g}</option>)}
        </select>
        <select value={year} onChange={(e) => setYear(e.target.value)} aria-label="Year filter">
          <option value="">All years</option>
          {years.map((y) => <option key={y} value={y}>{y}</option>)}
        </select>
        <select value={watched} onChange={(e) => setWatched(e.target.value as typeof watched)} aria-label="Watched filter">
          <option value="all">All</option>
          <option value="watched">Watched</option>
          <option value="unwatched">Unwatched</option>
        </select>
        <select value={sort} onChange={(e) => setSort(e.target.value as SortKey)} aria-label="Sort">
          {SORTS.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
        </select>
      </div>
      {base === undefined ? (
        <div className="grid"><div className="card"><div className="card-art skeleton" /></div></div>
      ) : filtered.length === 0 ? (
        <div className="empty">
          <p className="dim">Nothing here{query || genre || year || watched !== 'all' ? ' matches those filters' : ' yet'}.</p>
        </div>
      ) : (
        <div className="grid">
          {filtered.map((t) => <MediaCard key={t.id} title={t} onOpen={onOpen} />)}
        </div>
      )}
    </div>
  );
}
