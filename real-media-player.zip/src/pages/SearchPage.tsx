// Global search: instant, offline, against the local index. Filters for
// type, genre, year, watched state and favorites.

import { useMemo, useState } from 'react';
import { useTitles } from '../library/store';
import { resolveMeta, type TitleKind } from '../types';
import { MediaCard } from '../components/MediaCard';

export function SearchPage({ onOpen }: { onOpen: (id: string) => void }): React.JSX.Element {
  const titles = useTitles();
  const [query, setQuery] = useState('');
  const [type, setType] = useState<'' | TitleKind>('');
  const [genre, setGenre] = useState('');
  const [watched, setWatched] = useState<'all' | 'watched' | 'unwatched'>('all');
  const [favoritesOnly, setFavoritesOnly] = useState(false);

  const genres = useMemo(() => {
    const s = new Set<string>();
    for (const t of titles ?? []) for (const g of resolveMeta(t).genres) s.add(g);
    return [...s].sort();
  }, [titles]);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return (titles ?? [])
      .filter((t) => {
        if (type && t.kind !== type) return false;
        if (watched === 'watched' && !t.watched) return false;
        if (watched === 'unwatched' && t.watched) return false;
        if (favoritesOnly && !t.favorite) return false;
        if (genre && !resolveMeta(t).genres.includes(genre)) return false;
        if (!q) return true;
        const m = resolveMeta(t);
        return (
          m.name.toLowerCase().includes(q) ||
          (m.synopsis ?? '').toLowerCase().includes(q) ||
          m.genres.some((g) => g.toLowerCase().includes(q))
        );
      })
      .sort((a, b) => a.sortName.localeCompare(b.sortName))
      .slice(0, 200);
  }, [titles, query, type, genre, watched, favoritesOnly]);

  return (
    <div className="page">
      <h1 className="page-title">Search</h1>
      <input
        className="search-box"
        placeholder="Search your library…"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        autoFocus
        aria-label="Search your library"
      />
      <div className="filters">
        <select value={type} onChange={(e) => setType(e.target.value as '' | TitleKind)} aria-label="Type filter">
          <option value="">All types</option>
          <option value="show">Shows</option>
          <option value="movie">Movies</option>
          <option value="music">Music</option>
        </select>
        <select value={genre} onChange={(e) => setGenre(e.target.value)} aria-label="Genre filter">
          <option value="">All genres</option>
          {genres.map((g) => <option key={g} value={g}>{g}</option>)}
        </select>
        <select value={watched} onChange={(e) => setWatched(e.target.value as typeof watched)} aria-label="Watched filter">
          <option value="all">All</option>
          <option value="watched">Watched</option>
          <option value="unwatched">Unwatched</option>
        </select>
        <button className={`chip ${favoritesOnly ? 'active' : ''}`} onClick={() => setFavoritesOnly((f) => !f)} aria-pressed={favoritesOnly}>
          ♥ Favorites
        </button>
      </div>
      {query.trim() === '' && !type && !genre ? (
        <p className="dim">Type to search titles, synopses and genres. Works fully offline.</p>
      ) : results.length === 0 ? (
        <p className="dim">No matches.</p>
      ) : (
        <div className="grid">
          {results.map((t) => <MediaCard key={t.id} title={t} onOpen={onOpen} />)}
        </div>
      )}
    </div>
  );
}
