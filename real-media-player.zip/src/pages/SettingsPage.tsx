// Settings: Playback, Gestures, Library, Backup, Storage, About.

import { useEffect, useRef, useState } from 'react';
import { APP_NAME } from '../config';
import { db } from '../db/database';
import { useLibrary } from '../library/store';
import { isNative } from '../native/bridge';

export interface GestureSettings {
  seek: boolean;
  brightness: boolean;
  volume: boolean;
  doubleTap: boolean;
}

export const DEFAULT_GESTURES: GestureSettings = { seek: true, brightness: true, volume: true, doubleTap: true };

function Section({ title, children }: { title: string; children: React.ReactNode }): React.JSX.Element {
  return (
    <section className="settings-section" aria-label={title}>
      <h2>{title}</h2>
      {children}
    </section>
  );
}

export function SettingsPage(): React.JSX.Element {
  const lib = useLibrary();
  const {
    sources, runScan, cancelScan, scanning, scanError,
    addNativeFolder, addWebFolder, addSessionFiles, removeSource,
    getSetting, setSetting, exportJson, previewImport, restoreJson,
  } = lib;
  const [autoplayNext, setAutoplayNext] = useState(true);
  const [playerRate, setPlayerRate] = useState(1);
  const [gestures, setGestures] = useState<GestureSettings>(DEFAULT_GESTURES);
  const [busy, setBusy] = useState('');
  const [message, setMessage] = useState('');
  const [importPreview, setImportPreview] = useState<null | { counts: ReturnType<typeof previewImport>; json: string }>(null);
  const [storageInfo, setStorageInfo] = useState('');
  const fileInput = useRef<HTMLInputElement>(null);
  const backupInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    getSetting('autoplayNext', true).then(setAutoplayNext).catch(() => undefined);
    getSetting('playerRate', 1).then((r) => setPlayerRate(typeof r === 'number' ? r : 1)).catch(() => undefined);
    getSetting('gestures', DEFAULT_GESTURES).then(setGestures).catch(() => undefined);
    if (navigator.storage?.estimate) {
      navigator.storage.estimate().then((e) => {
        const mb = e.usage ? (e.usage / 1048576).toFixed(1) : '0';
        setStorageInfo(`${mb} MB used on this device`);
      }).catch(() => undefined);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const withBusy = async (label: string, fn: () => Promise<void>) => {
    setBusy(label);
    setMessage('');
    try {
      await fn();
      setMessage(`${label} done.`);
    } catch (e) {
      setMessage(`${label} failed: ${(e as Error).message}`);
    } finally {
      setBusy('');
    }
  };

  const saveGestures = (g: GestureSettings) => {
    setGestures(g);
    void setSetting('gestures', g);
  };

  return (
    <div className="page settings">
      <h1 className="page-title">Settings</h1>
      {message && <p className="notice" role="status">{message}</p>}
      {scanError && <p className="error" role="alert">Scan error: {scanError}</p>}

      <Section title="Playback">
        <label className="check">
          <input
            type="checkbox" checked={autoplayNext}
            onChange={(e) => { setAutoplayNext(e.target.checked); void setSetting('autoplayNext', e.target.checked); }}
          />
          Autoplay next episode
        </label>
        <label>
          Default speed
          <select value={playerRate} onChange={(e) => { const v = Number(e.target.value); setPlayerRate(v); void setSetting('playerRate', v); }}>
            {[0.5, 0.75, 1, 1.25, 1.5, 2].map((s) => <option key={s} value={s}>{s}×</option>)}
          </select>
        </label>
      </Section>

      <Section title="Gestures">
        <p className="dim small">Player touch gestures. Single tap always shows/hides the controls.</p>
        {([
          ['seek', 'Horizontal swipe — seek'],
          ['brightness', 'Swipe up/down on left — brightness'],
          ['volume', 'Swipe up/down on right — volume'],
          ['doubleTap', 'Double-tap left/right — skip ∓10 s, center — play/pause'],
        ] as Array<[keyof GestureSettings, string]>).map(([key, label]) => (
          <label key={key} className="check">
            <input
              type="checkbox" checked={gestures[key]}
              onChange={(e) => saveGestures({ ...gestures, [key]: e.target.checked })}
            />
            {label}
          </label>
        ))}
        {!isNative && <p className="dim small">On the web, brightness is a simulated dimming overlay (browsers expose no display-brightness API).</p>}
      </Section>

      <Section title="Library">
        {(sources ?? []).map((s) => (
          <div key={s.id} className="sheet-row">
            <span className="grow">
              <strong>{s.displayName}</strong>
              <small className="dim">{s.lastScanAt ? ` · scanned ${new Date(s.lastScanAt).toLocaleString()}` : ' · not scanned yet'}</small>
            </span>
            <button className="btn small" onClick={() => void withBusy('Rescan', () => runScan(s.id))} disabled={!!busy}>Rescan</button>
            <button className="btn small" onClick={() => {
              if (window.confirm(`Remove “${s.displayName}” from the library? Your files stay on disk; titles built only from this folder lose their file links.`)) {
                void withBusy('Remove', () => removeSource(s.id));
              }
            }} disabled={!!busy}>Remove</button>
          </div>
        ))}
        {(sources ?? []).length === 0 && <p className="dim">No folders yet.</p>}
        <div className="row wrap">
          {isNative && (
            <button className="btn" onClick={() => void withBusy('Add folder', addNativeFolder)} disabled={!!busy}>＋ Add folder (Android)</button>
          )}
          {!isNative && 'showDirectoryPicker' in window && (
            <button className="btn" onClick={() => void withBusy('Add folder', addWebFolder)} disabled={!!busy}>＋ Add folder</button>
          )}
          {!isNative && !('showDirectoryPicker' in window) && (
            <label className="btn">
              ＋ Choose files…
              <input
                ref={fileInput} type="file" hidden multiple
                // @ts-expect-error webkitdirectory is non-standard but widely supported
                webkitdirectory=""
                onChange={(e) => {
                  const fl = e.target.files;
                  if (fl?.length) void withBusy('Add files', () => addSessionFiles(fl));
                  e.target.value = '';
                }}
              />
            </label>
          )}
          <button className="btn" onClick={() => void withBusy('Rescan all', () => runScan())} disabled={!!busy || (sources ?? []).length === 0}>
            Rescan all
          </button>
          {scanning && (
            <button className="btn" onClick={cancelScan}>Cancel scan ({scanning.scanned}/{scanning.total})</button>
          )}
        </div>
        {scanning && (
          <div className="scan-progress" role="status">
            <div className="scan-bar"><div style={{ width: scanning.total ? `${Math.round((scanning.scanned / scanning.total) * 100)}%` : 0 }} /></div>
            <p className="small dim">
              {scanning.sourceName}: {scanning.scanned}/{scanning.total} — +{scanning.added} new, {scanning.skipped} skipped, {scanning.errors} errors
            </p>
          </div>
        )}
        {!isNative && (
          <p className="dim small">
            Browsers can&apos;t remember folder access between visits for security reasons. If playback stops working after a reload, re-pick the folder above — your metadata, posters and progress are kept.
          </p>
        )}
      </Section>

      <Section title="Backup">
        <div className="row wrap">
          <button className="btn" onClick={() => void withBusy('Export', async () => {
            const json = await exportJson();
            const blob = new Blob([json], { type: 'application/json' });
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = `my-media-backup-${new Date().toISOString().slice(0, 10)}.json`;
            a.click();
            setTimeout(() => URL.revokeObjectURL(a.href), 5000);
          })} disabled={!!busy}>Export library JSON</button>
          <label className="btn">
            Import backup…
            <input
              ref={backupInput} type="file" accept="application/json,.json" hidden
              onChange={(e) => {
                const f = e.target.files?.[0];
                e.target.value = '';
                if (!f) return;
                f.text().then((text) => {
                  try {
                    const counts = previewImport(text);
                    setImportPreview({ counts, json: text });
                  } catch (err) {
                    setMessage(`Import failed: ${(err as Error).message}`);
                  }
                }).catch((err: Error) => setMessage(`Import failed: ${err.message}`));
              }}
            />
          </label>
        </div>
        {importPreview && (
          <div className="notice">
            <p>This backup contains: {importPreview.counts.titles} titles, {importPreview.counts.episodes} episodes,{' '}
              {importPreview.counts.collections} collections, {importPreview.counts.history} history entries,{' '}
              {importPreview.counts.artwork} artwork items. File links are rebuilt by rescan. Apply?</p>
            <div className="row">
              <button className="btn primary" onClick={() => void withBusy('Restore', async () => {
                await restoreJson(importPreview.json);
                setImportPreview(null);
              })}>Restore backup</button>
              <button className="btn" onClick={() => setImportPreview(null)}>Cancel</button>
            </div>
          </div>
        )}
        <p className="dim small">Backups are human-readable JSON. Video files are never included. Folder permissions are never exported — re-pick folders after a restore.</p>
      </Section>

      <Section title="Storage">
        <p className="dim small">{storageInfo || 'Storage info unavailable.'}</p>
        <div className="row wrap">
          <button className="btn" onClick={() => {
            if (window.confirm('Delete all cached artwork (posters, thumbnails)? Custom-uploaded posters are kept. They will be re-downloaded on next metadata refresh.')) {
              void withBusy('Clear artwork cache', async () => {
                const arts = await db.artwork.where('kind').notEqual('custom').toArray();
                for (const a of arts) await db.artwork.delete(a.id);
              });
            }
          }} disabled={!!busy}>Clear artwork cache</button>
          <button className="btn" onClick={() => {
            if (window.confirm('Reset all playback progress and watch history? Your titles, posters and reviews stay.')) {
              void withBusy('Reset progress', async () => {
                await db.transaction('rw', [db.files, db.episodes, db.titles, db.history], async () => {
                  await db.history.clear();
                  await db.files.toCollection().modify({ positionMs: 0, watched: false, lastPlayedAt: undefined });
                  await db.episodes.toCollection().modify({ positionMs: 0, watched: false, lastPlayedAt: undefined });
                  await db.titles.toCollection().modify({ watched: false, lastPlayedAt: undefined, playCount: 0 });
                });
              });
            }
          }} disabled={!!busy}>Reset playback progress</button>
          <button className="btn danger" onClick={() => {
            if (window.confirm('Rebuild the library index? This drops all scanned files/episodes/titles. Settings, collections and reviews on titles are kept; rescan your folders afterwards.')) {
              void withBusy('Rebuild index', async () => {
                await db.transaction('rw', [db.files, db.episodes, db.titles], async () => {
                  await db.files.clear();
                  await db.episodes.clear();
                  await db.titles.clear();
                });
              });
            }
          }} disabled={!!busy}>Rebuild index</button>
        </div>
      </Section>

      <Section title="About">
        <p><strong>{APP_NAME}</strong> · v1.0.0</p>
        <p className="dim small">
          Local-first personal media library. No account, no server, no tracking — your files never leave this device.
          Online metadata (AniList, TVmaze, MyAnimeList) is fetched only when you ask, and cached for offline use.
        </p>
      </Section>
    </div>
  );
}
