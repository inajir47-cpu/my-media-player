// Domain types. Custom (user-edited) metadata is always stored separately
// from fetched metadata so manual overrides survive metadata refreshes.

export type TitleKind = 'show' | 'movie' | 'music';

export interface WhereToWatch {
  name: string;
  url: string;
}

export interface LocalReview {
  id: string;
  stars: number; // 0.5 - 5
  title: string;
  body: string;
  spoiler: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface PublicReview {
  source: 'anilist' | 'jikan' | 'tvmaze';
  author: string;
  rating?: number; // normalized 0-10
  summary: string;
  url?: string;
}

export interface RelatedEntry {
  kind: 'movie' | 'ova' | 'special' | 'series' | 'music';
  title: string;
  year?: number;
  note?: string;
}

export interface FetchedMeta {
  provider: 'anilist' | 'tvmaze' | 'jikan';
  providerId: string | number;
  providerUrl?: string;
  synopsis?: string;
  genres?: string[];
  rating?: number; // normalized 0-10
  ratingCount?: number;
  posterRemoteUrl?: string;
  backdropRemoteUrl?: string;
  posterArtworkId?: string; // cached blob id in artwork store
  backdropArtworkId?: string;
  year?: number;
  yearEnd?: number;
  episodeNames?: Record<string, string>; // "s1e2" -> name
  episodeSynopsis?: Record<string, string>;
  seasonArtwork?: Record<string, string>; // "s1" -> artwork id
  related?: RelatedEntry[];
  publicReviews?: PublicReview[];
  fetchedAt: number;
}

export interface CustomMeta {
  name?: string;
  synopsis?: string;
  genres?: string[];
  rating?: number; // 0-10, user override
  year?: number;
  yearEnd?: number;
  language?: string;
  posterArtworkId?: string; // user-uploaded poster
  backdropArtworkId?: string;
  whereToWatch?: WhereToWatch[];
}

export interface TitleRecord {
  id: string;
  kind: TitleKind;
  name: string;
  sortName: string;
  year?: number;
  yearEnd?: number;
  custom: CustomMeta;
  fetched?: FetchedMeta;
  favorite: boolean;
  saved: boolean; // "Saved" list (watchlist)
  addedAt: number;
  lastPlayedAt?: number;
  playCount: number;
  watched: boolean; // movies/music albums: fully watched
  /** Local artwork found next to the files (poster.jpg, fanart.jpg…). */
  localPosterArtworkId?: string;
  localBackdropArtworkId?: string;
  /** Private local reviews — always the last section on detail pages. */
  reviews: LocalReview[];
  updatedAt: number;
}

export interface EpisodeRecord {
  id: string;
  titleId: string;
  season: number;
  episode: number;
  episodeEnd?: number;
  name?: string;
  customName?: string;
  synopsis?: string;
  fileId: string;
  durationMs?: number;
  positionMs: number;
  watched: boolean;
  artworkId?: string; // cached thumbnail blob id
  previewStartMs?: number;
  previewLengthMs?: number;
  previewDisabled?: boolean;
  addedAt: number;
  lastPlayedAt?: number;
}

export interface FileRecord {
  id: string;
  kind: 'video' | 'audio' | 'subtitle' | 'artwork' | 'other';
  name: string;
  uri: string; // content://… (native) or webfs://<sourceId>/<relpath> (web)
  size: number;
  mtimeMs: number;
  relativePath: string;
  titleId?: string;
  episodeId?: string;
  durationMs?: number;
  positionMs: number;
  watched: boolean;
  missing: boolean;
  sourceId: string;
  addedAt: number;
  lastPlayedAt?: number;
  /** Music tracks: parsed track number/name from the filename. */
  trackNo?: number;
  trackName?: string;
}

export interface FolderSource {
  id: string;
  displayName: string;
  treeUri?: string; // native SAF tree
  webHandleId?: string; // web File System Access dir handle id
  addedAt: number;
  lastScanAt?: number;
}

export interface CollectionRecord {
  id: string;
  name: string;
  titleIds: string[];
  createdAt: number;
  updatedAt: number;
}

export interface HistoryEntry {
  id: string;
  fileId: string;
  titleId: string;
  episodeId?: string;
  startedAt: number;
  endedAt?: number;
  completed: boolean;
  positionMs: number;
}

export interface ArtworkRecord {
  id: string;
  blob?: Blob;
  /** Native content:// URI — resolved to a localhost URL at display time. */
  nativeUri?: string;
  kind: 'poster' | 'backdrop' | 'thumbnail' | 'season' | 'custom';
  updatedAt: number;
}

// Resolved view helpers -------------------------------------------------------

/** Effective display metadata: custom overrides win over fetched metadata. */
export interface ResolvedMeta {
  name: string;
  synopsis?: string;
  genres: string[];
  rating?: number;
  ratingSource?: string;
  year?: number;
  yearEnd?: number;
  language?: string;
  posterArtworkId?: string;
  backdropArtworkId?: string;
  whereToWatch: WhereToWatch[];
}

export function resolveMeta(t: TitleRecord): ResolvedMeta {
  const f = t.fetched;
  const c = t.custom;
  return {
    name: c.name ?? t.name,
    synopsis: c.synopsis ?? f?.synopsis,
    genres: c.genres ?? f?.genres ?? [],
    rating: c.rating ?? f?.rating,
    ratingSource: c.rating !== undefined ? 'Your rating' : f ? providerLabel(f.provider) : undefined,
    year: c.year ?? f?.year ?? t.year,
    yearEnd: c.yearEnd ?? f?.yearEnd ?? t.yearEnd,
    language: c.language,
    posterArtworkId: c.posterArtworkId ?? t.localPosterArtworkId ?? f?.posterArtworkId,
    backdropArtworkId: c.backdropArtworkId ?? t.localBackdropArtworkId ?? f?.backdropArtworkId,
    whereToWatch: c.whereToWatch ?? [],
  };
}

export function providerLabel(p: FetchedMeta['provider']): string {
  switch (p) {
    case 'anilist': return 'AniList';
    case 'tvmaze': return 'TVmaze';
    case 'jikan': return 'MyAnimeList';
  }
}

export function episodeKey(season: number, episode: number): string {
  return `s${season}e${episode}`;
}

/** Stable id from parts (FNV-1a hex). */
export function stableId(...parts: Array<string | number>): string {
  let h = 2166136261;
  const s = parts.join('|');
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16).padStart(8, '0');
}

export function newId(prefix: string): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}
