// Preview clip selection. Rules:
//  - default 12 s (configurable), never inside the first ~90 s,
//    never inside the last 12% (end credits), preferring the 25%-75% window;
//  - deterministic start per file (hash of a seed) so the clip stays
//    consistent across restarts until the user regenerates it;
//  - short files adapt the clip length safely;
//  - timing is stored as local metadata; no duplicate video is created.
// Pure functions — unit tested in clips.test.ts.

import { PREVIEW_CREDITS_MARGIN, PREVIEW_INTRO_SKIP_MS } from '../config';

export interface PreviewClip {
  startMs: number;
  lengthMs: number;
}

/** Deterministic 0..1 value from a string (stable across restarts). */
export function hash01(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) / 4294967295;
}

export interface ClipOptions {
  /** Desired clip length; defaults to the app constant (12 s). */
  desiredLengthMs?: number;
  /** Manual override chosen by the user (clamped into the safe window). */
  manualStartMs?: number;
}

/**
 * Pick a preview clip for a file of `durationMs`.
 * `seed` makes the choice deterministic per file; pass a fresh seed to regenerate.
 */
export function selectPreviewClip(durationMs: number, seed: string, opts: ClipOptions = {}): PreviewClip {
  const desiredLengthMs = opts.desiredLengthMs ?? 12_000;
  if (!Number.isFinite(durationMs) || durationMs <= 0 || !Number.isFinite(desiredLengthMs) || desiredLengthMs <= 0) {
    return { startMs: 0, lengthMs: 0 };
  }

  const introSkip = Math.min(PREVIEW_INTRO_SKIP_MS, durationMs * 0.2);
  const creditsSkip = durationMs * PREVIEW_CREDITS_MARGIN;
  const safeStart = introSkip;
  const safeEnd = durationMs - creditsSkip;

  // File too short for a full safe window: take the middle, never the whole file.
  if (safeEnd - safeStart <= desiredLengthMs) {
    const lengthMs = Math.max(1000, Math.floor(Math.min(durationMs * 0.6, durationMs - 2000)));
    if (lengthMs <= 0) return { startMs: 0, lengthMs: 0 };
    return { startMs: Math.floor((durationMs - lengthMs) / 2), lengthMs };
  }

  const lengthMs = Math.min(desiredLengthMs, Math.floor((safeEnd - safeStart) * 0.5));

  if (opts.manualStartMs !== undefined) {
    const startMs = Math.min(Math.max(safeStart, Math.floor(opts.manualStartMs)), Math.floor(safeEnd - lengthMs));
    return { startMs, lengthMs };
  }

  // Prefer the 25%-75% window, inside the safe window; deterministic offset.
  const windowStart = Math.max(safeStart, durationMs * 0.25);
  const windowEnd = Math.min(safeEnd, durationMs * 0.75) - lengthMs;
  const lo = Math.min(windowStart, windowEnd);
  const hi = Math.max(windowStart, windowEnd);
  const span = Math.max(0, hi - lo);
  const startMs = Math.floor(lo + hash01(`preview:${seed}`) * span);
  return { startMs, lengthMs };
}

/** A stored clip is valid only if it has a positive length. */
export function storedClipValid(startMs?: number, lengthMs?: number): boolean {
  return startMs !== undefined && lengthMs !== undefined && lengthMs > 0 && startMs >= 0;
}
