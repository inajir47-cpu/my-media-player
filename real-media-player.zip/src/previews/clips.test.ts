import { describe, expect, it } from 'vitest';
import { hash01, selectPreviewClip, storedClipValid } from './clips';

const MIN = 60_000;

describe('hash01', () => {
  it('is deterministic and in [0,1)', () => {
    expect(hash01('preview:abc')).toBe(hash01('preview:abc'));
    expect(hash01('preview:abc')).toBeGreaterThanOrEqual(0);
    expect(hash01('preview:abc')).toBeLessThan(1);
    expect(hash01('preview:abc')).not.toBe(hash01('preview:abd'));
  });
});

describe('selectPreviewClip', () => {
  it('returns a 12 s clip for a normal episode', () => {
    const clip = selectPreviewClip(24 * MIN, 'file-1');
    expect(clip.lengthMs).toBe(12_000);
    expect(clip.startMs).toBeGreaterThanOrEqual(90_000); // avoids first ~90 s
    expect(clip.startMs + clip.lengthMs).toBeLessThanOrEqual(24 * MIN * 0.88); // avoids last 12%
  });

  it('is deterministic per seed and varies across files', () => {
    const a = selectPreviewClip(24 * MIN, 'file-1');
    const b = selectPreviewClip(24 * MIN, 'file-1');
    const c = selectPreviewClip(24 * MIN, 'file-2');
    expect(a).toEqual(b);
    // starts differ across files with overwhelming probability via different hash
    expect(a.startMs === c.startMs && a.lengthMs === c.lengthMs).toBe(false);
  });

  it('prefers the 25%-75% window', () => {
    const dur = 60 * MIN;
    const clip = selectPreviewClip(dur, 'file-x');
    expect(clip.startMs).toBeGreaterThanOrEqual(dur * 0.25 - 1);
    expect(clip.startMs + clip.lengthMs).toBeLessThanOrEqual(dur * 0.75 + 1);
  });

  it('adapts short files safely', () => {
    const clip = selectPreviewClip(60_000, 'short');
    expect(clip.lengthMs).toBeGreaterThan(0);
    expect(clip.startMs + clip.lengthMs).toBeLessThanOrEqual(60_000);
    expect(clip.lengthMs).toBeLessThanOrEqual(60_000);
  });

  it('clamps a manual start into the safe window', () => {
    const dur = 24 * MIN;
    const clip = selectPreviewClip(dur, 'file-1', { manualStartMs: 0 });
    expect(clip.startMs).toBeGreaterThanOrEqual(90_000);
    const clip2 = selectPreviewClip(dur, 'file-1', { manualStartMs: dur });
    expect(clip2.startMs + clip2.lengthMs).toBeLessThanOrEqual(dur * 0.88 + 1);
  });

  it('returns an empty clip for invalid durations', () => {
    expect(selectPreviewClip(0, 'x')).toEqual({ startMs: 0, lengthMs: 0 });
    expect(selectPreviewClip(-5, 'x')).toEqual({ startMs: 0, lengthMs: 0 });
    expect(selectPreviewClip(NaN, 'x')).toEqual({ startMs: 0, lengthMs: 0 });
  });

  it('never exceeds the file', () => {
    for (const dur of [30_000, 90_000, 5 * MIN, 45 * MIN, 120 * MIN]) {
      const clip = selectPreviewClip(dur, `seed-${dur}`);
      expect(clip.startMs).toBeGreaterThanOrEqual(0);
      expect(clip.startMs + clip.lengthMs).toBeLessThanOrEqual(dur);
    }
  });
});

describe('storedClipValid', () => {
  it('validates stored timestamps', () => {
    expect(storedClipValid(1000, 12000)).toBe(true);
    expect(storedClipValid(undefined, 12000)).toBe(false);
    expect(storedClipValid(1000, 0)).toBe(false);
    expect(storedClipValid(-5, 12000)).toBe(false);
  });
});
