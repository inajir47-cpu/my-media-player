// Single source of truth for app identity and behavior constants.
export const APP_NAME = 'My Media';

export const PREVIEW_LENGTH_MS = 12_000;
export const PREVIEW_INTRO_SKIP_MS = 90_000; // never start a preview inside the first ~90s
export const PREVIEW_CREDITS_MARGIN = 0.12; // keep the last 12% (credits) out of previews
export const HERO_ROTATE_MS = 15_000;
export const SEEK_STEP_MS = 10_000;
export const RESUME_MIN_WATCHED_MS = 30_000; // restart if less than this was watched
export const COMPLETED_REMAINING_MS = 60_000; // <60s left counts as completed
export const WATCHED_THRESHOLD = 0.9; // 90% watched marks an item watched
export const SAVE_POSITION_INTERVAL_MS = 5_000;
export const MAX_HERO_CANDIDATES = 40;

export const VIDEO_EXTS = new Set([
  'mp4', 'm4v', 'webm', 'mkv', 'mov', 'avi', 'ogv', 'ts', 'm2ts', 'wmv', 'flv', '3gp',
]);
export const AUDIO_EXTS = new Set(['mp3', 'm4a', 'aac', 'flac', 'ogg', 'oga', 'opus', 'wav', 'wma', 'aiff']);
export const SUBTITLE_EXTS = new Set(['srt', 'vtt']);
export const ARTWORK_EXTS = new Set(['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'avif']);
export const ARTWORK_BASENAMES = new Set([
  'poster', 'folder', 'cover', 'fanart', 'backdrop', 'banner', 'thumb', 'thumbnail', 'logo',
]);
