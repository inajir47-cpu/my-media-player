// App shell: tab navigation (bottom bar on phones, rail on tablets/desktops),
// detail overlay, player overlay, scan banner, first-run setup gate.

import { useEffect, useState } from 'react';
import { APP_NAME } from './config';
import { LibraryProvider, useLibrary } from './library/store';
import { Home } from './pages/Home';
import { Browse } from './pages/Browse';
import { SearchPage } from './pages/SearchPage';
import { SettingsPage } from './pages/SettingsPage';
import { LibrarySetup } from './pages/LibrarySetup';
import { TitleDetail } from './components/TitleDetail';
import { Player } from './player/Player';
import { ErrorBoundary } from './components/ErrorBoundary';

type Tab = 'home' | 'shows' | 'movies' | 'music' | 'saved' | 'search' | 'settings';

const TABS: Array<{ id: Tab; label: string; icon: string }> = [
  { id: 'home', label: 'Home', icon: '⌂' },
  { id: 'shows', label: 'Shows', icon: '📺' },
  { id: 'movies', label: 'Movies', icon: '🎬' },
  { id: 'music', label: 'Music', icon: '🎵' },
  { id: 'saved', label: 'Saved', icon: '★' },
  { id: 'search', label: 'Search', icon: '🔍' },
  { id: 'settings', label: 'Settings', icon: '⚙' },
];

function Shell(): React.JSX.Element {
  const [tab, setTab] = useState<Tab>('home');
  const [detailId, setDetailId] = useState<string | null>(null);
  const [setupDismissed, setSetupDismissed] = useState(
    () => sessionStorage.getItem('mm.setupDismissed') === '1',
  );
  const { player, closePlayer, sources, scanning, cancelScan } = useLibrary();

  const openTitle = (id: string) => setDetailId(id);

  useEffect(() => {
    // Close detail when backing out via browser back button is out of scope;
    // Escape closes the detail overlay.
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && detailId && !player) setDetailId(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [detailId, player]);

  const showSetup = sources !== undefined && sources.length === 0 && !setupDismissed;

  return (
    <div className="app">
      <a className="skip-link" href="#main">Skip to content</a>

      {showSetup ? (
        <LibrarySetup onDone={() => { sessionStorage.setItem('mm.setupDismissed', '1'); setSetupDismissed(true); }} />
      ) : (
        <>
          <main id="main" className="main">
            {tab === 'home' && <Home onOpen={openTitle} />}
            {tab === 'shows' && <Browse kind="show" onOpen={openTitle} />}
            {tab === 'movies' && <Browse kind="movie" onOpen={openTitle} />}
            {tab === 'music' && <Browse kind="music" onOpen={openTitle} />}
            {tab === 'saved' && <Browse kind="saved" onOpen={openTitle} />}
            {tab === 'search' && <SearchPage onOpen={openTitle} />}
            {tab === 'settings' && <SettingsPage />}
          </main>

          <nav className="tabbar" aria-label="Primary">
            {TABS.map((t) => (
              <button
                key={t.id}
                className={`tab ${tab === t.id ? 'active' : ''}`}
                onClick={() => { setTab(t.id); setDetailId(null); }}
                aria-current={tab === t.id ? 'page' : undefined}
              >
                <span className="tab-icon" aria-hidden="true">{t.icon}</span>
                <span className="tab-label">{t.label}</span>
              </button>
            ))}
          </nav>
        </>
      )}

      {detailId && (
        <div className="detail-overlay" role="dialog" aria-modal="true" aria-label="Title details">
          <TitleDetail titleId={detailId} onBack={() => setDetailId(null)} />
        </div>
      )}

      {player && (
        <div className="player-overlay">
          <Player queue={player.queue} startIndex={player.index} onClose={closePlayer} />
        </div>
      )}

      {scanning && (
        <div className="scan-banner" role="status">
          <span>Scanning {scanning.sourceName}: {scanning.scanned}/{scanning.total}</span>
          <button className="btn small" onClick={cancelScan}>Cancel</button>
        </div>
      )}
    </div>
  );
}

export function App(): React.JSX.Element {
  return (
    <ErrorBoundary>
      <LibraryProvider>
        <Shell />
      </LibraryProvider>
    </ErrorBoundary>
  );
}

export { APP_NAME };
