// Library scanner: walks folder sources (native SAF via MediaBridge,
// web File System Access, or a one-shot webkitdirectory file input),
// parses filenames, groups into titles/episodes/tracks, and upserts
// everything into IndexedDB incrementally. Never deletes user metadata.

import { ARTWORK_BASENAMES } from '../config';
import { db } from '../db/database';
import { nativeListFiles } from '../native/bridge';
import { cleanName, detectKind, extOf, groupKey, parseFileName, stripExtension, type FileKind } from './filename';
import { stableId, type EpisodeRecord, type FileRecord, type FolderSource, type TitleKind, type TitleRecord } from '../types';

export interface ScanProgress {
  sourceName: string;
  scanned: number;
  total: number;
  added: number;
  updated: number;
  skipped: number;
  errors: number;
  missing: number;
}

export type ProgressCallback = (p: ScanProgress) => void;

export interface ScanEntry {
  name: string;
  relativePath: string;
  size: number;
  mtimeMs: number;
  /** Native content:// URI from the bridge (native sources only). */
  nativeUri?: string;
  /** Read file bytes (web only; native uses the bridge localhost server). */
  readFile?: () => Promise<File | Blob>;
}

const noop: ProgressCallback = () => undefined;

function extBase(name: string): string {
  return stripExtension(name).toLowerCase();
}

function isLocalArtworkName(name: string): 'poster' | 'backdrop' | null {
  const base = extBase(name);
  if (/(poster|folder|cover|thumb|thumbnail)$/.test(base) || ARTWORK_BASENAMES.has(base)) {
    return base.includes('fanart') || base.includes('backdrop') || base.includes('banner') ? 'backdrop' : 'poster';
  }
  if (base.includes('fanart') || base.includes('backdrop') || base.includes('banner')) return 'backdrop';
  return null;
}

// -- entry listing ---------------------------------------------------------------

async function listNativeEntries(source: FolderSource): Promise<ScanEntry[]> {
  if (!source.treeUri) return [];
  const files = await nativeListFiles(source.treeUri);
  return files.map((f) => ({
    name: f.name,
    relativePath: f.relativePath,
    size: f.size,
    mtimeMs: f.mtimeMs,
    nativeUri: f.uri,
  }));
}

async function* walkWebDir(
  dir: FileSystemDirectoryHandle,
  base: string,
): AsyncGenerator<{ handle: FileSystemFileHandle; relativePath: string }> {
  for await (const entry of dir.values()) {
    const rel = base ? `${base}/${entry.name}` : entry.name;
    if (entry.kind === 'file') {
      yield { handle: entry as FileSystemFileHandle, relativePath: rel };
    } else if (entry.kind === 'directory') {
      yield* walkWebDir(entry as FileSystemDirectoryHandle, rel);
    }
  }
}

async function ensureReadPermission(handle: FileSystemDirectoryHandle): Promise<boolean> {
  const opts = { mode: 'read' } as const;
  try {
    if ((await handle.queryPermission(opts)) === 'granted') return true;
    return (await handle.requestPermission(opts)) === 'granted';
  } catch {
    return false;
  }
}

async function listWebEntries(source: FolderSource): Promise<ScanEntry[]> {
  if (!source.webHandleId) return [];
  const rec = await db.handles.get(source.webHandleId);
  const handle = rec?.handle as FileSystemDirectoryHandle | undefined;
  if (!handle || handle.kind !== 'directory') throw new Error('Folder handle is gone — please re-pick the folder.');
  if (!(await ensureReadPermission(handle))) {
    throw new Error('Permission denied for that folder. Re-pick it to grant access again.');
  }
  const out: ScanEntry[] = [];
  for await (const { handle: fh, relativePath } of walkWebDir(handle, '')) {
    const file = await fh.getFile();
    out.push({
      name: fh.name,
      relativePath,
      size: file.size,
      mtimeMs: file.lastModified,
      readFile: () => fh.getFile(),
    });
  }
  return out;
}

/** One-shot fallback for browsers without File System Access (files live for this session only). */
export function sessionEntries(files: File[] | FileList): ScanEntry[] {
  const list = Array.from(files);
  return list.map((f) => {
    const rel = (f as File & { webkitRelativePath?: string }).webkitRelativePath || f.name;
    return {
      name: f.name,
      relativePath: rel,
      size: f.size,
      mtimeMs: f.lastModified,
      readFile: () => Promise.resolve(f),
    };
  });
}

// -- ingest ------------------------------------------------------------------------

interface IngestStats { added: number; updated: number; skipped: number; errors: number; }

function dirOf(relativePath: string): string {
  const i = Math.max(relativePath.lastIndexOf('/'), relativePath.lastIndexOf('\\'));
  return i >= 0 ? relativePath.slice(0, i) : '';
}

function parseTrack(cleaned: string): { no?: number; name: string } {
  const m = cleaned.match(/^(?:\d{1,3}\s*[-–.]\s*)?(.+)$/);
  const num = cleaned.match(/^0*(\d{1,3})\s*[-–.]/);
  return { no: num ? parseInt(num[1], 10) : undefined, name: (m?.[1] ?? cleaned).trim() || cleaned };
}

async function ensureTitle(kind: TitleKind, titleName: string, year: number | undefined, now: number): Promise<TitleRecord> {
  const key = groupKey(titleName);
  const id = `t_${kind}_${stableId(key)}`;
  const existing = await db.titles.get(id);
  if (existing) return existing;
  const record: TitleRecord = {
    id,
    kind,
    name: titleName,
    sortName: titleName.toLowerCase(),
    year,
    custom: {},
    favorite: false,
    saved: false,
    addedAt: now,
    playCount: 0,
    watched: false,
    reviews: [],
    updatedAt: now,
  };
  await db.titles.add(record);
  return record;
}

/** Core ingest: entries -> files/titles/episodes. Shared by all source types. */
export async function ingestEntries(
  source: FolderSource,
  entries: ScanEntry[],
  onProgress: ProgressCallback = noop,
  signal?: AbortSignal,
  sessionUris = false,
): Promise<IngestStats> {
  const stats: IngestStats = { added: 0, updated: 0, skipped: 0, errors: 0 };
  const now = Date.now();
  const seen = new Set<string>();
  const dirTitle = new Map<string, string>(); // normalized dir -> titleId
  const siblingVideo = new Map<string, string>(); // dir + base -> titleId (for subtitles/artwork)

  const total = entries.length;
  let scanned = 0;
  const report = () => onProgress({ sourceName: source.displayName, scanned, total, ...stats, missing: 0 });

  // Pass 1: media files (video/audio) create the titles.
  for (const entry of entries) {
    if (signal?.aborted) throw new DOMException('Scan cancelled', 'AbortError');
    scanned++;
    if (scanned % 25 === 0) report();
    const kind: FileKind = detectKind(entry.name);
    if (kind !== 'video' && kind !== 'audio') continue;
    if (entry.size === 0) { stats.skipped++; continue; }

    const id = `f_${stableId(source.id, entry.relativePath, entry.size, entry.mtimeMs)}`;
    seen.add(id);
    const uri = entryUri(source, entry, sessionUris);

    try {
      const existing = await db.files.get(id);
      if (existing) {
        stats.skipped++;
        if (existing.missing) await db.files.update(id, { missing: false });
        if (existing.titleId) dirTitle.set(dirOf(entry.relativePath).toLowerCase(), existing.titleId);
        continue;
      }

      const parsed = parseFileName(entry.name, entry.relativePath);
      const file: FileRecord = {
        id, kind, name: entry.name, uri,
        size: entry.size, mtimeMs: entry.mtimeMs, relativePath: entry.relativePath,
        positionMs: 0, watched: false, missing: false,
        sourceId: source.id, addedAt: now,
      };

      if (parsed.role === 'episode' && parsed.season !== undefined && parsed.episode !== undefined) {
        const title = await ensureTitle('show', parsed.titleName, parsed.year, now);
        file.titleId = title.id;
        const epId = `e_${stableId(title.id, parsed.season, parsed.episode)}`;
        const epExisting = await db.episodes.get(epId);
        const epName = cleanEpisodeName(entry.name, parsed.titleName);
        if (epExisting) {
          await db.episodes.update(epId, { fileId: id });
        } else {
          const ep: EpisodeRecord = {
            id: epId, titleId: title.id, season: parsed.season, episode: parsed.episode,
            episodeEnd: parsed.episodeEnd, name: epName || undefined, fileId: id,
            positionMs: 0, watched: false, addedAt: now,
          };
          await db.episodes.add(ep);
        }
        file.episodeId = epId;
        await db.files.add(file);
        dirTitle.set(dirOf(entry.relativePath).toLowerCase(), title.id);
        siblingVideo.set(`${dirOf(entry.relativePath).toLowerCase()}|${extBase(entry.name)}`, title.id);
        stats.added++;
      } else if (parsed.role === 'movie') {
        const title = await ensureTitle('movie', parsed.titleName, parsed.year, now);
        file.titleId = title.id;
        await db.files.add(file);
        dirTitle.set(dirOf(entry.relativePath).toLowerCase(), title.id);
        siblingVideo.set(`${dirOf(entry.relativePath).toLowerCase()}|${extBase(entry.name)}`, title.id);
        stats.added++;
      } else if (parsed.role === 'track') {
        const title = await ensureTitle('music', parsed.titleName, undefined, now);
        file.titleId = title.id;
        const track = parseTrack(cleanName(entry.name));
        file.trackNo = track.no;
        file.trackName = track.name;
        await db.files.add(file);
        dirTitle.set(dirOf(entry.relativePath).toLowerCase(), title.id);
        siblingVideo.set(`${dirOf(entry.relativePath).toLowerCase()}|${extBase(entry.name)}`, title.id);
        stats.added++;
      } else {
        stats.skipped++;
      }
    } catch {
      stats.errors++;
    }
  }

  // Pass 2: subtitles + artwork attach to whatever pass 1 built.
  for (const entry of entries) {
    if (signal?.aborted) throw new DOMException('Scan cancelled', 'AbortError');
    const kind: FileKind = detectKind(entry.name);
    if (kind !== 'subtitle' && kind !== 'artwork') continue;
    const dir = dirOf(entry.relativePath).toLowerCase();
    const titleId =
      siblingVideo.get(`${dir}|${extBase(entry.name)}`) ?? walkUpDirs(dir, dirTitle);
    if (!titleId) { stats.skipped++; continue; }
    const id = `f_${stableId(source.id, entry.relativePath, entry.size, entry.mtimeMs)}`;
    seen.add(id);
    try {
      if (await db.files.get(id)) { stats.skipped++; continue; }
      const uri = entryUri(source, entry, sessionUris);
      const file: FileRecord = {
        id, kind, name: entry.name, uri,
        size: entry.size, mtimeMs: entry.mtimeMs, relativePath: entry.relativePath,
        titleId, positionMs: 0, watched: false, missing: false,
        sourceId: source.id, addedAt: now,
      };
      // Subtitles inherit the episode link of their sibling video file.
      if (kind === 'subtitle') {
        const videoFile = await db.files
          .where('titleId').equals(titleId)
          .filter((f) => f.kind === 'video' && extBase(f.name) === extBase(entry.name))
          .first();
        if (videoFile?.episodeId) file.episodeId = videoFile.episodeId;
      }
      await db.files.add(file);

      if (kind === 'artwork') {
        const slot = isLocalArtworkName(entry.name);
        const base = extBase(entry.name);
        // same-basename art ("Movie-poster.jpg") counts as poster too
        const isPosterish = slot === 'poster' || /poster|cover|folder|thumb/.test(base);
        const isBackdropish = slot === 'backdrop' || /fanart|backdrop|banner/.test(base);
        if (isPosterish || isBackdropish) {
          let artId: string | undefined;
          if (entry.readFile) {
            const blob = await entry.readFile();
            artId = `art_${stableId(source.id, entry.relativePath)}`;
            await db.artwork.put({ id: artId, blob, kind: isPosterish ? 'poster' : 'backdrop', updatedAt: now });
          } else if (source.treeUri && entry.nativeUri) {
            artId = `art_${stableId(source.id, entry.relativePath)}`;
            await db.artwork.put({ id: artId, nativeUri: entry.nativeUri, kind: isPosterish ? 'poster' : 'backdrop', updatedAt: now });
          }
          if (artId) {
            const title = await db.titles.get(titleId);
            if (title) {
              const patch: Partial<TitleRecord> = {};
              if (isPosterish && !title.localPosterArtworkId && !title.custom.posterArtworkId) {
                patch.localPosterArtworkId = artId;
              }
              if (isBackdropish && !title.localBackdropArtworkId && !title.custom.backdropArtworkId) {
                patch.localBackdropArtworkId = artId;
              }
              if (Object.keys(patch).length) await db.titles.update(titleId, { ...patch, updatedAt: now });
            }
          }
        }
      }
      stats.added++;
    } catch {
      stats.errors++;
    }
  }

  report();
  return stats;
}

function walkUpDirs(dir: string, map: Map<string, string>): string | undefined {
  let d: string | undefined = dir || undefined;
  while (d !== undefined) {
    const hit = map.get(d);
    if (hit) return hit;
    const i = Math.max(d.lastIndexOf('/'), d.lastIndexOf('\\'));
    d = i > 0 ? d.slice(0, i) : i === 0 ? '' : undefined;
    if (d === '') {
      const rootHit = map.get('');
      return rootHit;
    }
  }
  return map.get('');
}

/** Resolve the stored URI for an entry: real content:// on native, webfs:// on web. */
function entryUri(source: FolderSource, entry: ScanEntry, sessionUris: boolean): string {
  if (sessionUris) return `session://${entry.relativePath}`;
  if (entry.nativeUri) return entry.nativeUri;
  return `webfs://${source.id}/${entry.relativePath}`;
}

function cleanEpisodeName(fileName: string, showName: string): string {
  let s = cleanName(fileName);
  const idx = s.toLowerCase().indexOf(showName.toLowerCase());
  if (idx >= 0) s = s.slice(idx + showName.length);
  s = s.replace(/^(s\d{1,2}e\d{1,3}(?:-?e\d{1,3})?|\d{1,2}x\d{1,3})/i, '');
  return s.replace(/^[\s\-–—:;,.]+|[\s\-–—:;,.]+$/g, '').replace(/\s{2,}/g, ' ');
}

// -- public scan entry points ------------------------------------------------------

export async function scanSource(
  source: FolderSource,
  onProgress: ProgressCallback = noop,
  signal?: AbortSignal,
): Promise<IngestStats & { missing: number }> {
  onProgress({ sourceName: source.displayName, scanned: 0, total: 0, added: 0, updated: 0, skipped: 0, errors: 0, missing: 0 });
  const entries = source.treeUri ? await listNativeEntries(source) : await listWebEntries(source);
  const stats = await ingestEntries(source, entries, onProgress, signal);
  // Missing files: seen in DB for this source but absent now. Keep metadata.
  const seenIds = new Set(entries.map((e) => `f_${stableId(source.id, e.relativePath, e.size, e.mtimeMs)}`));
  let missing = 0;
  await db.files.where('sourceId').equals(source.id).modify((f) => {
    if (!seenIds.has(f.id) && !f.missing) { f.missing = true; missing++; }
    else if (seenIds.has(f.id) && f.missing) { f.missing = false; }
  });
  await db.sources.update(source.id, { lastScanAt: Date.now() });
  return { ...stats, missing };
}

export async function scanAll(onProgress: ProgressCallback = noop, signal?: AbortSignal): Promise<void> {
  const sources = await db.sources.toArray();
  for (const source of sources) {
    if (signal?.aborted) throw new DOMException('Scan cancelled', 'AbortError');
    await scanSource(source, onProgress, signal);
  }
}

/** Scan a FileList from <input webkitdirectory> — files playable for this session only. */
export async function scanSessionFiles(files: File[] | FileList, displayName: string): Promise<FolderSource> {
  const source: FolderSource = {
    id: `src_session_${Date.now().toString(36)}`,
    displayName: `${displayName} (this session)`,
    addedAt: Date.now(),
  };
  await db.sources.add(source);
  const entries = sessionEntries(files);
  await ingestEntries(source, entries, noop, undefined, true);
  return source;
}

export { extOf };
