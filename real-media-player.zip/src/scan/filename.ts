// Filename parsing: episode patterns (SxxEyy, NxNN, "Episode N", anime
// absolute numbers), years, release-tag stripping, and grouping keys.
// Pure functions — unit tested in filename.test.ts.

import { ARTWORK_EXTS, AUDIO_EXTS, SUBTITLE_EXTS, VIDEO_EXTS } from '../config';

export type FileKind = 'video' | 'audio' | 'subtitle' | 'artwork' | 'other';

export function extOf(name: string): string {
  const i = name.lastIndexOf('.');
  return i >= 0 ? name.slice(i + 1).toLowerCase() : '';
}

export function detectKind(name: string): FileKind {
  const ext = extOf(name);
  if (VIDEO_EXTS.has(ext)) return 'video';
  if (AUDIO_EXTS.has(ext)) return 'audio';
  if (SUBTITLE_EXTS.has(ext)) return 'subtitle';
  if (ARTWORK_EXTS.has(ext)) return 'artwork';
  return 'other';
}

export function stripExtension(name: string): string {
  const i = name.lastIndexOf('.');
  return i > 0 ? name.slice(0, i) : name;
}

/** Release tags that carry no identity: resolutions, sources, codecs, groups. */
const TAG_PATTERNS: RegExp[] = [
  /\[[^\]]*\]/g, // [Group], [1080p], …
  /\([^)]*(1080p|720p|2160p|4k|bluray|bdrip|web-?dl|webrip|hdtv)[^)]*\)/gi,
  /\b(2160p|1080p|720p|480p|4k|uhd|hdr|dolby\.?vision)\b/gi,
  /\b(bluray|blu-ray|bdrip|brrip|dvdrip|web-?dl|webrip|hdtv|hdcam|camrip)\b/gi,
  /\b(x264|x265|h\.?264|h\.?265|hevc|avc|xvid|divx)\b/gi,
  /\b(aac|ac3|dts|truehd|atmos|ddp?\s?5\.?1|flac|opus)\b/gi,
  /\b(dual-?audio|multi-?subs?|subbed|dubbed|uncensored)\b/gi,
  /\b(remux|repack|proper|extended|unrated|directors?\.?cut)\b/gi,
  /\b(s\d{1,2})\b.*$/gi, // trailing season tags handled separately; keep simple
];

export function cleanName(raw: string): string {
  let s = stripExtension(raw);
  s = s.replace(/[._]+/g, ' ');
  for (const re of TAG_PATTERNS) {
    re.lastIndex = 0;
    s = s.replace(re, ' ');
  }
  // Year kept separately; strip here so group keys are stable.
  s = s.replace(/[([]?\b(19|20)\d{2}\b[)\]]?/g, ' ');
  s = s.replace(/\s{2,}/g, ' ').replace(/^[\s\-–—:;,.]+|[\s\-–—:;,.]+$/g, '');
  return s;
}

export interface EpisodeInfo {
  season: number;
  episode: number;
  episodeEnd?: number;
  absolute?: number;
}

/**
 * Parse S/E info from a (cleaned) filename. `folderSeason` is used when the
 * file sits inside a "Season N" folder but the name only has an episode number.
 */
export function parseEpisodeInfo(name: string, folderSeason?: number): EpisodeInfo | null {
  const s = ` ${name} `;
  let m: RegExpMatchArray | null;

  // S02E05, s2e5, S02E05-E07, S02E05E06
  m = s.match(/[^a-z0-9]s(\d{1,2})e(\d{1,3})(?:-?e(\d{1,3}))?[^a-z0-9]/i);
  if (m) {
    return {
      season: parseInt(m[1], 10),
      episode: parseInt(m[2], 10),
      episodeEnd: m[3] ? parseInt(m[3], 10) : undefined,
    };
  }
  // 2x05, 02x05
  m = s.match(/[^a-z0-9](\d{1,2})x(\d{1,3})[^a-z0-9]/i);
  if (m) return { season: parseInt(m[1], 10), episode: parseInt(m[2], 10) };
  // Season 2 Episode 5 / S2 Ep 5
  m = s.match(/season[^a-z0-9]*(\d{1,2})[^a-z0-9]+(?:episode|ep\.?)[^a-z0-9]*(\d{1,3})/i);
  if (m) return { season: parseInt(m[1], 10), episode: parseInt(m[2], 10) };
  // Episode 12 / Ep 12 / E12 (not part of a larger token)
  m = s.match(/(?:episode|ep\.?)[^a-z0-9]*(\d{1,3})(?:[^a-z0-9]|$)/i);
  if (m) return { season: folderSeason ?? 1, episode: parseInt(m[1], 10) };
  // Anime absolute: " - 042 - ", "[42]", "#42" (up to 4 digits: long runners)
  m = s.match(/(?:^|[\s\-_#[])(?:ep\.?)?0*(\d{1,4})(?:[\s\-_\]]|$)/i);
  if (m) {
    const abs = parseInt(m[1], 10);
    // A 4-digit number in year range is a year, not an absolute episode.
    if (abs < 1900 || abs > 2099) {
      // Only treat as absolute episode when the name has no other numbering
      // and (usually) lives in a show-like folder. Conservative: accept.
      if (abs >= 1 && abs <= 9999 && folderSeason === undefined) {
        return { season: 1, episode: abs, absolute: abs };
      }
      if (folderSeason !== undefined && abs >= 1 && abs <= 9999) {
        return { season: folderSeason, episode: abs, absolute: abs };
      }
    }
  }
  return null;
}

export function parseYear(name: string): { name: string; year?: number } {
  const m = name.match(/[([]?\b((?:19|20)\d{2})\b[)\]]?/);
  if (!m) return { name: name.trim() };
  return {
    name: name.slice(0, m.index).replace(/[._\-–—\s]+$/, '').trim(),
    year: parseInt(m[1], 10),
  };
}

export interface ParsedFile {
  kind: FileKind;
  /** Identity for grouping: show name or movie name, cleaned. */
  titleName: string;
  /** Stable grouping key (lowercase, punctuation stripped). */
  groupKey: string;
  year?: number;
  season?: number;
  episode?: number;
  episodeEnd?: number;
  absolute?: number;
  /** 'episode' | 'movie' | 'track' | 'other' — best guess at what this file is. */
  role: 'episode' | 'movie' | 'track' | 'other';
}

/** Parent folder names from a relative path, nearest last. */
export function parentDirs(relativePath: string): string[] {
  const parts = relativePath.split(/[\\/]/).filter(Boolean);
  parts.pop(); // file itself
  return parts;
}

export function folderSeason(dirs: string[]): number | undefined {
  for (const d of dirs) {
    const m = d.match(/season[^a-z0-9]*(\d{1,2})/i) ?? d.match(/^s(\d{1,2})$/i);
    if (m) return parseInt(m[1], 10);
  }
  return undefined;
}

/** Strip the episode token so the remainder can identify the show. */
function stripEpisodeToken(cleaned: string, info: EpisodeInfo): string {
  let s = cleaned;
  s = s.replace(new RegExp(`s0*${info.season}e0*${info.episode}(?:-?e0*${info.episodeEnd})?`, 'i'), ' ');
  s = s.replace(new RegExp(`0*${info.season}x0*${info.episode}`, 'i'), ' ');
  s = s.replace(/(episode|ep\.?)\s*0*\d{1,3}/i, ' ');
  if (info.absolute !== undefined) {
    s = s.replace(new RegExp(`[\\s\\-_#\\[]0*${info.absolute}(?=[\\s\\-_\\]]|$)`, ''), ' ');
  }
  // trailing " - Episode title" after the number: keep it out of the show name
  const dash = s.search(/\s[-–—]\s/);
  if (dash > 0 && info.episode !== undefined) s = s.slice(0, dash);
  return s.replace(/\s{2,}/g, ' ').replace(/^[\s\-–—:;,.]+|[\s\-–—:;,.]+$/g, '');
}

export function groupKey(name: string): string {
  return name
    .toLowerCase()
    .replace(/[''ʼ`]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .replace(/\s+/g, ' ');
}

export function parseFileName(fileName: string, relativePath = ''): ParsedFile {
  const kind = detectKind(fileName);
  const dirs = parentDirs(relativePath);
  const seasonHint = folderSeason(dirs);
  // Year is stripped by cleanName, so capture it from the raw name first.
  const rawYear = parseYear(stripExtension(fileName)).year;
  const cleaned = cleanName(fileName);

  if (kind === 'audio') {
    // Track: "Artist - Album - 03 - Title" or "03 Title". Album = parent dir.
    const album = dirs.length ? dirs[dirs.length - 1] : cleanName(fileName);
    const trackMatch = cleaned.match(/(?:^|\s)(\d{1,3})(?:\s*[-–.]\s*|\s{2,})/);
    void trackMatch;
    return {
      kind,
      titleName: album.replace(/[._]+/g, ' ').trim() || 'Unknown Album',
      groupKey: groupKey(dirs.length ? dirs[dirs.length - 1] : cleaned),
      role: 'track',
    };
  }

  if (kind !== 'video') {
    return { kind, titleName: cleaned, groupKey: groupKey(cleaned), role: 'other' };
  }

  const info = parseEpisodeInfo(cleaned, seasonHint);
  if (info) {
    const showName = stripEpisodeToken(cleaned, info);
    const { year } = parseYear(showName);
    const name = parseYear(showName).name || showName;
    return {
      kind,
      titleName: name.trim(),
      groupKey: groupKey(name),
      year: year ?? rawYear,
      season: info.season,
      episode: info.episode,
      episodeEnd: info.episodeEnd,
      absolute: info.absolute,
      role: 'episode',
    };
  }

  // Movie: "Name (2019)" / "Name.2019."
  const { name, year } = parseYear(cleaned);
  return {
    kind,
    titleName: name.trim() || cleaned,
    groupKey: groupKey(name || cleaned),
    year: year ?? rawYear,
    role: 'movie',
  };
}

/** "My Show S02E05" vs "My Show S02E06" — same show key. */
export function looksLikeAnime(name: string): boolean {
  return /\b(anime|donghua|ova|ona|special)\b/i.test(name);
}
