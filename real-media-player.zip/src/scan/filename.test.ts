import { describe, expect, it } from 'vitest';
import {
  cleanName,
  detectKind,
  extOf,
  folderSeason,
  groupKey,
  parseEpisodeInfo,
  parseFileName,
  parseYear,
} from './filename';

describe('detectKind / extOf', () => {
  it('classifies common containers', () => {
    expect(detectKind('movie.mkv')).toBe('video');
    expect(detectKind('clip.MP4')).toBe('video');
    expect(detectKind('song.flac')).toBe('audio');
    expect(detectKind('song.MP3')).toBe('audio');
    expect(detectKind('subs.srt')).toBe('subtitle');
    expect(detectKind('subs.vtt')).toBe('subtitle');
    expect(detectKind('poster.jpg')).toBe('artwork');
    expect(detectKind('notes.txt')).toBe('other');
    expect(extOf('a.b.c.mkv')).toBe('mkv');
  });
});

describe('parseEpisodeInfo', () => {
  it('parses SxxEyy', () => {
    expect(parseEpisodeInfo('Show S02E05')).toEqual({ season: 2, episode: 5, episodeEnd: undefined });
  });
  it('parses SxxEyy-Ezz ranges', () => {
    expect(parseEpisodeInfo('Show S01E01-E02')).toMatchObject({ season: 1, episode: 1, episodeEnd: 2 });
  });
  it('parses NxNN', () => {
    expect(parseEpisodeInfo('Show 2x05')).toMatchObject({ season: 2, episode: 5 });
  });
  it('parses "Episode N" with folder season hint', () => {
    expect(parseEpisodeInfo('Episode 12', 3)).toMatchObject({ season: 3, episode: 12 });
  });
  it('parses anime absolute numbers', () => {
    const info = parseEpisodeInfo('One Piece - 042 - Something');
    expect(info).toMatchObject({ season: 1, episode: 42, absolute: 42 });
  });
  it('returns null when there is no numbering', () => {
    expect(parseEpisodeInfo('Just A Movie Name 2019')).toBeNull();
  });
});

describe('parseYear', () => {
  it('extracts parenthesized years', () => {
    expect(parseYear('Dune (2021)')).toEqual({ name: 'Dune', year: 2021 });
  });
  it('extracts dotted years', () => {
    expect(parseYear('Dune.2021.1080p')).toEqual({ name: 'Dune', year: 2021 });
  });
});

describe('cleanName', () => {
  it('strips release tags and normalizes separators', () => {
    expect(cleanName('The.Show.S02E05.1080p.BluRay.x264-[Group].mkv')).toBe('The Show S02E05');
  });
  it('keeps meaningful words', () => {
    expect(cleanName('Spirited Away (2001)')).toBe('Spirited Away');
  });
});

describe('parseFileName', () => {
  it('groups episodes of one show under one key', () => {
    const a = parseFileName('My Show S01E01.mkv', 'My Show/S01/My Show S01E01.mkv');
    const b = parseFileName('My Show S01E02.mkv', 'My Show/S01/My Show S01E02.mkv');
    const c = parseFileName('My Show 1x03.mkv', 'My Show/S01/My Show 1x03.mkv');
    expect(a.role).toBe('episode');
    expect(a.groupKey).toBe(b.groupKey);
    expect(a.groupKey).toBe(c.groupKey);
    expect(a.groupKey).toBe(groupKey('My Show'));
    expect([a.season, b.season, c.season]).toEqual([1, 1, 1]);
    expect([a.episode, b.episode, c.episode]).toEqual([1, 2, 3]);
  });

  it('uses the Season N folder when the filename only has an episode number', () => {
    const p = parseFileName('Episode 7.mkv', 'My Show/Season 2/Episode 7.mkv');
    expect(p.role).toBe('episode');
    expect(p.season).toBe(2);
    expect(p.episode).toBe(7);
  });

  it('parses movies with year', () => {
    const p = parseFileName('Dune Part Two (2024) 2160p.mkv', 'Movies/Dune Part Two (2024) 2160p.mkv');
    expect(p.role).toBe('movie');
    expect(p.year).toBe(2024);
    expect(p.titleName).toBe('Dune Part Two');
  });

  it('parses anime absolute episodes', () => {
    const p = parseFileName('[SubPlease] One Piece - 1071 [1080p].mkv', 'Anime/One Piece/[SubPlease] One Piece - 1071 [1080p].mkv');
    expect(p.role).toBe('episode');
    expect(p.episode).toBe(1071);
    expect(p.absolute).toBe(1071);
    expect(p.groupKey).toBe(groupKey('One Piece'));
  });

  it('treats audio files as tracks grouped by folder', () => {
    const p = parseFileName('03 - Midnight Drive.mp3', 'Music/Synthwave Nights/03 - Midnight Drive.mp3');
    expect(p.role).toBe('track');
    expect(p.groupKey).toBe(groupKey('Synthwave Nights'));
  });
});

describe('folderSeason', () => {
  it('finds Season N folders', () => {
    expect(folderSeason(['My Show', 'Season 2'])).toBe(2);
    expect(folderSeason(['S03'])).toBe(3);
    expect(folderSeason(['Movies'])).toBeUndefined();
  });
});
