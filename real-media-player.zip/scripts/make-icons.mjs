/* eslint-disable no-console -- build script output */
// Generates PWA icons as PNGs with zero dependencies (raw RGBA -> zlib PNG).
// Dark charcoal rounded square, orange play triangle, subtle ring.
import { writeFileSync, mkdirSync } from 'node:fs';
import { deflateSync } from 'node:zlib';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', 'public');
mkdirSync(join(root, 'icons'), { recursive: true });

function crc32(buf) {
  let table = crc32.table;
  if (!table) {
    table = crc32.table = new Int32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      table[n] = c;
    }
  }
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) crc = table[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const typeBuf = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])));
  return Buffer.concat([len, typeBuf, data, crc]);
}

function encodePng(size, paint) {
  const px = Buffer.alloc(size * size * 4);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const [r, g, b, a] = paint(x / size, y / size);
      const o = (y * size + x) * 4;
      px[o] = r; px[o + 1] = g; px[o + 2] = b; px[o + 3] = a;
    }
  }
  const raw = Buffer.alloc(size * (1 + size * 4));
  for (let y = 0; y < size; y++) {
    raw[y * (1 + size * 4)] = 0;
    px.copy(raw, y * (1 + size * 4) + 1, y * size * 4, (y + 1) * size * 4);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0); ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8; ihdr[9] = 6;
  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  return Buffer.concat([sig, chunk('IHDR', ihdr), chunk('IDAT', deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

// Palette: charcoal bg, orange accent (#ff7a1a), soft vignette.
function iconPaint(maskable) {
  const pad = maskable ? 0.06 : 0.0; // maskable keeps artwork inside the safe zone
  return (nx, ny) => {
    const cx = 0.5, cy = 0.5;
    const dx = Math.abs(nx - cx) - (0.5 - pad) + 0.09;
    const dy = Math.abs(ny - cy) - (0.5 - pad) + 0.09;
    const corner = 0.09;
    // rounded-rect SDF (approx)
    const qx = Math.max(dx, 0), qy = Math.max(dy, 0);
    const dist = Math.hypot(qx, qy) + Math.min(Math.max(dx, dy), 0) - corner;
    if (dist > 0) return [0, 0, 0, 0];
    const aa = Math.max(0, Math.min(1, -dist * 60));
    // vignette
    const v = 1 - 0.35 * Math.hypot(nx - cx, ny - cy);
    const bg = [Math.round(24 * v) + 8, Math.round(22 * v) + 8, Math.round(26 * v) + 10];
    // play triangle pointing right, centered
    const tx = (nx - 0.5) / 0.62, ty = (ny - 0.5) / 0.62;
    const inTri = tx > -0.28 && tx < 0.34 && Math.abs(ty) < (0.34 - tx) * 0.82 && tx > -0.28;
    const edge = Math.abs(Math.abs(ty) - (0.34 - tx) * 0.82);
    if (inTri) {
      const glow = edge < 0.05 ? 1.12 : 1.0;
      return [Math.min(255, 255 * glow), Math.round(122 * glow), Math.round(26 * glow), 255];
    }
    // thin orange ring
    const ring = Math.hypot(nx - cx, ny - cy);
    if (Math.abs(ring - 0.36) < 0.008) return [255, 122, 26, Math.round(120 * aa)];
    return [bg[0], bg[1], bg[2], Math.round(255 * aa)];
  };
}

const jobs = [
  ['icons/icon-192.png', 192, false],
  ['icons/icon-512.png', 512, false],
  ['icons/icon-maskable-512.png', 512, true],
  ['apple-touch-icon.png', 180, false],
];
for (const [rel, size, maskable] of jobs) {
  writeFileSync(join(root, rel), encodePng(size, iconPaint(maskable)));
  console.log('wrote', rel);
}
