// PWA smoke test: serves dist/, loads the app in headless Chromium, asserts
// no console/page errors, manifest link + service worker registration, then
// goes offline and asserts the app shell still renders.
// Usage: npm run build && npm run smoke
/* eslint-disable no-console */
import { chromium } from 'playwright-core';
import { createServer } from 'http';
import { readFile, access } from 'fs/promises';
import { extname, join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { homedir } from 'os';

const dist = join(dirname(fileURLToPath(import.meta.url)), '..', 'dist');

// Use the Playwright-cached Chromium when the default headless-shell
// executable is not present (matches this environment's browser cache).
async function launchOptions() {
  const cached = join(homedir(), '.cache/ms-playwright/chromium-1243/chrome-linux64/chrome');
  try {
    await access(cached);
    return { executablePath: cached };
  } catch {
    return {};
  }
}
const TYPES = {
  '.html': 'text/html',
  '.js': 'text/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.webmanifest': 'application/manifest+json',
  '.png': 'image/png',
};

async function main() {
  const server = createServer(async (req, res) => {
    let p = '/index.html';
    try {
      p = decodeURIComponent(new URL(req.url || '/', 'http://x').pathname);
    } catch { /* keep default */ }
    if (p === '/') p = '/index.html';
    if (p === '/manifest.webmanifest' || p.endsWith('.webmanifest')) {
      // served with manifest content type below
    }
    try {
      const data = await readFile(join(dist, p.replace(/^\//, '')));
      res.writeHead(200, { 'Content-Type': TYPES[extname(p)] || 'application/octet-stream' });
      res.end(data);
    } catch {
      res.writeHead(404);
      res.end('not found');
    }
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const port = server.address().port;
  const base = `http://127.0.0.1:${port}`;

  const browser = await chromium.launch(await launchOptions());
  const page = await browser.newPage();
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push(String(e && e.message || e)));

  await page.goto(base + '/', { waitUntil: 'networkidle' });
  await page.waitForTimeout(3000);

  const checks = await page.evaluate(async () => {
    const reg = 'serviceWorker' in navigator
      ? await navigator.serviceWorker.getRegistration().catch(() => null)
      : null;
    return {
      title: document.title,
      hasManifestLink: !!document.querySelector('link[rel="manifest"]'),
      swRegistered: !!reg,
      swActive: !!reg && !!reg.active,
      rootRendered: (document.getElementById('root')?.textContent?.length || 0) > 10,
    };
  });

  // Offline: the app shell (precached) must still render with no network.
  await page.context().setOffline(true);
  await page.reload({ waitUntil: 'domcontentloaded' }).catch(() => undefined);
  await page.waitForTimeout(2000);
  const offline = await page.evaluate(() => ({
    rootRendered: (document.getElementById('root')?.textContent?.length || 0) > 10,
    controlled: !!navigator.serviceWorker?.controller,
  }));

  await browser.close();
  server.close();

  const result = { checks, offline, consoleErrors: errors };
  console.log(JSON.stringify(result, null, 2));
  const failed =
    errors.length > 0 ||
    !checks.hasManifestLink || !checks.swRegistered || !checks.rootRendered ||
    !offline.rootRendered;
  if (failed) {
    console.error('SMOKE FAILED');
    process.exit(1);
  }
  console.log('SMOKE PASSED');
}

main().catch((e) => { console.error(e); process.exit(1); });
