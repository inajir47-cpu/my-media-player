#!/bin/bash
# Rebuild the My Media (app.mymedia.player) debug APK via the apktool patch route.
# Usage: ./rebuild-apk.sh   (expects ../dist to be the fresh production build)
set -e
cd "$(dirname "$0")"
ANDROID_DIR="$PWD"
export JAVA_HOME=$HOME/workspace/tools/jdk-21
export ANDROID_HOME=$HOME/workspace/tools/android-sdk
export ANDROID_SDK_ROOT=$HOME/workspace/tools/android-sdk
export PATH=$JAVA_HOME/bin:$PATH
BT=$ANDROID_HOME/build-tools/34.0.0
WORK=/tmp/player-apk
APKTOOL=$WORK/apktool.jar
OLD_PKG_DOT="app.mymedia.library"; NEW_PKG_DOT="app.mymedia.player"
OLD_PKG_SLASH="app/mymedia/library"; NEW_PKG_SLASH="app/mymedia/player"

[ -f "$APKTOOL" ] || { echo "missing $APKTOOL"; exit 1; }
rm -rf "$WORK/rebuild" && mkdir -p "$WORK/rebuild"
cd "$WORK/rebuild"
# 1. sync fresh web assets into the android source tree
rm -rf "$ANDROID_DIR/app/src/main/assets/public"
mkdir -p "$ANDROID_DIR/app/src/main/assets/public"
cp -r "$ANDROID_DIR/../dist/." "$ANDROID_DIR/app/src/main/assets/public/"
# 2. decode base APK (last Gradle-built debug APK of the sibling project)
cp "$HOME/workspace/my-media/android/app/build/outputs/apk/debug/app-debug.apk" base.apk
java -jar "$APKTOOL" d -f -o decoded base.apk > /dev/null
cd decoded
# 3. rename package in smali
for d in smali smali_classes2 smali_classes3 smali_classes4 smali_classes5; do
  [ -d "$d/$OLD_PKG_SLASH" ] && mkdir -p "$d/$(dirname $NEW_PKG_SLASH)" && mv "$d/$OLD_PKG_SLASH" "$d/$NEW_PKG_SLASH"
done
grep -rl "$OLD_PKG_SLASH" --include='*.smali' . | xargs sed -i "s|$OLD_PKG_SLASH|$NEW_PKG_SLASH|g"
# 4. manifest + strings + version
sed -i "s|$OLD_PKG_DOT|$NEW_PKG_DOT|g" AndroidManifest.xml
sed -i "s|$OLD_PKG_DOT|$NEW_PKG_DOT|g" res/values/strings.xml
sed -i 's/versionName: .*/versionName: 1.0.0/' apktool.yml
# 5. CRITICAL: requestCodes annotation (base APK predates the Kotlin fix)
python3 - smali_classes4/app/mymedia/player/MediaBridgePlugin.smali <<'PY'
import sys
p = sys.argv[1]
s = open(p).read()
old = '.annotation runtime Lcom/getcapacitor/annotation/CapacitorPlugin;\n    name = "MediaBridge"\n.end annotation'
new = '.annotation runtime Lcom/getcapacitor/annotation/CapacitorPlugin;\n    name = "MediaBridge"\n    requestCodes = {\n        0xb41d\n    }\n.end annotation'
assert old in s, "annotation block not found - base APK may already carry the fix"
open(p, 'w').write(s.replace(old, new))
print("requestCodes annotation patched")
PY
# 6. swap assets (fresh capacitor.config.json + new public/); keep native-bridge.js from base
rm -rf assets
cp -r "$ANDROID_DIR/app/src/main/assets" assets
unzip -o -j ../base.apk assets/native-bridge.js -d /tmp/nb/ > /dev/null
cp /tmp/nb/native-bridge.js assets/native-bridge.js
# 7. rebuild / align / sign
cd ..
java -jar "$APKTOOL" b decoded -o fixed.apk 2>&1 | tail -1
$BT/zipalign -f 4 fixed.apk aligned.apk
$BT/apksigner sign --ks "$ANDROID_DIR/player-debug.keystore" --ks-pass pass:android --key-pass pass:android --out signed.apk aligned.apk
mkdir -p "$ANDROID_DIR/app/build/outputs/apk/debug"
cp signed.apk "$ANDROID_DIR/app/build/outputs/apk/debug/app-debug.apk"
echo "=== badging ==="; $BT/aapt dump badging signed.apk | head -3
echo "=== verify ==="; $BT/apksigner verify --print-certs signed.apk 2>/dev/null | grep -E "Signer #1"
echo "=== sha256 ==="; sha256sum signed.apk
