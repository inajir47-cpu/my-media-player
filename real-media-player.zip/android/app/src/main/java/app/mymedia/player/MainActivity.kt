package app.mymedia.player

import android.os.Bundle
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        registerPlugin(MediaBridgePlugin::class.java)
        super.onCreate(savedInstanceState)
    }
}
